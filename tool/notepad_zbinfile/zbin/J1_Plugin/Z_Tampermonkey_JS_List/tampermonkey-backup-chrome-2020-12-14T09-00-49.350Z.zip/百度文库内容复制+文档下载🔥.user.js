// ==UserScript==
// @name         百度文库内容复制+文档下载🔥
// @namespace    https://www.wenku.zone/
// @version      2.7
// @description  百度文库下载卷文档、共享文档、VIP文档等内容复制
// @author       文库社
// @include      *://wenku.baidu.com/view/*
// @require      https://cdn.bootcss.com/jquery/2.1.2/jquery.min.js
// @require      https://cdn.jsdelivr.net/npm/clipboard@2/dist/clipboard.min.js
// ==/UserScript==

(function() {
    'use strict';
    var url = window.location.href;
        url = encodeURIComponent(url);
    var urlFree = 'http://www.wenku.zone/?from=youhou&url=' + url;
    var urlPro =  'http://pro.wenku.zone/?from=youhou&url=' + url;

    function addBtn1(){
                var doc_tag_wrap = $(".doc-tag-wrap");
                if(doc_tag_wrap && doc_tag_wrap.length){
                   var download = "<div id='wenkudownload-wenkushe'style='display: block;line-height: 40px; text-align: center;vertical-align: top; background-color: #EB5B3B; cursor: pointer; color: #fff;margin-bottom: 20px;z-index:9999;'><a href='"
                   +urlFree+"' target='_blank' style='font-size:16px;color:#fff;display: block; height: 100%; padding: 2px 10px;z-index:9999;'>下载此文档</a></div>";
                   $(".doc-tag-wrap").prepend(download);
                }else{
                  var download2 = "<div id='wenkudownload-wenkushe'style='display: block;line-height: 40px; text-align: center; vertical-align: top;background-color: #EB5B3B; cursor: pointer; color: #fff; margin-bottom: 20px; position: fixed; left: 0; top: 260px; width: 83px; z-index: 9999; '><a href='"
                  +urlFree+"' target='_blank' style='font-size:16px;color:#fff;display: block; height: 100%; padding: 2px 10px;'>下载此文档</a></div>";
                  $("body").append(download2);
                };
    }
     function addBtn2(){
                var doc_tag_wrap = $(".doc-info-right");
                if(doc_tag_wrap && doc_tag_wrap.length){
                   var download = "<div id='wenkudownload-wenkushe-pro'style='display: block;line-height: 40px; text-align: center; vertical-align: top; background-color: #25ae84; cursor: pointer; color: #fff;margin-bottom: 2px;z-index:9999;'><a href='"
                   +urlPro+"' target='_blank' style='font-size:16px;color:#fff;display: block; height: 100%; padding: 2px 10px;'>下载此文档</a></div>";
                   doc_tag_wrap.append(download);
                }else{
                  var download2 = "<div id='wenkudownload-wenkushe-pro'style='display: block;line-height: 40px; text-align: center; vertical-align: top; background-color: #25ae84; cursor: pointer; color: #fff; margin-bottom: 2px; position: fixed; left: 0; top: 358px; width: 83px; z-index: 9999;'><a href='"
                  +urlPro+"' target='_blank' style='font-size:16px;color:#fff;display: block; height: 100%; padding: 2px 10px;'>下载此文档</a></div>";
                  $("body").append(download2);
                };
    }



    addBtn2();

  var css_buttom = "#_copy{width:70px;height:40px;background:red;color:#fff;position:absolute;z-index:1000;display:flex;justify-content:center;align-items:center;border-radius:3px;font-size:13px;cursor:pointer}#select-tooltip,#sfModal,.modal-backdrop,div[id^=reader-helper]{display:none!important}.modal-open{overflow:auto!important}._sf_adjust_body{padding-right:0!important}";

  function styleInit(css, ref) {
    if (ref === void 0) ref = {};
    var insertAt = ref.insertAt;
    if (!css || typeof document === 'undefined') {
      return;
    }
    var head = document.head || document.getElementsByTagName('head')[0];
    var style = document.createElement('style');
    style.type = 'text/css';

    if (insertAt === 'top') {
      if (head.firstChild) {
        head.insertBefore(style, head.firstChild);
      } else {
        head.appendChild(style);
      }
    } else {
      head.appendChild(style);
    }

    if (style.styleSheet) {
      style.styleSheet.cssText = css;
    } else {
      style.appendChild(document.createTextNode(css));
    }
  }

  styleInit(css_buttom);

  function initEvent($, ClipboardJS) {
    $("body").on("mousedown", function (e) {
      $("#_copy").remove();
    });

    document.oncopy = function () {};

    $("body").on("copy", function (e) {
      e.stopPropagation();
      return true;
    });
    ClipboardJS.prototype.on('success', function (e) {
      $("#_copy").html("复制成功");
      setTimeout(function () {
        return $("#_copy").fadeOut(1000);
      }, 1000);
      e.clearSelection();
    });
    ClipboardJS.prototype.on('error', function (e) {
      $("#_copy").html("复制失败");
      setTimeout(function () {
        return $("#_copy").fadeOut(1000);
      }, 1000);
      e.clearSelection();
    });
  }

  var path = "";
  function getSelectedText() {
    var select = unsafeWindow;
    path.split(".").forEach(function (v) {
      select = select[v];
    });
    return select;
  }

  function init$1($) {
    $(window).on("load", function (e) {
      $(".sf-edu-wenku-vw-container").attr("style", "");
      $(".sfa-body").on("selectstart", function (e) {
        e.stopPropagation();
        return true;
      });
    });
  }

  function getSelectedText$1() {
    if (unsafeWindow.pad) {
      unsafeWindow.pad.editor.clipboardManager.copy();
      return unsafeWindow.pad.editor.clipboardManager.customClipboard.plain;
    }

    return void 0;
  }

  var siteGetSelectedText = null;
  function initWebsite($, ClipboardJS) {
    var mather = function mather(regex, site) {
      if (regex.test(window.location.href)) {
        for (var _len = arguments.length, args = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) {
          args[_key - 2] = arguments[_key];
        }

        site.init.apply(site, args);
        if (site.getSelectedText) siteGetSelectedText = site.getSelectedText;
      }
    };
    mather(/.*wk\.baidu\.com\/view\/.+/, { init: init$1 }, $);
  }

  function getSelectedText$2() {
    if (siteGetSelectedText) return siteGetSelectedText();
    if (window.getSelection) return window.getSelection().toString();else if (document.getSelection) return document.getSelection();else if (document.selection) return document.selection.createRange().text;
    return "";
  }

  (function () {
    var $ = window.$;
    var ClipboardJS = window.ClipboardJS; // https://clipboardjs.com/#example-text

    initEvent($, ClipboardJS);
    initWebsite($);
    document.addEventListener("mouseup", function (e) {
      var copyText = getSelectedText$2();
      if (copyText) console.log(copyText);else return "";
      $("#_copy").remove();
      var template = "\n            <div id=\"_copy\"\n            style=\"left:".concat(e.pageX + 30, "px;top:").concat(e.pageY, "px;\"\n            data-clipboard-text=\"").concat(copyText, "\">\u590D\u5236</div>\n        ");
      $("body").append(template);
      $("#_copy").on("mousedown", function (event) {
        event.stopPropagation();
      });
      $("#_copy").on("mouseup", function (event) {
        event.stopPropagation();
      });
      new ClipboardJS('#_copy');
    });
  })();



})();