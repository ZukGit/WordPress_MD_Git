// ==UserScript==
// @name         显示当前网站所有可用的油猴脚本【持续更新，放心使用！】
// @name:zh      显示当前网站所有可用的油猴脚本【持续更新，放心使用！】
// @name:zh-CN   显示当前网站所有可用的油猴脚本【持续更新，放心使用！】
// @name:zh-TW   顯示當前網站所有可用的油猴腳本【持續更新，放心使用！】
// @homepage     https://greasyfork.org/zh-CN/scripts/403916-%E6%98%BE%E7%A4%BA%E5%BD%93%E5%89%8D%E7%BD%91%E7%AB%99%E6%89%80%E6%9C%89%E5%8F%AF%E7%94%A8%E7%9A%84%E6%B2%B9%E7%8C%B4%E8%84%9A%E6%9C%AC-%E6%8C%81%E7%BB%AD%E6%9B%B4%E6%96%B0-%E6%94%BE%E5%BF%83%E4%BD%BF%E7%94%A8
// @namespace    https://greasyfork.org/zh-CN/users/33431-chenshao
// @version      1.0.3.1
// @description         This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @description:zh      显示适用于当前网站所有可用的油猴脚本【持续更新，放心使用！】
// @description:zh-CN   显示适用于当前网站所有可用的油猴脚本【持续更新，放心使用！】
// @description:zh-TW   顯示適用於當前網站所有可用的油猴腳本【持續更新，放心使用！】
// @author       ChenShao(chenshao@qq.com)
// @match        *://*/*
// @grant        GM_xmlHttpRequest
// @grant        GM_getResourceText
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_addStyle
// @grant        GM_deleteValue
// @grant        GM_registerMenuCommand
// @grant        GM_openInTab
// @grant        unsafeWindow
// @connect      greasyfork.org
// @run-at       document-end
// ==/UserScript==
