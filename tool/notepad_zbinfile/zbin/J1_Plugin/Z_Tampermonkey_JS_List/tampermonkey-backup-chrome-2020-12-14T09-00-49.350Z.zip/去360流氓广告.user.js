// ==UserScript==
// @name         去360流氓广告
// @namespace    http://tampermonkey.net/
// @version      0.1测试版
// @description  这个脚本可以让你浏览360流氓时不会看到那些烦人的广告。
// @author       Google
// @match        https://hao.360.com/
// @match        https://www.so.com/*
// @grant        note
// @note         v0.1 360首页界可以拦截全部广告，但是有些广告清理速度有点慢要等一会。搜索界面有时候能拦截广告有时候不行，因为这个脚本有时候不会工作。十分不稳定。
// @require      https://apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js
// ==/UserScript==

(function() {
    console.log("这是测试")
    $("#doc-main-bd").remove();
    $("#service-relax").remove();
    $("#service-video").remove();
    $("#service-gouwu").remove();
    $("#service-youxi").remove();
    $("#localcity").remove();
    $("#service-licai").remove();
    $("#info-flow").remove();
    $("#side").remove();
    $("#").remove();
    $("#").remove();
    $("#").remove();
    $("#").remove();
    $("#").remove();
    setTimeout(function(){
        console.log("This is 4秒后测试")
        $("#corner-flash").remove();
        $("#doc-view-front").remove();
        $("#").remove();
    },4000)
})();