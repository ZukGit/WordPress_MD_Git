// ==UserScript==
// @name         页面平滑滚动
// @namespace    http://tampermonkey.net/
// @icon         https://www.easyicon.net/download/ico/543226/64/
// @version      0.2
// @description 让页面不掉帧的平滑滚动
// @author       PAINCLOWN
// @run-at       document-start
// @resource smscl     https://cdn.bootcss.com/smoothscroll/1.4.9/SmoothScroll.min.js
// @grant        GM_addStyle
// @grant        GM_registerMenuCommand
// @grant        GM_setValue
// @grant        GM_getValue
// @grant        GM_getResourceText
// @include        *
// ==/UserScript==

(function() {
    var scr = document.createElement('script');
    scr.type = 'text/javascript';
    scr.textContent = GM_getResourceText('smscl')
    document.head.appendChild(scr);

})();